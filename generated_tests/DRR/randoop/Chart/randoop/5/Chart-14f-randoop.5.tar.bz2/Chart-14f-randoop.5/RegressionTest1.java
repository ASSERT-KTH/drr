import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace5);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setRangeCrosshairValue((double) 0.0f);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot0.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot13.getDomainAxisLocation();
        boolean boolean15 = xYPlot13.isRangeGridlinesVisible();
        boolean boolean16 = xYPlot13.isOutlineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot13.getOrientation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        xYPlot13.notifyListeners(plotChangeEvent18);
        java.awt.geom.Point2D point2D20 = xYPlot13.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D20);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(point2D20);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (double) 0.5f, 0.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset((int) (byte) 1, xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot25.setWeight((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder47);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint51 = xYPlot50.getDomainGridlinePaint();
        java.awt.Stroke stroke52 = xYPlot50.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot50.zoomDomainAxes((double) (short) 10, plotRenderingInfo54, point2D55);
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint58 = xYPlot57.getDomainGridlinePaint();
        java.awt.Stroke stroke59 = xYPlot57.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
        double double67 = categoryAxis62.getCategoryEnd(0, (int) (short) 0, rectangle2D65, rectangleEdge66);
        categoryAxis62.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double71 = rectangleInsets70.getBottom();
        double double73 = rectangleInsets70.extendHeight((double) (short) 0);
        double double75 = rectangleInsets70.calculateRightInset((double) 8);
        categoryAxis62.setTickLabelInsets(rectangleInsets70);
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape79 = numberAxis78.getUpArrow();
        numberAxis78.setTickMarksVisible(false);
        double double82 = numberAxis78.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = numberAxis78.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer84 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis62, (org.jfree.chart.axis.ValueAxis) numberAxis78, categoryItemRenderer84);
        java.awt.Stroke stroke86 = categoryPlot85.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot85.setRangeAxisLocation(axisLocation87, true);
        xYPlot57.setRangeAxisLocation(axisLocation87);
        xYPlot50.setDomainAxisLocation(axisLocation87, true);
        categoryPlot25.setDomainAxisLocation(500, axisLocation87);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 4.0d + "'", double71 == 4.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 8.0d + "'", double73 == 8.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 8.0d + "'", double75 == 8.0d);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.05d + "'", double82 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets83);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(axisLocation87);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLowerMargin((double) '4');
        categoryAxis1.setVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        float float25 = xYPlot24.getForegroundAlpha();
        java.awt.Color color28 = java.awt.Color.darkGray;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color28, stroke29);
        categoryMarker30.setLabel("hi!");
        categoryMarker30.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color36 = java.awt.Color.darkGray;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color36, stroke37);
        categoryMarker38.setLabel("hi!");
        java.awt.Color color42 = java.awt.Color.darkGray;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color42, stroke43);
        categoryMarker38.setStroke(stroke43);
        categoryMarker30.setStroke(stroke43);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean49 = xYPlot24.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker30, layer47, true);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot24.setDataset(xYDataset50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        xYPlot24.drawAnnotations(graphics2D52, rectangle2D53, plotRenderingInfo54);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot24.getRangeAxisEdge();
        try {
            double double57 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT", (java.lang.Comparable) 10, categoryDataset21, (double) (byte) 1, rectangle2D23, rectangleEdge56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleEdge56);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 10);
        double double4 = rectangleInsets0.calculateTopOutset((-1.0d));
        double double6 = rectangleInsets0.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.centerRange((double) (byte) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(numberTickUnit6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        categoryPlot25.configureDomainAxes();
        int int48 = categoryPlot25.getWeight();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis27.getCategoryEnd(0, (int) (short) 0, rectangle2D30, rectangleEdge31);
        categoryAxis27.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double36 = rectangleInsets35.getBottom();
        double double38 = rectangleInsets35.extendHeight((double) (short) 0);
        double double40 = rectangleInsets35.calculateRightInset((double) 8);
        categoryAxis27.setTickLabelInsets(rectangleInsets35);
        xYPlot0.setAxisOffset(rectangleInsets35);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        float float44 = xYPlot43.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = xYPlot43.getAxisOffset();
        double double47 = rectangleInsets45.extendWidth((double) ' ');
        xYPlot0.setInsets(rectangleInsets45);
        double double50 = rectangleInsets45.calculateRightOutset(1.0E-8d);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 8.0d + "'", double38 == 8.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 8.0d + "'", double40 == 8.0d);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 40.0d + "'", double47 == 40.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        xYPlot0.setRangeAxis(valueAxis2);
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, (int) 'a');
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        xYPlot0.setDomainCrosshairValue((double) (short) 1, false);
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        int int2 = objectList1.size();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        int int4 = objectList1.indexOf((java.lang.Object) color3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean6 = objectList1.equals((java.lang.Object) timeZone5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot25.getRendererForDataset(categoryDataset35);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNull(categoryItemRenderer36);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis1.isTickMarksVisible();
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setVerticalTickLabels(true);
        boolean boolean8 = numberAxis1.isVerticalTickLabels();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (byte) 100, (float) (short) 1, (float) '4');
        numberAxis1.setLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = numberAxis1.isAxisLineVisible();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        float float16 = xYPlot15.getForegroundAlpha();
        java.awt.Color color19 = java.awt.Color.darkGray;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color19, stroke20);
        categoryMarker21.setLabel("hi!");
        categoryMarker21.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color27 = java.awt.Color.darkGray;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color27, stroke28);
        categoryMarker29.setLabel("hi!");
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker29.setStroke(stroke34);
        categoryMarker21.setStroke(stroke34);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean40 = xYPlot15.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker21, layer38, true);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        xYPlot15.setDataset(xYDataset41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        xYPlot15.drawAnnotations(graphics2D43, rectangle2D44, plotRenderingInfo45);
        boolean boolean47 = xYPlot15.isDomainCrosshairVisible();
        boolean boolean48 = xYPlot15.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        double double52 = intervalMarker51.getStartValue();
        double double53 = intervalMarker51.getStartValue();
        xYPlot15.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker51);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-1.0d) + "'", double52 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-1.0d) + "'", double53 == (-1.0d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis27.getCategoryEnd(0, (int) (short) 0, rectangle2D30, rectangleEdge31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        java.lang.String str41 = categoryAxis34.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis34.getCategoryJava2DCoordinate(categoryAnchor42, 64, (int) (byte) 0, rectangle2D45, rectangleEdge46);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray48 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis27, categoryAxis34 };
        categoryPlot25.setDomainAxes(categoryAxisArray48);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAxisArray48);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight((double) (short) 0);
        double double5 = rectangleInsets0.calculateRightInset((double) 8);
        double double7 = rectangleInsets0.calculateBottomOutset((double) 100);
        double double9 = rectangleInsets0.extendHeight((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 18.0d + "'", double9 == 18.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets9.getBottom();
        double double12 = rectangleInsets9.extendHeight((double) (short) 0);
        double double14 = rectangleInsets9.calculateRightInset((double) 8);
        categoryAxis1.setTickLabelInsets(rectangleInsets9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets16.getRight();
        categoryAxis1.setLabelInsets(rectangleInsets16);
        double double19 = categoryAxis1.getFixedDimension();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        float float22 = xYPlot21.getForegroundAlpha();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d);
        xYPlot21.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker24);
        java.awt.Image image26 = xYPlot21.getBackgroundImage();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace30 = categoryAxis1.reserveSpace(graphics2D20, (org.jfree.chart.plot.Plot) xYPlot21, rectangle2D27, rectangleEdge28, axisSpace29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNull(image26);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        boolean boolean2 = xYPlot0.isDomainCrosshairVisible();
        xYPlot0.clearAnnotations();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = java.awt.Color.RED;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        float float4 = xYPlot3.getForegroundAlpha();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker9.setLabel("hi!");
        categoryMarker9.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color15, stroke16);
        categoryMarker17.setLabel("hi!");
        java.awt.Color color21 = java.awt.Color.darkGray;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color21, stroke22);
        categoryMarker17.setStroke(stroke22);
        categoryMarker9.setStroke(stroke22);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean28 = xYPlot3.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker9, layer26, true);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot3.setDataset(xYDataset29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot3.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        boolean boolean35 = xYPlot3.isDomainCrosshairVisible();
        boolean boolean36 = xYPlot3.isDomainZeroBaselineVisible();
        boolean boolean37 = categoryAxis0.equals((java.lang.Object) xYPlot3);
        int int38 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setLowerMargin((double) (short) 10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean33 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            xYPlot0.handleClick(7, (int) '#', plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int3 = java.awt.Color.HSBtoRGB((float) 43629L, (float) 6, (float) 500);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-14907) + "'", int3 == (-14907));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLabel("RectangleAnchor.TOP_LEFT");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        double double20 = dateAxis17.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date25 = dateAxis21.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis17.dateToJava2D(date25, rectangle2D26, rectangleEdge27);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) double28);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions30 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource5);
        java.awt.Color color7 = java.awt.Color.pink;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis14.getCategoryEnd(0, (int) (short) 0, rectangle2D17, rectangleEdge18);
        categoryAxis14.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double23 = rectangleInsets22.getBottom();
        double double25 = rectangleInsets22.extendHeight((double) (short) 0);
        double double27 = rectangleInsets22.calculateRightInset((double) 8);
        categoryAxis14.setTickLabelInsets(rectangleInsets22);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape31 = numberAxis30.getUpArrow();
        numberAxis30.setTickMarksVisible(false);
        double double34 = numberAxis30.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis30.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer36);
        java.awt.Stroke stroke38 = categoryPlot37.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot37.setRangeAxisLocation(axisLocation39, true);
        java.lang.String str42 = axisLocation39.toString();
        xYPlot9.setDomainAxisLocation(500, axisLocation39);
        java.awt.Paint paint44 = xYPlot9.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        float float46 = xYPlot45.getForegroundAlpha();
        java.awt.Color color49 = java.awt.Color.darkGray;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color49, stroke50);
        categoryMarker51.setLabel("hi!");
        categoryMarker51.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color57 = java.awt.Color.darkGray;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color57, stroke58);
        categoryMarker59.setLabel("hi!");
        java.awt.Color color63 = java.awt.Color.darkGray;
        java.awt.Stroke stroke64 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color63, stroke64);
        categoryMarker59.setStroke(stroke64);
        categoryMarker51.setStroke(stroke64);
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean70 = xYPlot45.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker51, layer68, true);
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        xYPlot45.setDataset(xYDataset71);
        java.awt.Graphics2D graphics2D73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        xYPlot45.drawAnnotations(graphics2D73, rectangle2D74, plotRenderingInfo75);
        java.awt.Stroke stroke77 = xYPlot45.getDomainZeroBaselineStroke();
        xYPlot9.setDomainGridlineStroke(stroke77);
        java.awt.Color color80 = java.awt.Color.darkGray;
        java.awt.Stroke stroke81 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker82 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color80, stroke81);
        java.awt.Paint paint83 = categoryMarker82.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot84 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        xYPlot84.drawAnnotations(graphics2D85, rectangle2D86, plotRenderingInfo87);
        org.jfree.chart.axis.AxisSpace axisSpace89 = null;
        xYPlot84.setFixedDomainAxisSpace(axisSpace89);
        java.awt.Stroke stroke91 = xYPlot84.getDomainCrosshairStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker93 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10, (java.awt.Paint) color7, stroke77, paint83, stroke91, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 8.0d + "'", double27 == 8.0d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str42.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 1.0f + "'", float46 == 1.0f);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(stroke91);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        org.jfree.data.Range range13 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot14 = numberAxis1.getPlot();
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        java.lang.String str7 = dateAxis6.getLabel();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot25.getDataset();
        java.util.List list31 = categoryPlot25.getAnnotations();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]", timeZone3);
        boolean boolean7 = dateAxis6.isAutoRange();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        boolean boolean30 = categoryPlot25.isDomainGridlinesVisible();
        categoryPlot25.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot25.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(categoryAnchor33);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = categoryMarker3.getLabelOffsetType();
        java.lang.String str7 = lengthAdjustmentType6.toString();
        java.lang.String str8 = lengthAdjustmentType6.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "EXPAND" + "'", str7.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "EXPAND" + "'", str8.equals("EXPAND"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        dateAxis0.setRange((double) 10L, (double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis0.valueToJava2D((double) 10L, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis0.setTickUnit(dateTickUnit10);
        dateAxis0.setUpperMargin((double) 1560495599999L);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        categoryMarker5.setLabel("hi!");
        categoryMarker5.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color11, stroke12);
        categoryMarker13.setLabel("hi!");
        java.awt.Color color17 = java.awt.Color.darkGray;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color17, stroke18);
        categoryMarker13.setStroke(stroke18);
        categoryMarker5.setStroke(stroke18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        java.awt.Stroke stroke26 = intervalMarker25.getStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.RIGHT", (java.awt.Paint) color1, stroke18, (java.awt.Paint) color22, stroke26, (float) (-123));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        boolean boolean2 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot3.getDomainAxisLocation();
        java.awt.Image image5 = null;
        xYPlot3.setBackgroundImage(image5);
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color8, stroke9);
        categoryMarker10.setLabel("hi!");
        categoryMarker10.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color16, stroke17);
        categoryMarker18.setLabel("hi!");
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color22, stroke23);
        categoryMarker18.setStroke(stroke23);
        categoryMarker10.setStroke(stroke23);
        xYPlot3.setDomainZeroBaselineStroke(stroke23);
        xYPlot0.setDomainZeroBaselineStroke(stroke23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset(1.0E-8d);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.awt.Paint paint3 = dateAxis0.getLabelPaint();
        java.awt.Paint paint4 = dateAxis0.getAxisLinePaint();
        double double5 = dateAxis0.getUpperBound();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot25.setRowRenderingOrder(sortOrder28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.lang.Object obj34 = numberAxis31.clone();
        org.jfree.chart.event.AxisChangeListener axisChangeListener35 = null;
        numberAxis31.addChangeListener(axisChangeListener35);
        boolean boolean37 = sortOrder28.equals((java.lang.Object) numberAxis31);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis39.setAutoRangeIncludesZero(false);
        java.awt.Color color42 = java.awt.Color.darkGray;
        numberAxis39.setAxisLinePaint((java.awt.Paint) color42);
        boolean boolean44 = sortOrder28.equals((java.lang.Object) color42);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis7.getCategoryEnd(0, (int) (short) 0, rectangle2D10, rectangleEdge11);
        categoryAxis7.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double16 = rectangleInsets15.getBottom();
        double double18 = rectangleInsets15.extendHeight((double) (short) 0);
        double double20 = rectangleInsets15.calculateRightInset((double) 8);
        categoryAxis7.setTickLabelInsets(rectangleInsets15);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape24 = numberAxis23.getUpArrow();
        numberAxis23.setTickMarksVisible(false);
        double double27 = numberAxis23.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis23.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer29);
        java.awt.Stroke stroke31 = categoryPlot30.getDomainGridlineStroke();
        int int32 = categoryPlot30.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot30.getLegendItems();
        boolean boolean34 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getRangeAxisEdge((int) 'a');
        try {
            double double37 = dateAxis0.lengthToJava2D(1.0E-8d, rectangle2D4, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        categoryPlot25.drawBackgroundImage(graphics2D47, rectangle2D48);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList((int) '4');
        int int4 = objectList3.size();
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        int int6 = objectList3.indexOf((java.lang.Object) color5);
        java.awt.Stroke stroke7 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int9 = color8.getTransparency();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj15 = categoryAxis14.clone();
        double double16 = categoryAxis14.getFixedDimension();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis14.setLabelFont(font17);
        java.awt.Stroke stroke19 = categoryAxis14.getAxisLineStroke();
        intervalMarker12.setStroke(stroke19);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 0.5f, (-1.0d), (java.awt.Paint) color5, stroke7, (java.awt.Paint) color8, stroke19, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis33.getCategoryEnd(0, (int) (short) 0, rectangle2D36, rectangleEdge37);
        categoryAxis33.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double42 = rectangleInsets41.getBottom();
        double double44 = rectangleInsets41.extendHeight((double) (short) 0);
        double double46 = rectangleInsets41.calculateRightInset((double) 8);
        categoryAxis33.setTickLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape50 = numberAxis49.getUpArrow();
        numberAxis49.setTickMarksVisible(false);
        double double53 = numberAxis49.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = numberAxis49.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis49, categoryItemRenderer55);
        java.awt.Stroke stroke57 = categoryPlot56.getDomainGridlineStroke();
        int int58 = categoryPlot56.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection59 = categoryPlot56.getLegendItems();
        boolean boolean60 = categoryPlot25.equals((java.lang.Object) legendItemCollection59);
        categoryPlot25.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 8.0d + "'", double44 == 8.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        xYPlot0.setNoDataMessageFont(font51);
        java.awt.Paint paint53 = null;
        xYPlot0.setRangeTickBandPaint(paint53);
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight(10.0d);
        double double5 = rectangleInsets0.calculateLeftInset((-1.0d));
        double double7 = rectangleInsets0.calculateLeftInset((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        valueMarker1.setValue(100.0d);
        double double4 = valueMarker1.getValue();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getDomainAxisLocation();
        boolean boolean7 = xYPlot5.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = xYPlot5.getRangeMarkers(layer8);
        java.awt.Paint paint10 = xYPlot5.getDomainZeroBaselinePaint();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot5);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!", timeZone13);
        dateAxis14.setLabelURL("");
        java.awt.Shape shape17 = dateAxis14.getRightArrow();
        int int18 = xYPlot5.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        boolean boolean27 = categoryPlot25.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot25.setDomainAxis((int) (byte) 0, categoryAxis29, true);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot25.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(valueAxis32);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = xYPlot0.getOrientation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder61 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertNotNull(datasetRenderingOrder61);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke6);
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryMarker3.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot1.getDomainAxisLocation();
        boolean boolean3 = xYPlot1.isRangeGridlinesVisible();
        boolean boolean4 = xYPlot1.isOutlineVisible();
        boolean boolean5 = categoryAnchor0.equals((java.lang.Object) xYPlot1);
        xYPlot1.zoom((double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot8.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        int int11 = xYPlot8.indexOf(xYDataset10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot8.setFixedDomainAxisSpace(axisSpace12, false);
        boolean boolean15 = xYPlot8.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = xYPlot8.getLegendItems();
        xYPlot1.setFixedLegendItems(legendItemCollection16);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(legendItemCollection16);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setAutoRangeIncludesZero(false);
        java.awt.Color color5 = java.awt.Color.darkGray;
        numberAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = numberAxis2.clone();
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis2.setTickMarkPaint(paint8);
        java.text.NumberFormat numberFormat10 = null;
        numberAxis2.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis2.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis2.setStandardTickUnits(tickUnitSource13);
        boolean boolean15 = dateAxis0.equals((java.lang.Object) tickUnitSource13);
        dateAxis0.setLowerBound(0.0d);
        java.text.DateFormat dateFormat18 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis0.setTimeline(timeline19);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(dateFormat18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLowerMargin((double) '4');
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (-1));
        double double19 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (short) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        categoryPlot25.clearDomainMarkers((int) (short) 1);
        categoryPlot25.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.axis.AxisSpace axisSpace66 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace66, false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke2 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        xYPlot0.setRangeAxisLocation(axisLocation30);
        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation30.getOpposite();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        org.jfree.data.Range range13 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot14 = numberAxis1.getPlot();
        boolean boolean15 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        double double11 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setUpperMargin(0.05d);
        boolean boolean14 = xYPlot0.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint16 = xYPlot15.getDomainGridlinePaint();
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker20.setLabel("hi!");
        boolean boolean23 = xYPlot15.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker20);
        categoryMarker20.setLabel("DatasetRenderingOrder.FORWARD");
        boolean boolean26 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        java.lang.Object obj3 = datasetChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = categoryAxis1.clone();
        double double3 = categoryAxis1.getFixedDimension();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setLabelFont(font4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setUpperMargin((double) 10);
        numberAxis7.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis7.getTickLabelInsets();
        double double15 = rectangleInsets13.calculateRightOutset((double) (short) 0);
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        double double8 = numberAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = dateAxis0.hasListener(eventListener6);
        java.awt.Shape shape8 = dateAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (byte) -1);
        categoryAxis1.setLowerMargin((double) 10L);
        categoryAxis1.setLabel("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        boolean boolean2 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainGridlinePaint();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color10, stroke11);
        categoryMarker12.setLabel("hi!");
        boolean boolean15 = xYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryMarker12.setLabel("DatasetRenderingOrder.FORWARD");
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker12, layer18, true);
        boolean boolean21 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        categoryPlot25.clearAnnotations();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis32.getCategoryEnd(0, (int) (short) 0, rectangle2D35, rectangleEdge36);
        categoryAxis32.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double41 = rectangleInsets40.getBottom();
        double double43 = rectangleInsets40.extendHeight((double) (short) 0);
        double double45 = rectangleInsets40.calculateRightInset((double) 8);
        categoryAxis32.setTickLabelInsets(rectangleInsets40);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape49 = numberAxis48.getUpArrow();
        numberAxis48.setTickMarksVisible(false);
        double double52 = numberAxis48.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = numberAxis48.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis48, categoryItemRenderer54);
        java.awt.Stroke stroke56 = categoryPlot55.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot55.setRangeAxisLocation(axisLocation57, true);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis61.setAutoRangeIncludesZero(false);
        java.awt.Color color64 = java.awt.Color.darkGray;
        numberAxis61.setAxisLinePaint((java.awt.Paint) color64);
        numberAxis61.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.axis.AxisState axisState69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        java.util.List list72 = numberAxis61.refreshTicks(graphics2D68, axisState69, rectangle2D70, rectangleEdge71);
        java.awt.Paint paint73 = numberAxis61.getTickMarkPaint();
        categoryPlot55.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis61);
        categoryPlot55.setWeight((int) (byte) -1);
        java.awt.Color color78 = java.awt.Color.darkGray;
        java.awt.Stroke stroke79 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker80 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color78, stroke79);
        categoryMarker80.setLabel("hi!");
        java.awt.Stroke stroke83 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker80.setStroke(stroke83);
        java.awt.Paint paint85 = categoryMarker80.getPaint();
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation87 = xYPlot86.getDomainAxisLocation();
        boolean boolean88 = xYPlot86.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer89 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection90 = xYPlot86.getRangeMarkers(layer89);
        boolean boolean91 = categoryPlot55.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker80, layer89);
        boolean boolean92 = categoryPlot25.removeDomainMarker(0, marker29, layer89);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 8.0d + "'", double43 == 8.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.05d + "'", double52 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(list72);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(layer89);
        org.junit.Assert.assertNull(collection90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        xYPlot0.clearRangeMarkers((int) (short) -1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        boolean boolean10 = xYPlot0.equals((java.lang.Object) date7);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(9, axisLocation38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis41.getCategoryEnd(0, (int) (short) 0, rectangle2D44, rectangleEdge45);
        double double47 = categoryAxis41.getCategoryMargin();
        categoryPlot25.setDomainAxis(categoryAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace49 = categoryPlot25.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.2d + "'", double47 == 0.2d);
        org.junit.Assert.assertNull(axisSpace49);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot25.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot25.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        categoryPlot25.zoomDomainAxes((double) 1L, plotRenderingInfo50, point2D51);
        java.awt.Paint paint53 = null;
        try {
            categoryPlot25.setRangeCrosshairPaint(paint53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(valueAxis47);
        org.junit.Assert.assertNotNull(plotOrientation48);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = categoryPlot25.getDrawingSupplier();
        java.awt.Paint paint37 = categoryPlot25.getDomainGridlinePaint();
        categoryPlot25.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(drawingSupplier36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        boolean boolean8 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker7);
        try {
            java.awt.Paint paint10 = xYPlot0.getQuadrantPaint((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (52) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) numberAxis1, dataset13);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets6.createInsetRectangle(rectangle2D7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        xYPlot0.setRangeGridlinePaint(paint4);
        try {
            java.awt.Paint paint7 = xYPlot0.getQuadrantPaint((-123));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-123) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        categoryPlot25.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot25.setDomainAxis(15, categoryAxis29);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        org.jfree.data.Range range13 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1, jFreeChart14);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis1.setNumberFormatOverride(numberFormat16);
        double double18 = numberAxis1.getLabelAngle();
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis1.removeChangeListener(axisChangeListener19);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setMaximumCategoryLabelLines(6);
        java.lang.Object obj9 = categoryAxis1.clone();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color0 = java.awt.Color.BLACK;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis24.setAutoRangeIncludesZero(false);
        java.awt.Color color27 = java.awt.Color.darkGray;
        numberAxis24.setAxisLinePaint((java.awt.Paint) color27);
        categoryMarker6.setPaint((java.awt.Paint) color27);
        int int30 = color27.getTransparency();
        java.awt.Color color31 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray39 = new float[] { (byte) 10, 100, (byte) -1, (byte) 100 };
        float[] floatArray40 = java.awt.Color.RGBtoHSB(0, (int) (byte) 1, (int) (byte) 10, floatArray39);
        float[] floatArray41 = color31.getComponents(floatArray40);
        float[] floatArray42 = color27.getColorComponents(floatArray41);
        float[] floatArray43 = color0.getRGBColorComponents(floatArray42);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        float float6 = xYPlot5.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot5.getAxisOffset();
        double double9 = rectangleInsets7.calculateTopOutset((double) (byte) 100);
        valueMarker3.setLabelOffset(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = dateAxis0.hasListener(eventListener6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setAutoRangeIncludesZero(false);
        java.awt.Color color12 = java.awt.Color.darkGray;
        numberAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.lang.Object obj14 = numberAxis9.clone();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis9.setTickMarkPaint(paint15);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis9.setNumberFormatOverride(numberFormat17);
        boolean boolean19 = numberAxis9.isAutoRange();
        java.awt.Shape shape20 = numberAxis9.getLeftArrow();
        org.jfree.data.Range range21 = numberAxis9.getDefaultAutoRange();
        dateAxis0.setRange(range21, false, true);
        org.jfree.chart.plot.Plot plot25 = dateAxis0.getPlot();
        boolean boolean27 = dateAxis0.isHiddenValue((long) 5);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        boolean boolean45 = categoryPlot25.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        boolean boolean2 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainGridlinePaint();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color10, stroke11);
        categoryMarker12.setLabel("hi!");
        boolean boolean15 = xYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker12);
        categoryMarker12.setLabel("DatasetRenderingOrder.FORWARD");
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker12, layer18, true);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(layer18);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        numberAxis1.setPositiveArrowVisible(true);
        double double10 = numberAxis1.getUpperMargin();
        java.text.NumberFormat numberFormat11 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertNull(numberFormat11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot0.getDomainAxisLocation((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot0.getRangeAxisLocation(0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        int int27 = categoryPlot25.getWeight();
        double double28 = categoryPlot25.getAnchorValue();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 255, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setTickLabelsVisible(true);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        boolean boolean5 = datasetRenderingOrder0.equals((java.lang.Object) dateAxis1);
        java.lang.String str6 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str6.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        float float3 = xYPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder4);
        java.lang.String str6 = seriesRenderingOrder4.toString();
        java.lang.String str7 = seriesRenderingOrder4.toString();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str6.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str7.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker4.setLabelTextAnchor(textAnchor5);
        valueMarker4.setAlpha((float) (byte) 0);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker4.getLabelOffsetType();
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color11, stroke12);
        categoryMarker13.setLabel("hi!");
        java.awt.Color color17 = java.awt.Color.darkGray;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color17, stroke18);
        categoryMarker13.setStroke(stroke18);
        categoryMarker13.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint23 = categoryMarker13.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = categoryMarker13.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets0.createAdjustedRectangle(rectangle2D2, lengthAdjustmentType9, lengthAdjustmentType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot25.getRangeAxis((int) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        java.lang.String str41 = categoryAxis34.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis34.getCategoryJava2DCoordinate(categoryAnchor42, 64, (int) (byte) 0, rectangle2D45, rectangleEdge46);
        categoryAxis34.setLowerMargin((double) '4');
        try {
            categoryPlot25.setDomainAxis((-14907), categoryAxis34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint7 = xYPlot6.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = xYPlot6.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot6.zoomDomainAxes((double) (short) 10, plotRenderingInfo10, point2D11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = xYPlot13.getDomainGridlinePaint();
        java.awt.Stroke stroke15 = xYPlot13.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis18.getCategoryEnd(0, (int) (short) 0, rectangle2D21, rectangleEdge22);
        categoryAxis18.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double27 = rectangleInsets26.getBottom();
        double double29 = rectangleInsets26.extendHeight((double) (short) 0);
        double double31 = rectangleInsets26.calculateRightInset((double) 8);
        categoryAxis18.setTickLabelInsets(rectangleInsets26);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape35 = numberAxis34.getUpArrow();
        numberAxis34.setTickMarksVisible(false);
        double double38 = numberAxis34.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = numberAxis34.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer40);
        java.awt.Stroke stroke42 = categoryPlot41.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot41.setRangeAxisLocation(axisLocation43, true);
        xYPlot13.setRangeAxisLocation(axisLocation43);
        xYPlot6.setDomainAxisLocation(axisLocation43, true);
        xYPlot0.setDomainAxisLocation(9, axisLocation43);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot0.getRenderer(1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNull(xYItemRenderer51);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getLowerMargin();
        numberAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot32.getDomainAxisLocation();
        boolean boolean34 = xYPlot32.isRangeGridlinesVisible();
        boolean boolean35 = xYPlot32.isOutlineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = xYPlot32.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = null;
        dateAxis37.setTickUnit(dateTickUnit38);
        java.awt.Paint paint40 = dateAxis37.getLabelPaint();
        java.awt.Paint paint41 = dateAxis37.getAxisLinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis43.setAutoRangeIncludesZero(false);
        java.awt.Color color46 = java.awt.Color.darkGray;
        numberAxis43.setAxisLinePaint((java.awt.Paint) color46);
        java.lang.Object obj48 = numberAxis43.clone();
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis43.setTickMarkPaint(paint49);
        java.text.NumberFormat numberFormat51 = null;
        numberAxis43.setNumberFormatOverride(numberFormat51);
        boolean boolean53 = numberAxis43.isAutoRange();
        java.awt.Shape shape54 = numberAxis43.getLeftArrow();
        org.jfree.data.Range range55 = numberAxis43.getDefaultAutoRange();
        org.jfree.chart.JFreeChart jFreeChart56 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis43, jFreeChart56);
        java.text.NumberFormat numberFormat58 = null;
        numberAxis43.setNumberFormatOverride(numberFormat58);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis61.setUpperMargin((double) 10);
        numberAxis61.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = numberAxis61.getTickLabelInsets();
        numberAxis61.setPositiveArrowVisible(true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray70 = new org.jfree.chart.axis.ValueAxis[] { dateAxis37, numberAxis43, numberAxis61 };
        xYPlot32.setDomainAxes(valueAxisArray70);
        xYPlot0.setDomainAxes(valueAxisArray70);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(valueAxisArray70);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        java.awt.Paint paint15 = categoryMarker14.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        boolean boolean17 = xYPlot16.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis19.setAutoRangeIncludesZero(false);
        java.lang.Object obj22 = numberAxis19.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis19.getStandardTickUnits();
        numberAxis19.setTickMarksVisible(false);
        org.jfree.data.Range range26 = xYPlot16.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis33.getCategoryEnd(0, (int) (short) 0, rectangle2D36, rectangleEdge37);
        categoryAxis33.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double42 = rectangleInsets41.getBottom();
        double double44 = rectangleInsets41.extendHeight((double) (short) 0);
        double double46 = rectangleInsets41.calculateRightInset((double) 8);
        categoryAxis33.setTickLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape50 = numberAxis49.getUpArrow();
        numberAxis49.setTickMarksVisible(false);
        double double53 = numberAxis49.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = numberAxis49.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis49, categoryItemRenderer55);
        java.awt.Stroke stroke57 = categoryPlot56.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot56.setRangeAxisLocation(axisLocation58, true);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis62.setAutoRangeIncludesZero(false);
        java.awt.Color color65 = java.awt.Color.darkGray;
        numberAxis62.setAxisLinePaint((java.awt.Paint) color65);
        numberAxis62.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.axis.AxisState axisState70 = null;
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        java.util.List list73 = numberAxis62.refreshTicks(graphics2D69, axisState70, rectangle2D71, rectangleEdge72);
        java.awt.Paint paint74 = numberAxis62.getTickMarkPaint();
        categoryPlot56.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis62);
        categoryPlot56.setWeight((int) (byte) -1);
        categoryPlot56.clearRangeMarkers(10);
        java.awt.Color color81 = java.awt.Color.darkGray;
        java.awt.Stroke stroke82 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker83 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color81, stroke82);
        categoryMarker83.setLabel("hi!");
        java.awt.Stroke stroke86 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker83.setStroke(stroke86);
        java.awt.Paint paint88 = categoryMarker83.getLabelPaint();
        org.jfree.chart.util.Layer layer89 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean90 = categoryPlot56.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker83, layer89);
        boolean boolean91 = xYPlot16.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker30, layer89);
        boolean boolean92 = xYPlot0.removeDomainMarker(3, (org.jfree.chart.plot.Marker) categoryMarker14, layer89);
        xYPlot0.setRangeCrosshairValue((double) (short) 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 8.0d + "'", double44 == 8.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(list73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(layer89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot0.setDataset((int) (short) 1, xYDataset19);
        java.awt.Stroke stroke21 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        categoryMarker5.setLabel("hi!");
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker5);
        categoryMarker5.setAlpha((float) 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double49 = rectangleInsets47.calculateLeftInset(1.0E-8d);
        java.awt.Color color51 = java.awt.Color.darkGray;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color51, stroke52);
        categoryMarker53.setLabel("hi!");
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker53.setStroke(stroke56);
        boolean boolean58 = rectangleInsets47.equals((java.lang.Object) stroke56);
        categoryPlot25.setInsets(rectangleInsets47, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        categoryPlot25.setRenderer(categoryItemRenderer61, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation64 = null;
        try {
            boolean boolean66 = categoryPlot25.removeAnnotation(categoryAnnotation64, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        double double8 = intervalMarker7.getStartValue();
        boolean boolean9 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker7);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        int int30 = categoryPlot25.getRangeAxisCount();
        java.util.List list31 = categoryPlot25.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot25.zoomDomainAxes((double) (byte) 1, plotRenderingInfo33, point2D34, true);
        java.util.List list37 = categoryPlot25.getAnnotations();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(list31);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        xYPlot0.setRangeAxis(valueAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color5 = color4.darker();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color16, stroke17);
        categoryMarker18.setLabel("hi!");
        boolean boolean21 = chartChangeEventType14.equals((java.lang.Object) categoryMarker18);
        boolean boolean22 = categoryAxis6.equals((java.lang.Object) chartChangeEventType14);
        chartChangeEvent2.setType(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        double double9 = rectangleInsets7.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        int int51 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double6 = rectangleInsets4.calculateBottomInset((double) 10);
        double double8 = rectangleInsets4.calculateTopOutset((double) (-123));
        xYPlot0.setInsets(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.axis.AxisState axisState14 = numberAxis1.draw(graphics2D8, (double) 1560495599999L, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        xYPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot7.getDomainAxisLocation();
        boolean boolean9 = xYPlot7.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection11 = xYPlot7.getRangeMarkers(layer10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot7.getRangeAxisLocation();
        xYPlot7.setRangeCrosshairValue((double) 5, true);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot0.getDomainAxis(12);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot25.setRowRenderingOrder(sortOrder28);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot25.getDataset((int) (byte) 10);
        boolean boolean32 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis35.getCategoryEnd(0, (int) (short) 0, rectangle2D38, rectangleEdge39);
        double double41 = categoryAxis35.getCategoryMargin();
        categoryAxis35.setMaximumCategoryLabelWidthRatio((float) (byte) -1);
        java.awt.Font font45 = null;
        categoryAxis35.setTickLabelFont((java.lang.Comparable) (byte) 10, font45);
        try {
            categoryPlot25.setDomainAxis((int) (short) -1, categoryAxis35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.2d + "'", double41 == 0.2d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLabel("RectangleAnchor.TOP_LEFT");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        double double20 = dateAxis17.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date25 = dateAxis21.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis17.dateToJava2D(date25, rectangle2D26, rectangleEdge27);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) double28);
        double double30 = categoryAxis1.getCategoryMargin();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.next();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) day33);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.valueToJava2D(1.0E-8d, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis9.getCategoryEnd(0, (int) (short) 0, rectangle2D12, rectangleEdge13);
        double double15 = categoryAxis9.getCategoryMargin();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color17);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint31 = xYPlot30.getDomainGridlinePaint();
        java.awt.Stroke stroke32 = xYPlot30.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis35.getCategoryEnd(0, (int) (short) 0, rectangle2D38, rectangleEdge39);
        categoryAxis35.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double44 = rectangleInsets43.getBottom();
        double double46 = rectangleInsets43.extendHeight((double) (short) 0);
        double double48 = rectangleInsets43.calculateRightInset((double) 8);
        categoryAxis35.setTickLabelInsets(rectangleInsets43);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape52 = numberAxis51.getUpArrow();
        numberAxis51.setTickMarksVisible(false);
        double double55 = numberAxis51.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = numberAxis51.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer57);
        java.awt.Stroke stroke59 = categoryPlot58.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot58.setRangeAxisLocation(axisLocation60, true);
        xYPlot30.setRangeAxisLocation(axisLocation60);
        boolean boolean64 = categoryPlot25.equals((java.lang.Object) xYPlot30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        try {
            categoryPlot25.handleClick((-1), (int) (short) 100, plotRenderingInfo67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 8.0d + "'", double48 == 8.0d);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot25.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot25.getOrientation();
        categoryPlot25.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(valueAxis47);
        org.junit.Assert.assertNotNull(plotOrientation48);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        java.awt.Stroke stroke18 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        int int18 = xYPlot0.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis22.getCategoryEnd(0, (int) (short) 0, rectangle2D25, rectangleEdge26);
        categoryAxis22.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double31 = rectangleInsets30.getBottom();
        double double33 = rectangleInsets30.extendHeight((double) (short) 0);
        double double35 = rectangleInsets30.calculateRightInset((double) 8);
        categoryAxis22.setTickLabelInsets(rectangleInsets30);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape39 = numberAxis38.getUpArrow();
        numberAxis38.setTickMarksVisible(false);
        double double42 = numberAxis38.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis38.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis38, categoryItemRenderer44);
        categoryPlot45.zoom(0.0d);
        categoryPlot45.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint50 = categoryPlot45.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = categoryPlot45.getDomainGridlinePosition();
        java.awt.Color color53 = java.awt.Color.darkGray;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color53, stroke54);
        categoryMarker55.setLabel("hi!");
        java.awt.Color color59 = java.awt.Color.darkGray;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color59, stroke60);
        categoryMarker55.setStroke(stroke60);
        categoryMarker55.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint65 = categoryMarker55.getLabelPaint();
        categoryPlot45.addDomainMarker(categoryMarker55);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot45.getRangeAxis();
        xYPlot0.setDomainAxis((int) (short) 1, valueAxis67);
        java.awt.Color color69 = java.awt.Color.WHITE;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color69);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(categoryAnchor51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxis67);
        org.junit.Assert.assertNotNull(color69);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray10 = new float[] { (byte) 10, 100, (byte) -1, (byte) 100 };
        float[] floatArray11 = java.awt.Color.RGBtoHSB(0, (int) (byte) 1, (int) (byte) 10, floatArray10);
        float[] floatArray12 = color2.getComponents(floatArray11);
        try {
            float[] floatArray13 = color0.getColorComponents(colorSpace1, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
        float float3 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis2.getTickMarkPosition();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        java.awt.Color color4 = java.awt.Color.CYAN;
//        java.awt.Stroke stroke5 = null;
//        try {
//            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) str3, (java.awt.Paint) color4, stroke5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(color4);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker3);
        java.awt.Image image5 = xYPlot0.getBackgroundImage();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.data.general.Dataset dataset7 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color6, dataset7);
        org.jfree.data.general.Dataset dataset9 = datasetChangeEvent8.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(dataset9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        boolean boolean60 = xYPlot0.isDomainCrosshairLockedOnData();
        boolean boolean61 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot1.getDomainAxisLocation();
        boolean boolean3 = xYPlot1.isRangeGridlinesVisible();
        boolean boolean4 = xYPlot1.isOutlineVisible();
        boolean boolean5 = categoryAnchor0.equals((java.lang.Object) xYPlot1);
        java.lang.String str6 = categoryAnchor0.toString();
        java.lang.String str7 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str6.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str7.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace26, false);
        int int29 = categoryPlot25.getDomainAxisCount();
        int int30 = categoryPlot25.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.awt.Paint paint3 = dateAxis0.getLabelPaint();
        java.awt.Paint paint4 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getRight();
        categoryAxis6.setLabelInsets(rectangleInsets21);
        dateAxis0.setTickLabelInsets(rectangleInsets21);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        xYPlot0.clearRangeMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setAutoRangeIncludesZero(false);
        java.lang.Object obj10 = numberAxis7.clone();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        java.util.List list15 = numberAxis7.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge14);
        xYPlot0.drawRangeTickBands(graphics2D4, rectangle2D5, list15);
        boolean boolean17 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        java.lang.String str33 = axisLocation30.toString();
        xYPlot0.setDomainAxisLocation(500, axisLocation30);
        java.awt.Paint paint35 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        float float37 = xYPlot36.getForegroundAlpha();
        java.awt.Color color40 = java.awt.Color.darkGray;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color40, stroke41);
        categoryMarker42.setLabel("hi!");
        categoryMarker42.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color48 = java.awt.Color.darkGray;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color48, stroke49);
        categoryMarker50.setLabel("hi!");
        java.awt.Color color54 = java.awt.Color.darkGray;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color54, stroke55);
        categoryMarker50.setStroke(stroke55);
        categoryMarker42.setStroke(stroke55);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean61 = xYPlot36.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker42, layer59, true);
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        xYPlot36.setDataset(xYDataset62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        xYPlot36.drawAnnotations(graphics2D64, rectangle2D65, plotRenderingInfo66);
        java.awt.Stroke stroke68 = xYPlot36.getDomainZeroBaselineStroke();
        xYPlot0.setDomainGridlineStroke(stroke68);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier70 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.axis.ValueAxis valueAxis72 = xYPlot0.getRangeAxis(3);
        org.jfree.chart.axis.AxisLocation axisLocation74 = null;
        xYPlot0.setDomainAxisLocation(5, axisLocation74);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str33.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(drawingSupplier70);
        org.junit.Assert.assertNull(valueAxis72);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker3.setStroke(stroke8);
        categoryMarker3.setKey((java.lang.Comparable) 10.0f);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.lang.Class<?> wildcardClass14 = color13.getClass();
        try {
            java.util.EventListener[] eventListenerArray15 = categoryMarker3.getListeners((java.lang.Class) wildcardClass14);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = categoryPlot25.getDrawingSupplier();
        java.awt.Paint paint37 = categoryPlot25.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        double double40 = categoryAxis39.getCategoryMargin();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis39.setTickMarkStroke(stroke41);
        categoryPlot25.setDomainGridlineStroke(stroke41);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(drawingSupplier36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis1.getCategoryMargin();
        double double8 = categoryAxis1.getUpperMargin();
        categoryAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        categoryMarker5.setLabel("hi!");
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker5);
        java.awt.Paint paint9 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color7);
        xYPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange(0.0d);
        double double6 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        float float10 = xYPlot9.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot9.getAxisOffset();
        java.lang.Object obj12 = xYPlot9.clone();
        java.awt.Paint paint13 = xYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getDomainAxisEdge((int) '4');
        try {
            double double16 = numberAxis1.valueToJava2D((double) (-14907), rectangle2D8, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        java.awt.Paint paint4 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getDomainAxisEdge((int) '4');
        java.awt.Stroke stroke7 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean8 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke9 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        categoryMarker8.setKey((java.lang.Comparable) 1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis22.getCategoryEnd(0, (int) (short) 0, rectangle2D25, rectangleEdge26);
        categoryAxis22.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double31 = rectangleInsets30.getBottom();
        double double33 = rectangleInsets30.extendHeight((double) (short) 0);
        double double35 = rectangleInsets30.calculateRightInset((double) 8);
        categoryAxis22.setTickLabelInsets(rectangleInsets30);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape39 = numberAxis38.getUpArrow();
        numberAxis38.setTickMarksVisible(false);
        double double42 = numberAxis38.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis38.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis38, categoryItemRenderer44);
        categoryPlot45.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder48 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot45.setRowRenderingOrder(sortOrder48);
        org.jfree.data.category.CategoryDataset categoryDataset51 = categoryPlot45.getDataset((int) (byte) 10);
        categoryMarker8.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot45);
        float float53 = categoryPlot45.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.5f + "'", float53 == 0.5f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setAutoRangeIncludesZero(false);
        java.awt.Color color5 = java.awt.Color.darkGray;
        numberAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = numberAxis2.clone();
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis2.setTickMarkPaint(paint8);
        java.text.NumberFormat numberFormat10 = null;
        numberAxis2.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis2.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis2.setStandardTickUnits(tickUnitSource13);
        boolean boolean15 = dateAxis0.equals((java.lang.Object) tickUnitSource13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) (short) -1, 0.2d);
        dateAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit23);
        java.util.Date date26 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit23);
        dateAxis0.zoomRange(40.0d, (double) 64);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis0.setUpArrow(shape30);
        java.awt.Shape shape32 = dateAxis0.getLeftArrow();
        java.text.DateFormat dateFormat33 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(dateFormat33);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = categoryPlot25.getDrawingSupplier();
        categoryPlot25.clearAnnotations();
        categoryPlot25.setBackgroundImageAlignment(0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(drawingSupplier36);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = categoryAxis64.getCategoryEnd(0, (int) (short) 0, rectangle2D67, rectangleEdge68);
        java.lang.String str71 = categoryAxis64.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = null;
        double double77 = categoryAxis64.getCategoryJava2DCoordinate(categoryAnchor72, 64, (int) (byte) 0, rectangle2D75, rectangleEdge76);
        float float78 = categoryAxis64.getMaximumCategoryLabelWidthRatio();
        categoryPlot57.setDomainAxis(0, categoryAxis64);
        org.jfree.chart.plot.PlotOrientation plotOrientation80 = categoryPlot57.getOrientation();
        java.lang.String str81 = plotOrientation80.toString();
        java.awt.Color color82 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        int int83 = color82.getTransparency();
        boolean boolean84 = plotOrientation80.equals((java.lang.Object) color82);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
        org.junit.Assert.assertNotNull(plotOrientation80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "PlotOrientation.VERTICAL" + "'", str81.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis33.getCategoryEnd(0, (int) (short) 0, rectangle2D36, rectangleEdge37);
        categoryAxis33.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double42 = rectangleInsets41.getBottom();
        double double44 = rectangleInsets41.extendHeight((double) (short) 0);
        double double46 = rectangleInsets41.calculateRightInset((double) 8);
        categoryAxis33.setTickLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape50 = numberAxis49.getUpArrow();
        numberAxis49.setTickMarksVisible(false);
        double double53 = numberAxis49.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = numberAxis49.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis49, categoryItemRenderer55);
        categoryPlot56.zoom(0.0d);
        categoryPlot56.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint61 = categoryPlot56.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor62 = categoryPlot56.getDomainGridlinePosition();
        java.awt.Color color64 = java.awt.Color.darkGray;
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker66 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color64, stroke65);
        categoryMarker66.setLabel("hi!");
        java.awt.Color color70 = java.awt.Color.darkGray;
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color70, stroke71);
        categoryMarker66.setStroke(stroke71);
        categoryMarker66.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint76 = categoryMarker66.getLabelPaint();
        categoryPlot56.addDomainMarker(categoryMarker66);
        org.jfree.chart.axis.ValueAxis valueAxis78 = categoryPlot56.getRangeAxis();
        int int79 = categoryPlot25.getRangeAxisIndex(valueAxis78);
        java.lang.String str80 = categoryPlot25.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 8.0d + "'", double44 == 8.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(categoryAnchor62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(valueAxis78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNull(str80);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        categoryPlot25.configureDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double49 = rectangleInsets48.getBottom();
        categoryPlot25.setAxisOffset(rectangleInsets48);
        java.awt.Stroke stroke51 = categoryPlot25.getOutlineStroke();
        categoryPlot25.setBackgroundImageAlignment((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 4.0d + "'", double49 == 4.0d);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke2 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (short) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainGridlinePaint();
        java.awt.Stroke stroke9 = xYPlot7.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis12.getCategoryEnd(0, (int) (short) 0, rectangle2D15, rectangleEdge16);
        categoryAxis12.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getBottom();
        double double23 = rectangleInsets20.extendHeight((double) (short) 0);
        double double25 = rectangleInsets20.calculateRightInset((double) 8);
        categoryAxis12.setTickLabelInsets(rectangleInsets20);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape29 = numberAxis28.getUpArrow();
        numberAxis28.setTickMarksVisible(false);
        double double32 = numberAxis28.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis28.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot35.setRangeAxisLocation(axisLocation37, true);
        xYPlot7.setRangeAxisLocation(axisLocation37);
        xYPlot0.setDomainAxisLocation(axisLocation37, true);
        java.lang.Object obj43 = xYPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Stroke stroke32 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis35.getCategoryEnd(0, (int) (short) 0, rectangle2D38, rectangleEdge39);
        categoryAxis35.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double44 = rectangleInsets43.getBottom();
        double double46 = rectangleInsets43.extendHeight((double) (short) 0);
        double double48 = rectangleInsets43.calculateRightInset((double) 8);
        categoryAxis35.setTickLabelInsets(rectangleInsets43);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape52 = numberAxis51.getUpArrow();
        numberAxis51.setTickMarksVisible(false);
        double double55 = numberAxis51.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = numberAxis51.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer57);
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot58.setFixedDomainAxisSpace(axisSpace59, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        double double68 = categoryAxis63.getCategoryEnd(0, (int) (short) 0, rectangle2D66, rectangleEdge67);
        categoryAxis63.setCategoryLabelPositionOffset((int) '4');
        int int71 = categoryPlot58.getDomainAxisIndex(categoryAxis63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        categoryPlot58.zoomRangeAxes(0.0d, plotRenderingInfo73, point2D74);
        categoryPlot58.setAnchorValue((double) 0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        categoryPlot58.setRenderer(10, categoryItemRenderer79);
        categoryPlot58.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent83 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot58);
        xYPlot0.notifyListeners(plotChangeEvent83);
        org.jfree.chart.plot.Plot plot85 = plotChangeEvent83.getPlot();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 8.0d + "'", double48 == 8.0d);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(plot85);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.util.Calendar calendar4 = null;
        try {
            day2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryAxis2.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot32.getDomainAxisLocation();
        java.awt.Image image34 = null;
        xYPlot32.setBackgroundImage(image34);
        java.awt.Color color38 = java.awt.Color.darkGray;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color38, stroke39);
        categoryMarker40.setLabel("hi!");
        categoryMarker40.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker40.setLabelFont(font45);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean49 = xYPlot32.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker40, layer47, true);
        int int50 = xYPlot32.getDatasetCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot32.getDomainAxisEdge();
        try {
            double double52 = categoryAxis2.getCategorySeriesMiddle((java.lang.Comparable) 0.0f, (java.lang.Comparable) (-1L), categoryDataset29, (double) 100L, rectangle2D31, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.util.Date date9 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit7);
        dateAxis0.setTickMarkInsideLength(0.0f);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        dateAxis0.setLabel("hi!");
        dateAxis0.setVerticalTickLabels(true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getRangeAxisEdge();
        xYPlot0.clearDomainMarkers(12);
        org.jfree.data.xy.XYDataset xYDataset63 = xYPlot0.getDataset(0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNull(xYDataset63);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight((double) (short) 0);
        double double5 = rectangleInsets0.calculateRightInset((double) 8);
        double double7 = rectangleInsets0.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(unitType8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        boolean boolean27 = categoryPlot25.getDrawSharedDomainAxis();
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Color color31 = java.awt.Color.darkGray;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color31, stroke32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis37.getCategoryEnd(0, (int) (short) 0, rectangle2D40, rectangleEdge41);
        categoryAxis37.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double46 = rectangleInsets45.getBottom();
        double double48 = rectangleInsets45.extendHeight((double) (short) 0);
        double double50 = rectangleInsets45.calculateRightInset((double) 8);
        categoryAxis37.setTickLabelInsets(rectangleInsets45);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape54 = numberAxis53.getUpArrow();
        numberAxis53.setTickMarksVisible(false);
        double double57 = numberAxis53.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis53.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer59);
        java.awt.Stroke stroke61 = categoryPlot60.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, paint29, stroke32, (java.awt.Paint) color34, stroke61, 0.0f);
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color34);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 8.0d + "'", double48 == 8.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 8.0d + "'", double50 == 8.0d);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        double double3 = dateAxis0.getUpperMargin();
        try {
            dateAxis0.setRange((double) 10.0f, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace5);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setRangeCrosshairValue((double) 0.0f);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot0.getDataset();
        xYPlot0.zoom((double) ' ');
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Color color0 = java.awt.Color.black;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getColorComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.util.Date date9 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone10);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(tickUnitSource12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.util.Date date9 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        java.lang.String str13 = day11.toString();
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets9.getBottom();
        double double12 = rectangleInsets9.extendHeight((double) (short) 0);
        double double14 = rectangleInsets9.calculateRightInset((double) 8);
        categoryAxis1.setTickLabelInsets(rectangleInsets9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets16.getRight();
        categoryAxis1.setLabelInsets(rectangleInsets16);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis26.getCategoryEnd(0, (int) (short) 0, rectangle2D29, rectangleEdge30);
        categoryAxis26.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double35 = rectangleInsets34.getBottom();
        double double37 = rectangleInsets34.extendHeight((double) (short) 0);
        double double39 = rectangleInsets34.calculateRightInset((double) 8);
        categoryAxis26.setTickLabelInsets(rectangleInsets34);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape43 = numberAxis42.getUpArrow();
        numberAxis42.setTickMarksVisible(false);
        double double46 = numberAxis42.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis42.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer48);
        java.awt.Stroke stroke50 = categoryPlot49.getDomainGridlineStroke();
        int int51 = categoryPlot49.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection52 = categoryPlot49.getLegendItems();
        boolean boolean53 = categoryPlot49.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot49.getRangeAxisEdge((int) 'a');
        try {
            double double56 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) "TextAnchor.TOP_CENTER", (java.lang.Comparable) (-16.0d), categoryDataset21, (double) 3, rectangle2D23, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 8.0d + "'", double37 == 8.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 8.0d + "'", double39 == 8.0d);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        float float7 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis1.getCategoryEnd(0, (int) (short) 100, rectangle2D10, rectangleEdge11);
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) 0.5f);
        categoryAxis1.setCategoryLabelPositionOffset((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        xYPlot0.setNoDataMessageFont(font51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker(0.2d, (double) 1);
        java.lang.Object obj57 = intervalMarker56.clone();
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker56);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryPlot25.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot25.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            categoryPlot25.handleClick((int) (short) 0, (int) (byte) 10, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertNotNull(axisLocation38);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj9 = categoryAxis8.clone();
        double double10 = categoryAxis8.getFixedDimension();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis8.setLabelFont(font11);
        java.awt.Stroke stroke13 = categoryAxis8.getAxisLineStroke();
        intervalMarker6.setStroke(stroke13);
        xYPlot0.setRangeZeroBaselineStroke(stroke13);
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, (int) (byte) 0);
        java.awt.Paint paint19 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        xYPlot0.setRangeAxis(valueAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getDomainAxisLocation();
        java.lang.String str6 = axisLocation5.toString();
        xYPlot0.setDomainAxisLocation(axisLocation5, true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str6.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker6.setStroke(stroke9);
        dateAxis0.setTickMarkStroke(stroke9);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        int int2 = objectList1.size();
        objectList1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        numberAxis1.setPositiveArrowVisible(true);
        boolean boolean9 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        float float13 = xYPlot12.getForegroundAlpha();
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color16, stroke17);
        categoryMarker18.setLabel("hi!");
        categoryMarker18.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color24 = java.awt.Color.darkGray;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color24, stroke25);
        categoryMarker26.setLabel("hi!");
        java.awt.Color color30 = java.awt.Color.darkGray;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color30, stroke31);
        categoryMarker26.setStroke(stroke31);
        categoryMarker18.setStroke(stroke31);
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = xYPlot12.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker18, layer35, true);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis39.setAutoRangeIncludesZero(false);
        java.awt.Color color42 = java.awt.Color.darkGray;
        numberAxis39.setAxisLinePaint((java.awt.Paint) color42);
        boolean boolean44 = numberAxis39.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis46.setAutoRangeIncludesZero(false);
        java.awt.Color color49 = java.awt.Color.darkGray;
        numberAxis46.setAxisLinePaint((java.awt.Paint) color49);
        java.lang.Object obj51 = numberAxis46.clone();
        java.awt.Paint paint52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis46.setTickMarkPaint(paint52);
        java.text.NumberFormat numberFormat54 = null;
        numberAxis46.setNumberFormatOverride(numberFormat54);
        boolean boolean56 = numberAxis46.isAutoRange();
        java.awt.Shape shape57 = numberAxis46.getLeftArrow();
        org.jfree.data.Range range58 = numberAxis46.getDefaultAutoRange();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis46.setLeftArrow(shape59);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray61 = new org.jfree.chart.axis.ValueAxis[] { numberAxis39, numberAxis46 };
        xYPlot12.setDomainAxes(valueAxisArray61);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis64.setAutoRangeIncludesZero(false);
        java.lang.Object obj67 = numberAxis64.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource68 = numberAxis64.getStandardTickUnits();
        boolean boolean69 = numberAxis64.isTickMarksVisible();
        xYPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis64);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = xYPlot12.getDomainAxisEdge();
        try {
            double double72 = numberAxis1.lengthToJava2D((double) 500, rectangle2D11, rectangleEdge71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(valueAxisArray61);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNotNull(tickUnitSource68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        valueMarker1.setLabelFont(font51);
        java.awt.Stroke stroke53 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Color color30 = java.awt.Color.darkGray;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color30, stroke31);
        categoryMarker32.setLabel("hi!");
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker32.setStroke(stroke35);
        java.awt.Paint paint37 = categoryMarker32.getLabelPaint();
        boolean boolean38 = categoryMarker32.getDrawAsLine();
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean40 = xYPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker32, layer39);
        float float41 = categoryMarker32.getAlpha();
        categoryMarker32.setLabel("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.valueToJava2D(1.0E-8d, rectangle2D5, rectangleEdge6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis12.getCategoryEnd(0, (int) (short) 0, rectangle2D15, rectangleEdge16);
        categoryAxis12.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getBottom();
        double double23 = rectangleInsets20.extendHeight((double) (short) 0);
        double double25 = rectangleInsets20.calculateRightInset((double) 8);
        categoryAxis12.setTickLabelInsets(rectangleInsets20);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape29 = numberAxis28.getUpArrow();
        numberAxis28.setTickMarksVisible(false);
        double double32 = numberAxis28.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis28.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot35.zoomDomainAxes((double) (-1), plotRenderingInfo38, point2D39, true);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis44.getCategoryEnd(0, (int) (short) 0, rectangle2D47, rectangleEdge48);
        categoryAxis44.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double53 = rectangleInsets52.getBottom();
        double double55 = rectangleInsets52.extendHeight((double) (short) 0);
        double double57 = rectangleInsets52.calculateRightInset((double) 8);
        categoryAxis44.setTickLabelInsets(rectangleInsets52);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape61 = numberAxis60.getUpArrow();
        numberAxis60.setTickMarksVisible(false);
        double double64 = numberAxis60.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = numberAxis60.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis60, categoryItemRenderer66);
        java.awt.Stroke stroke68 = categoryPlot67.getDomainGridlineStroke();
        int int69 = categoryPlot67.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection70 = categoryPlot67.getLegendItems();
        boolean boolean71 = categoryPlot35.equals((java.lang.Object) categoryPlot67);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = null;
        double double79 = categoryAxis74.getCategoryEnd(0, (int) (short) 0, rectangle2D77, rectangleEdge78);
        java.lang.String str81 = categoryAxis74.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor82 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        double double87 = categoryAxis74.getCategoryJava2DCoordinate(categoryAnchor82, 64, (int) (byte) 0, rectangle2D85, rectangleEdge86);
        float float88 = categoryAxis74.getMaximumCategoryLabelWidthRatio();
        categoryPlot67.setDomainAxis(0, categoryAxis74);
        float float90 = categoryPlot67.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = null;
        java.awt.geom.Point2D point2D93 = null;
        categoryPlot67.zoomRangeAxes((double) 10.0f, plotRenderingInfo92, point2D93, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge96 = categoryPlot67.getRangeAxisEdge();
        try {
            double double97 = numberAxis1.java2DToValue(0.0d, rectangle2D9, rectangleEdge96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 4.0d + "'", double53 == 4.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 8.0d + "'", double55 == 8.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 8.0d + "'", double57 == 8.0d);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.05d + "'", double64 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(categoryAnchor82);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + float88 + "' != '" + 0.0f + "'", float88 == 0.0f);
        org.junit.Assert.assertTrue("'" + float90 + "' != '" + 1.0f + "'", float90 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge96);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightOutset((double) 3);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = dateAxis0.hasListener(eventListener6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setAutoRangeIncludesZero(false);
        java.awt.Color color12 = java.awt.Color.darkGray;
        numberAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.lang.Object obj14 = numberAxis9.clone();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis9.setTickMarkPaint(paint15);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis9.setNumberFormatOverride(numberFormat17);
        boolean boolean19 = numberAxis9.isAutoRange();
        java.awt.Shape shape20 = numberAxis9.getLeftArrow();
        org.jfree.data.Range range21 = numberAxis9.getDefaultAutoRange();
        dateAxis0.setRange(range21, false, true);
        org.jfree.chart.plot.Plot plot25 = dateAxis0.getPlot();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis28.setAutoRangeIncludesZero(false);
        java.awt.Color color31 = java.awt.Color.darkGray;
        numberAxis28.setAxisLinePaint((java.awt.Paint) color31);
        java.lang.Object obj33 = numberAxis28.clone();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis28.setTickMarkPaint(paint34);
        java.text.NumberFormat numberFormat36 = null;
        numberAxis28.setNumberFormatOverride(numberFormat36);
        boolean boolean38 = numberAxis28.isAutoRange();
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis28.setRange(range39, true, true);
        dateAxis0.setRange(range39);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker3.setStroke(stroke8);
        categoryMarker3.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint13 = categoryMarker3.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = categoryMarker3.getLabelOffsetType();
        boolean boolean16 = lengthAdjustmentType14.equals((java.lang.Object) 2019);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.setAutoRangeMinimumSize((double) 2.0f, true);
        dateAxis0.setAutoRangeMinimumSize((double) 100, false);
        org.junit.Assert.assertNotNull(timeline4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Date date3 = day2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            day2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Color color0 = java.awt.Color.magenta;
        float[] floatArray8 = new float[] { (byte) 10, 100, (byte) -1, (byte) 100 };
        float[] floatArray9 = java.awt.Color.RGBtoHSB(0, (int) (byte) 1, (int) (byte) 10, floatArray8);
        float[] floatArray10 = color0.getRGBColorComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        xYPlot0.setNoDataMessageFont(font51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        boolean boolean30 = categoryPlot25.isDomainGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis33.getCategoryEnd(0, (int) (short) 0, rectangle2D36, rectangleEdge37);
        categoryAxis33.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double42 = rectangleInsets41.getBottom();
        double double44 = rectangleInsets41.extendHeight((double) (short) 0);
        double double46 = rectangleInsets41.calculateRightInset((double) 8);
        categoryAxis33.setTickLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape50 = numberAxis49.getUpArrow();
        numberAxis49.setTickMarksVisible(false);
        double double53 = numberAxis49.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = numberAxis49.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis49, categoryItemRenderer55);
        categoryPlot56.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = categoryPlot56.getRendererForDataset(categoryDataset59);
        java.lang.String str61 = categoryPlot56.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot56.setRangeAxisLocation(4, axisLocation63);
        categoryPlot25.setDomainAxisLocation(axisLocation63);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 8.0d + "'", double44 == 8.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNull(categoryItemRenderer60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Category Plot" + "'", str61.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        objectList0.set(0, (java.lang.Object) rectangleInsets2);
        java.lang.Object obj4 = objectList0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setAutoRangeIncludesZero(false);
        java.awt.Color color12 = java.awt.Color.darkGray;
        numberAxis9.setAxisLinePaint((java.awt.Paint) color12);
        org.jfree.data.RangeType rangeType14 = numberAxis9.getRangeType();
        numberAxis1.setRangeType(rangeType14);
        java.lang.Object obj16 = numberAxis1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj38 = categoryAxis37.clone();
        java.awt.Stroke stroke39 = categoryAxis37.getTickMarkStroke();
        categoryPlot25.setRangeCrosshairStroke(stroke39);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setTickLabelsVisible(true);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        boolean boolean5 = datasetRenderingOrder0.equals((java.lang.Object) dateAxis1);
        dateAxis1.setRangeAboutValue(0.0d, (double) 500);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        xYPlot0.setDomainCrosshairValue((double) (short) 1, false);
        java.awt.Paint paint36 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace5);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot8.getDomainAxisLocation((int) (byte) 100);
        xYPlot0.setDomainAxisLocation(255, axisLocation11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        xYPlot0.addChangeListener(plotChangeListener13);
        java.awt.Paint paint15 = xYPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLabel("RectangleAnchor.TOP_LEFT");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        double double20 = dateAxis17.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date25 = dateAxis21.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis17.dateToJava2D(date25, rectangle2D26, rectangleEdge27);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) double28);
        double double30 = categoryAxis1.getCategoryMargin();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.AxisState axisState32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        float float35 = xYPlot34.getForegroundAlpha();
        java.awt.Color color38 = java.awt.Color.darkGray;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color38, stroke39);
        categoryMarker40.setLabel("hi!");
        categoryMarker40.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color46 = java.awt.Color.darkGray;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color46, stroke47);
        categoryMarker48.setLabel("hi!");
        java.awt.Color color52 = java.awt.Color.darkGray;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color52, stroke53);
        categoryMarker48.setStroke(stroke53);
        categoryMarker40.setStroke(stroke53);
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = xYPlot34.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker40, layer57, true);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        xYPlot34.setDataset(xYDataset60);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        xYPlot34.drawAnnotations(graphics2D62, rectangle2D63, plotRenderingInfo64);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot34.getRangeAxisEdge();
        try {
            java.util.List list67 = categoryAxis1.refreshTicks(graphics2D31, axisState32, rectangle2D33, rectangleEdge66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        java.awt.Color color15 = java.awt.Color.darkGray;
        numberAxis12.setAxisLinePaint((java.awt.Paint) color15);
        java.lang.Object obj17 = numberAxis12.clone();
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis12.setTickMarkPaint(paint18);
        java.text.NumberFormat numberFormat20 = null;
        numberAxis12.setNumberFormatOverride(numberFormat20);
        boolean boolean22 = numberAxis12.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis12.setStandardTickUnits(tickUnitSource23);
        boolean boolean25 = dateAxis10.equals((java.lang.Object) tickUnitSource23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.zoomRange((double) (short) -1, 0.2d);
        dateAxis26.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis32.setTickUnit(dateTickUnit33);
        java.util.Date date35 = dateAxis26.calculateHighestVisibleTickValue(dateTickUnit33);
        java.util.Date date36 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit33);
        java.util.Date date37 = dateAxis7.calculateHighestVisibleTickValue(dateTickUnit33);
        java.util.Date date38 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit33);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color8, stroke9);
        categoryMarker10.setLabel("hi!");
        boolean boolean13 = chartChangeEventType6.equals((java.lang.Object) categoryMarker10);
        java.lang.Object obj14 = null;
        boolean boolean15 = chartChangeEventType6.equals(obj14);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart5, chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        valueMarker1.setAlpha((float) (byte) 0);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker1.getLabelOffsetType();
        valueMarker1.setLabel("hi!");
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        int int27 = categoryPlot25.getWeight();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot25.getColumnRenderingOrder();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot25.removeChangeListener(plotChangeListener29);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(sortOrder28);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        double double3 = dateAxis0.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date8 = dateAxis4.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis0.dateToJava2D(date8, rectangle2D9, rectangleEdge10);
        dateAxis0.setTickMarksVisible(true);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis0.setTimeZone(timeZone14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setAutoRangeIncludesZero(false);
        java.awt.Color color21 = java.awt.Color.darkGray;
        numberAxis18.setAxisLinePaint((java.awt.Paint) color21);
        java.lang.Object obj23 = numberAxis18.clone();
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis18.setTickMarkPaint(paint24);
        java.text.NumberFormat numberFormat26 = null;
        numberAxis18.setNumberFormatOverride(numberFormat26);
        boolean boolean28 = numberAxis18.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis18.setStandardTickUnits(tickUnitSource29);
        boolean boolean31 = dateAxis16.equals((java.lang.Object) tickUnitSource29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.zoomRange((double) (short) -1, 0.2d);
        dateAxis32.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis38.setTickUnit(dateTickUnit39);
        java.util.Date date41 = dateAxis32.calculateHighestVisibleTickValue(dateTickUnit39);
        java.util.Date date42 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit39);
        dateAxis0.setMaximumDate(date42);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color2, stroke3);
        categoryMarker4.setLabel("hi!");
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) categoryMarker4);
        java.lang.Object obj8 = null;
        boolean boolean9 = chartChangeEventType0.equals(obj8);
        java.lang.String str10 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str10.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = categoryPlot25.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        java.awt.Paint paint8 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis9.setTickUnit(dateTickUnit10);
        dateAxis5.setTickUnit(dateTickUnit10, false, true);
        java.util.Date date15 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit10);
        dateAxis0.zoomRange((double) 0L, (double) 1);
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color20, stroke21);
        categoryMarker22.setLabel("hi!");
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker22.setStroke(stroke25);
        java.awt.Paint paint27 = categoryMarker22.getLabelPaint();
        boolean boolean28 = categoryMarker22.getDrawAsLine();
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        categoryMarker22.setLabelTextAnchor(textAnchor29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis33.getCategoryEnd(0, (int) (short) 0, rectangle2D36, rectangleEdge37);
        categoryAxis33.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double42 = rectangleInsets41.getBottom();
        double double44 = rectangleInsets41.extendHeight((double) (short) 0);
        double double46 = rectangleInsets41.calculateRightInset((double) 8);
        categoryAxis33.setTickLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape50 = numberAxis49.getUpArrow();
        numberAxis49.setTickMarksVisible(false);
        double double53 = numberAxis49.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = numberAxis49.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis49, categoryItemRenderer55);
        categoryPlot56.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder59 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot56.setRowRenderingOrder(sortOrder59);
        boolean boolean61 = textAnchor29.equals((java.lang.Object) sortOrder59);
        boolean boolean63 = sortOrder59.equals((java.lang.Object) 255);
        java.awt.Color color65 = java.awt.Color.darkGray;
        java.awt.Stroke stroke66 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color65, stroke66);
        java.awt.Paint paint68 = categoryMarker67.getLabelPaint();
        boolean boolean69 = sortOrder59.equals((java.lang.Object) paint68);
        dateAxis0.setTickLabelPaint(paint68);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 8.0d + "'", double44 == 8.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(sortOrder59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        int int47 = categoryPlot25.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setDomainAxisLocation(axisLocation48, false);
        org.jfree.chart.LegendItemCollection legendItemCollection51 = categoryPlot25.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis53 = categoryPlot25.getRangeAxisForDataset(8);
        org.jfree.data.Range range54 = valueAxis53.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(legendItemCollection51);
        org.junit.Assert.assertNotNull(valueAxis53);
        org.junit.Assert.assertNotNull(range54);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        java.awt.Stroke stroke34 = categoryPlot25.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis27.getCategoryEnd(0, (int) (short) 0, rectangle2D30, rectangleEdge31);
        categoryAxis27.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double36 = rectangleInsets35.getBottom();
        double double38 = rectangleInsets35.extendHeight((double) (short) 0);
        double double40 = rectangleInsets35.calculateRightInset((double) 8);
        categoryAxis27.setTickLabelInsets(rectangleInsets35);
        xYPlot0.setAxisOffset(rectangleInsets35);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        float float44 = xYPlot43.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = xYPlot43.getAxisOffset();
        double double47 = rectangleInsets45.extendWidth((double) ' ');
        xYPlot0.setInsets(rectangleInsets45);
        xYPlot0.setNoDataMessage("RectangleAnchor.TOP_LEFT");
        xYPlot0.setForegroundAlpha((float) 4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 8.0d + "'", double38 == 8.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 8.0d + "'", double40 == 8.0d);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 40.0d + "'", double47 == 40.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot25.setWeight((int) (byte) -1);
        categoryPlot25.clearRangeMarkers(10);
        java.awt.Color color50 = java.awt.Color.darkGray;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color50, stroke51);
        categoryMarker52.setLabel("hi!");
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker52.setStroke(stroke55);
        java.awt.Paint paint57 = categoryMarker52.getLabelPaint();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean59 = categoryPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer58);
        java.awt.Paint paint60 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace61 = categoryPlot25.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(axisSpace61);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.data.general.Dataset dataset46 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color45, dataset46);
        categoryPlot25.datasetChanged(datasetChangeEvent47);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        numberAxis1.setPositiveArrowVisible(true);
        boolean boolean9 = numberAxis1.getAutoRangeIncludesZero();
        boolean boolean10 = numberAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Paint paint14 = dateAxis11.getLabelPaint();
        numberAxis1.setLabelPaint(paint14);
        boolean boolean16 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = categoryMarker3.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        xYPlot0.setRangeAxis(valueAxis2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        java.awt.Paint paint5 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(9, axisLocation38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot25.zoomDomainAxes((double) 15, plotRenderingInfo41, point2D42, false);
        int int45 = categoryPlot25.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            categoryPlot25.handleClick(8, (int) (byte) 100, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Category Plot");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis3.setUpperMargin((double) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = numberAxis3.getTickUnit();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) numberTickUnit6);
        org.junit.Assert.assertNotNull(numberTickUnit6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot25.getDataset();
        java.awt.Paint paint31 = categoryPlot25.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis35.getCategoryEnd(0, (int) (short) 0, rectangle2D38, rectangleEdge39);
        categoryAxis35.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double44 = rectangleInsets43.getBottom();
        double double46 = rectangleInsets43.extendHeight((double) (short) 0);
        double double48 = rectangleInsets43.calculateRightInset((double) 8);
        categoryAxis35.setTickLabelInsets(rectangleInsets43);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape52 = numberAxis51.getUpArrow();
        numberAxis51.setTickMarksVisible(false);
        double double55 = numberAxis51.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = numberAxis51.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer57);
        categoryPlot58.zoom(0.0d);
        categoryPlot58.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint63 = categoryPlot58.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor64 = categoryPlot58.getDomainGridlinePosition();
        java.awt.Color color66 = java.awt.Color.darkGray;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker68 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color66, stroke67);
        categoryMarker68.setLabel("hi!");
        java.awt.Color color72 = java.awt.Color.darkGray;
        java.awt.Stroke stroke73 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker74 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color72, stroke73);
        categoryMarker68.setStroke(stroke73);
        categoryMarker68.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint78 = categoryMarker68.getLabelPaint();
        categoryPlot58.addDomainMarker(categoryMarker68);
        int int80 = categoryPlot58.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation81 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot58.setDomainAxisLocation(axisLocation81, false);
        categoryPlot25.setRangeAxisLocation(1, axisLocation81);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 8.0d + "'", double48 == 8.0d);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(categoryAnchor64);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(axisLocation81);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        valueMarker1.setLabelFont(font51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = valueMarker1.getLabelOffset();
        java.awt.Paint paint54 = valueMarker1.getOutlinePaint();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        xYPlot0.zoomRangeAxes((double) 100L, plotRenderingInfo29, point2D30, true);
        java.awt.Paint paint33 = xYPlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace26, false);
        int int29 = categoryPlot25.getBackgroundImageAlignment();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot25.setRenderers(categoryItemRendererArray30);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        try {
            boolean boolean33 = categoryPlot25.removeAnnotation(categoryAnnotation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", timeZone2);
        dateAxis4.zoomRange((double) 1L, 100.0d);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        java.lang.Object obj60 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(obj60);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.AxisSpace axisSpace62 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace62, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation65 = null;
        try {
            categoryPlot25.addAnnotation(categoryAnnotation65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke6);
        java.awt.Paint paint8 = categoryMarker3.getLabelPaint();
        boolean boolean9 = categoryMarker3.getDrawAsLine();
        categoryMarker3.setDrawAsLine(true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryMarker3.notifyListeners(markerChangeEvent12);
        java.awt.Stroke stroke14 = categoryMarker3.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        double double11 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setUpperMargin(0.05d);
        boolean boolean14 = xYPlot0.equals((java.lang.Object) categoryAxis5);
        categoryAxis5.setLabelToolTip("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        int int18 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape21 = numberAxis20.getUpArrow();
        numberAxis20.setTickMarksVisible(false);
        double double24 = numberAxis20.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis20.getTickLabelInsets();
        boolean boolean26 = numberAxis20.getAutoRangeIncludesZero();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        xYPlot0.setNoDataMessageFont(font51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = xYPlot0.getDomainAxisLocation(7);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double2 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.getRight();
        double double5 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        float float3 = xYPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot0.getRenderer(10);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        float float9 = xYPlot8.getForegroundAlpha();
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        categoryMarker14.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color20, stroke21);
        categoryMarker22.setLabel("hi!");
        java.awt.Color color26 = java.awt.Color.darkGray;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color26, stroke27);
        categoryMarker22.setStroke(stroke27);
        categoryMarker14.setStroke(stroke27);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = xYPlot8.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker14, layer31, true);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setAutoRangeIncludesZero(false);
        java.awt.Color color38 = java.awt.Color.darkGray;
        numberAxis35.setAxisLinePaint((java.awt.Paint) color38);
        boolean boolean40 = numberAxis35.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis42.setAutoRangeIncludesZero(false);
        java.awt.Color color45 = java.awt.Color.darkGray;
        numberAxis42.setAxisLinePaint((java.awt.Paint) color45);
        java.lang.Object obj47 = numberAxis42.clone();
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis42.setTickMarkPaint(paint48);
        java.text.NumberFormat numberFormat50 = null;
        numberAxis42.setNumberFormatOverride(numberFormat50);
        boolean boolean52 = numberAxis42.isAutoRange();
        java.awt.Shape shape53 = numberAxis42.getLeftArrow();
        org.jfree.data.Range range54 = numberAxis42.getDefaultAutoRange();
        java.awt.Shape shape55 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis42.setLeftArrow(shape55);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray57 = new org.jfree.chart.axis.ValueAxis[] { numberAxis35, numberAxis42 };
        xYPlot8.setDomainAxes(valueAxisArray57);
        xYPlot0.setDomainAxes(valueAxisArray57);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(valueAxisArray57);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickLabelsVisible(true);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis4.setTickUnit(dateTickUnit5);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis4.getTickMarkPosition();
        dateAxis4.setVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setAutoRangeIncludesZero(false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        numberAxis11.setAxisLinePaint((java.awt.Paint) color14);
        java.lang.Object obj16 = numberAxis11.clone();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis11.setTickMarkPaint(paint17);
        java.text.NumberFormat numberFormat19 = null;
        numberAxis11.setNumberFormatOverride(numberFormat19);
        boolean boolean21 = numberAxis11.isAutoRange();
        java.awt.Shape shape22 = numberAxis11.getLeftArrow();
        org.jfree.data.Range range23 = numberAxis11.getDefaultAutoRange();
        dateAxis4.setDefaultAutoRange(range23);
        dateAxis0.setDefaultAutoRange(range23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.setTickLabelsVisible(true);
        java.awt.Stroke stroke29 = dateAxis26.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setAutoRangeIncludesZero(false);
        java.awt.Color color38 = java.awt.Color.darkGray;
        numberAxis35.setAxisLinePaint((java.awt.Paint) color38);
        java.lang.Object obj40 = numberAxis35.clone();
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis35.setTickMarkPaint(paint41);
        java.text.NumberFormat numberFormat43 = null;
        numberAxis35.setNumberFormatOverride(numberFormat43);
        boolean boolean45 = numberAxis35.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource46 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis35.setStandardTickUnits(tickUnitSource46);
        boolean boolean48 = dateAxis33.equals((java.lang.Object) tickUnitSource46);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        dateAxis49.zoomRange((double) (short) -1, 0.2d);
        dateAxis49.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis55.setTickUnit(dateTickUnit56);
        java.util.Date date58 = dateAxis49.calculateHighestVisibleTickValue(dateTickUnit56);
        java.util.Date date59 = dateAxis33.calculateHighestVisibleTickValue(dateTickUnit56);
        java.util.Date date60 = dateAxis30.calculateHighestVisibleTickValue(dateTickUnit56);
        java.util.Date date61 = dateAxis26.calculateLowestVisibleTickValue(dateTickUnit56);
        dateAxis0.setMaximumDate(date61);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(tickUnitSource46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTickUnit56);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        categoryPlot25.configureDomainAxes();
        categoryPlot25.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot25.getRendererForDataset(categoryDataset49);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(categoryItemRenderer50);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        categoryPlot25.configureRangeAxes();
        float float31 = categoryPlot25.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection34 = categoryPlot25.getRangeMarkers(10, layer33);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis27.getCategoryEnd(0, (int) (short) 0, rectangle2D30, rectangleEdge31);
        categoryAxis27.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double36 = rectangleInsets35.getBottom();
        double double38 = rectangleInsets35.extendHeight((double) (short) 0);
        double double40 = rectangleInsets35.calculateRightInset((double) 8);
        categoryAxis27.setTickLabelInsets(rectangleInsets35);
        xYPlot0.setAxisOffset(rectangleInsets35);
        xYPlot0.setBackgroundAlpha((float) 15);
        xYPlot0.mapDatasetToRangeAxis(0, 2019);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 8.0d + "'", double38 == 8.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 8.0d + "'", double40 == 8.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=175,b=175]");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        xYPlot0.setNoDataMessageFont(font51);
        java.awt.Paint paint53 = null;
        xYPlot0.setRangeTickBandPaint(paint53);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot0.getDomainAxis(5);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNull(valueAxis57);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        int int27 = categoryPlot25.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot25.getLegendItems();
        boolean boolean29 = categoryPlot25.getDrawSharedDomainAxis();
        categoryPlot25.zoom(0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        numberAxis1.addChangeListener(axisChangeListener4);
        numberAxis1.setLabel("RectangleAnchor.RIGHT");
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setAxisLineVisible(true);
        categoryAxis1.setMaximumCategoryLabelWidthRatio(100.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj9 = categoryAxis8.clone();
        double double10 = categoryAxis8.getFixedDimension();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis8.setLabelFont(font11);
        java.awt.Stroke stroke13 = categoryAxis8.getAxisLineStroke();
        intervalMarker6.setStroke(stroke13);
        xYPlot0.setRangeZeroBaselineStroke(stroke13);
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, (int) (byte) 0);
        xYPlot0.clearDomainAxes();
        boolean boolean20 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        categoryPlot25.mapDatasetToRangeAxis((int) 'a', (int) (byte) 10);
        categoryPlot25.setBackgroundImageAlignment((-123));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot25.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot25.getRendererForDataset(categoryDataset41);
        java.awt.Stroke stroke43 = categoryPlot25.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 100, (float) (short) 1, (float) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double8 = rectangleInsets6.calculateLeftInset(1.0E-8d);
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color10, stroke11);
        categoryMarker12.setLabel("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker12.setStroke(stroke15);
        boolean boolean17 = rectangleInsets6.equals((java.lang.Object) stroke15);
        java.awt.Color color20 = java.awt.Color.getColor("AxisLocation.TOP_OR_RIGHT", 0);
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Color color23 = java.awt.Color.getColor("", color22);
        java.awt.Color color24 = color22.darker();
        float[] floatArray30 = new float[] { 1L, 0L, 1.0f, (short) 100, (-1L) };
        float[] floatArray31 = color22.getRGBComponents(floatArray30);
        float[] floatArray32 = color20.getColorComponents(floatArray31);
        java.awt.Stroke stroke33 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) (-1), 10.0d, (java.awt.Paint) color5, stroke15, (java.awt.Paint) color20, stroke33, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.awt.Paint paint3 = dateAxis0.getLabelPaint();
        java.awt.Paint paint4 = dateAxis0.getAxisLinePaint();
        dateAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        boolean boolean45 = numberAxis31.isVisible();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke2 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        xYPlot0.setRangeAxisLocation(axisLocation30);
        java.awt.Paint paint34 = xYPlot0.getDomainTickBandPaint();
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNull(paint34);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis6.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        java.awt.Color color15 = java.awt.Color.darkGray;
        numberAxis12.setAxisLinePaint((java.awt.Paint) color15);
        java.lang.Object obj17 = numberAxis12.clone();
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis12.setTickMarkPaint(paint18);
        java.text.NumberFormat numberFormat20 = null;
        numberAxis12.setNumberFormatOverride(numberFormat20);
        boolean boolean22 = numberAxis12.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis12.setStandardTickUnits(tickUnitSource23);
        boolean boolean25 = dateAxis10.equals((java.lang.Object) tickUnitSource23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.zoomRange((double) (short) -1, 0.2d);
        dateAxis26.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis32.setTickUnit(dateTickUnit33);
        java.util.Date date35 = dateAxis26.calculateHighestVisibleTickValue(dateTickUnit33);
        java.util.Date date36 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit33);
        java.util.Date date37 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit33);
        java.util.Date date38 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit33);
        java.text.DateFormat dateFormat39 = dateAxis0.getDateFormatOverride();
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(dateFormat39);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot25.setRowRenderingOrder(sortOrder28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot25.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace31, false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNull(categoryItemRenderer30);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        java.awt.Stroke stroke10 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker12.setLabelTextAnchor(textAnchor13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis17.getCategoryEnd(0, (int) (short) 0, rectangle2D20, rectangleEdge21);
        categoryAxis17.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets25.getBottom();
        double double28 = rectangleInsets25.extendHeight((double) (short) 0);
        double double30 = rectangleInsets25.calculateRightInset((double) 8);
        categoryAxis17.setTickLabelInsets(rectangleInsets25);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape34 = numberAxis33.getUpArrow();
        numberAxis33.setTickMarksVisible(false);
        double double37 = numberAxis33.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis33.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer39);
        categoryPlot40.zoom(0.0d);
        categoryPlot40.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint45 = categoryPlot40.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor46 = categoryPlot40.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot40.setFixedDomainAxisSpace(axisSpace47, true);
        java.awt.Color color52 = java.awt.Color.darkGray;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color52, stroke53);
        categoryMarker54.setLabel("hi!");
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker54.setStroke(stroke57);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot40.addDomainMarker((int) '4', categoryMarker54, layer59, true);
        java.awt.Font font62 = categoryMarker54.getLabelFont();
        valueMarker12.setLabelFont(font62);
        xYPlot0.setNoDataMessageFont(font62);
        java.awt.Color color66 = java.awt.Color.darkGray;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker68 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color66, stroke67);
        categoryMarker68.setLabel("hi!");
        java.awt.Paint paint71 = categoryMarker68.getOutlinePaint();
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker68);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 8.0d + "'", double28 == 8.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 8.0d + "'", double30 == 8.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(categoryAnchor46);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        java.awt.Paint paint4 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getDomainAxisEdge((int) '4');
        java.awt.Stroke stroke7 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setAutoRangeIncludesZero(false);
        java.lang.Object obj12 = numberAxis9.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis9.getStandardTickUnits();
        numberAxis9.setTickMarksVisible(false);
        int int16 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        xYPlot0.setRangeGridlinePaint(paint4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setLabelURL("TextAnchor.TOP_CENTER");
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        categoryMarker3.setKey((java.lang.Comparable) 0.2d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker3.setLabelAnchor(rectangleAnchor8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker3.setLabelTextAnchor(textAnchor10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        double double10 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setUpperMargin((double) 10);
        numberAxis13.resizeRange(0.0d);
        numberAxis13.setVerticalTickLabels(true);
        boolean boolean20 = numberAxis13.isVerticalTickLabels();
        xYPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) numberAxis13, false);
        boolean boolean23 = numberAxis13.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        boolean boolean7 = dateAxis6.isVisible();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        xYPlot0.mapDatasetToDomainAxis((int) (short) 10, 6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        xYPlot0.removeChangeListener(plotChangeListener6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis12.getCategoryEnd(0, (int) (short) 0, rectangle2D15, rectangleEdge16);
        categoryAxis12.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getBottom();
        double double23 = rectangleInsets20.extendHeight((double) (short) 0);
        double double25 = rectangleInsets20.calculateRightInset((double) 8);
        categoryAxis12.setTickLabelInsets(rectangleInsets20);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape29 = numberAxis28.getUpArrow();
        numberAxis28.setTickMarksVisible(false);
        double double32 = numberAxis28.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis28.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer34);
        categoryPlot35.zoom(0.0d);
        categoryPlot35.clearRangeMarkers((int) (short) 0);
        int int40 = categoryPlot35.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        categoryPlot35.setDataset(categoryDataset41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot35.getDomainAxisEdge(12);
        categoryPlot35.setRangeGridlinesVisible(true);
        categoryPlot35.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot51.getDomainAxisLocation();
        boolean boolean53 = xYPlot51.isRangeGridlinesVisible();
        boolean boolean54 = xYPlot51.isOutlineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation55 = xYPlot51.getOrientation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        xYPlot51.notifyListeners(plotChangeEvent56);
        java.awt.geom.Point2D point2D58 = xYPlot51.getQuadrantOrigin();
        categoryPlot35.zoomRangeAxes(0.05d, (double) 1.0f, plotRenderingInfo50, point2D58);
        xYPlot0.zoomRangeAxes((double) 2019, plotRenderingInfo9, point2D58, false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(plotOrientation55);
        org.junit.Assert.assertNotNull(point2D58);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        float float2 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        boolean boolean5 = xYPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setAutoRangeIncludesZero(false);
        java.lang.Object obj10 = numberAxis7.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = numberAxis7.getStandardTickUnits();
        numberAxis7.setTickMarksVisible(false);
        org.jfree.data.Range range14 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis21.getCategoryEnd(0, (int) (short) 0, rectangle2D24, rectangleEdge25);
        categoryAxis21.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double30 = rectangleInsets29.getBottom();
        double double32 = rectangleInsets29.extendHeight((double) (short) 0);
        double double34 = rectangleInsets29.calculateRightInset((double) 8);
        categoryAxis21.setTickLabelInsets(rectangleInsets29);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape38 = numberAxis37.getUpArrow();
        numberAxis37.setTickMarksVisible(false);
        double double41 = numberAxis37.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer43);
        java.awt.Stroke stroke45 = categoryPlot44.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot44.setRangeAxisLocation(axisLocation46, true);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis50.setAutoRangeIncludesZero(false);
        java.awt.Color color53 = java.awt.Color.darkGray;
        numberAxis50.setAxisLinePaint((java.awt.Paint) color53);
        numberAxis50.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.axis.AxisState axisState58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        java.util.List list61 = numberAxis50.refreshTicks(graphics2D57, axisState58, rectangle2D59, rectangleEdge60);
        java.awt.Paint paint62 = numberAxis50.getTickMarkPaint();
        categoryPlot44.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis50);
        categoryPlot44.setWeight((int) (byte) -1);
        categoryPlot44.clearRangeMarkers(10);
        java.awt.Color color69 = java.awt.Color.darkGray;
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color69, stroke70);
        categoryMarker71.setLabel("hi!");
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker71.setStroke(stroke74);
        java.awt.Paint paint76 = categoryMarker71.getLabelPaint();
        org.jfree.chart.util.Layer layer77 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean78 = categoryPlot44.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker71, layer77);
        boolean boolean79 = xYPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker18, layer77);
        try {
            xYPlot0.addRangeMarker(marker3, layer77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 8.0d + "'", double32 == 8.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 8.0d + "'", double34 == 8.0d);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(layer77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot25.setRowRenderingOrder(sortOrder28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot25.getRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            categoryPlot25.addAnnotation(categoryAnnotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNull(categoryItemRenderer30);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]", timeZone3);
        java.awt.Shape shape7 = dateAxis6.getLeftArrow();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke2 = xYPlot0.getDomainZeroBaselineStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        xYPlot0.drawAnnotations(graphics2D3, rectangle2D4, plotRenderingInfo5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis1.getCategoryMargin();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis11.setTickUnit(dateTickUnit12);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) dateTickUnit12, "PlotOrientation.VERTICAL");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(dateTickUnit12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        xYPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis8.getCategoryEnd(0, (int) (short) 0, rectangle2D11, rectangleEdge12);
        java.lang.String str15 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis8.getCategoryJava2DCoordinate(categoryAnchor16, 64, (int) (byte) 0, rectangle2D19, rectangleEdge20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        boolean boolean23 = categoryAnchor16.equals((java.lang.Object) color22);
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color25, stroke26);
        categoryMarker27.setLabel("hi!");
        categoryMarker27.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker27.setStroke(stroke40);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis45.setAutoRangeIncludesZero(false);
        java.awt.Color color48 = java.awt.Color.darkGray;
        numberAxis45.setAxisLinePaint((java.awt.Paint) color48);
        categoryMarker27.setPaint((java.awt.Paint) color48);
        int int51 = color48.getTransparency();
        java.awt.Color color52 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray60 = new float[] { (byte) 10, 100, (byte) -1, (byte) 100 };
        float[] floatArray61 = java.awt.Color.RGBtoHSB(0, (int) (byte) 1, (int) (byte) 10, floatArray60);
        float[] floatArray62 = color52.getComponents(floatArray61);
        float[] floatArray63 = color48.getColorComponents(floatArray62);
        float[] floatArray64 = color22.getColorComponents(floatArray62);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(9, axisLocation38);
        categoryPlot25.clearDomainMarkers(4);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint44 = xYPlot43.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot43.getDomainAxisLocation((int) (byte) 100);
        java.lang.String str47 = axisLocation46.toString();
        categoryPlot25.setRangeAxisLocation(10, axisLocation46, true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str47.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot0.zoomDomainAxes((double) (-123), 0.05d, plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean33 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        double double37 = intervalMarker36.getStartValue();
        double double38 = intervalMarker36.getStartValue();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker36);
        intervalMarker36.setStartValue(0.0d);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace5);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setRangeCrosshairValue((double) 0.0f);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot0.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(12, axisLocation12, false);
        java.awt.Paint paint15 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.Plot plot1 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(plot1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        valueMarker1.setAlpha((float) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setCategoryLabelPositionOffset(2019);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource5);
        java.awt.Color color7 = java.awt.Color.pink;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = xYPlot9.getDomainGridlinePaint();
        java.awt.Stroke stroke11 = xYPlot9.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 9, (java.awt.Paint) color7, stroke11);
        int int13 = color7.getRed();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        int int30 = categoryPlot25.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot25.setDataset(categoryDataset31);
        java.awt.Paint paint33 = categoryPlot25.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis36.getCategoryEnd(0, (int) (short) 0, rectangle2D39, rectangleEdge40);
        categoryAxis36.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets44.getBottom();
        double double47 = rectangleInsets44.extendHeight((double) (short) 0);
        double double49 = rectangleInsets44.calculateRightInset((double) 8);
        categoryAxis36.setTickLabelInsets(rectangleInsets44);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape53 = numberAxis52.getUpArrow();
        numberAxis52.setTickMarksVisible(false);
        double double56 = numberAxis52.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis52.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis52, categoryItemRenderer58);
        java.awt.Stroke stroke60 = categoryPlot59.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        java.awt.geom.Point2D point2D63 = null;
        categoryPlot59.zoomDomainAxes((double) (-1), plotRenderingInfo62, point2D63, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent66 = null;
        categoryPlot59.rendererChanged(rendererChangeEvent66);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier68 = categoryPlot59.getDrawingSupplier();
        categoryPlot25.setDrawingSupplier(drawingSupplier68);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(drawingSupplier68);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date19 = dateAxis15.getMinimumDate();
        java.awt.Stroke stroke20 = dateAxis15.getAxisLineStroke();
        categoryAxis1.setAxisLineStroke(stroke20);
        categoryAxis1.setLabel("DatasetRenderingOrder.FORWARD");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        float float5 = xYPlot4.getForegroundAlpha();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color8, stroke9);
        categoryMarker10.setLabel("hi!");
        categoryMarker10.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color16, stroke17);
        categoryMarker18.setLabel("hi!");
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color22, stroke23);
        categoryMarker18.setStroke(stroke23);
        categoryMarker10.setStroke(stroke23);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean29 = xYPlot4.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker10, layer27, true);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot4.setDataset(xYDataset30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYPlot4.drawAnnotations(graphics2D32, rectangle2D33, plotRenderingInfo34);
        boolean boolean36 = xYPlot4.isDomainCrosshairVisible();
        boolean boolean37 = xYPlot4.isDomainZeroBaselineVisible();
        boolean boolean38 = categoryAxis1.equals((java.lang.Object) xYPlot4);
        boolean boolean39 = unitType0.equals((java.lang.Object) boolean38);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, false);
        boolean boolean7 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(xYItemRenderer8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.zoomRange((double) (short) -1, 0.2d);
        dateAxis11.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis17.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis23.setAutoRangeIncludesZero(false);
        java.awt.Color color26 = java.awt.Color.darkGray;
        numberAxis23.setAxisLinePaint((java.awt.Paint) color26);
        java.lang.Object obj28 = numberAxis23.clone();
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis23.setTickMarkPaint(paint29);
        java.text.NumberFormat numberFormat31 = null;
        numberAxis23.setNumberFormatOverride(numberFormat31);
        boolean boolean33 = numberAxis23.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource34 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis23.setStandardTickUnits(tickUnitSource34);
        boolean boolean36 = dateAxis21.equals((java.lang.Object) tickUnitSource34);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.zoomRange((double) (short) -1, 0.2d);
        dateAxis37.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis43.setTickUnit(dateTickUnit44);
        java.util.Date date46 = dateAxis37.calculateHighestVisibleTickValue(dateTickUnit44);
        java.util.Date date47 = dateAxis21.calculateHighestVisibleTickValue(dateTickUnit44);
        java.util.Date date48 = dateAxis17.calculateLowestVisibleTickValue(dateTickUnit44);
        java.util.Date date49 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit44);
        xYPlot0.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot53.getDomainAxis();
        xYPlot53.clearRangeMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis60.setAutoRangeIncludesZero(false);
        java.lang.Object obj63 = numberAxis60.clone();
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.axis.AxisState axisState65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        java.util.List list68 = numberAxis60.refreshTicks(graphics2D64, axisState65, rectangle2D66, rectangleEdge67);
        xYPlot53.drawRangeTickBands(graphics2D57, rectangle2D58, list68);
        xYPlot0.drawDomainTickBands(graphics2D51, rectangle2D52, list68);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(tickUnitSource34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTickUnit44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNull(valueAxis54);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(list68);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        numberAxis1.setAxisLineVisible(false);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis12.getCategoryEnd(0, (int) (short) 0, rectangle2D15, rectangleEdge16);
        categoryAxis12.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getBottom();
        double double23 = rectangleInsets20.extendHeight((double) (short) 0);
        double double25 = rectangleInsets20.calculateRightInset((double) 8);
        categoryAxis12.setTickLabelInsets(rectangleInsets20);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape29 = numberAxis28.getUpArrow();
        numberAxis28.setTickMarksVisible(false);
        double double32 = numberAxis28.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis28.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot35.zoomDomainAxes((double) (-1), plotRenderingInfo38, point2D39, true);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis44.getCategoryEnd(0, (int) (short) 0, rectangle2D47, rectangleEdge48);
        categoryAxis44.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double53 = rectangleInsets52.getBottom();
        double double55 = rectangleInsets52.extendHeight((double) (short) 0);
        double double57 = rectangleInsets52.calculateRightInset((double) 8);
        categoryAxis44.setTickLabelInsets(rectangleInsets52);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape61 = numberAxis60.getUpArrow();
        numberAxis60.setTickMarksVisible(false);
        double double64 = numberAxis60.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = numberAxis60.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis60, categoryItemRenderer66);
        java.awt.Stroke stroke68 = categoryPlot67.getDomainGridlineStroke();
        int int69 = categoryPlot67.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection70 = categoryPlot67.getLegendItems();
        boolean boolean71 = categoryPlot35.equals((java.lang.Object) categoryPlot67);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = null;
        double double79 = categoryAxis74.getCategoryEnd(0, (int) (short) 0, rectangle2D77, rectangleEdge78);
        java.lang.String str81 = categoryAxis74.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor82 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        double double87 = categoryAxis74.getCategoryJava2DCoordinate(categoryAnchor82, 64, (int) (byte) 0, rectangle2D85, rectangleEdge86);
        float float88 = categoryAxis74.getMaximumCategoryLabelWidthRatio();
        categoryPlot67.setDomainAxis(0, categoryAxis74);
        float float90 = categoryPlot67.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = null;
        java.awt.geom.Point2D point2D93 = null;
        categoryPlot67.zoomRangeAxes((double) 10.0f, plotRenderingInfo92, point2D93, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge96 = categoryPlot67.getRangeAxisEdge();
        try {
            double double97 = numberAxis1.valueToJava2D((double) '4', rectangle2D9, rectangleEdge96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 4.0d + "'", double53 == 4.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 8.0d + "'", double55 == 8.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 8.0d + "'", double57 == 8.0d);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.05d + "'", double64 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(categoryAnchor82);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + float88 + "' != '" + 0.0f + "'", float88 == 0.0f);
        org.junit.Assert.assertTrue("'" + float90 + "' != '" + 1.0f + "'", float90 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge96);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        categoryMarker5.setLabel("hi!");
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker5);
        java.awt.Stroke stroke9 = categoryMarker5.getOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        float float11 = xYPlot10.getForegroundAlpha();
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color14, stroke15);
        categoryMarker16.setLabel("hi!");
        categoryMarker16.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color22, stroke23);
        categoryMarker24.setLabel("hi!");
        java.awt.Color color28 = java.awt.Color.darkGray;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color28, stroke29);
        categoryMarker24.setStroke(stroke29);
        categoryMarker16.setStroke(stroke29);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = xYPlot10.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker16, layer33, true);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot10.setDataset(xYDataset36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        xYPlot10.drawAnnotations(graphics2D38, rectangle2D39, plotRenderingInfo40);
        xYPlot10.setDomainGridlinesVisible(false);
        categoryMarker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]", timeZone3);
        java.awt.Paint paint7 = dateAxis6.getTickLabelPaint();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.FORWARD");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "TextAnchor.TOP_CENTER", "CategoryAnchor.MIDDLE");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot25.setWeight((int) (byte) -1);
        categoryPlot25.clearRangeMarkers(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot25.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker1.setStroke(stroke4);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke2 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        xYPlot0.setRangeAxisLocation(axisLocation30);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double36 = rectangleInsets34.calculateLeftInset(1.0E-8d);
        double double37 = rectangleInsets34.getTop();
        java.awt.Paint[] paintArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean39 = rectangleInsets34.equals((java.lang.Object) paintArray38);
        xYPlot0.setInsets(rectangleInsets34, false);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets34.createOutsetRectangle(rectangle2D42, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.0d + "'", double36 == 8.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        xYPlot4.drawAnnotations(graphics2D5, rectangle2D6, plotRenderingInfo7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot4.setRenderer((int) (short) 1, xYItemRenderer10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace12);
        java.awt.Stroke stroke14 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker16.setLabelTextAnchor(textAnchor17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis21.getCategoryEnd(0, (int) (short) 0, rectangle2D24, rectangleEdge25);
        categoryAxis21.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double30 = rectangleInsets29.getBottom();
        double double32 = rectangleInsets29.extendHeight((double) (short) 0);
        double double34 = rectangleInsets29.calculateRightInset((double) 8);
        categoryAxis21.setTickLabelInsets(rectangleInsets29);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape38 = numberAxis37.getUpArrow();
        numberAxis37.setTickMarksVisible(false);
        double double41 = numberAxis37.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer43);
        categoryPlot44.zoom(0.0d);
        categoryPlot44.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint49 = categoryPlot44.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = categoryPlot44.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        categoryPlot44.setFixedDomainAxisSpace(axisSpace51, true);
        java.awt.Color color56 = java.awt.Color.darkGray;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color56, stroke57);
        categoryMarker58.setLabel("hi!");
        java.awt.Stroke stroke61 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker58.setStroke(stroke61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot44.addDomainMarker((int) '4', categoryMarker58, layer63, true);
        java.awt.Font font66 = categoryMarker58.getLabelFont();
        valueMarker16.setLabelFont(font66);
        xYPlot4.setNoDataMessageFont(font66);
        xYPlot0.setNoDataMessageFont(font66);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 8.0d + "'", double32 == 8.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 8.0d + "'", double34 == 8.0d);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(categoryAnchor50);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNotNull(font66);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setAutoRangeIncludesZero(false);
        java.awt.Color color7 = java.awt.Color.darkGray;
        numberAxis4.setAxisLinePaint((java.awt.Paint) color7);
        numberAxis4.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        java.util.List list15 = numberAxis4.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot0.getRangeAxis();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = null;
        try {
            xYPlot0.setRenderers(xYItemRendererArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!", timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", timeZone4);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis8.setAutoRangeIncludesZero(false);
        java.awt.Color color11 = java.awt.Color.darkGray;
        numberAxis8.setAxisLinePaint((java.awt.Paint) color11);
        java.lang.Object obj13 = numberAxis8.clone();
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis8.setTickMarkPaint(paint14);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis8.setNumberFormatOverride(numberFormat16);
        boolean boolean18 = numberAxis8.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape21 = numberAxis20.getUpArrow();
        numberAxis8.setRightArrow(shape21);
        dateAxis6.setLeftArrow(shape21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        int int27 = xYPlot25.indexOf(xYDataset26);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        double double13 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        xYPlot0.removeChangeListener(plotChangeListener60);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryMarker63.getLabelOffset();
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean66 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer65);
        java.awt.Graphics2D graphics2D67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYPlot0.drawBackgroundImage(graphics2D67, rectangle2D68);
        java.awt.Color color70 = java.awt.Color.ORANGE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color70);
        boolean boolean72 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis36.getCategoryEnd(0, (int) (short) 0, rectangle2D39, rectangleEdge40);
        categoryAxis36.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets44.getBottom();
        double double47 = rectangleInsets44.extendHeight((double) (short) 0);
        double double49 = rectangleInsets44.calculateRightInset((double) 8);
        categoryAxis36.setTickLabelInsets(rectangleInsets44);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape53 = numberAxis52.getUpArrow();
        numberAxis52.setTickMarksVisible(false);
        double double56 = numberAxis52.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis52.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis52, categoryItemRenderer58);
        categoryPlot59.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder62 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot59.setRowRenderingOrder(sortOrder62);
        categoryPlot25.setColumnRenderingOrder(sortOrder62);
        categoryPlot25.setRangeGridlinesVisible(true);
        categoryPlot25.mapDatasetToRangeAxis(500, 500);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(sortOrder62);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = categoryAxis64.getCategoryEnd(0, (int) (short) 0, rectangle2D67, rectangleEdge68);
        java.lang.String str71 = categoryAxis64.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = null;
        double double77 = categoryAxis64.getCategoryJava2DCoordinate(categoryAnchor72, 64, (int) (byte) 0, rectangle2D75, rectangleEdge76);
        float float78 = categoryAxis64.getMaximumCategoryLabelWidthRatio();
        categoryPlot57.setDomainAxis(0, categoryAxis64);
        categoryPlot57.clearRangeMarkers(8);
        categoryPlot57.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setVerticalTickLabels(true);
        boolean boolean8 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        java.awt.Paint paint8 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis9.setTickUnit(dateTickUnit10);
        dateAxis5.setTickUnit(dateTickUnit10, false, true);
        java.util.Date date15 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit10);
        dateAxis0.zoomRange((double) 0L, (double) 1);
        java.util.Date date19 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = categoryAxis64.getCategoryEnd(0, (int) (short) 0, rectangle2D67, rectangleEdge68);
        java.lang.String str71 = categoryAxis64.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = null;
        double double77 = categoryAxis64.getCategoryJava2DCoordinate(categoryAnchor72, 64, (int) (byte) 0, rectangle2D75, rectangleEdge76);
        float float78 = categoryAxis64.getMaximumCategoryLabelWidthRatio();
        categoryPlot57.setDomainAxis(0, categoryAxis64);
        org.jfree.chart.plot.PlotOrientation plotOrientation80 = categoryPlot57.getOrientation();
        double double81 = categoryPlot57.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
        org.junit.Assert.assertNotNull(plotOrientation80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.geom.Rectangle2D rectangle2D5 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
//        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
//        categoryAxis2.setMaximumCategoryLabelLines(6);
//        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
//        double double11 = rectangleInsets10.getBottom();
//        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
//        double double15 = rectangleInsets10.calculateRightInset((double) 8);
//        categoryAxis2.setTickLabelInsets(rectangleInsets10);
//        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
//        java.awt.Shape shape19 = numberAxis18.getUpArrow();
//        numberAxis18.setTickMarksVisible(false);
//        double double22 = numberAxis18.getLowerMargin();
//        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
//        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
//        categoryPlot25.setFixedDomainAxisSpace(axisSpace26, false);
//        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
//        double double35 = categoryAxis30.getCategoryEnd(0, (int) (short) 0, rectangle2D33, rectangleEdge34);
//        categoryAxis30.setCategoryLabelPositionOffset((int) '4');
//        int int38 = categoryPlot25.getDomainAxisIndex(categoryAxis30);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate40 = day39.getSerialDate();
//        long long41 = day39.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate42 = day39.getSerialDate();
//        java.awt.Font font43 = categoryAxis30.getTickLabelFont((java.lang.Comparable) day39);
//        java.util.Date date44 = day39.getStart();
//        java.util.Calendar calendar45 = null;
//        try {
//            long long46 = day39.getFirstMillisecond(calendar45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangleInsets10);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
//        org.junit.Assert.assertNotNull(shape19);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
//        org.junit.Assert.assertNotNull(rectangleInsets23);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560452399999L + "'", long41 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(font43);
//        org.junit.Assert.assertNotNull(date44);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setTickMarkOutsideLength((float) (-1L));
        double double9 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis6.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        java.awt.Color color15 = java.awt.Color.darkGray;
        numberAxis12.setAxisLinePaint((java.awt.Paint) color15);
        java.lang.Object obj17 = numberAxis12.clone();
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis12.setTickMarkPaint(paint18);
        java.text.NumberFormat numberFormat20 = null;
        numberAxis12.setNumberFormatOverride(numberFormat20);
        boolean boolean22 = numberAxis12.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis12.setStandardTickUnits(tickUnitSource23);
        boolean boolean25 = dateAxis10.equals((java.lang.Object) tickUnitSource23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.zoomRange((double) (short) -1, 0.2d);
        dateAxis26.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis32.setTickUnit(dateTickUnit33);
        java.util.Date date35 = dateAxis26.calculateHighestVisibleTickValue(dateTickUnit33);
        java.util.Date date36 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit33);
        java.util.Date date37 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit33);
        java.util.Date date38 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit33);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis41.getCategoryEnd(0, (int) (short) 0, rectangle2D44, rectangleEdge45);
        categoryAxis41.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double50 = rectangleInsets49.getBottom();
        double double52 = rectangleInsets49.extendHeight((double) (short) 0);
        double double54 = rectangleInsets49.calculateRightInset((double) 8);
        categoryAxis41.setTickLabelInsets(rectangleInsets49);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape58 = numberAxis57.getUpArrow();
        numberAxis57.setTickMarksVisible(false);
        double double61 = numberAxis57.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = numberAxis57.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis41, (org.jfree.chart.axis.ValueAxis) numberAxis57, categoryItemRenderer63);
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot64.setFixedDomainAxisSpace(axisSpace65, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = categoryAxis69.getCategoryEnd(0, (int) (short) 0, rectangle2D72, rectangleEdge73);
        categoryAxis69.setCategoryLabelPositionOffset((int) '4');
        int int77 = categoryPlot64.getDomainAxisIndex(categoryAxis69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        java.awt.geom.Point2D point2D80 = null;
        categoryPlot64.zoomRangeAxes(0.0d, plotRenderingInfo79, point2D80);
        categoryPlot64.setAnchorValue((double) 0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer85 = null;
        categoryPlot64.setRenderer(10, categoryItemRenderer85);
        categoryPlot64.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation90 = categoryPlot64.getDomainAxisLocation((int) 'a');
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot64);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 8.0d + "'", double52 == 8.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 8.0d + "'", double54 == 8.0d);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(axisLocation90);
    }
}

