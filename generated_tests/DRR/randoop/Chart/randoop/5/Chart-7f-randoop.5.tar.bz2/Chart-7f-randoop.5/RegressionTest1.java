import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "13-June-2019");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getMonth();
        java.lang.Class<?> wildcardClass7 = day5.getClass();
        int int9 = day5.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 1560495599999L);
        java.lang.Object obj12 = timePeriodValue11.clone();
        timePeriodValues4.add(timePeriodValue11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, 1577865599999L);
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("13-June-2019");
//        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("13-June-2019");
//        seriesException5.addSuppressed((java.lang.Throwable) seriesException7);
//        boolean boolean9 = day0.equals((java.lang.Object) seriesException5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int4 = day0.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod7, "hi!", "TimePeriodValue[13-June-2019,1560495599999]");
        int int11 = timePeriodValues10.getMinMiddleIndex();
        int int12 = timePeriodValues10.getMaxEndIndex();
        int int13 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean16 = day14.equals((java.lang.Object) 1);
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        int int19 = year18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) (byte) 100);
        java.lang.Class<?> wildcardClass23 = year18.getClass();
        java.util.Date date24 = null;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean27 = day25.equals((java.lang.Object) 1);
        java.util.Date date28 = day25.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        boolean boolean32 = day30.equals((java.lang.Object) 1);
        java.util.Date date33 = day30.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date28, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone34);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod37);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        timePeriodValues4.setNotify(false);
        int int7 = timePeriodValues4.getMinMiddleIndex();
        timePeriodValues4.setRangeDescription("13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues4.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int4 = day0.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod7, "hi!", "TimePeriodValue[13-June-2019,1560495599999]");
        java.lang.Class<?> wildcardClass11 = timePeriod7.getClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560495599999L, (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException6.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        java.lang.String str9 = day0.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560452399999L + "'", long7 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        java.util.Date date6 = day3.getEnd();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) day3);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean5 = timePeriodValues4.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues4.createCopy(0, (int) (short) 1);
        boolean boolean9 = timePeriodValues8.getNotify();
        java.lang.Object obj10 = timePeriodValues8.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues8.createCopy(2, (int) '#');
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) 100L);
        java.lang.Object obj7 = new java.lang.Object();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent(obj7);
        boolean boolean9 = timePeriodValues1.equals(obj7);
        timePeriodValues1.setRangeDescription("hi!");
        timePeriodValues1.setDescription("");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        java.lang.Class<?> wildcardClass16 = day14.getClass();
        int int18 = day14.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        timePeriodValue20.setValue((java.lang.Number) 2019);
        timePeriodValues1.add(timePeriodValue20);
        timePeriodValues1.setDomainDescription("");
        java.lang.Comparable comparable27 = timePeriodValues1.getKey();
        int int28 = timePeriodValues1.getMinMiddleIndex();
        int int29 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (byte) 1 + "'", comparable27.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        timePeriodValues4.setNotify(false);
        int int7 = timePeriodValues4.getItemCount();
        int int8 = timePeriodValues4.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) 'a', 0);
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable[] throwableArray7 = seriesException3.getSuppressed();
        java.lang.Throwable[] throwableArray8 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues9.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) 100L);
        java.lang.Object obj15 = new java.lang.Object();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent(obj15);
        boolean boolean17 = timePeriodValues9.equals(obj15);
        timePeriodValues9.setRangeDescription("hi!");
        timePeriodValues9.setDescription("");
        boolean boolean22 = year4.equals((java.lang.Object) timePeriodValues9);
        int int23 = timePeriodValues9.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, (long) '4');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.lang.Class<?> wildcardClass8 = day6.getClass();
//        java.util.Date date9 = day6.getStart();
//        int int10 = day0.compareTo((java.lang.Object) day6);
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        int int13 = day12.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int4 = day0.compareTo((java.lang.Object) 12);
//        int int5 = day0.getYear();
//        long long6 = day0.getFirstMillisecond();
//        long long7 = day0.getFirstMillisecond();
//        long long8 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int4 = day0.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValue6.setValue((java.lang.Number) 2019);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        boolean boolean12 = day10.equals((java.lang.Object) 1);
        java.util.Date date13 = day10.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        java.lang.Class<?> wildcardClass16 = day14.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean20 = day18.equals((java.lang.Object) 1);
        java.util.Date date21 = day18.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date13, timeZone23);
        long long26 = year25.getLastMillisecond();
        boolean boolean27 = timePeriodValue6.equals((java.lang.Object) year25);
        long long28 = year25.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (-1L));
        timePeriodValue6.setValue((java.lang.Number) 7);
        java.lang.Number number9 = timePeriodValue6.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 7 + "'", number9.equals(7));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (-1.0f));
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        long long10 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) 1);
        java.util.Date date8 = day5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date3, timeZone11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean16 = day14.equals((java.lang.Object) 1);
        java.util.Date date17 = day14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        boolean boolean23 = day21.equals((java.lang.Object) 1);
        java.util.Date date24 = day21.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date24, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean31 = day29.equals((java.lang.Object) 1);
        java.util.Date date32 = day29.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32, timeZone35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date24, timeZone35);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date17, timeZone35);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date3, timeZone35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        boolean boolean45 = day43.equals((java.lang.Object) 1);
        java.util.Date date46 = day43.getEnd();
        boolean boolean47 = simpleTimePeriod42.equals((java.lang.Object) day43);
        java.util.Date date48 = simpleTimePeriod42.getStart();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        int int50 = day49.getMonth();
        java.lang.Class<?> wildcardClass51 = day49.getClass();
        java.util.Date date52 = day49.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date48, date52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        boolean boolean56 = day54.equals((java.lang.Object) 1);
        java.util.Date date57 = day54.getEnd();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        boolean boolean61 = day59.equals((java.lang.Object) 1);
        java.util.Date date62 = day59.getEnd();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date57, timeZone63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        boolean boolean68 = day66.equals((java.lang.Object) 1);
        java.util.Date date69 = day66.getEnd();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date69, timeZone70);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date57, timeZone70);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date48, timeZone70);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date3, timeZone70);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        boolean boolean2 = timePeriodValues1.getNotify();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy(100, (int) (byte) 1);
//        int int6 = timePeriodValues5.getMinStartIndex();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "", "13-June-2019");
//        boolean boolean12 = timePeriodValues5.equals((java.lang.Object) timePeriodValues11);
//        boolean boolean13 = timePeriodValues5.getNotify();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) 11);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        boolean boolean23 = day21.equals((java.lang.Object) 1);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 1);
//        java.util.Date date27 = day24.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean31 = day29.equals((java.lang.Object) 1);
//        java.util.Date date32 = day29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32, timeZone35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date27, timeZone35);
//        int int38 = day21.compareTo((java.lang.Object) date27);
//        int int39 = day18.compareTo((java.lang.Object) int38);
//        long long40 = day18.getLastMillisecond();
//        boolean boolean41 = simpleTimePeriod16.equals((java.lang.Object) day18);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) (short) 10);
//        java.util.Date date44 = simpleTimePeriod16.getStart();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560495599999L + "'", long40 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(date44);
//    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test27");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int4 = day0.compareTo((java.lang.Object) 12);
//        int int5 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) '4');
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 13);
//        boolean boolean11 = timePeriodValue7.equals((java.lang.Object) simpleTimePeriod10);
//        java.lang.String str12 = timePeriodValue7.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,52.0]" + "'", str12.equals("TimePeriodValue[13-June-2019,52.0]"));
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        java.util.Date date7 = day4.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.lang.String str9 = year8.toString();
        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) year8);
        long long11 = year8.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year8.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test29");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test30");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy(100, (int) (byte) 1);
        int int6 = timePeriodValues5.getMinStartIndex();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "", "13-June-2019");
        boolean boolean12 = timePeriodValues5.equals((java.lang.Object) timePeriodValues11);
        int int13 = timePeriodValues5.getMaxEndIndex();
        try {
            timePeriodValues5.update(13, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(timePeriodValues5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test32");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean5 = timePeriodValues4.getNotify();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues4.getKey();
        timePeriodValues4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 1 + "'", comparable8.equals((byte) 1));
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test34");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        int int5 = year4.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
//        boolean boolean10 = year4.equals((java.lang.Object) timePeriodValues7);
//        java.lang.String str11 = timePeriodValues7.getDomainDescription();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        java.lang.Class<?> wildcardClass14 = day12.getClass();
//        java.util.Date date15 = day12.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day12.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) (-1L));
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day12, (double) 11);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getMonth();
//        java.lang.Class<?> wildcardClass23 = day21.getClass();
//        int int25 = day21.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue27.getPeriod();
//        org.jfree.data.time.TimePeriod timePeriod29 = timePeriodValue27.getPeriod();
//        java.lang.String str30 = timePeriodValue27.toString();
//        timePeriodValues7.add(timePeriodValue27);
//        timePeriodValue27.setValue((java.lang.Number) 100.0d);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(timePeriod28);
//        org.junit.Assert.assertNotNull(timePeriod29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TimePeriodValue[13-June-2019,1560495599999]" + "'", str30.equals("TimePeriodValue[13-June-2019,1560495599999]"));
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 0);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        boolean boolean8 = day6.equals((java.lang.Object) 1);
        java.util.Date date9 = day6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getMonth();
        java.lang.Class<?> wildcardClass12 = day10.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean16 = day14.equals((java.lang.Object) 1);
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date9, timeZone19);
        long long22 = year21.getLastMillisecond();
        long long23 = year21.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year21, 0.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean28 = timePeriodValues27.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        boolean boolean33 = day31.equals((java.lang.Object) 1);
        java.util.Date date34 = day31.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        int int36 = year35.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
        long long38 = year35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
        timePeriodValues27.setKey((java.lang.Comparable) year35);
        boolean boolean41 = timePeriodValues1.equals((java.lang.Object) timePeriodValues27);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 1);
//        java.util.Date date4 = day1.getEnd();
//        java.lang.String str5 = day1.toString();
//        long long6 = day1.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate7 = day1.getSerialDate();
//        java.lang.String str8 = day1.toString();
//        java.util.Date date9 = day1.getStart();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date0, date9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test37");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.lang.Class<?> wildcardClass8 = day6.getClass();
//        java.util.Date date9 = day6.getStart();
//        int int10 = day0.compareTo((java.lang.Object) day6);
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        int int13 = day12.getYear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int4 = day0.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod7, "hi!", "TimePeriodValue[13-June-2019,1560495599999]");
        int int11 = timePeriodValues10.getMinMiddleIndex();
        int int12 = timePeriodValues10.getMaxEndIndex();
        timePeriodValues10.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues16.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean21 = timePeriodValues16.equals((java.lang.Object) 100L);
        java.lang.Object obj22 = new java.lang.Object();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent(obj22);
        boolean boolean24 = timePeriodValues16.equals(obj22);
        timePeriodValues16.setRangeDescription("hi!");
        timePeriodValues16.setDescription("");
        boolean boolean29 = timePeriodValues10.equals((java.lang.Object) timePeriodValues16);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue31 = timePeriodValues16.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "13-June-2019");
        java.lang.Class<?> wildcardClass5 = timePeriodValues4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean9 = day7.equals((java.lang.Object) 1);
        java.util.Date date10 = day7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean13 = day11.equals((java.lang.Object) 1);
        java.util.Date date14 = day11.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        boolean boolean18 = day16.equals((java.lang.Object) 1);
        java.util.Date date19 = day16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date14, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        boolean boolean25 = day23.equals((java.lang.Object) 1);
        java.util.Date date26 = day23.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date14, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        boolean boolean32 = day30.equals((java.lang.Object) 1);
        java.util.Date date33 = day30.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.next();
        java.lang.Class<?> wildcardClass36 = year34.getClass();
        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        boolean boolean40 = day38.equals((java.lang.Object) 1);
        java.util.Date date41 = day38.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = day42.getMonth();
        java.lang.Class<?> wildcardClass44 = day42.getClass();
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        boolean boolean48 = day46.equals((java.lang.Object) 1);
        java.util.Date date49 = day46.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date49, timeZone51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date41, timeZone51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        boolean boolean56 = day54.equals((java.lang.Object) 1);
        java.util.Date date57 = day54.getEnd();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57, timeZone58);
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date57, timeZone60);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean64 = day62.equals((java.lang.Object) 1);
        java.util.Date date65 = day62.getEnd();
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65, timeZone66);
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date65, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date57, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date41, timeZone68);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date14, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone68);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNull(regularTimePeriod73);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 1);
        java.util.Date date5 = day2.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1));
        boolean boolean11 = timePeriodValues1.getNotify();
        boolean boolean12 = timePeriodValues1.getNotify();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 1);
        java.util.Date date16 = day13.getEnd();
        int int17 = day13.getMonth();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 5);
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: Time");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 6);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        int int4 = day0.getMonth();
        int int5 = day0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int4 = day0.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 11);
        java.lang.Object obj7 = timePeriodValue6.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        int int4 = day3.getMonth();
        java.lang.Class<?> wildcardClass5 = day3.getClass();
        int int7 = day3.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod10, "hi!", "TimePeriodValue[13-June-2019,1560495599999]");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        int int15 = timePeriodValues13.getMaxEndIndex();
        timePeriodValues13.fireSeriesChanged();
        int int17 = timePeriodValues13.getMinStartIndex();
        boolean boolean18 = year1.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues13.createCopy(12, (int) 'a');
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timePeriodValues21);
    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test47");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        java.util.Date date7 = day4.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        java.lang.Class<?> wildcardClass9 = year8.getClass();
//        long long10 = year8.getFirstMillisecond();
//        java.util.Date date11 = year8.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        java.lang.Class<?> wildcardClass14 = day12.getClass();
//        int int16 = day12.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 1560495599999L);
//        int int19 = year8.compareTo((java.lang.Object) day12);
//        boolean boolean20 = day0.equals((java.lang.Object) day12);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

//    @Test
//    public void test48() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test48");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int4 = day0.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod7, "hi!", "TimePeriodValue[13-June-2019,1560495599999]");
//        int int11 = timePeriodValues10.getMinMiddleIndex();
//        int int12 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 1);
//        java.util.Date date16 = day13.getEnd();
//        java.lang.String str17 = day13.toString();
//        long long18 = day13.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate19 = day13.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate19, "hi!", "hi!");
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getMonth();
//        java.lang.Class<?> wildcardClass25 = day23.getClass();
//        int int27 = day23.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) 1560495599999L);
//        java.lang.Object obj30 = timePeriodValue29.clone();
//        timePeriodValues22.add(timePeriodValue29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getMonth();
//        java.lang.Class<?> wildcardClass34 = day32.getClass();
//        int int36 = day32.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day32, (java.lang.Number) 1560495599999L);
//        timePeriodValue38.setValue((java.lang.Number) 10.0d);
//        timePeriodValues22.add(timePeriodValue38);
//        org.jfree.data.time.TimePeriod timePeriod42 = timePeriodValue38.getPeriod();
//        timePeriodValues10.add(timePeriodValue38);
//        java.lang.String str44 = timePeriodValue38.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(timePeriod7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(timePeriod42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str44.equals("TimePeriodValue[13-June-2019,10.0]"));
//    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 12);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) 100L);
        java.lang.Object obj7 = new java.lang.Object();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent(obj7);
        boolean boolean9 = timePeriodValues1.equals(obj7);
        timePeriodValues1.setRangeDescription("hi!");
        timePeriodValues1.setDescription("");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        java.lang.Class<?> wildcardClass16 = day14.getClass();
        int int18 = day14.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        timePeriodValue20.setValue((java.lang.Number) 2019);
        timePeriodValues1.add(timePeriodValue20);
        timePeriodValues1.setDomainDescription("");
        java.lang.Comparable comparable27 = timePeriodValues1.getKey();
        int int28 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Comparable comparable29 = timePeriodValues1.getKey();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (byte) 1 + "'", comparable27.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (byte) 1 + "'", comparable29.equals((byte) 1));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        boolean boolean8 = day6.equals((java.lang.Object) 1);
        java.util.Date date9 = day6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date3, timeZone10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date3);
        int int14 = year13.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int4 = day0.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod7, "hi!", "TimePeriodValue[13-June-2019,1560495599999]");
        int int11 = timePeriodValues10.getMinMiddleIndex();
        int int12 = timePeriodValues10.getMaxEndIndex();
        timePeriodValues10.setRangeDescription("");
        java.lang.String str15 = timePeriodValues10.getDescription();
        boolean boolean16 = timePeriodValues10.getNotify();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.lang.Class<?> wildcardClass19 = day17.getClass();
        int int21 = day17.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod24 = timePeriodValue23.getPeriod();
        timePeriodValue23.setValue((java.lang.Number) 2019);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        boolean boolean29 = day27.equals((java.lang.Object) 1);
        java.util.Date date30 = day27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = day31.getMonth();
        java.lang.Class<?> wildcardClass33 = day31.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        boolean boolean37 = day35.equals((java.lang.Object) 1);
        java.util.Date date38 = day35.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date38, timeZone40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date30, timeZone40);
        long long43 = year42.getLastMillisecond();
        boolean boolean44 = timePeriodValue23.equals((java.lang.Object) year42);
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(timePeriod24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        int int7 = year6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues10.createCopy((int) (short) 0, (int) (short) 100);
        timePeriodValues13.setNotify(false);
        java.lang.Object obj16 = timePeriodValues13.clone();
        int int17 = year6.compareTo((java.lang.Object) timePeriodValues13);
        java.util.Calendar calendar18 = null;
        try {
            year6.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test54");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        java.util.Date date6 = day3.getEnd();
//        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) day3);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues9.createCopy((int) (short) 0, (int) (short) 100);
//        timePeriodValues12.setNotify(false);
//        java.lang.Object obj15 = timePeriodValues12.clone();
//        boolean boolean16 = day3.equals(obj15);
//        long long17 = day3.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(timePeriodValues12);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560452399999L + "'", long17 == 1560452399999L);
//    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        boolean boolean6 = timePeriodValues1.getNotify();
        java.lang.String str7 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 1 + "'", comparable5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test56");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        boolean boolean2 = timePeriodValues1.getNotify();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy(100, (int) (byte) 1);
//        int int6 = timePeriodValues5.getMinStartIndex();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "", "13-June-2019");
//        boolean boolean12 = timePeriodValues5.equals((java.lang.Object) timePeriodValues11);
//        boolean boolean13 = timePeriodValues5.getNotify();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) 11);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        boolean boolean23 = day21.equals((java.lang.Object) 1);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 1);
//        java.util.Date date27 = day24.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean31 = day29.equals((java.lang.Object) 1);
//        java.util.Date date32 = day29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32, timeZone35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date27, timeZone35);
//        int int38 = day21.compareTo((java.lang.Object) date27);
//        int int39 = day18.compareTo((java.lang.Object) int38);
//        long long40 = day18.getLastMillisecond();
//        boolean boolean41 = simpleTimePeriod16.equals((java.lang.Object) day18);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) (short) 10);
//        long long44 = simpleTimePeriod16.getEndMillis();
//        long long45 = simpleTimePeriod16.getStartMillis();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560495599999L + "'", long40 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 11L + "'", long44 == 11L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) 100L);
        int int7 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj8 = timePeriodValues1.clone();
        timePeriodValues1.setDomainDescription("TimePeriodValue[13-June-2019,1560495599999]");
        int int11 = timePeriodValues1.getMinStartIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 1);
        java.util.Date date5 = day2.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1));
        java.lang.String str11 = year6.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) 100L);
        java.lang.Object obj7 = new java.lang.Object();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent(obj7);
        boolean boolean9 = timePeriodValues1.equals(obj7);
        timePeriodValues1.setRangeDescription("hi!");
        timePeriodValues1.setDescription("");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        java.lang.Class<?> wildcardClass16 = day14.getClass();
        int int18 = day14.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        timePeriodValue20.setValue((java.lang.Number) 2019);
        timePeriodValues1.add(timePeriodValue20);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValues1.getTimePeriod(0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        java.util.Date date30 = simpleTimePeriod29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        boolean boolean33 = day31.equals((java.lang.Object) 1);
        java.util.Date date34 = day31.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        java.lang.String str36 = year35.toString();
        boolean boolean37 = simpleTimePeriod29.equals((java.lang.Object) year35);
        timePeriodValues1.setKey((java.lang.Comparable) year35);
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 0);
        timePeriodValues1.fireSeriesChanged();
        boolean boolean3 = timePeriodValues1.isEmpty();
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean5 = timePeriodValues4.getNotify();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        boolean boolean11 = day9.equals((java.lang.Object) 1);
        java.util.Date date12 = day9.getEnd();
        boolean boolean13 = simpleTimePeriod8.equals((java.lang.Object) day9);
        java.util.Date date14 = simpleTimePeriod8.getStart();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (double) (short) 100);
        timePeriodValues4.setNotify(true);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        boolean boolean24 = day22.equals((java.lang.Object) 1);
        java.util.Date date25 = day22.getEnd();
        boolean boolean26 = simpleTimePeriod21.equals((java.lang.Object) day22);
        long long27 = simpleTimePeriod21.getEndMillis();
        long long28 = simpleTimePeriod21.getEndMillis();
        long long29 = simpleTimePeriod21.getEndMillis();
        java.util.Date date30 = simpleTimePeriod21.getEnd();
        long long31 = simpleTimePeriod21.getStartMillis();
        long long32 = simpleTimePeriod21.getStartMillis();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, (java.lang.Number) (byte) 10);
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        int int7 = year6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues10.createCopy((int) (short) 0, (int) (short) 100);
        timePeriodValues13.setNotify(false);
        java.lang.Object obj16 = timePeriodValues13.clone();
        int int17 = year6.compareTo((java.lang.Object) timePeriodValues13);
        java.lang.String str18 = year6.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Class<?> wildcardClass6 = year4.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int4 = day0.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValue6.setValue((java.lang.Number) 2019);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        boolean boolean12 = day10.equals((java.lang.Object) 1);
        java.util.Date date13 = day10.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        java.lang.Class<?> wildcardClass16 = day14.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean20 = day18.equals((java.lang.Object) 1);
        java.util.Date date21 = day18.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date13, timeZone23);
        long long26 = year25.getLastMillisecond();
        boolean boolean27 = timePeriodValue6.equals((java.lang.Object) year25);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean27);
        try {
            timePeriodValues28.update((int) '#', (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        java.util.Date date6 = day3.getEnd();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) day3);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getMonth();
        java.lang.Class<?> wildcardClass11 = day9.getClass();
        java.util.Date date12 = day9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

//    @Test
//    public void test68() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test68");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.lang.Class<?> wildcardClass8 = day6.getClass();
//        java.util.Date date9 = day6.getStart();
//        int int10 = day0.compareTo((java.lang.Object) day6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day0.previous();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        java.util.Date date15 = day12.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        int int17 = year16.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues19.addPropertyChangeListener(propertyChangeListener20);
//        boolean boolean22 = year16.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str23 = timePeriodValues19.getDomainDescription();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getMonth();
//        java.lang.Class<?> wildcardClass26 = day24.getClass();
//        java.util.Date date27 = day24.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day24.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (double) (-1L));
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day24, (double) 11);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        java.lang.Class<?> wildcardClass35 = day33.getClass();
//        int int37 = day33.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.TimePeriod timePeriod40 = timePeriodValue39.getPeriod();
//        org.jfree.data.time.TimePeriod timePeriod41 = timePeriodValue39.getPeriod();
//        java.lang.String str42 = timePeriodValue39.toString();
//        timePeriodValues19.add(timePeriodValue39);
//        int int44 = day0.compareTo((java.lang.Object) timePeriodValue39);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int46 = day45.getMonth();
//        java.lang.Class<?> wildcardClass47 = day45.getClass();
//        int int49 = day45.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day45, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 0);
//        boolean boolean54 = timePeriodValues53.getNotify();
//        boolean boolean55 = timePeriodValue51.equals((java.lang.Object) timePeriodValues53);
//        int int56 = timePeriodValues53.getItemCount();
//        java.lang.Comparable comparable57 = timePeriodValues53.getKey();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        boolean boolean60 = day58.equals((java.lang.Object) 1);
//        java.util.Date date61 = day58.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61, timeZone62);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date61, timeZone64);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date61);
//        java.lang.String str67 = year66.toString();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        boolean boolean73 = day71.equals((java.lang.Object) 1);
//        java.util.Date date74 = day71.getEnd();
//        boolean boolean75 = simpleTimePeriod70.equals((java.lang.Object) day71);
//        long long76 = simpleTimePeriod70.getEndMillis();
//        long long77 = simpleTimePeriod70.getEndMillis();
//        long long78 = simpleTimePeriod70.getEndMillis();
//        int int79 = year66.compareTo((java.lang.Object) simpleTimePeriod70);
//        java.util.Date date80 = simpleTimePeriod70.getStart();
//        java.util.Date date81 = simpleTimePeriod70.getEnd();
//        timePeriodValues53.setKey((java.lang.Comparable) simpleTimePeriod70);
//        boolean boolean83 = day0.equals((java.lang.Object) timePeriodValues53);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(timePeriod40);
//        org.junit.Assert.assertNotNull(timePeriod41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "TimePeriodValue[13-June-2019,1560495599999]" + "'", str42.equals("TimePeriodValue[13-June-2019,1560495599999]"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + (byte) 0 + "'", comparable57.equals((byte) 0));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 10L + "'", long76 == 10L);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 0);
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        timePeriodValues1.fireSeriesChanged();
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3);
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 1);
        java.util.Date date16 = day13.getEnd();
        boolean boolean17 = simpleTimePeriod12.equals((java.lang.Object) day13);
        long long18 = simpleTimePeriod12.getEndMillis();
        long long19 = simpleTimePeriod12.getEndMillis();
        long long20 = simpleTimePeriod12.getEndMillis();
        int int21 = year8.compareTo((java.lang.Object) simpleTimePeriod12);
        java.util.Date date22 = simpleTimePeriod12.getStart();
        java.util.Date date23 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
    }

//    @Test
//    public void test71() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test71");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.lang.Class<?> wildcardClass8 = day6.getClass();
//        java.util.Date date9 = day6.getStart();
//        int int10 = day0.compareTo((java.lang.Object) day6);
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0d);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        boolean boolean8 = day6.equals((java.lang.Object) 1);
        java.util.Date date9 = day6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date3, timeZone10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone10);
        java.lang.Object obj14 = seriesChangeEvent13.getSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test74() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test74");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        java.util.Date date7 = day4.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean11 = day9.equals((java.lang.Object) 1);
//        java.util.Date date12 = day9.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date7, timeZone15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date3, timeZone15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 0);
//        timePeriodValues20.fireSeriesChanged();
//        boolean boolean22 = day18.equals((java.lang.Object) timePeriodValues20);
//        long long23 = day18.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//    }

//    @Test
//    public void test75() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test75");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) 100L);
//        int int7 = timePeriodValues1.getMinMiddleIndex();
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        java.lang.Class<?> wildcardClass11 = day9.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 1);
//        java.util.Date date16 = day13.getEnd();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone18);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 13);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        boolean boolean24 = day22.equals((java.lang.Object) 1);
//        java.util.Date date25 = day22.getEnd();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = year26.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timePeriodValues29.addPropertyChangeListener(propertyChangeListener30);
//        boolean boolean32 = year26.equals((java.lang.Object) timePeriodValues29);
//        java.lang.String str33 = timePeriodValues29.getDomainDescription();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getMonth();
//        java.lang.Class<?> wildcardClass36 = day34.getClass();
//        java.util.Date date37 = day34.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day34.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (double) (-1L));
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day34, (double) 11);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getMonth();
//        java.lang.Class<?> wildcardClass45 = day43.getClass();
//        int int47 = day43.compareTo((java.lang.Object) 12);
//        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.TimePeriod timePeriod50 = timePeriodValue49.getPeriod();
//        org.jfree.data.time.TimePeriod timePeriod51 = timePeriodValue49.getPeriod();
//        java.lang.String str52 = timePeriodValue49.toString();
//        timePeriodValues29.add(timePeriodValue49);
//        java.lang.Number number54 = timePeriodValue49.getValue();
//        timePeriodValues1.add(timePeriodValue49);
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.junit.Assert.assertNotNull(timePeriodValues4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(timePeriod50);
//        org.junit.Assert.assertNotNull(timePeriod51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "TimePeriodValue[13-June-2019,1560495599999]" + "'", str52.equals("TimePeriodValue[13-June-2019,1560495599999]"));
//        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 1560495599999L + "'", number54.equals(1560495599999L));
//    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        timePeriodValues4.setNotify(false);
        java.lang.Object obj7 = timePeriodValues4.clone();
        boolean boolean8 = timePeriodValues4.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener9);
        timePeriodValues4.delete((int) '4', (int) (byte) -1);
        java.lang.Object obj14 = timePeriodValues4.clone();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 0);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        java.lang.Class<?> wildcardClass6 = day4.getClass();
        int int8 = day4.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 1560495599999L);
        java.lang.Object obj11 = timePeriodValue10.clone();
        timePeriodValues1.add(timePeriodValue10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 1);
        java.util.Date date16 = day13.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
        int int20 = year19.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, 100.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        boolean boolean28 = day26.equals((java.lang.Object) 1);
        java.util.Date date29 = day26.getEnd();
        boolean boolean30 = simpleTimePeriod25.equals((java.lang.Object) day26);
        long long31 = simpleTimePeriod25.getEndMillis();
        boolean boolean32 = timePeriodValue22.equals((java.lang.Object) simpleTimePeriod25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, (double) 0L);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        java.lang.Comparable comparable37 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + (byte) 0 + "'", comparable37.equals((byte) 0));
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy((int) (short) 0, (int) (short) 100);
        boolean boolean5 = timePeriodValues4.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues4.createCopy(0, (int) (short) 1);
        boolean boolean9 = timePeriodValues8.getNotify();
        java.lang.String str10 = timePeriodValues8.getDomainDescription();
        int int11 = timePeriodValues8.getMinStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test79() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test79");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        java.util.Date date7 = day4.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        java.lang.String str9 = year8.toString();
//        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) year8);
//        long long11 = year8.getFirstMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        long long15 = day12.getFirstMillisecond();
//        int int16 = year8.compareTo((java.lang.Object) day12);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test80() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test80");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        java.util.Date date9 = day6.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (-1));
//        boolean boolean15 = timePeriodValues5.getNotify();
//        boolean boolean16 = timePeriodValues5.getNotify();
//        boolean boolean17 = day0.equals((java.lang.Object) boolean16);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test81");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.lang.String str3 = timePeriodValues1.getDescription();
        try {
            java.lang.Number number5 = timePeriodValues1.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
    }

//    @Test
//    public void test82() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test82");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.util.Date date3 = day0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day5.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

//    @Test
//    public void test83() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test83");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }
//}

