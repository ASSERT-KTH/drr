import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) ' ', shape1, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Shape shape0 = null;
        java.awt.Paint paint1 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) (byte) 0, (float) (byte) 1, (-1.0d), (float) 0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 1L, (float) 1L, textAnchor4, (double) '#', textAnchor6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        try {
            org.jfree.data.Range range7 = barRenderer0.findRangeBounds(categoryDataset6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (short) 100, 0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) (short) 10, "", textAnchor3, textAnchor4, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            barRenderer0.drawOutline(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("hi!");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 100L, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1, numberFormat1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace2, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=128]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE2" + "'", str1.equals("ItemLabelAnchor.INSIDE2"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { '4', 10.0f, (-1L), 10.0f, (-1) };
        java.lang.Comparable[] comparableArray6 = null;
        double[] doubleArray12 = new double[] { (short) 10, 10L, (-1), 100, 'a' };
        double[] doubleArray18 = new double[] { (short) 10, 10L, (-1), 100, 'a' };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray6, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (short) -1, 0.0d, rectangleAnchor5);
        java.awt.Shape shape7 = null;
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D6, shape7);
        try {
            org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) '#', (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.Plot plot7 = null;
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (short) -1, 0.0d, rectangleAnchor13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace17 = numberAxis1.reserveSpace(graphics2D6, plot7, rectangle2D14, rectangleEdge15, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = null;
        barRenderer14.setGradientPaintTransformer(gradientPaintTransformer15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer14.setBaseOutlineStroke(stroke17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint21 = barRenderer19.lookupSeriesPaint(0);
        java.awt.Paint paint23 = barRenderer19.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj24 = barRenderer19.clone();
        java.awt.Paint paint27 = barRenderer19.getItemPaint((int) (short) 10, 0);
        try {
            org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem(attributedString0, "ClassContext", "hi!", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke17, paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) ' ', (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (short) -1, 0.0d, rectangleAnchor18);
        java.awt.Shape shape20 = null;
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D19, shape20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str23 = color22.toString();
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D19, (java.awt.Paint) color22, stroke24, (java.awt.Paint) color25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean30 = numberAxis29.isPositiveArrowVisible();
        numberAxis29.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.util.Layer layer34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        try {
            barRenderer0.drawAnnotations(graphics2D8, rectangle2D19, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis29, layer34, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str23.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("ItemLabelAnchor.INSIDE2", font1, (java.awt.Paint) color2, (float) (short) -1, (int) (byte) 1, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        try {
            numberAxis1.setRange((double) 255, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (255.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(numberFormat3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("java.awt.Color[r=255,g=255,b=64]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=255,g=255,b=64]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) "ClassContext");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("CONTRACT", graphics2D1, (float) (short) 0, (float) (byte) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        try {
            java.util.List list7 = categoryAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setVersion("java.awt.Color[r=255,g=255,b=64]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double double3 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("RangeType.NEGATIVE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RangeType.NEGATIVE");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("ClassContext", "java.awt.Color[r=0,g=0,b=128]", "ItemLabelAnchor.INSIDE2", image3, "", "RangeType.NEGATIVE", "ClassContext");
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) barRenderer1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke2 = numberAxis1.getAxisLineStroke();
        java.awt.Font font3 = null;
        try {
            numberAxis1.setTickLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.lang.String str8 = numberAxis1.getLabelToolTip();
        numberAxis1.setLabelToolTip("AxisLocation.TOP_OR_RIGHT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis1.setMarkerBand(markerAxisBand11);
        double double13 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        try {
            legendItem17.setFillPaintTransformer(gradientPaintTransformer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            barRenderer0.addChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        numberAxis1.setAutoRangeMinimumSize((double) '#');
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 100, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, (double) (short) -1, 0.0d, rectangleAnchor20);
        plotRenderingInfo14.setDataArea(rectangle2D21);
        try {
            barRenderer0.drawBackground(graphics2D11, categoryPlot12, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 0.0f, (float) (short) 10, 0.0d, 0.0f, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            boolean boolean11 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D8, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean2 = textTitle1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Stroke stroke3 = null;
        try {
            barRenderer0.setBaseStroke(stroke3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        java.lang.Comparable comparable4 = null;
        try {
            categoryAxis0.addCategoryLabelToolTip(comparable4, "AxisLocation.TOP_OR_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        java.awt.Shape shape7 = barRenderer0.getItemShape(0, 10);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        java.awt.Shape shape7 = barRenderer0.getItemShape(0, 10);
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke(0, 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, range8);
        try {
            org.jfree.chart.util.Size2D size2D10 = flowArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.lang.String str8 = numberAxis1.getLabelToolTip();
        boolean boolean9 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        numberAxis1.setLowerMargin((double) 10);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color8);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color8);
        int int11 = color8.getGreen();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 0, (double) 100, 0, (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=255,g=255,b=64]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (byte) 10, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RangeType.NEGATIVE", graphics2D1, (float) (short) 10, (float) 2, textAnchor4, (double) 100.0f, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 10, (float) '4', textAnchor4, (double) 15, (float) 1, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener12 = null;
        try {
            barRenderer0.addChangeListener(rendererChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesPaint(0);
        barRenderer9.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer9.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesNegativeItemLabelPosition(100, itemLabelPosition15, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        java.lang.Object obj20 = standardCategorySeriesLabelGenerator18.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 15, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = null;
        try {
            numberAxis0.setRange(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font2 = textTitle1.getFont();
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle1.addChangeListener(titleChangeListener3);
        textTitle1.setText("");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, range9);
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle1.arrange(graphics2D7, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke2 = numberAxis1.getAxisLineStroke();
        org.jfree.data.Range range3 = null;
        try {
            numberAxis1.setRangeWithMargins(range3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        barRenderer9.setGradientPaintTransformer(gradientPaintTransformer10);
        barRenderer9.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer9.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = barRenderer9.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        barRenderer21.setGradientPaintTransformer(gradientPaintTransformer22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer21.setBaseOutlineStroke(stroke24);
        barRenderer21.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint32 = barRenderer30.lookupSeriesPaint(0);
        barRenderer30.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer30.getBaseNegativeItemLabelPosition();
        barRenderer21.setSeriesNegativeItemLabelPosition(100, itemLabelPosition36, false);
        barRenderer9.setSeriesPositiveItemLabelPosition(1, itemLabelPosition36);
        try {
            barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit(1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        double double5 = size2D4.getWidth();
        size2D4.setWidth((double) (short) -1);
        size2D4.setHeight(0.0d);
        size2D4.setWidth(0.0d);
        boolean boolean12 = blockBorder1.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.clearCache(classLoader3);
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean3 = textTitle1.equals((java.lang.Object) paint2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font6);
        textTitle1.setFont(font6);
        java.lang.String str9 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        int int22 = color17.getRed();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.awt.Shape shape8 = numberAxis1.getDownArrow();
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean6 = numberAxis5.isPositiveArrowVisible();
        numberAxis5.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = null;
        numberAxis5.setMarkerBand(markerAxisBand10);
        java.awt.Shape shape12 = numberAxis5.getDownArrow();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = null;
        barRenderer13.setGradientPaintTransformer(gradientPaintTransformer14);
        barRenderer13.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = barRenderer13.getLegendItemToolTipGenerator();
        boolean boolean22 = barRenderer13.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int23 = barRenderer13.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer13);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str26 = color25.toString();
        barRenderer13.setBaseItemLabelPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        try {
            org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem(attributedString0, "", "ClassContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", shape12, (java.awt.Paint) color25, stroke28, (java.awt.Paint) color29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str26.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        boolean boolean12 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic4.getShapeLocation();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (short) -1, 0.0d, rectangleAnchor18);
        java.awt.Shape shape20 = null;
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D19, shape20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str23 = color22.toString();
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D19, (java.awt.Paint) color22, stroke24, (java.awt.Paint) color25);
        try {
            java.lang.Object obj28 = legendGraphic4.draw(graphics2D8, rectangle2D19, (java.lang.Object) "java.awt.Color[r=0,g=0,b=128]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str23.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        java.lang.String str3 = numberTickUnit0.valueToString((double) 1.0f);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (short) -1, 0.0d, rectangleAnchor11);
        java.awt.Shape shape13 = null;
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D12, shape13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D12, rectangleEdge15);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D12);
        numberAxis5.setLeftArrow((java.awt.Shape) rectangle2D12);
        try {
            blockBorder1.draw(graphics2D3, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray7 = new float[] { (short) 0, (byte) -1, (short) -1 };
        float[] floatArray8 = color3.getRGBColorComponents(floatArray7);
        float[] floatArray9 = java.awt.Color.RGBtoHSB((int) (byte) -1, 1, 1, floatArray7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = null;
        try {
            legendGraphic4.setShapeAnchor(rectangleAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.lang.Object obj3 = null;
        boolean boolean4 = rectangleInsets2.equals(obj3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic4.getShapeLocation();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range9, range10);
        org.jfree.data.Range range12 = rectangleConstraint11.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint11.toFixedHeight((double) (short) 10);
        try {
            org.jfree.chart.util.Size2D size2D15 = legendGraphic4.arrange(graphics2D8, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.awt.Paint paint7 = barRenderer0.getItemLabelPaint((int) (byte) 1, 100);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        java.awt.Shape shape14 = null;
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D13, shape14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str17 = color16.toString();
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D13, (java.awt.Paint) color16, stroke18, (java.awt.Paint) color19);
        textTitle1.setBackgroundPaint((java.awt.Paint) color16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ClassContext" + "'", str2.equals("ClassContext"));
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str17.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        categoryItemEntity15.setRowKey((java.lang.Comparable) (short) 100);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        numberAxis1.addChangeListener(axisChangeListener8);
        boolean boolean10 = numberAxis1.isVerticalTickLabels();
        numberAxis1.resizeRange((double) (-1.0f), 62.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        numberAxis1.resizeRange((double) 1.0f);
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        double double6 = rectangleInsets4.trimWidth((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-100.0d) + "'", double6 == (-100.0d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        boolean boolean11 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((-100.0d), range1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis2.setLabelFont(font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=64]", font3);
        boolean boolean6 = textTitle5.getNotify();
        textTitle5.setMargin(0.0d, (double) 1L, 0.0d, (double) (-1));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 0, 10.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj6 = categoryAxis3.clone();
        boolean boolean7 = rectangleInsets2.equals((java.lang.Object) categoryAxis3);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean11 = textTitle9.equals((java.lang.Object) paint10);
        boolean boolean12 = textTitle9.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) (short) -1, 0.0d, rectangleAnchor22);
        java.awt.Shape shape24 = null;
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D23, shape24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str27 = color26.toString();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D23, (java.awt.Paint) color26, stroke28, (java.awt.Paint) color29);
        textTitle9.setBounds(rectangle2D23);
        rectangleInsets2.trim(rectangle2D23);
        double double34 = rectangleInsets2.calculateLeftOutset(0.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str27.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false, false);
        java.awt.Paint paint8 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = barRenderer0.getPlot();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryPlot10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        barRenderer0.setAutoPopulateSeriesStroke(false);
        java.awt.Paint paint17 = barRenderer0.getSeriesFillPaint(10);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=0,g=0,b=128]", graphics2D1, (float) (short) 1, (float) 0, (double) '4', 0.0f, (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        java.awt.Font font15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 1L, textMeasurer18);
        int int20 = color16.getAlpha();
        barRenderer0.setBasePaint((java.awt.Paint) color16);
        int int22 = color16.getGreen();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (short) -1, 0.0d, rectangleAnchor18);
        java.awt.Shape shape20 = null;
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D19, shape20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge22);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis27.setLabelFont(font28);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=64]", font28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray35 = new float[] { (short) 0, (byte) -1, (short) -1 };
        float[] floatArray36 = color31.getRGBColorComponents(floatArray35);
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font28, (java.awt.Paint) color31);
        try {
            java.lang.Object obj38 = legendTitle11.draw(graphics2D12, rectangle2D19, (java.lang.Object) font28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(textBlock37);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        barRenderer0.setAutoPopulateSeriesStroke(false);
        double double16 = barRenderer0.getLowerClip();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) double16);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = color0.brighter();
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-14336) + "'", int2 == (-14336));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        try {
            barRenderer0.setPlot(categoryPlot12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle11.setVerticalAlignment(verticalAlignment13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        boolean boolean16 = verticalAlignment13.equals((java.lang.Object) categoryLabelPositions15);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint12 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean13 = textTitle11.equals((java.lang.Object) paint12);
        boolean boolean14 = textTitle11.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        java.awt.Shape shape26 = null;
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D25, shape26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str29 = color28.toString();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D25, (java.awt.Paint) color28, stroke30, (java.awt.Paint) color31);
        textTitle11.setBounds(rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) (short) -1, 0.0d, rectangleAnchor45);
        plotRenderingInfo39.setDataArea(rectangle2D46);
        plotRenderingInfo37.addSubplotInfo(plotRenderingInfo39);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState49 = barRenderer0.initialise(graphics2D9, rectangle2D25, categoryPlot34, 0, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str29.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RangeType.NEGATIVE");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("RangeType.NEGATIVE");
        try {
            java.lang.Object obj7 = jFreeChartResources0.getObject("1");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key 1");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        barRenderer4.setGradientPaintTransformer(gradientPaintTransformer5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer4.setBaseOutlineStroke(stroke7);
        java.awt.Shape shape11 = barRenderer4.getItemShape(0, 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape11, rectangleAnchor12, (double) (-1), (double) (-1L));
        java.awt.Color color16 = java.awt.Color.gray;
        try {
            org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=255,g=255,b=64]", "RectangleEdge.LEFT", "java.awt.Color[r=255,g=255,b=64]", shape15, (java.awt.Paint) color16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("CONTRACT", graphics2D1, 2.0f, (float) '#', textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        boolean boolean12 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, (double) (short) -1, 0.0d, rectangleAnchor20);
        java.awt.Shape shape22 = null;
        boolean boolean23 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D21, shape22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D21, rectangleEdge24);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D21);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj30 = categoryAxis27.clone();
        categoryAxis27.setAxisLineVisible(true);
        double double33 = categoryAxis27.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType36 = numberAxis35.getRangeType();
        org.jfree.chart.util.Layer layer37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.util.Size2D size2D44 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, (double) (short) -1, 0.0d, rectangleAnchor47);
        plotRenderingInfo41.setDataArea(rectangle2D48);
        plotRenderingInfo39.addSubplotInfo(plotRenderingInfo41);
        try {
            barRenderer0.drawAnnotations(graphics2D14, rectangle2D21, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis35, layer37, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(rangeType36);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedWidth();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (short) -1, 0.0d, rectangleAnchor11);
        java.awt.Shape shape13 = null;
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D12, shape13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str16 = color15.toString();
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D12, (java.awt.Paint) color15, stroke17, (java.awt.Paint) color18);
        objectList0.set((int) '4', (java.lang.Object) color15);
        boolean boolean22 = objectList0.equals((java.lang.Object) "CONTRACT");
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str16.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean3 = textTitle1.equals((java.lang.Object) paint2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font6);
        textTitle1.setFont(font6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ItemLabelAnchor.INSIDE2", graphics2D1, (float) 1, (float) 1, (double) (byte) 0, 2.0f, (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setLabelURL("ItemLabelAnchor.INSIDE2");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        java.lang.String str7 = rectangleInsets6.toString();
        double double9 = rectangleInsets6.trimHeight(100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str7.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 96.0d + "'", double9 == 96.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        int int18 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (short) 1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener19 = null;
        defaultStatisticalCategoryDataset12.removeChangeListener(datasetChangeListener19);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) (byte) 100);
        double double23 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset22);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Paint paint9 = null;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape2, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double16 = categoryAxis1.getCategoryStart((int) (short) 10, (int) (short) 1, rectangle2D13, rectangleEdge15);
        try {
            double double17 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 854.9999999999999d + "'", double16 == 854.9999999999999d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.lang.String str13 = numberAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setBaseSeriesVisible(false);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        barRenderer8.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer8.setBaseOutlineStroke(stroke11);
        barRenderer0.setBaseOutlineStroke(stroke11, true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.plot.Plot plot6 = categoryAxis0.getPlot();
        int int7 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        double double17 = categoryAxis0.getCategoryMargin();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.Plot plot19 = null;
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, (double) (short) -1, 0.0d, rectangleAnchor25);
        java.awt.Shape shape27 = null;
        boolean boolean28 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D26, shape27);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint33 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean34 = textTitle32.equals((java.lang.Object) paint33);
        boolean boolean35 = textTitle32.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) (short) -1, 0.0d, rectangleAnchor45);
        java.awt.Shape shape47 = null;
        boolean boolean48 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D46, shape47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str50 = color49.toString();
        java.awt.Stroke stroke51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D46, (java.awt.Paint) color49, stroke51, (java.awt.Paint) color52);
        textTitle32.setBounds(rectangle2D46);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.TOP;
        double double56 = numberAxis29.lengthToJava2D((double) 10L, rectangle2D46, rectangleEdge55);
        org.jfree.chart.axis.AxisSpace axisSpace57 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace58 = new org.jfree.chart.axis.AxisSpace();
        axisSpace57.ensureAtLeast(axisSpace58);
        double double60 = axisSpace58.getRight();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace61 = categoryAxis0.reserveSpace(graphics2D18, plot19, rectangle2D26, rectangleEdge55, axisSpace58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str50.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 100.0d + "'", double56 == 100.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (byte) 10, "UnitType.ABSOLUTE");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        double double3 = size2D2.getWidth();
        double double4 = size2D2.getWidth();
        size2D2.setHeight((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.chart.ui.ProjectInfo projectInfo16 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = org.jfree.chart.JFreeChart.INFO;
        projectInfo16.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo17.getVersion();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo21 = org.jfree.chart.JFreeChart.INFO;
        projectInfo20.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo21);
        projectInfo21.setCopyright("java.awt.Color[r=0,g=0,b=128]");
        projectInfo17.addLibrary((org.jfree.chart.ui.Library) projectInfo21);
        boolean boolean26 = categoryItemEntity15.equals((java.lang.Object) projectInfo21);
        java.lang.Comparable comparable27 = categoryItemEntity15.getColumnKey();
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(projectInfo16);
        org.junit.Assert.assertNotNull(projectInfo17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str19.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(projectInfo21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100L + "'", comparable27.equals(100L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean5 = textTitle3.equals((java.lang.Object) paint4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) (short) -1, 0.0d, rectangleAnchor16);
        java.awt.Shape shape18 = null;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D17, shape18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str21 = color20.toString();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D17, (java.awt.Paint) color20, stroke22, (java.awt.Paint) color23);
        textTitle3.setBounds(rectangle2D17);
        try {
            blockContainer0.draw(graphics2D1, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj6 = categoryAxis3.clone();
        boolean boolean7 = rectangleInsets2.equals((java.lang.Object) categoryAxis3);
        double double9 = rectangleInsets2.extendHeight((double) (-1L));
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) (short) -1, 0.0d, rectangleAnchor19);
        java.awt.Shape shape21 = null;
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D20, shape21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str24 = color23.toString();
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D20, (java.awt.Paint) color23, stroke25, (java.awt.Paint) color26);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity28 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str30 = lengthAdjustmentType29.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets2.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType29, lengthAdjustmentType31);
        java.lang.String str33 = lengthAdjustmentType29.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str24.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "CONTRACT" + "'", str30.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CONTRACT" + "'", str33.equals("CONTRACT"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean7 = barRenderer0.getBaseSeriesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj11 = categoryAxis8.clone();
        categoryAxis8.setAxisLineVisible(true);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint21 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape20, paint21);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape20, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList28 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D36 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D36, (double) (short) -1, 0.0d, rectangleAnchor39);
        java.awt.Shape shape41 = null;
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D40, shape41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str44 = color43.toString();
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D40, (java.awt.Paint) color43, stroke45, (java.awt.Paint) color46);
        objectList28.set((int) '4', (java.lang.Object) color43);
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape20, stroke27, (java.awt.Paint) color43);
        categoryAxis8.setTickLabelPaint((java.awt.Paint) color43);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color43);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str44.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font1, (java.awt.Paint) color2, (float) (byte) 0);
        float float5 = textFragment4.getBaselineOffset();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.Object obj10 = null;
        boolean boolean11 = textAnchor9.equals(obj10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor7, textAnchor8, textAnchor9, (double) (byte) -1);
        try {
            float float14 = textFragment4.calculateBaselineOffset(graphics2D6, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.chart.ui.ProjectInfo projectInfo16 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = org.jfree.chart.JFreeChart.INFO;
        projectInfo16.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo17.getVersion();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo21 = org.jfree.chart.JFreeChart.INFO;
        projectInfo20.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo21);
        projectInfo21.setCopyright("java.awt.Color[r=0,g=0,b=128]");
        projectInfo17.addLibrary((org.jfree.chart.ui.Library) projectInfo21);
        boolean boolean26 = categoryItemEntity15.equals((java.lang.Object) projectInfo21);
        java.lang.String str27 = categoryItemEntity15.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(projectInfo16);
        org.junit.Assert.assertNotNull(projectInfo17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str19.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(projectInfo21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-6,-50,4,50" + "'", str27.equals("-6,-50,4,50"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        double double6 = categoryAxis0.getUpperMargin();
        java.lang.String str8 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.lang.String str2 = textTitle1.getText();
        textTitle1.setID("1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ClassContext" + "'", str2.equals("ClassContext"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D10, rectangleEdge13);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D10);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke18 = numberAxis17.getAxisLineStroke();
        org.jfree.chart.util.Size2D size2D25 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) (short) -1, 0.0d, rectangleAnchor28);
        java.awt.Shape shape30 = null;
        boolean boolean31 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D29, shape30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str33 = color32.toString();
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D29, (java.awt.Paint) color32, stroke34, (java.awt.Paint) color35);
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=0,g=0,b=128]", "1", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", shape15, stroke18, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str33.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        double double8 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesPaint(0);
        java.awt.Paint paint8 = barRenderer4.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj9 = barRenderer4.clone();
        java.awt.Paint paint11 = barRenderer4.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer4.getPositiveItemLabelPosition((int) '4', 255);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition14);
        barRenderer0.setAutoPopulateSeriesShape(false);
        double double18 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = barRenderer0.getSeriesPaint((int) '#');
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition7);
        barRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        numberAxis1.setFixedAutoRange((double) '4');
        numberAxis1.centerRange((double) '#');
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(3.0d, (double) (short) 1, 100.0d, (double) 0.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) 'a', (java.lang.Boolean) true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 100.0d, (double) (-1));
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (short) -1, 0.0d, rectangleAnchor13);
        java.awt.Shape shape15 = null;
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D14, shape15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D14, rectangleEdge17);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer20.setSeriesItemLabelFont(1, font24, false);
        boolean boolean27 = barRenderer20.getIncludeBaseInRange();
        boolean boolean28 = barRenderer20.getAutoPopulateSeriesStroke();
        boolean boolean29 = categoryLabelPosition19.equals((java.lang.Object) boolean28);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition30 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = categoryLabelPosition30.getLabelAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        org.jfree.chart.util.Size2D size2D41 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D41, (double) (short) -1, 0.0d, rectangleAnchor44);
        plotRenderingInfo38.setDataArea(rectangle2D45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = categoryAxis32.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D45, rectangleEdge47);
        int int49 = categoryAxis32.getCategoryLabelPositionOffset();
        double double50 = categoryAxis32.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions51 = categoryAxis32.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition52 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor53 = categoryLabelPosition52.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions54 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions51, categoryLabelPosition52);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition55 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint58 = barRenderer56.lookupSeriesPaint(0);
        java.awt.Font font60 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer56.setSeriesItemLabelFont(1, font60, false);
        boolean boolean63 = barRenderer56.getIncludeBaseInRange();
        boolean boolean64 = barRenderer56.getAutoPopulateSeriesStroke();
        boolean boolean65 = categoryLabelPosition55.equals((java.lang.Object) boolean64);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions66 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition19, categoryLabelPosition30, categoryLabelPosition52, categoryLabelPosition55);
        try {
            java.lang.Object obj67 = blockContainer0.draw(graphics2D7, rectangle2D14, (java.lang.Object) categoryLabelPosition55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.2d + "'", double50 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions51);
        org.junit.Assert.assertNotNull(textBlockAnchor53);
        org.junit.Assert.assertNotNull(categoryLabelPositions54);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart1, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        legendGraphic4.setLineVisible(true);
        legendGraphic4.setWidth(0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis13.setTickLabelInsets(rectangleInsets18);
        java.lang.Object obj20 = numberAxis13.clone();
        numberAxis13.setTickMarkInsideLength(10.0f);
        numberAxis13.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        org.jfree.chart.util.Size2D size2D33 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, (double) (short) -1, 0.0d, rectangleAnchor36);
        java.awt.Shape shape38 = null;
        boolean boolean39 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D37, shape38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str41 = color40.toString();
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D37, (java.awt.Paint) color40, stroke42, (java.awt.Paint) color43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        java.util.List list46 = numberAxis13.refreshTicks(graphics2D25, axisState26, rectangle2D37, rectangleEdge45);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition47 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor48 = categoryLabelPosition47.getLabelAnchor();
        try {
            java.lang.Object obj49 = legendGraphic4.draw(graphics2D11, rectangle2D37, (java.lang.Object) textBlockAnchor48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str41.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(textBlockAnchor48);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer1.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean6 = barRenderer1.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer1.getLegendItemToolTipGenerator();
        boolean boolean8 = rangeType0.equals((java.lang.Object) categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer0.getSeriesToolTipGenerator((-1));
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getPositiveItemLabelPosition((int) '4', 255);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        try {
            java.lang.Number number18 = defaultStatisticalCategoryDataset12.getValue((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        int int18 = legendItem17.getDatasetIndex();
        int int19 = legendItem17.getSeriesIndex();
        java.awt.Stroke stroke20 = legendItem17.getLineStroke();
        legendItem17.setDatasetIndex(2);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) (short) 1, (double) 10.0f, (float) (byte) -1, (float) (byte) 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 3.0d, 0.0d, (int) '#', (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleEdge.LEFT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer10.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean15 = barRenderer10.equals((java.lang.Object) (-1.0d));
        barRenderer10.setBaseCreateEntities(false, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer10.setBaseItemLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        barRenderer10.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition22);
        java.awt.Paint paint25 = barRenderer10.lookupSeriesPaint((int) (short) -1);
        barRenderer0.setBaseFillPaint(paint25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = barRenderer0.getSeriesURLGenerator(255);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryURLGenerator28);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer11.setBaseOutlineStroke(stroke14);
        barRenderer11.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        barRenderer20.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer20.getBaseNegativeItemLabelPosition();
        barRenderer11.setSeriesNegativeItemLabelPosition(100, itemLabelPosition26, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        int int32 = barRenderer0.getPassCount();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke36 = numberAxis35.getAxisLineStroke();
        barRenderer0.setSeriesStroke(0, stroke36, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) 0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) '#', (double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font2 = textTitle1.getFont();
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle1.addChangeListener(titleChangeListener3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis7.setTickLabelInsets(rectangleInsets12);
        java.lang.Object obj14 = numberAxis7.clone();
        numberAxis7.setTickMarkInsideLength(10.0f);
        numberAxis7.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        org.jfree.chart.util.Size2D size2D27 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, (double) (short) -1, 0.0d, rectangleAnchor30);
        java.awt.Shape shape32 = null;
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D31, shape32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str35 = color34.toString();
        java.awt.Stroke stroke36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D31, (java.awt.Paint) color34, stroke36, (java.awt.Paint) color37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        java.util.List list40 = numberAxis7.refreshTicks(graphics2D19, axisState20, rectangle2D31, rectangleEdge39);
        textTitle1.draw(graphics2D5, rectangle2D31);
        java.awt.Paint paint42 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str35.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNull(paint42);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) false);
        barRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 1L, (double) (-1L), 0.0d, (double) 100, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("1", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) axisLocation0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font2 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean7 = barRenderer0.getBaseSeriesVisible();
        barRenderer0.setDrawBarOutline(true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendGraphic4.getMargin();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        java.lang.String str7 = unitType6.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType6, 0.2d, (double) 255, 0.05d, (double) 0);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint16 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, paint16);
        boolean boolean18 = unitType6.equals((java.lang.Object) paint16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition6.getRotationAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle11.setVerticalAlignment(verticalAlignment13);
        java.lang.String str15 = verticalAlignment13.toString();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "VerticalAlignment.CENTER" + "'", str15.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font1, (java.awt.Paint) color2, (float) (byte) 0);
        float float5 = textFragment4.getBaselineOffset();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Font font11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color12, (float) 1L, textMeasurer14);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick19 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) '4', textBlock15, textBlockAnchor16, textAnchor17, 0.0d);
        try {
            textFragment4.draw(graphics2D6, (float) (short) 1, (float) 100, textAnchor17, (float) (-14336), (float) (byte) 10, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean3 = textTitle1.equals((java.lang.Object) paint2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) (short) -1, 0.0d, rectangleAnchor14);
        java.awt.Shape shape16 = null;
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D15, shape16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str19 = color18.toString();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D15, (java.awt.Paint) color18, stroke20, (java.awt.Paint) color21);
        textTitle1.setBounds(rectangle2D15);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.Paint paint26 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.lang.Object obj27 = textTitle1.draw(graphics2D24, rectangle2D25, (java.lang.Object) paint26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.data.Range range29 = null;
        org.jfree.data.Range range30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(range29, range30);
        org.jfree.data.Range range32 = rectangleConstraint31.getHeightRange();
        org.jfree.data.Range range33 = rectangleConstraint31.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D34 = textTitle1.arrange(graphics2D28, rectangleConstraint31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str19.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, range3);
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint4.toFixedHeight((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getWidthConstraintType();
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(2.0d, range1, lengthConstraintType8, 1.0E-8d, range10, lengthConstraintType11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedHeight();
        org.jfree.data.Range range14 = rectangleConstraint12.getWidthRange();
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        boolean boolean12 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean13 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        double double18 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = categoryLabelPosition20.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions19, categoryLabelPosition20);
        java.awt.Image image26 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo30 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image26, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        boolean boolean31 = categoryLabelPositions19.equals((java.lang.Object) "java.awt.Color[r=0,g=0,b=128]");
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setItemLabelAnchorOffset((double) 'a');
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        double double17 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.plot.Plot plot18 = null;
        categoryAxis0.setPlot(plot18);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        java.awt.Paint paint15 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        int int16 = barRenderer0.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.lang.String str2 = textTitle1.getText();
        textTitle1.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean8 = textTitle6.equals((java.lang.Object) paint7);
        boolean boolean9 = textTitle6.getExpandToFitSpace();
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font11);
        textTitle6.setFont(font11);
        textTitle6.setToolTipText("java.awt.Color[r=0,g=0,b=128]");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle6.getTextAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ClassContext" + "'", str2.equals("ClassContext"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        java.lang.Number number38 = defaultStatisticalCategoryDataset29.getStdDevValue((java.lang.Comparable) "ClassContext", (java.lang.Comparable) "TextAnchor.CENTER_RIGHT");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(number38);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickLabelsVisible(false);
        numberAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (short) -1, 0.0d, rectangleAnchor13);
        java.awt.Shape shape15 = null;
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D14, shape15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets6.createInsetRectangle(rectangle2D14);
        double double19 = rectangleInsets6.extendWidth((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 109.0d + "'", double19 == 109.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (short) -1, 0.0d, rectangleAnchor5);
        java.awt.Shape shape7 = null;
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D6, shape7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D6, rectangleEdge9);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D6);
        java.lang.String str13 = legendItemEntity12.getShapeType();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "rect" + "'", str13.equals("rect"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        numberAxis1.addChangeListener(axisChangeListener8);
        boolean boolean10 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.LegendItem legendItem6 = barRenderer0.getLegendItem((int) (short) 1, 0);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean5 = textTitle3.equals((java.lang.Object) paint4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) (short) -1, 0.0d, rectangleAnchor16);
        java.awt.Shape shape18 = null;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D17, shape18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str21 = color20.toString();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D17, (java.awt.Paint) color20, stroke22, (java.awt.Paint) color23);
        textTitle3.setBounds(rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.TOP;
        double double27 = numberAxis0.lengthToJava2D((double) 10L, rectangle2D17, rectangleEdge26);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = numberAxis0.getTickUnit();
        org.jfree.data.Range range29 = null;
        try {
            numberAxis0.setRange(range29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(numberTickUnit28);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleEdge.LEFT", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2");
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        barRenderer2.setGradientPaintTransformer(gradientPaintTransformer3);
        barRenderer2.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer2.getLegendItemToolTipGenerator();
        boolean boolean11 = barRenderer2.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int12 = barRenderer2.getColumnCount();
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D24 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) (short) -1, 0.0d, rectangleAnchor23);
        java.awt.Shape shape25 = null;
        boolean boolean26 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D24, shape25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str28 = color27.toString();
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D24, (java.awt.Paint) color27, stroke29, (java.awt.Paint) color30);
        int int32 = legendItem31.getDatasetIndex();
        int int33 = legendItem31.getSeriesIndex();
        java.awt.Stroke stroke34 = legendItem31.getLineStroke();
        barRenderer2.setSeriesOutlineStroke(0, stroke34);
        strokeList0.setStroke((int) '#', stroke34);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str28.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer10.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean15 = barRenderer10.equals((java.lang.Object) (-1.0d));
        barRenderer10.setBaseCreateEntities(false, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer10.setBaseItemLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        barRenderer10.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition22);
        java.awt.Paint paint25 = barRenderer10.lookupSeriesPaint((int) (short) -1);
        barRenderer0.setBaseFillPaint(paint25);
        java.awt.Paint paint28 = barRenderer0.getSeriesItemLabelPaint((-14336));
        barRenderer0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        boolean boolean9 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        java.awt.Paint paint11 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, paint19);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape18, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList26 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (short) -1, 0.0d, rectangleAnchor37);
        java.awt.Shape shape39 = null;
        boolean boolean40 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D38, shape39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str42 = color41.toString();
        java.awt.Stroke stroke43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D38, (java.awt.Paint) color41, stroke43, (java.awt.Paint) color44);
        objectList26.set((int) '4', (java.lang.Object) color41);
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape18, stroke25, (java.awt.Paint) color41);
        java.text.AttributedString attributedString48 = legendItem47.getAttributedLabel();
        java.awt.Paint paint49 = legendItem47.getOutlinePaint();
        barRenderer0.setBaseFillPaint(paint49);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str42.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(attributedString48);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        barRenderer7.setGradientPaintTransformer(gradientPaintTransformer8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesPaint(0);
        java.awt.Paint paint15 = barRenderer11.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj16 = barRenderer11.clone();
        java.awt.Paint paint18 = barRenderer11.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer11.getPositiveItemLabelPosition((int) '4', 255);
        barRenderer7.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition21);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition21);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        java.util.List list35 = defaultStatisticalCategoryDataset29.getColumnKeys();
        java.lang.Comparable comparable37 = null;
        java.lang.Number number38 = defaultStatisticalCategoryDataset29.getValue((java.lang.Comparable) '#', comparable37);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNull(number38);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RangeType.NEGATIVE", "");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickLabelsVisible(false);
        double double16 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.lang.String str8 = numberAxis1.getLabelToolTip();
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis12.setTickLabelInsets(rectangleInsets17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = numberAxis12.getStandardTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource19);
        boolean boolean21 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Font font2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color3, (float) 1L, textMeasurer5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) '4', textBlock6, textBlockAnchor7, textAnchor8, 0.0d);
        org.jfree.chart.text.TextBlock textBlock11 = categoryTick10.getLabel();
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryTick10.getTextAnchor();
        java.lang.Object obj13 = categoryTick10.clone();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("RangeType.NEGATIVE", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis1.setLabelFont(font2);
        try {
            numberAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        java.lang.String str3 = projectInfo1.getVersion();
//        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        projectInfo5.setCopyright("java.awt.Color[r=0,g=0,b=128]");
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo5.getLibraries();
//        java.lang.String str11 = projectInfo5.toString();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
//        org.junit.Assert.assertNotNull(projectInfo4);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChart version java.awt.Color[r=255,g=255,b=64].\njava.awt.Color[r=0,g=0,b=128].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=255,g=255,b=64]" + "'", str11.equals("JFreeChart version java.awt.Color[r=255,g=255,b=64].\njava.awt.Color[r=0,g=0,b=128].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=255,g=255,b=64]"));
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.RIGHT" + "'", str1.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RangeType.NEGATIVE");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(strEnumeration4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.lang.Boolean boolean7 = barRenderer0.getSeriesCreateEntities((int) 'a');
        java.awt.Paint paint8 = barRenderer0.getBasePaint();
        boolean boolean10 = barRenderer0.isSeriesVisible((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) 0);
        legendGraphic4.setLine(shape23);
        java.awt.Shape shape25 = legendGraphic4.getShape();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke((int) '4');
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("java.awt.Color[r=255,g=255,b=64]", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer12.setBaseOutlineStroke(stroke15);
        java.awt.Shape shape19 = barRenderer12.getItemShape(0, 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, rectangleAnchor20, (double) (-1), (double) (-1L));
        numberAxis1.setRightArrow(shape23);
        java.awt.Font font25 = numberAxis1.getTickLabelFont();
        numberAxis1.setUpperMargin((double) 'a');
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer7.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean12 = barRenderer7.equals((java.lang.Object) (-1.0d));
        barRenderer7.setBaseCreateEntities(false, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer7.setBaseItemLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        barRenderer7.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition19);
        barRenderer7.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        barRenderer23.setGradientPaintTransformer(gradientPaintTransformer24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer23.setBaseOutlineStroke(stroke26);
        barRenderer23.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint34 = barRenderer32.lookupSeriesPaint(0);
        barRenderer32.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer32.getBaseNegativeItemLabelPosition();
        barRenderer23.setSeriesNegativeItemLabelPosition(100, itemLabelPosition38, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator41 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer23.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator41);
        barRenderer7.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator41);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator41);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        try {
            barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        int int12 = categoryAxis11.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) (short) -1, 0.0d, rectangleAnchor22);
        plotRenderingInfo16.setDataArea(rectangle2D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double26 = categoryAxis11.getCategoryStart((int) (short) 10, (int) (short) 1, rectangle2D23, rectangleEdge25);
        try {
            java.util.List list27 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 854.9999999999999d + "'", double26 == 854.9999999999999d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(paint13);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean3 = textTitle1.equals((java.lang.Object) paint2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font6);
        textTitle1.setFont(font6);
        textTitle1.setToolTipText("java.awt.Color[r=0,g=0,b=128]");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle1.getTextAlignment();
        boolean boolean12 = textTitle1.getNotify();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, paint7);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList14 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, (double) (short) -1, 0.0d, rectangleAnchor25);
        java.awt.Shape shape27 = null;
        boolean boolean28 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D26, shape27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str30 = color29.toString();
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D26, (java.awt.Paint) color29, stroke31, (java.awt.Paint) color32);
        objectList14.set((int) '4', (java.lang.Object) color29);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape6, stroke13, (java.awt.Paint) color29);
        boolean boolean36 = legendItem35.isLineVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str30.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 100.0d, (double) (-1));
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj14 = categoryAxis11.clone();
        boolean boolean15 = rectangleInsets10.equals((java.lang.Object) categoryAxis11);
        double double17 = rectangleInsets10.extendHeight((double) (-1L));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) (short) -1, 0.0d, rectangleAnchor27);
        java.awt.Shape shape29 = null;
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D28, shape29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str32 = color31.toString();
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D28, (java.awt.Paint) color31, stroke33, (java.awt.Paint) color34);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity36 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D28);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str38 = lengthAdjustmentType37.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets10.createAdjustedRectangle(rectangle2D28, lengthAdjustmentType37, lengthAdjustmentType39);
        try {
            blockContainer0.draw(graphics2D7, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str32.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "CONTRACT" + "'", str38.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType39);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("CONTRACT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesPaint(0);
        java.awt.Paint paint6 = barRenderer2.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj7 = barRenderer2.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        barRenderer2.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition9);
        double double11 = barRenderer2.getMinimumBarLength();
        barRenderer2.setIncludeBaseInRange(false);
        boolean boolean14 = gradientPaintTransformType0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        int int18 = legendItem17.getDatasetIndex();
        int int19 = legendItem17.getSeriesIndex();
        legendItem17.setDatasetIndex(15);
        java.lang.Comparable comparable22 = legendItem17.getSeriesKey();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(comparable22);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = textTitle1.clone();
        java.lang.String str4 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ClassContext" + "'", str2.equals("ClassContext"));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ClassContext" + "'", str4.equals("ClassContext"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1.0f, (double) 1.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesPaint(0);
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer12.setSeriesItemLabelFont(1, font16, false);
        boolean boolean19 = barRenderer12.getIncludeBaseInRange();
        boolean boolean20 = barRenderer12.getAutoPopulateSeriesStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer12.setBaseOutlinePaint((java.awt.Paint) color21);
        barRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color21, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean7 = barRenderer0.getBaseSeriesVisible();
        barRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer11.setBaseOutlineStroke(stroke14);
        barRenderer11.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        barRenderer20.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer20.getBaseNegativeItemLabelPosition();
        barRenderer11.setSeriesNegativeItemLabelPosition(100, itemLabelPosition26, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor32 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        boolean boolean33 = standardCategorySeriesLabelGenerator29.equals((java.lang.Object) itemLabelAnchor32);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(itemLabelAnchor32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        numberAxis1.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        java.awt.Shape shape26 = null;
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D25, shape26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str29 = color28.toString();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D25, (java.awt.Paint) color28, stroke30, (java.awt.Paint) color31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = numberAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D25, rectangleEdge33);
        boolean boolean35 = numberAxis1.isAutoRange();
        boolean boolean36 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.event.AxisChangeListener axisChangeListener37 = null;
        numberAxis1.addChangeListener(axisChangeListener37);
        org.jfree.data.Range range39 = null;
        try {
            numberAxis1.setRange(range39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str29.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        int int6 = barRenderer0.getRowCount();
        int int7 = barRenderer0.getColumnCount();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean7 = barRenderer0.getBaseSeriesVisible();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesPaint((int) (short) 100);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (-1.0d), (double) 255, (-100.0d), (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        size2D2.setWidth(100.0d);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        java.awt.Paint paint7 = barRenderer0.getBasePaint();
        barRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=0,b=128]", "CONTRACT", "", "");
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int3 = java.awt.Color.HSBtoRGB((float) (-14336), (float) 15, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        int int18 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (short) 1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener19 = null;
        defaultStatisticalCategoryDataset12.removeChangeListener(datasetChangeListener19);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) (byte) 100);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = defaultStatisticalCategoryDataset12.hasListener(eventListener23);
        defaultStatisticalCategoryDataset12.add((java.lang.Number) 10.0f, (java.lang.Number) 62.0d, (java.lang.Comparable) "MINOR", (java.lang.Comparable) "ItemLabelAnchor.INSIDE2");
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setBaseSeriesVisible(false);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, false);
        barRenderer0.setBaseSeriesVisibleInLegend(false, true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj6 = categoryAxis3.clone();
        boolean boolean7 = rectangleInsets2.equals((java.lang.Object) categoryAxis3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        boolean boolean9 = categoryAxis3.equals((java.lang.Object) textBlockAnchor8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        numberAxis1.addChangeListener(axisChangeListener8);
        boolean boolean10 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        java.awt.Font font12 = null;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, (java.awt.Paint) color13, (float) 1L, textMeasurer15);
        int int17 = color13.getAlpha();
        barRenderer0.setSeriesItemLabelPaint(2, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont(3, 3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer15.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean20 = barRenderer15.equals((java.lang.Object) (-1.0d));
        barRenderer15.setBaseCreateEntities(false, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer15.setBaseItemLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        barRenderer15.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition27);
        java.awt.Font font30 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color31, (float) 1L, textMeasurer33);
        int int35 = color31.getAlpha();
        barRenderer15.setBasePaint((java.awt.Paint) color31);
        double double37 = barRenderer15.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = barRenderer15.getSeriesPositiveItemLabelPosition((int) '#');
        try {
            barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 255, 10L, 62.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 255, 10L, 62.0d };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "{0}", numberArray12);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font8, (java.awt.Paint) color9, (float) (byte) 0);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.lang.String str14 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 10L);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer1.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer1.setBaseSeriesVisible(false);
        boolean boolean13 = barRenderer1.getBaseSeriesVisibleInLegend();
        boolean boolean14 = color0.equals((java.lang.Object) barRenderer1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        java.awt.color.ColorSpace colorSpace11 = color9.getColorSpace();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle11.setVerticalAlignment(verticalAlignment13);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint18 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, paint18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendGraphic19.getMargin();
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        java.lang.String str22 = unitType21.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets(unitType21, 0.2d, (double) 255, 0.05d, (double) 0);
        legendTitle11.setMargin(rectangleInsets27);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnitType.ABSOLUTE" + "'", str22.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine2.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TextAnchor.CENTER_RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false, false);
        boolean boolean7 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType9);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesPaint(0);
        barRenderer0.setBaseFillPaint(paint6, true);
        barRenderer0.setBaseSeriesVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getSeriesNegativeItemLabelPosition(2);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        legendTitle11.setItemFont(font12);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setCopyright("java.awt.Color[r=0,g=0,b=128]");
        projectInfo1.setLicenceText("java.awt.Color[r=255,g=255,b=64]");
        projectInfo1.setVersion("{0}");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        java.awt.Font font30 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color31, (float) 1L, textMeasurer33);
        org.jfree.chart.text.TextLine textLine35 = textBlock34.getLastLine();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock34.draw(graphics2D36, (float) 100, (float) (byte) 1, textBlockAnchor39, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock34.setLineAlignment(horizontalAlignment44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) (short) -1, 0.0d, rectangleAnchor53);
        plotRenderingInfo47.setDataArea(rectangle2D54);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D54, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58);
        boolean boolean63 = horizontalAlignment44.equals((java.lang.Object) defaultStatisticalCategoryDataset58);
        java.util.List list64 = defaultStatisticalCategoryDataset58.getColumnKeys();
        java.lang.Comparable comparable65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset58, comparable65);
        org.jfree.chart.renderer.category.BarRenderer barRenderer67 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer68 = null;
        barRenderer67.setGradientPaintTransformer(gradientPaintTransformer68);
        barRenderer67.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator73 = barRenderer67.getLegendItemToolTipGenerator();
        boolean boolean74 = borderArrangement11.equals((java.lang.Object) categorySeriesLabelGenerator73);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNull(textLine35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("{0}", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font3 = textTitle2.getFont();
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle2.addChangeListener(titleChangeListener4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis8.setTickLabelInsets(rectangleInsets13);
        java.lang.Object obj15 = numberAxis8.clone();
        numberAxis8.setTickMarkInsideLength(10.0f);
        numberAxis8.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) (short) -1, 0.0d, rectangleAnchor31);
        java.awt.Shape shape33 = null;
        boolean boolean34 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D32, shape33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str36 = color35.toString();
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D32, (java.awt.Paint) color35, stroke37, (java.awt.Paint) color38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        java.util.List list41 = numberAxis8.refreshTicks(graphics2D20, axisState21, rectangle2D32, rectangleEdge40);
        textTitle2.draw(graphics2D6, rectangle2D32);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity45 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 96.0d, (java.awt.Shape) rectangle2D32, "JFreeChart version java.awt.Color[r=255,g=255,b=64].\njava.awt.Color[r=0,g=0,b=128].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=255,g=255,b=64]", "{0}");
        java.lang.Comparable comparable46 = categoryLabelEntity45.getKey();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str36.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 96.0d + "'", comparable46.equals(96.0d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        double double6 = categoryAxis0.getUpperMargin();
        categoryAxis0.setLabel("java.awt.Color[r=0,g=0,b=128]");
        double double9 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis1.setTickLabelFont(font8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis11.setLabelFont(font12);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis11.setMarkerBand(markerAxisBand14);
        double double16 = numberAxis11.getLowerMargin();
        org.jfree.data.Range range17 = numberAxis11.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis19.setLabelFont(font20);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis19.setMarkerBand(markerAxisBand22);
        double double24 = numberAxis19.getLowerMargin();
        org.jfree.data.Range range25 = numberAxis19.getDefaultAutoRange();
        org.jfree.data.Range range26 = org.jfree.data.Range.combine(range17, range25);
        numberAxis1.setDefaultAutoRange(range17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, paint7);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList14 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, (double) (short) -1, 0.0d, rectangleAnchor25);
        java.awt.Shape shape27 = null;
        boolean boolean28 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D26, shape27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str30 = color29.toString();
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D26, (java.awt.Paint) color29, stroke31, (java.awt.Paint) color32);
        objectList14.set((int) '4', (java.lang.Object) color29);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape6, stroke13, (java.awt.Paint) color29);
        java.text.AttributedString attributedString36 = legendItem35.getAttributedLabel();
        legendItem35.setSeriesKey((java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str30.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(attributedString36);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesPaint(0);
        barRenderer0.setBaseFillPaint(paint6, true);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean14 = barRenderer0.getItemCreateEntity((int) 'a', (int) '4');
        java.awt.Paint paint15 = null;
        try {
            barRenderer0.setBaseFillPaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) "rect");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean5 = textTitle3.equals((java.lang.Object) paint4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) (short) -1, 0.0d, rectangleAnchor16);
        java.awt.Shape shape18 = null;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D17, shape18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str21 = color20.toString();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D17, (java.awt.Paint) color20, stroke22, (java.awt.Paint) color23);
        textTitle3.setBounds(rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.TOP;
        double double27 = numberAxis0.lengthToJava2D((double) 10L, rectangle2D17, rectangleEdge26);
        boolean boolean28 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        int int2 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        double double17 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setCategoryLabelPositionOffset((int) '4');
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (short) -1, 0.0d, rectangleAnchor38);
        plotRenderingInfo32.setDataArea(rectangle2D39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis26.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D39, rectangleEdge41);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("{0}", "[size=1]", "ClassContext", "", (java.awt.Shape) rectangle2D39, stroke43, (java.awt.Paint) color44);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis50.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo55);
        org.jfree.chart.util.Size2D size2D59 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, (double) (short) -1, 0.0d, rectangleAnchor62);
        plotRenderingInfo56.setDataArea(rectangle2D63);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
        double double66 = categoryAxis50.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D63, rectangleEdge65);
        java.awt.Stroke stroke67 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color68 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("{0}", "[size=1]", "ClassContext", "", (java.awt.Shape) rectangle2D63, stroke67, (java.awt.Paint) color68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo73);
        org.jfree.chart.util.Size2D size2D77 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor80 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D81 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D77, (double) (short) -1, 0.0d, rectangleAnchor80);
        plotRenderingInfo74.setDataArea(rectangle2D81);
        plotRenderingInfo72.addSubplotInfo(plotRenderingInfo74);
        int int84 = plotRenderingInfo72.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D85 = plotRenderingInfo72.getPlotArea();
        try {
            org.jfree.chart.axis.AxisState axisState86 = categoryAxis0.draw(graphics2D20, (double) (-1), rectangle2D39, rectangle2D63, rectangleEdge70, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(rectangleAnchor80);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNull(rectangle2D85);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        double double5 = rectangleInsets4.getTop();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        barRenderer2.setGradientPaintTransformer(gradientPaintTransformer3);
        barRenderer2.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = barRenderer2.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesPaint(0);
        java.awt.Font font13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer9.setSeriesItemLabelFont(1, font13, false);
        barRenderer2.setBaseItemLabelFont(font13);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str18 = color17.toString();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=0,g=0,b=128]", font13, (java.awt.Paint) color17);
        boolean boolean20 = categoryLabelWidthType0.equals((java.lang.Object) color17);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setLowerMargin((double) '#');
        numberAxis1.setLabelToolTip("java.awt.Color[r=255,g=255,b=64]");
        org.jfree.data.RangeType rangeType13 = org.jfree.data.RangeType.POSITIVE;
        numberAxis1.setRangeType(rangeType13);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rangeType13);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "RangeType.NEGATIVE");
        categoryAxis1.setLabelToolTip("RangeType.NEGATIVE");
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle11.getHorizontalAlignment();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("1", "RectangleEdge.LEFT", "RangeType.NEGATIVE", "109", "");
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean5 = textTitle3.equals((java.lang.Object) paint4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) (short) -1, 0.0d, rectangleAnchor16);
        java.awt.Shape shape18 = null;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D17, shape18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str21 = color20.toString();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D17, (java.awt.Paint) color20, stroke22, (java.awt.Paint) color23);
        textTitle3.setBounds(rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.TOP;
        double double27 = numberAxis0.lengthToJava2D((double) 10L, rectangle2D17, rectangleEdge26);
        java.text.NumberFormat numberFormat28 = null;
        numberAxis0.setNumberFormatOverride(numberFormat28);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        double double6 = categoryAxis0.getUpperMargin();
        double double7 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj7 = textTitle6.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer8.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer8.setBaseURLGenerator(categoryURLGenerator12, true);
        barRenderer8.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        boolean boolean18 = barRenderer8.removeAnnotation(categoryAnnotation17);
        org.jfree.chart.block.BorderArrangement borderArrangement19 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment21, 100.0d, (double) (-1));
        java.awt.Image image28 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo32 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image28, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo32.setName("CONTRACT");
        boolean boolean35 = flowArrangement24.equals((java.lang.Object) projectInfo32);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer8, (org.jfree.chart.block.Arrangement) borderArrangement19, (org.jfree.chart.block.Arrangement) flowArrangement24);
        java.awt.Font font38 = null;
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer41 = null;
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, (java.awt.Paint) color39, (float) 1L, textMeasurer41);
        org.jfree.chart.text.TextLine textLine43 = textBlock42.getLastLine();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor47 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock42.draw(graphics2D44, (float) 100, (float) (byte) 1, textBlockAnchor47, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock42.setLineAlignment(horizontalAlignment52);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo54);
        org.jfree.chart.util.Size2D size2D58 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D62 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D58, (double) (short) -1, 0.0d, rectangleAnchor61);
        plotRenderingInfo55.setDataArea(rectangle2D62);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset66 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity69 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D62, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset66, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset66);
        boolean boolean71 = horizontalAlignment52.equals((java.lang.Object) defaultStatisticalCategoryDataset66);
        java.util.List list72 = defaultStatisticalCategoryDataset66.getColumnKeys();
        java.lang.Comparable comparable73 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer74 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement19, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset66, comparable73);
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) borderArrangement19);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(textBlock42);
        org.junit.Assert.assertNull(textLine43);
        org.junit.Assert.assertNotNull(textBlockAnchor47);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(list72);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (-1));
        java.awt.Image image8 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image8, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo12.setName("CONTRACT");
        boolean boolean15 = flowArrangement4.equals((java.lang.Object) projectInfo12);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        boolean boolean19 = flowArrangement4.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font11, true);
        boolean boolean16 = barRenderer0.getItemVisible(1, (int) (byte) 0);
        barRenderer0.setItemLabelAnchorOffset(1.0E-8d);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean3 = textTitle1.equals((java.lang.Object) paint2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        textTitle1.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        try {
            textTitle1.setTextAlignment(horizontalAlignment7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D3, (float) (byte) 10, (float) 0, textAnchor6, (double) (byte) -1, (float) (short) 10, (float) 255);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.Object obj14 = null;
        boolean boolean15 = textAnchor13.equals(obj14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12, textAnchor13, (double) (byte) -1);
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0d, "", textAnchor6, textAnchor13, (double) 2.0f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        java.awt.Paint paint24 = barRenderer20.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj25 = barRenderer20.clone();
        java.awt.Paint paint27 = barRenderer20.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = barRenderer20.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint32 = barRenderer30.lookupSeriesPaint(0);
        java.awt.Paint paint34 = barRenderer30.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj35 = barRenderer30.clone();
        java.awt.Paint paint37 = barRenderer30.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = barRenderer30.getPositiveItemLabelPosition((int) '4', 255);
        barRenderer20.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition40, true);
        boolean boolean43 = numberTick19.equals((java.lang.Object) barRenderer20);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(itemLabelPosition40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1);
        try {
            keyedObjects2D0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("UnitType.ABSOLUTE", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        org.jfree.chart.text.TextFragment textFragment3 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNull(textFragment3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        int int18 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Number number21 = defaultStatisticalCategoryDataset12.getStdDevValue((java.lang.Comparable) (-16777216), (java.lang.Comparable) 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(number21);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        int int6 = barRenderer0.getRowCount();
        java.awt.Paint paint7 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.Comparable comparable18 = legendItem17.getSeriesKey();
        boolean boolean19 = legendItem17.isLineVisible();
        java.awt.Shape shape20 = legendItem17.getShape();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation73 = null;
        try {
            boolean boolean74 = categoryPlot69.removeAnnotation(categoryAnnotation73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = java.awt.Color.black;
        barRenderer0.setBasePaint((java.awt.Paint) color9);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.Comparable comparable18 = legendItem17.getSeriesKey();
        boolean boolean19 = legendItem17.isLineVisible();
        java.lang.String str20 = legendItem17.getToolTipText();
        java.awt.Stroke stroke21 = legendItem17.getLineStroke();
        java.awt.Shape shape22 = legendItem17.getShape();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        barRenderer2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer2.setBaseOutlineStroke(stroke5);
        java.awt.Shape shape9 = barRenderer2.getItemShape(0, 10);
        try {
            java.awt.GradientPaint gradientPaint10 = standardGradientPaintTransformer0.transform(gradientPaint1, shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesPaint(0);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer1.setSeriesItemLabelFont(1, font5, false);
        boolean boolean8 = barRenderer1.getIncludeBaseInRange();
        boolean boolean9 = barRenderer1.getAutoPopulateSeriesStroke();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        barRenderer1.setBaseItemLabelPaint((java.awt.Paint) color10, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke15 = numberAxis14.getAxisLineStroke();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, paint19);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextAnchor textAnchor25 = null;
        textLine21.draw(graphics2D22, 1.0f, 0.0f, textAnchor25, (float) 255, 100.0f, (double) 100);
        boolean boolean30 = legendGraphic20.equals((java.lang.Object) 0.0f);
        java.awt.Font font32 = null;
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, (java.awt.Paint) color33, (float) 1L, textMeasurer35);
        legendGraphic20.setFillPaint((java.awt.Paint) color33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = barRenderer38.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean43 = barRenderer38.equals((java.lang.Object) (-1.0d));
        barRenderer38.setBaseCreateEntities(false, false);
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer38.setBaseItemLabelPaint((java.awt.Paint) color47);
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer50.setBaseOutlineStroke(stroke53);
        barRenderer38.setSeriesStroke((int) (short) 100, stroke53, false);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) (-1L), (java.awt.Paint) color10, stroke15, (java.awt.Paint) color33, stroke53, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertNull(categoryURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        numberAxis1.setFixedAutoRange((double) '4');
        numberAxis1.configure();
        numberAxis1.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer1.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesPaint(0);
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer8.setSeriesItemLabelFont(1, font12, false);
        barRenderer1.setBaseItemLabelFont(font12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        barRenderer16.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer16.setBaseOutlineStroke(stroke19);
        barRenderer16.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        java.awt.Paint paint26 = barRenderer16.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE2", font12, paint26);
        labelBlock27.setToolTipText("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getNegativeItemLabelPosition(4, (-14336));
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis2.setLabelFont(font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=64]", font3);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean9 = textTitle7.equals((java.lang.Object) paint8);
        boolean boolean10 = textTitle7.getExpandToFitSpace();
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font12);
        textTitle7.setFont(font12);
        textTitle7.setToolTipText("java.awt.Color[r=0,g=0,b=128]");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle7.getTextAlignment();
        textTitle5.setHorizontalAlignment(horizontalAlignment17);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getPositiveItemLabelPosition((int) '4', 255);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer11.setBaseOutlineStroke(stroke14);
        barRenderer0.setBaseOutlineStroke(stroke14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D10);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) 'a');
        org.jfree.data.general.Dataset dataset21 = legendItemEntity18.getDataset();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(dataset21);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setCopyright("java.awt.Color[r=0,g=0,b=128]");
        projectInfo1.setLicenceText("java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str7 = projectInfo1.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str7.equals("java.awt.Color[r=0,g=0,b=128]"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, 100, (int) (byte) 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        java.awt.Font font30 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color31, (float) 1L, textMeasurer33);
        org.jfree.chart.text.TextLine textLine35 = textBlock34.getLastLine();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock34.draw(graphics2D36, (float) 100, (float) (byte) 1, textBlockAnchor39, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock34.setLineAlignment(horizontalAlignment44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) (short) -1, 0.0d, rectangleAnchor53);
        plotRenderingInfo47.setDataArea(rectangle2D54);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D54, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58);
        boolean boolean63 = horizontalAlignment44.equals((java.lang.Object) defaultStatisticalCategoryDataset58);
        java.util.List list64 = defaultStatisticalCategoryDataset58.getColumnKeys();
        java.lang.Comparable comparable65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset58, comparable65);
        java.lang.Comparable comparable67 = legendItemBlockContainer66.getSeriesKey();
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        java.lang.Object obj70 = null;
        try {
            java.lang.Object obj71 = legendItemBlockContainer66.draw(graphics2D68, rectangle2D69, obj70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNull(textLine35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNull(comparable67);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis2.setLabelFont(font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=64]", font3);
        textTitle5.setPadding(0.0d, (double) (byte) 1, (double) 10.0f, (double) 0L);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        barRenderer0.setBaseItemLabelFont(font11);
        boolean boolean17 = barRenderer0.isItemLabelVisible(0, 0);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        try {
            org.jfree.data.Range range20 = barRenderer0.findRangeBounds(categoryDataset19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color1 = java.awt.Color.red;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) color1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font7 = textTitle6.getFont();
        org.jfree.chart.event.TitleChangeListener titleChangeListener8 = null;
        textTitle6.addChangeListener(titleChangeListener8);
        textTitle6.setText("");
        java.lang.Object obj12 = textTitle6.clone();
        try {
            java.lang.Object obj13 = blockContainer0.draw(graphics2D3, rectangle2D4, (java.lang.Object) textTitle6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        legendGraphic4.setLineVisible(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendGraphic4.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendGraphic4.getShapeAnchor();
        java.awt.Paint paint11 = legendGraphic4.getLinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.clearCache(classLoader3);
        java.util.ResourceBundle.Control control5 = null;
        try {
            java.util.ResourceBundle resourceBundle6 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", locale1, classLoader3, control5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer1.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesPaint(0);
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer8.setSeriesItemLabelFont(1, font12, false);
        barRenderer1.setBaseItemLabelFont(font12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        barRenderer16.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer16.setBaseOutlineStroke(stroke19);
        barRenderer16.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        java.awt.Paint paint26 = barRenderer16.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE2", font12, paint26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        int int30 = categoryAxis29.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) (short) -1, 0.0d, rectangleAnchor40);
        plotRenderingInfo34.setDataArea(rectangle2D41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double44 = categoryAxis29.getCategoryStart((int) (short) 10, (int) (short) 1, rectangle2D41, rectangleEdge43);
        try {
            labelBlock27.draw(graphics2D28, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 854.9999999999999d + "'", double44 == 854.9999999999999d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int3 = java.awt.Color.HSBtoRGB(100.0f, (float) (-14336), (float) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2120800) + "'", int3 == (-2120800));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        barRenderer0.setBaseItemLabelFont(font11);
        boolean boolean17 = barRenderer0.isItemLabelVisible(0, 0);
        barRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke22 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Font font2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color3, (float) 1L, textMeasurer5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) '4', textBlock6, textBlockAnchor7, textAnchor8, 0.0d);
        org.jfree.chart.text.TextBlock textBlock11 = categoryTick10.getLabel();
        double double12 = categoryTick10.getAngle();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean7 = barRenderer0.getBaseSeriesVisible();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int9 = defaultStatisticalCategoryDataset7.getRowIndex((java.lang.Comparable) (short) -1);
        java.util.List list10 = defaultStatisticalCategoryDataset7.getRowKeys();
        java.util.List list11 = defaultStatisticalCategoryDataset7.getRowKeys();
        boolean boolean12 = itemLabelPosition6.equals((java.lang.Object) defaultStatisticalCategoryDataset7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.Plot plot2 = numberAxis1.getPlot();
        boolean boolean3 = numberAxis1.isNegativeArrowVisible();
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        int int18 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (short) 1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener19 = null;
        defaultStatisticalCategoryDataset12.removeChangeListener(datasetChangeListener19);
        boolean boolean22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) datasetChangeListener19, (java.lang.Object) "-6,-50,4,50");
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace30 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.ensureAtLeast(axisSpace30);
        double double32 = axisSpace29.getLeft();
        boolean boolean33 = legendTitle28.equals((java.lang.Object) axisSpace29);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        double double7 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer12.setBaseOutlineStroke(stroke15);
        barRenderer0.setSeriesStroke((int) (short) 100, stroke15, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer20.setSeriesItemLabelFont(1, font24, false);
        try {
            barRenderer0.setSeriesItemLabelFont((int) (byte) -1, font24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        double double18 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        categoryAxis0.setLowerMargin((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font1, (java.awt.Paint) color2, (float) (byte) 0);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D11, (float) (byte) 10, (float) 0, textAnchor14, (double) (byte) -1, (float) (short) 10, (float) 255);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.Object obj22 = null;
        boolean boolean23 = textAnchor21.equals(obj22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor19, textAnchor20, textAnchor21, (double) (byte) -1);
        org.jfree.chart.axis.NumberTick numberTick27 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0d, "", textAnchor14, textAnchor21, (double) 2.0f);
        try {
            textFragment4.draw(graphics2D5, 0.0f, (float) 4, textAnchor21, (float) (-1), (float) 100, 62.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection63 = categoryPlot60.getLegendItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(legendItemCollection63);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        java.awt.Font font30 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color31, (float) 1L, textMeasurer33);
        org.jfree.chart.text.TextLine textLine35 = textBlock34.getLastLine();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock34.draw(graphics2D36, (float) 100, (float) (byte) 1, textBlockAnchor39, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock34.setLineAlignment(horizontalAlignment44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) (short) -1, 0.0d, rectangleAnchor53);
        plotRenderingInfo47.setDataArea(rectangle2D54);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D54, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58);
        boolean boolean63 = horizontalAlignment44.equals((java.lang.Object) defaultStatisticalCategoryDataset58);
        java.util.List list64 = defaultStatisticalCategoryDataset58.getColumnKeys();
        java.lang.Comparable comparable65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset58, comparable65);
        java.lang.String str67 = legendItemBlockContainer66.getURLText();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNull(textLine35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNull(str67);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setLabelURL("ItemLabelAnchor.INSIDE2");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        java.awt.Shape shape7 = numberAxis1.getDownArrow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        try {
            keyedObjects0.removeValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getPositiveItemLabelPosition(1, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNull(itemLabelPosition16);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = barRenderer0.getPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint15 = categoryAxis13.getTickLabelPaint((java.lang.Comparable) "RangeType.NEGATIVE");
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        barRenderer17.setGradientPaintTransformer(gradientPaintTransformer18);
        barRenderer17.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = barRenderer17.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint26 = barRenderer24.lookupSeriesPaint(0);
        java.awt.Font font28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer24.setSeriesItemLabelFont(1, font28, false);
        barRenderer17.setBaseItemLabelFont(font28);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str33 = color32.toString();
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=0,g=0,b=128]", font28, (java.awt.Paint) color32);
        categoryAxis13.setLabelFont(font28);
        barRenderer0.setSeriesItemLabelFont(0, font28, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str33.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color6, false);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        java.lang.String str2 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MINOR" + "'", str2.equals("MINOR"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        java.util.ResourceBundle.clearCache(classLoader1);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toFixedWidth(100.0d);
        double double8 = rectangleConstraint7.getHeight();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setID("java.awt.Color[r=0,g=0,b=128]");
        java.lang.Object obj7 = legendGraphic4.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer11.setBaseOutlineStroke(stroke14);
        barRenderer11.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        barRenderer20.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer20.getBaseNegativeItemLabelPosition();
        barRenderer11.setSeriesNegativeItemLabelPosition(100, itemLabelPosition26, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        int int32 = barRenderer0.getPassCount();
        java.awt.Font font35 = barRenderer0.getItemLabelFont(10, (int) (short) 10);
        boolean boolean36 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        legendGraphic4.setLineVisible(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendGraphic4.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendGraphic4.getShapeAnchor();
        java.lang.Object obj11 = legendGraphic4.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toFixedWidth(100.0d);
        org.jfree.data.Range range8 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint2.toRangeWidth(range8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 10, 0.05d, 1.0E-8d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.Object obj6 = null;
        boolean boolean7 = textAnchor5.equals(obj6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4, textAnchor5, (double) (byte) -1);
        try {
            org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "", textAnchor2, textAnchor4, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        boolean boolean75 = categoryPlot69.isDomainGridlinesVisible();
        categoryPlot69.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis1.setMarkerBand(markerAxisBand11);
        java.awt.Shape shape13 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer0.getSeriesToolTipGenerator((int) '4');
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 100.0d, (double) (-1));
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        barRenderer7.setGradientPaintTransformer(gradientPaintTransformer8);
        barRenderer7.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer7.getLegendItemToolTipGenerator();
        boolean boolean16 = barRenderer7.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int17 = barRenderer7.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer7);
        java.lang.Object obj19 = legendTitle18.clone();
        java.awt.Paint paint20 = legendTitle18.getBackgroundPaint();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint24 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape23, paint24);
        legendGraphic25.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendGraphic25.getShapeLocation();
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor28);
        java.lang.String str30 = legendTitle18.getID();
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle18);
        java.lang.Object obj32 = blockContainer0.clone();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis2.setLabelFont(font3);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        double double7 = numberAxis2.getLowerMargin();
        org.jfree.data.Range range8 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis10.setLabelFont(font11);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis10.setMarkerBand(markerAxisBand13);
        double double15 = numberAxis10.getLowerMargin();
        org.jfree.data.Range range16 = numberAxis10.getDefaultAutoRange();
        org.jfree.data.Range range17 = org.jfree.data.Range.combine(range8, range16);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis21.setLabelFont(font22);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis21.setMarkerBand(markerAxisBand24);
        double double26 = numberAxis21.getLowerMargin();
        org.jfree.data.Range range27 = numberAxis21.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis29.setLabelFont(font30);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis29.setMarkerBand(markerAxisBand32);
        double double34 = numberAxis29.getLowerMargin();
        org.jfree.data.Range range35 = numberAxis29.getDefaultAutoRange();
        org.jfree.data.Range range36 = org.jfree.data.Range.combine(range27, range35);
        org.jfree.data.Range range37 = null;
        org.jfree.data.Range range38 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(range37, range38);
        org.jfree.data.Range range40 = rectangleConstraint39.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint39.toFixedHeight((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType43 = rectangleConstraint42.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint(1.0E-8d, range16, lengthConstraintType18, 1.0E-8d, range27, lengthConstraintType43);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(lengthConstraintType43);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        java.util.List list35 = defaultStatisticalCategoryDataset29.getColumnKeys();
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNull(range36);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        numberAxis1.setFixedAutoRange((double) '4');
        numberAxis1.configure();
        boolean boolean14 = numberAxis1.isInverted();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesPaint(0);
        java.awt.Font font19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer15.setSeriesItemLabelFont(1, font19, false);
        boolean boolean22 = barRenderer15.getIncludeBaseInRange();
        boolean boolean23 = barRenderer15.getAutoPopulateSeriesStroke();
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer15.setBaseOutlinePaint((java.awt.Paint) color24);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.awt.Color color1 = java.awt.Color.ORANGE;
        boolean boolean2 = tickType0.equals((java.lang.Object) color1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer3.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer3.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer3.getLegendItemToolTipGenerator();
        boolean boolean12 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int13 = barRenderer3.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer3);
        java.lang.Object obj15 = legendTitle14.clone();
        boolean boolean16 = tickType0.equals((java.lang.Object) legendTitle14);
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle14.getItemContainer();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(blockContainer17);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        numberAxis1.addChangeListener(axisChangeListener8);
        org.jfree.data.RangeType rangeType10 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(rangeType10);
    }
}

