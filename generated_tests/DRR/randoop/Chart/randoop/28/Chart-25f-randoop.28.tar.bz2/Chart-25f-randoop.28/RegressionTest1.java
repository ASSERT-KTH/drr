import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.lang.Object obj8 = barRenderer0.clone();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color10 = java.awt.Color.red;
        boolean boolean11 = blockContainer9.equals((java.lang.Object) color10);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color10);
        java.awt.Font font14 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color15, (float) 1L, textMeasurer17);
        org.jfree.chart.text.TextLine textLine19 = textBlock18.getLastLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock18.draw(graphics2D20, (float) 100, (float) (byte) 1, textBlockAnchor23, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock18.setLineAlignment(horizontalAlignment28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (short) -1, 0.0d, rectangleAnchor37);
        plotRenderingInfo31.setDataArea(rectangle2D38);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D38, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42);
        boolean boolean47 = horizontalAlignment28.equals((java.lang.Object) defaultStatisticalCategoryDataset42);
        org.jfree.data.general.DatasetGroup datasetGroup48 = defaultStatisticalCategoryDataset42.getGroup();
        org.jfree.data.Range range50 = defaultStatisticalCategoryDataset42.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean55 = numberAxis54.isPositiveArrowVisible();
        numberAxis54.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = null;
        numberAxis54.setMarkerBand(markerAxisBand59);
        double double61 = numberAxis54.getUpperBound();
        java.text.NumberFormat numberFormat62 = numberAxis54.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        barRenderer63.setGradientPaintTransformer(gradientPaintTransformer64);
        barRenderer63.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator69 = barRenderer63.getLegendItemToolTipGenerator();
        boolean boolean72 = barRenderer63.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer63);
        boolean boolean74 = categoryPlot73.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot73.setDomainAxisLocation(4, axisLocation76);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot73);
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str80 = axisLocation79.toString();
        categoryPlot73.setRangeAxisLocation(axisLocation79);
        java.lang.String str82 = axisLocation79.toString();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNull(textLine19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(datasetGroup48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertNull(numberFormat62);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str80.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str82.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        double double37 = defaultStatisticalCategoryDataset29.getRangeLowerBound(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj2 = textTitle1.clone();
        double double3 = textTitle1.getContentYOffset();
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font2 = textTitle1.getFont();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot60.removeChangeListener(plotChangeListener61);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo64);
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot60.zoomDomainAxes((double) 2.0f, plotRenderingInfo65, point2D66);
        double double68 = categoryPlot60.getAnchorValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((-14336), categoryItemLabelGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        double double18 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        boolean boolean61 = categoryPlot60.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double64 = rectangleInsets62.calculateLeftOutset(10.0d);
        categoryPlot60.setInsets(rectangleInsets62);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.0d + "'", double64 == 3.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic4.getShapeLocation();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str9 = color8.toString();
        legendGraphic4.setLinePaint((java.awt.Paint) color8);
        legendGraphic4.setShapeOutlineVisible(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str9.equals("java.awt.Color[r=0,g=0,b=128]"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) (short) -1, 0.0d, rectangleAnchor32);
        java.awt.Shape shape34 = null;
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D33, shape34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str37 = color36.toString();
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D33, (java.awt.Paint) color36, stroke38, (java.awt.Paint) color39);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType41 = org.jfree.chart.block.LengthConstraintType.RANGE;
        try {
            java.lang.Object obj42 = legendGraphic4.draw(graphics2D22, rectangle2D33, (java.lang.Object) lengthConstraintType41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str37.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(lengthConstraintType41);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        int int39 = defaultStatisticalCategoryDataset29.getRowIndex((java.lang.Comparable) 50.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        int int6 = barRenderer0.getRowCount();
        boolean boolean7 = barRenderer0.getBaseSeriesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape10 = barRenderer0.lookupSeriesShape(0);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = barRenderer0.getLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean11 = numberAxis10.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat12 = numberAxis10.getNumberFormatOverride();
        numberAxis10.setInverted(true);
        boolean boolean15 = legendItemCollection8.equals((java.lang.Object) numberAxis10);
        numberAxis10.setLabelAngle((double) ' ');
        java.awt.Shape shape18 = numberAxis10.getUpArrow();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        java.lang.String str3 = projectInfo1.getVersion();
//        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        projectInfo5.setCopyright("java.awt.Color[r=0,g=0,b=128]");
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        java.lang.String str10 = projectInfo5.getName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
//        org.junit.Assert.assertNotNull(projectInfo4);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JFreeChart" + "'", str10.equals("JFreeChart"));
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        boolean boolean12 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        java.awt.Paint paint17 = barRenderer0.getSeriesItemLabelPaint((int) (short) -1);
        java.awt.Stroke stroke20 = barRenderer0.getItemStroke((int) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.lang.Boolean boolean7 = barRenderer0.getSeriesCreateEntities((int) 'a');
        java.awt.Paint paint8 = barRenderer0.getBasePaint();
        int int9 = barRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.awt.Color color1 = java.awt.Color.ORANGE;
        boolean boolean2 = tickType0.equals((java.lang.Object) color1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer3.setGradientPaintTransformer(gradientPaintTransformer4);
        barRenderer3.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer3.getLegendItemToolTipGenerator();
        boolean boolean12 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int13 = barRenderer3.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer3);
        java.lang.Object obj15 = legendTitle14.clone();
        boolean boolean16 = tickType0.equals((java.lang.Object) legendTitle14);
        java.awt.geom.Rectangle2D rectangle2D17 = legendTitle14.getBounds();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle14.getItemContainer();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(blockContainer18);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        legendGraphic4.setLineVisible(true);
        java.awt.Shape shape9 = legendGraphic4.getShape();
        legendGraphic4.setShapeOutlineVisible(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font15 = textTitle14.getFont();
        org.jfree.chart.event.TitleChangeListener titleChangeListener16 = null;
        textTitle14.addChangeListener(titleChangeListener16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis20.setTickLabelInsets(rectangleInsets25);
        java.lang.Object obj27 = numberAxis20.clone();
        numberAxis20.setTickMarkInsideLength(10.0f);
        numberAxis20.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.AxisState axisState33 = null;
        org.jfree.chart.util.Size2D size2D40 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D44 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D40, (double) (short) -1, 0.0d, rectangleAnchor43);
        java.awt.Shape shape45 = null;
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D44, shape45);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str48 = color47.toString();
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color50 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D44, (java.awt.Paint) color47, stroke49, (java.awt.Paint) color50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        java.util.List list53 = numberAxis20.refreshTicks(graphics2D32, axisState33, rectangle2D44, rectangleEdge52);
        textTitle14.draw(graphics2D18, rectangle2D44);
        try {
            legendGraphic4.draw(graphics2D12, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str48.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(list53);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesPaint(0);
        java.awt.Paint paint6 = barRenderer2.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj7 = barRenderer2.clone();
        barRenderer2.setAutoPopulateSeriesShape(false);
        java.awt.Color color10 = java.awt.Color.cyan;
        barRenderer2.setBasePaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer15 = new org.jfree.chart.text.G2TextMeasurer(graphics2D14);
        try {
            org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.BOTTOM_LEFT", font1, (java.awt.Paint) color10, (float) (-1), 2, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str1.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font4 = textTitle3.getFont();
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        textTitle3.addChangeListener(titleChangeListener5);
        textTitle3.setText("");
        textTitle3.setMargin((double) 1.0f, 62.0d, 1.0d, (-1.0d));
        java.lang.String str14 = textTitle3.getText();
        boolean boolean15 = standardGradientPaintTransformer1.equals((java.lang.Object) textTitle3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        boolean boolean13 = legendTitle11.equals((java.lang.Object) "CONTRACT");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor14);
        boolean boolean16 = legendTitle11.getNotify();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        java.awt.Font font15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 1L, textMeasurer18);
        int int20 = color16.getAlpha();
        barRenderer0.setBasePaint((java.awt.Paint) color16);
        double double22 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Paint paint24 = barRenderer0.lookupSeriesOutlinePaint(10);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer1.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesPaint(0);
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer8.setSeriesItemLabelFont(1, font12, false);
        barRenderer1.setBaseItemLabelFont(font12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        barRenderer16.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer16.setBaseOutlineStroke(stroke19);
        barRenderer16.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        java.awt.Paint paint26 = barRenderer16.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE2", font12, paint26);
        java.awt.Font font28 = labelBlock27.getFont();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        numberAxis1.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        java.awt.Shape shape26 = null;
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D25, shape26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str29 = color28.toString();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D25, (java.awt.Paint) color28, stroke30, (java.awt.Paint) color31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = numberAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D25, rectangleEdge33);
        boolean boolean35 = numberAxis1.isAutoRange();
        java.lang.String str36 = numberAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str29.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(str36);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesPaint(0);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer1.setSeriesItemLabelFont(1, font5, false);
        boolean boolean8 = barRenderer1.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer1.setBaseURLGenerator(categoryURLGenerator9, true);
        barRenderer1.setBaseCreateEntities(false);
        boolean boolean14 = textAnchor0.equals((java.lang.Object) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        barRenderer16.setGradientPaintTransformer(gradientPaintTransformer17);
        barRenderer16.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = barRenderer16.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesPaint(0);
        java.awt.Font font27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer23.setSeriesItemLabelFont(1, font27, false);
        barRenderer16.setBaseItemLabelFont(font27);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str32 = color31.toString();
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=0,g=0,b=128]", font27, (java.awt.Paint) color31);
        boolean boolean34 = textAnchor0.equals((java.lang.Object) "java.awt.Color[r=0,g=0,b=128]");
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str32.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Object obj3 = keyedObjects0.getObject((int) (short) 10);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        java.awt.Paint paint15 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        barRenderer0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color17, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        barRenderer0.setSeriesURLGenerator((int) (byte) 10, categoryURLGenerator21, true);
        try {
            barRenderer0.setSeriesVisible((-2120800), (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis64.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj67 = categoryAxis64.clone();
        categoryAxis64.setAxisLineVisible(true);
        java.awt.Font font72 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color73 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment75 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font72, (java.awt.Paint) color73, (float) (byte) 0);
        categoryAxis64.setTickLabelFont((java.lang.Comparable) 0, font72);
        categoryPlot60.setDomainAxis(categoryAxis64);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertNotNull(color73);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setFixedAutoRange((double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(numberFormat3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.Comparable comparable18 = legendItem17.getSeriesKey();
        boolean boolean19 = legendItem17.isLineVisible();
        boolean boolean20 = legendItem17.isLineVisible();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean5 = textTitle3.equals((java.lang.Object) paint4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) (short) -1, 0.0d, rectangleAnchor16);
        java.awt.Shape shape18 = null;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D17, shape18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str21 = color20.toString();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D17, (java.awt.Paint) color20, stroke22, (java.awt.Paint) color23);
        textTitle3.setBounds(rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.TOP;
        double double27 = numberAxis0.lengthToJava2D((double) 10L, rectangle2D17, rectangleEdge26);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = numberAxis0.getTickUnit();
        java.lang.String str30 = numberTickUnit28.valueToString(109.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = null;
        barRenderer31.setGradientPaintTransformer(gradientPaintTransformer32);
        barRenderer31.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer31.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator41 = barRenderer31.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer44 = null;
        barRenderer43.setGradientPaintTransformer(gradientPaintTransformer44);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer43.setBaseOutlineStroke(stroke46);
        barRenderer43.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer52 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint54 = barRenderer52.lookupSeriesPaint(0);
        barRenderer52.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition58 = barRenderer52.getBaseNegativeItemLabelPosition();
        barRenderer43.setSeriesNegativeItemLabelPosition(100, itemLabelPosition58, false);
        barRenderer31.setSeriesPositiveItemLabelPosition(1, itemLabelPosition58);
        boolean boolean62 = numberTickUnit28.equals((java.lang.Object) barRenderer31);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "109" + "'", str30.equals("109"));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator41);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(itemLabelPosition58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Font font2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color3, (float) 1L, textMeasurer5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) '4', textBlock6, textBlockAnchor7, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 1L, textMeasurer18);
        org.jfree.chart.text.TextLine textLine20 = textBlock19.getLastLine();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock19.draw(graphics2D21, (float) 100, (float) (byte) 1, textBlockAnchor24, 1.0f, (float) '4', (double) 1.0f);
        textBlock6.draw(graphics2D11, (float) 3, (float) (-1), textBlockAnchor24);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock6.draw(graphics2D30, 2.0f, (float) 0, textBlockAnchor33);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNull(textLine20);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        double double7 = legendGraphic4.getWidth();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesPaint(0);
        java.awt.Paint paint7 = barRenderer3.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj8 = barRenderer3.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition10);
        double double12 = barRenderer3.getMinimumBarLength();
        boolean boolean13 = textLine2.equals((java.lang.Object) barRenderer3);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        barRenderer3.setBaseShape(shape14, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        double double6 = categoryAxis0.getUpperMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 255);
        categoryAxis0.setLabel("");
        double double11 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setCategoryMargin(1.0d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font1, (java.awt.Paint) color2, (float) (byte) 0);
        boolean boolean6 = textFragment4.equals((java.lang.Object) ' ');
        float float7 = textFragment4.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot60.removeChangeListener(plotChangeListener61);
        float float63 = categoryPlot60.getForegroundAlpha();
        categoryPlot60.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 1.0f + "'", float63 == 1.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint27 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, paint27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendGraphic28.getMargin();
        legendTitle11.setLegendItemGraphicPadding(rectangleInsets29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.Range range32 = null;
        org.jfree.data.Range range33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint(range32, range33);
        org.jfree.data.Range range35 = rectangleConstraint34.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = rectangleConstraint34.toFixedHeight((double) (short) 10);
        org.jfree.chart.util.Size2D size2D38 = legendTitle11.arrange(graphics2D31, rectangleConstraint34);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
        org.junit.Assert.assertNotNull(size2D38);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = legendTitle11.getSources();
        org.jfree.chart.block.BlockContainer blockContainer25 = legendTitle11.getItemContainer();
        java.lang.Object obj26 = blockContainer25.clone();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertNotNull(blockContainer25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        numberAxis1.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        java.awt.Shape shape26 = null;
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D25, shape26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str29 = color28.toString();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D25, (java.awt.Paint) color28, stroke30, (java.awt.Paint) color31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = numberAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D25, rectangleEdge33);
        numberAxis1.setAutoRangeIncludesZero(true);
        numberAxis1.resizeRange((double) 2);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str29.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int3 = java.awt.Color.HSBtoRGB((float) (-14336), (float) 1, (float) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-655360) + "'", int3 == (-655360));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis4.setLabelFont(font5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=64]", font5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray12 = new float[] { (short) 0, (byte) -1, (short) -1 };
        float[] floatArray13 = color8.getRGBColorComponents(floatArray12);
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, (java.awt.Paint) color8);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        org.jfree.chart.text.TextLine textLine21 = textBlock20.getLastLine();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock20.draw(graphics2D22, (float) 100, (float) (byte) 1, textBlockAnchor25, 1.0f, (float) '4', (double) 1.0f);
        java.lang.String str30 = textBlockAnchor25.toString();
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick33 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "1", textBlock14, textBlockAnchor25, textAnchor31, (double) 1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str30.equals("TextBlockAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        java.awt.Paint paint13 = barRenderer0.getItemPaint((int) (byte) 0, (-16777216));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        java.lang.Object obj3 = null;
        objectList0.set((int) (byte) 1, obj3);
        int int5 = objectList0.size();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        categoryPlot69.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis76.setTickLabelInsets(rectangleInsets81);
        java.lang.Object obj83 = numberAxis76.clone();
        org.jfree.chart.plot.Plot plot84 = null;
        numberAxis76.setPlot(plot84);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand86 = null;
        numberAxis76.setMarkerBand(markerAxisBand86);
        numberAxis76.setLabelToolTip("ClassContext");
        categoryPlot69.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis76);
        java.text.NumberFormat numberFormat91 = null;
        numberAxis76.setNumberFormatOverride(numberFormat91);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj83);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.lang.String str8 = numberAxis1.getLabelToolTip();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean30 = flowArrangement16.equals((java.lang.Object) categoryAnchor29);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = null;
        keyedObjects0.addObject((java.lang.Comparable) ' ', obj3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = barRenderer0.getLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean11 = numberAxis10.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat12 = numberAxis10.getNumberFormatOverride();
        numberAxis10.setInverted(true);
        boolean boolean15 = legendItemCollection8.equals((java.lang.Object) numberAxis10);
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, (double) (short) -1, 0.0d, rectangleAnchor25);
        java.awt.Shape shape27 = null;
        boolean boolean28 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D26, shape27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str30 = color29.toString();
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D26, (java.awt.Paint) color29, stroke31, (java.awt.Paint) color32);
        int int34 = legendItem33.getDatasetIndex();
        int int35 = legendItem33.getSeriesIndex();
        legendItemCollection8.add(legendItem33);
        int int37 = legendItemCollection8.getItemCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str30.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset73 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int74 = defaultStatisticalCategoryDataset73.getColumnCount();
        categoryPlot69.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset73);
        try {
            java.lang.Number number78 = defaultStatisticalCategoryDataset73.getStdDevValue((int) (byte) 100, (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis4.setTickLabelInsets(rectangleInsets9);
        java.lang.Object obj11 = numberAxis4.clone();
        numberAxis4.setLowerMargin((double) '#');
        numberAxis4.setLabelToolTip("java.awt.Color[r=255,g=255,b=64]");
        boolean boolean16 = size2D2.equals((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str17 = size2D2.toString();
        double double18 = size2D2.getHeight();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str17.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        java.lang.Comparable comparable2 = null;
        keyedObjects2D0.setObject(obj1, comparable2, (java.lang.Comparable) 100.0f);
        keyedObjects2D0.removeRow((int) (byte) 0);
        try {
            keyedObjects2D0.removeColumn((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        java.lang.Object obj22 = legendGraphic4.clone();
        java.awt.geom.Rectangle2D rectangle2D23 = legendGraphic4.getBounds();
        java.awt.Shape shape24 = null;
        legendGraphic4.setShape(shape24);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer1.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesPaint(0);
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer8.setSeriesItemLabelFont(1, font12, false);
        barRenderer1.setBaseItemLabelFont(font12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        barRenderer16.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer16.setBaseOutlineStroke(stroke19);
        barRenderer16.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        java.awt.Paint paint26 = barRenderer16.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE2", font12, paint26);
        java.awt.Color color28 = java.awt.Color.darkGray;
        labelBlock27.setPaint((java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        boolean boolean12 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke15 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        defaultStatisticalCategoryDataset0.validateObject();
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color1 = java.awt.Color.red;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) color1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = blockContainer0.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("TextAnchor.CENTER_RIGHT", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer10.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean15 = barRenderer10.equals((java.lang.Object) (-1.0d));
        barRenderer10.setBaseCreateEntities(false, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer10.setBaseItemLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        barRenderer10.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition22);
        java.awt.Paint paint25 = barRenderer10.lookupSeriesPaint((int) (short) -1);
        barRenderer0.setBaseFillPaint(paint25);
        java.awt.Font font28 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font28);
        barRenderer0.setBaseItemLabelFont(font28, true);
        double double32 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        int int18 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (short) 1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener19 = null;
        defaultStatisticalCategoryDataset12.removeChangeListener(datasetChangeListener19);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) (byte) 100);
        double double24 = defaultStatisticalCategoryDataset12.getRangeUpperBound(false);
        org.jfree.data.general.DatasetGroup datasetGroup25 = defaultStatisticalCategoryDataset12.getGroup();
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup25);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject(1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer4.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setBaseURLGenerator(categoryURLGenerator8, true);
        barRenderer4.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        boolean boolean14 = barRenderer4.removeAnnotation(categoryAnnotation13);
        org.jfree.chart.block.BorderArrangement borderArrangement15 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, 100.0d, (double) (-1));
        java.awt.Image image24 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo28 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image24, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo28.setName("CONTRACT");
        boolean boolean31 = flowArrangement20.equals((java.lang.Object) projectInfo28);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer4, (org.jfree.chart.block.Arrangement) borderArrangement15, (org.jfree.chart.block.Arrangement) flowArrangement20);
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement20);
        java.util.List list34 = blockContainer3.getBlocks();
        projectInfo1.setContributors(list34);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        double double3 = axisSpace1.getRight();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer4.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean9 = barRenderer4.equals((java.lang.Object) (-1.0d));
        int int10 = barRenderer4.getRowCount();
        boolean boolean11 = barRenderer4.getBaseSeriesVisible();
        barRenderer4.setSeriesVisible(3, (java.lang.Boolean) true, false);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint19 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean20 = textTitle18.equals((java.lang.Object) paint19);
        boolean boolean21 = textTitle18.getExpandToFitSpace();
        java.lang.Object obj22 = textTitle18.clone();
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle18.getBounds();
        barRenderer4.setSeriesShape(0, (java.awt.Shape) rectangle2D23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis26.setTickLabelInsets(rectangleInsets31);
        java.lang.Object obj33 = numberAxis26.clone();
        numberAxis26.setTickMarkInsideLength(10.0f);
        numberAxis26.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        org.jfree.chart.util.Size2D size2D46 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, (double) (short) -1, 0.0d, rectangleAnchor49);
        java.awt.Shape shape51 = null;
        boolean boolean52 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D50, shape51);
        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str54 = color53.toString();
        java.awt.Stroke stroke55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D50, (java.awt.Paint) color53, stroke55, (java.awt.Paint) color56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        java.util.List list59 = numberAxis26.refreshTicks(graphics2D38, axisState39, rectangle2D50, rectangleEdge58);
        java.awt.geom.Rectangle2D rectangle2D60 = axisSpace1.shrink(rectangle2D23, rectangle2D50);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str54.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(rectangle2D60);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj6 = categoryAxis3.clone();
        boolean boolean7 = rectangleInsets2.equals((java.lang.Object) categoryAxis3);
        double double9 = rectangleInsets2.trimWidth((double) 0.0f);
        double double11 = rectangleInsets2.trimHeight((double) (-1.0f));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.0d) + "'", double9 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-3.0d) + "'", double11 == (-3.0d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.title.LegendTitle legendTitle65 = jFreeChart63.getLegend((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint68 = barRenderer66.lookupSeriesPaint(0);
        java.awt.Paint paint70 = barRenderer66.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj71 = barRenderer66.clone();
        barRenderer66.setAutoPopulateSeriesShape(false);
        java.awt.Color color74 = java.awt.Color.cyan;
        barRenderer66.setBasePaint((java.awt.Paint) color74);
        jFreeChart63.setBackgroundPaint((java.awt.Paint) color74);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNull(legendTitle65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNull(paint70);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(color74);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 2.0d, (float) (byte) 10, (float) (byte) 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.Comparable comparable18 = legendItem17.getSeriesKey();
        java.awt.Shape shape19 = legendItem17.getLine();
        java.awt.Paint paint20 = legendItem17.getOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        boolean boolean10 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        boolean boolean13 = legendTitle11.equals((java.lang.Object) "CONTRACT");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font16 = textTitle15.getFont();
        legendTitle11.setItemFont(font16);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset73 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int74 = defaultStatisticalCategoryDataset73.getColumnCount();
        categoryPlot69.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset73);
        double double77 = defaultStatisticalCategoryDataset73.getRangeUpperBound(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setBaseCreateEntities(true);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesStroke(255);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean3 = textTitle1.equals((java.lang.Object) paint2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.lang.Object obj5 = textTitle1.clone();
        textTitle1.setNotify(false);
        java.awt.Paint paint8 = textTitle1.getBackgroundPaint();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint12 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, paint12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendGraphic13.getMargin();
        textTitle1.setPadding(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        double double18 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition7);
        double double9 = barRenderer0.getMinimumBarLength();
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(itemLabelPosition12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        double double3 = axisSpace1.getRight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace1.add((double) (short) -1, rectangleEdge5);
        java.lang.String str7 = axisSpace1.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = jFreeChart63.getCategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation66 = axisLocation65.getOpposite();
        categoryPlot64.setDomainAxisLocation(axisLocation66);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation66, plotOrientation68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(categoryPlot64);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(axisLocation66);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 100.0d, (double) (-1));
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement5);
        flowArrangement5.clear();
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor4 = categoryLabelPosition1.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        java.lang.Object obj2 = null;
        boolean boolean3 = keyedObjects2D0.equals(obj2);
        int int5 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str5 = color4.toString();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=255,b=64]", font2, (java.awt.Paint) color4, (float) (-14336));
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesPaint(0);
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer12.setSeriesItemLabelFont(1, font16, false);
        boolean boolean19 = barRenderer12.getIncludeBaseInRange();
        boolean boolean20 = barRenderer12.getAutoPopulateSeriesStroke();
        boolean boolean21 = categoryLabelPosition11.equals((java.lang.Object) boolean20);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition22.getLabelAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        org.jfree.chart.util.Size2D size2D33 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, (double) (short) -1, 0.0d, rectangleAnchor36);
        plotRenderingInfo30.setDataArea(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis24.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D37, rectangleEdge39);
        int int41 = categoryAxis24.getCategoryLabelPositionOffset();
        double double42 = categoryAxis24.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions43 = categoryAxis24.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = categoryLabelPosition44.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions46 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions43, categoryLabelPosition44);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition47 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint50 = barRenderer48.lookupSeriesPaint(0);
        java.awt.Font font52 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer48.setSeriesItemLabelFont(1, font52, false);
        boolean boolean55 = barRenderer48.getIncludeBaseInRange();
        boolean boolean56 = barRenderer48.getAutoPopulateSeriesStroke();
        boolean boolean57 = categoryLabelPosition47.equals((java.lang.Object) boolean56);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions58 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition11, categoryLabelPosition22, categoryLabelPosition44, categoryLabelPosition47);
        org.jfree.chart.text.TextAnchor textAnchor59 = categoryLabelPosition47.getRotationAnchor();
        try {
            textFragment7.draw(graphics2D8, (-1.0f), (float) 1, textAnchor59, (float) 255, (float) '4', (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str5.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.2d + "'", double42 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions43);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertNotNull(categoryLabelPositions46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(textAnchor59);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=64,b=255]" + "'", str1.equals("java.awt.Color[r=64,g=64,b=255]"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        numberAxis1.addChangeListener(axisChangeListener8);
        double double10 = numberAxis1.getLowerBound();
        boolean boolean11 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setAutoRangeMinimumSize(854.9999999999999d);
        boolean boolean14 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj66 = textTitle65.clone();
        org.jfree.chart.event.TitleChangeListener titleChangeListener67 = null;
        textTitle65.addChangeListener(titleChangeListener67);
        jFreeChart63.addSubtitle((org.jfree.chart.title.Title) textTitle65);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = null;
        try {
            jFreeChart63.handleClick(3, 15, chartRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(obj66);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis2.setLabelFont(font3);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        double double7 = numberAxis2.getLowerMargin();
        org.jfree.data.Range range8 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range8);
        org.jfree.data.Range range10 = rectangleConstraint9.getHeightRange();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType9);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer12.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean17 = barRenderer12.equals((java.lang.Object) (-1.0d));
        barRenderer12.setBaseCreateEntities(false, false);
        java.awt.Font font22 = null;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, (java.awt.Paint) color23, (float) 1L, textMeasurer25);
        org.jfree.chart.text.TextLine textLine27 = textBlock26.getLastLine();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock26.draw(graphics2D28, (float) 100, (float) (byte) 1, textBlockAnchor31, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock26.setLineAlignment(horizontalAlignment36);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) (short) -1, 0.0d, rectangleAnchor45);
        plotRenderingInfo39.setDataArea(rectangle2D46);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset50 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity53 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D46, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset50, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset50);
        boolean boolean55 = horizontalAlignment36.equals((java.lang.Object) defaultStatisticalCategoryDataset50);
        org.jfree.data.general.DatasetGroup datasetGroup56 = defaultStatisticalCategoryDataset50.getGroup();
        org.jfree.data.Range range58 = defaultStatisticalCategoryDataset50.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean63 = numberAxis62.isPositiveArrowVisible();
        numberAxis62.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand67 = null;
        numberAxis62.setMarkerBand(markerAxisBand67);
        double double69 = numberAxis62.getUpperBound();
        java.text.NumberFormat numberFormat70 = numberAxis62.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer71 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer72 = null;
        barRenderer71.setGradientPaintTransformer(gradientPaintTransformer72);
        barRenderer71.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator77 = barRenderer71.getLegendItemToolTipGenerator();
        boolean boolean80 = barRenderer71.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot81 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset50, categoryAxis60, (org.jfree.chart.axis.ValueAxis) numberAxis62, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer71);
        org.jfree.chart.event.PlotChangeListener plotChangeListener82 = null;
        categoryPlot81.removeChangeListener(plotChangeListener82);
        barRenderer12.setPlot(categoryPlot81);
        org.jfree.chart.util.Layer layer85 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection86 = categoryPlot81.getDomainMarkers(layer85);
        boolean boolean87 = categoryPlot81.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis88 = categoryPlot81.getRangeAxis();
        boolean boolean89 = standardGradientPaintTransformer10.equals((java.lang.Object) valueAxis88);
        valueAxis88.setRangeAboutValue((double) (byte) 10, (double) (byte) 1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(textLine27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(datasetGroup56);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.0d + "'", double69 == 10.0d);
        org.junit.Assert.assertNull(numberFormat70);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(layer85);
        org.junit.Assert.assertNull(collection86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(valueAxis88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis4.setTickLabelInsets(rectangleInsets9);
        java.lang.Object obj11 = numberAxis4.clone();
        numberAxis4.setLowerMargin((double) '#');
        numberAxis4.setLabelToolTip("java.awt.Color[r=255,g=255,b=64]");
        boolean boolean16 = size2D2.equals((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]");
        double double17 = size2D2.getWidth();
        size2D2.height = 4;
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        java.awt.Paint paint73 = categoryPlot69.getDomainGridlinePaint();
        boolean boolean74 = categoryPlot69.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesPaint(0);
        barRenderer0.setBaseFillPaint(paint6, true);
        barRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer65 = null;
        barRenderer64.setGradientPaintTransformer(gradientPaintTransformer65);
        barRenderer64.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator70 = barRenderer64.getLegendItemToolTipGenerator();
        boolean boolean73 = barRenderer64.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int74 = barRenderer64.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer64);
        java.lang.Object obj76 = legendTitle75.clone();
        java.awt.Paint paint77 = legendTitle75.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment78 = legendTitle75.getHorizontalAlignment();
        jFreeChart63.addLegend(legendTitle75);
        java.util.List list80 = null;
        try {
            jFreeChart63.setSubtitles(list80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNull(paint77);
        org.junit.Assert.assertNotNull(horizontalAlignment78);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle2.getPadding();
        double double5 = rectangleInsets4.getRight();
        double double6 = rectangleInsets4.getLeft();
        boolean boolean7 = lengthAdjustmentType0.equals((java.lang.Object) rectangleInsets4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "Size2D[width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = jFreeChart63.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle66 = jFreeChart63.getLegend((int) (byte) 1);
        java.lang.Object obj67 = jFreeChart63.getTextAntiAlias();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(categoryPlot64);
        org.junit.Assert.assertNull(legendTitle66);
        org.junit.Assert.assertNull(obj67);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        try {
            keyedObjects0.removeValue(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 100.0d, (double) (-1));
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        barRenderer7.setGradientPaintTransformer(gradientPaintTransformer8);
        barRenderer7.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer7.getLegendItemToolTipGenerator();
        boolean boolean16 = barRenderer7.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int17 = barRenderer7.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer7);
        java.lang.Object obj19 = legendTitle18.clone();
        java.awt.Paint paint20 = legendTitle18.getBackgroundPaint();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint24 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape23, paint24);
        legendGraphic25.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendGraphic25.getShapeLocation();
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor28);
        java.lang.String str30 = legendTitle18.getID();
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer34 = null;
        barRenderer33.setGradientPaintTransformer(gradientPaintTransformer34);
        barRenderer33.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = barRenderer33.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint42 = barRenderer40.lookupSeriesPaint(0);
        java.awt.Font font44 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer40.setSeriesItemLabelFont(1, font44, false);
        barRenderer33.setBaseItemLabelFont(font44);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str49 = color48.toString();
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=0,g=0,b=128]", font44, (java.awt.Paint) color48);
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock50);
        java.lang.Object obj52 = labelBlock50.clone();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str49.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        boolean boolean75 = categoryPlot69.isDomainGridlinesVisible();
        int int76 = categoryPlot69.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = categoryPlot69.getInsets();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 15 + "'", int76 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets77);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        boolean boolean61 = categoryPlot60.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = categoryPlot60.getDomainAxis((int) (short) -1);
        categoryPlot60.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(categoryAxis63);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent6.setType(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        java.awt.Color color75 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot69.setRangeCrosshairPaint((java.awt.Paint) color75);
        categoryPlot69.configureDomainAxes();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertNotNull(color75);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=64,g=64,b=255]", graphics2D1, (float) (-655360), (float) 0L, textAnchor4, (double) (-2120800), 0.0f, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str5.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis3.setLabelFont(font4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=64]", font4);
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]");
        java.lang.Object obj8 = null;
        boolean boolean9 = chartChangeEventType0.equals(obj8);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        java.awt.Paint paint10 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint14 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, paint14);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.TextAnchor textAnchor20 = null;
        textLine16.draw(graphics2D17, 1.0f, 0.0f, textAnchor20, (float) 255, 100.0f, (double) 100);
        boolean boolean25 = legendGraphic15.equals((java.lang.Object) 0.0f);
        java.awt.Font font27 = null;
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color28, (float) 1L, textMeasurer30);
        legendGraphic15.setFillPaint((java.awt.Paint) color28);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color28, false);
        java.awt.Shape shape36 = barRenderer0.getSeriesShape((int) '#');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNull(shape36);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = jFreeChart63.getCategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation66 = axisLocation65.getOpposite();
        categoryPlot64.setDomainAxisLocation(axisLocation66);
        org.jfree.chart.LegendItemCollection legendItemCollection68 = categoryPlot64.getLegendItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(categoryPlot64);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(legendItemCollection68);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        boolean boolean75 = categoryPlot69.isDomainGridlinesVisible();
        int int76 = categoryPlot69.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder77 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot69.setRowRenderingOrder(sortOrder77);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 15 + "'", int76 == 15);
        org.junit.Assert.assertNotNull(sortOrder77);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (short) -1, 0.0d, rectangleAnchor11);
        java.awt.Shape shape13 = null;
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D12, shape13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str16 = color15.toString();
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D12, (java.awt.Paint) color15, stroke17, (java.awt.Paint) color18);
        objectList0.set((int) '4', (java.lang.Object) color15);
        int int21 = objectList0.size();
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str16.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke75 = numberAxis74.getAxisLineStroke();
        barRenderer0.setBaseStroke(stroke75);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        int int18 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (short) 1);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.util.List list4 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(pieDataset6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.Comparable comparable18 = legendItem17.getSeriesKey();
        boolean boolean19 = legendItem17.isLineVisible();
        java.lang.String str20 = legendItem17.getToolTipText();
        java.awt.Stroke stroke21 = legendItem17.getLineStroke();
        java.lang.Comparable comparable22 = legendItem17.getSeriesKey();
        legendItem17.setSeriesKey((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(comparable22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesPaint(0);
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer2.setSeriesItemLabelFont(1, font6, false);
        boolean boolean9 = barRenderer2.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer2.setBaseURLGenerator(categoryURLGenerator10, true);
        barRenderer2.setBaseCreateEntities(false);
        boolean boolean15 = verticalAlignment1.equals((java.lang.Object) false);
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '4', 2.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis4.setTickLabelInsets(rectangleInsets9);
        java.lang.Object obj11 = numberAxis4.clone();
        numberAxis4.setLowerMargin((double) '#');
        numberAxis4.setLabelToolTip("java.awt.Color[r=255,g=255,b=64]");
        boolean boolean16 = size2D2.equals((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str17 = size2D2.toString();
        double double18 = size2D2.getWidth();
        size2D2.setWidth((double) (-1));
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str17.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        int int18 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (short) 1);
        int int20 = defaultStatisticalCategoryDataset12.getRowIndex((java.lang.Comparable) (-1L));
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = jFreeChart63.getCategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation66 = axisLocation65.getOpposite();
        categoryPlot64.setDomainAxisLocation(axisLocation66);
        try {
            categoryPlot64.setBackgroundImageAlpha((float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(categoryPlot64);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(axisLocation66);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        java.awt.Paint paint7 = barRenderer0.getBasePaint();
        java.awt.Stroke stroke9 = barRenderer0.lookupSeriesStroke((int) (byte) -1);
        java.awt.Paint paint12 = barRenderer0.getItemOutlinePaint((int) '#', (int) '4');
        boolean boolean15 = barRenderer0.getItemVisible((-1), (int) (byte) 0);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic4.getShapeLocation();
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) (short) -1, 0.0d, rectangleAnchor17);
        java.awt.Shape shape19 = null;
        boolean boolean20 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D18, shape19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str22 = color21.toString();
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D18, (java.awt.Paint) color21, stroke23, (java.awt.Paint) color24);
        java.lang.String str26 = legendItem25.getURLText();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint30 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape29, paint30);
        legendGraphic31.setShapeOutlineVisible(false);
        legendGraphic31.setLineVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer36 = legendGraphic31.getFillPaintTransformer();
        legendItem25.setFillPaintTransformer(gradientPaintTransformer36);
        legendGraphic4.setFillPaintTransformer(gradientPaintTransformer36);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str22.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ClassContext" + "'", str26.equals("ClassContext"));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer36);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, (double) 15, (double) (-1));
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.Plot plot2 = numberAxis1.getPlot();
        float float3 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setVisible(false);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.title.LegendTitle legendTitle65 = jFreeChart63.getLegend((int) (short) 100);
        jFreeChart63.fireChartChanged();
        java.awt.Stroke stroke67 = jFreeChart63.getBorderStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNull(legendTitle65);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D10, rectangleEdge13);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D10);
        java.awt.Font font17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color18, (float) 1L, textMeasurer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray26 = new float[] { (short) 0, (byte) -1, (short) -1 };
        float[] floatArray27 = color22.getRGBColorComponents(floatArray26);
        float[] floatArray28 = color18.getRGBColorComponents(floatArray27);
        try {
            org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "TextAnchor.CENTER_RIGHT", shape15, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean5 = textTitle3.equals((java.lang.Object) paint4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) (short) -1, 0.0d, rectangleAnchor16);
        java.awt.Shape shape18 = null;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D17, shape18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str21 = color20.toString();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D17, (java.awt.Paint) color20, stroke22, (java.awt.Paint) color23);
        textTitle3.setBounds(rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.TOP;
        double double27 = numberAxis0.lengthToJava2D((double) 10L, rectangle2D17, rectangleEdge26);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = numberAxis0.getTickUnit();
        java.lang.String str30 = numberTickUnit28.valueToString(109.0d);
        java.lang.String str31 = numberTickUnit28.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "109" + "'", str30.equals("109"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "[size=1]" + "'", str31.equals("[size=1]"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean27 = textTitle25.equals((java.lang.Object) paint26);
        boolean boolean28 = textTitle25.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (short) -1, 0.0d, rectangleAnchor38);
        java.awt.Shape shape40 = null;
        boolean boolean41 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D39, shape40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str43 = color42.toString();
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D39, (java.awt.Paint) color42, stroke44, (java.awt.Paint) color45);
        textTitle25.setBounds(rectangle2D39);
        java.awt.geom.AffineTransform affineTransform48 = null;
        java.awt.RenderingHints renderingHints49 = null;
        java.awt.PaintContext paintContext50 = color17.createContext(colorModel22, rectangle23, rectangle2D39, affineTransform48, renderingHints49);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str43.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paintContext50);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = categoryItemRendererState1.getInfo();
        double double3 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.entity.EntityCollection entityCollection4 = categoryItemRendererState1.getEntityCollection();
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(entityCollection4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        java.awt.Font font30 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color31, (float) 1L, textMeasurer33);
        org.jfree.chart.text.TextLine textLine35 = textBlock34.getLastLine();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock34.draw(graphics2D36, (float) 100, (float) (byte) 1, textBlockAnchor39, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock34.setLineAlignment(horizontalAlignment44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) (short) -1, 0.0d, rectangleAnchor53);
        plotRenderingInfo47.setDataArea(rectangle2D54);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D54, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58);
        boolean boolean63 = horizontalAlignment44.equals((java.lang.Object) defaultStatisticalCategoryDataset58);
        java.util.List list64 = defaultStatisticalCategoryDataset58.getColumnKeys();
        java.lang.Comparable comparable65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset58, comparable65);
        legendItemBlockContainer66.setMargin(3.0d, (double) 10L, Double.NaN, (double) (short) 100);
        legendItemBlockContainer66.setURLText("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNull(textLine35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(list64);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        boolean boolean75 = categoryPlot69.isDomainGridlinesVisible();
        org.jfree.chart.plot.Marker marker76 = null;
        try {
            categoryPlot69.addRangeMarker(marker76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, paint7);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList14 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, (double) (short) -1, 0.0d, rectangleAnchor25);
        java.awt.Shape shape27 = null;
        boolean boolean28 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D26, shape27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str30 = color29.toString();
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D26, (java.awt.Paint) color29, stroke31, (java.awt.Paint) color32);
        objectList14.set((int) '4', (java.lang.Object) color29);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape6, stroke13, (java.awt.Paint) color29);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray43 = new float[] { (short) 0, (byte) -1, (short) -1 };
        float[] floatArray44 = color39.getRGBColorComponents(floatArray43);
        float[] floatArray45 = java.awt.Color.RGBtoHSB((int) (byte) 100, 15, 10, floatArray43);
        float[] floatArray46 = color29.getColorComponents(floatArray43);
        int int47 = color29.getGreen();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str30.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 255 + "'", int47 == 255);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getItemLabelGenerator((int) ' ', (int) (byte) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Color color0 = java.awt.Color.PINK;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 175 + "'", int1 == 175);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        boolean boolean61 = numberAxis41.isPositiveArrowVisible();
        java.lang.String str62 = numberAxis41.getLabelToolTip();
        numberAxis41.setLabelAngle(164483.00980392157d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(str62);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer1.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer1.setBaseSeriesVisible(false);
        boolean boolean13 = sortOrder0.equals((java.lang.Object) barRenderer1);
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine();
        boolean boolean15 = sortOrder0.equals((java.lang.Object) textLine14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = textLine14.calculateDimensions(graphics2D16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine14.getFirstTextFragment();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNull(textFragment18);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        java.util.List list15 = textBlock5.getLines();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Font font21 = null;
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer24 = null;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font21, (java.awt.Paint) color22, (float) 1L, textMeasurer24);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick29 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) '4', textBlock25, textBlockAnchor26, textAnchor27, 0.0d);
        java.awt.Shape shape33 = textBlock5.calculateBounds(graphics2D16, 0.0f, 0.0f, textBlockAnchor26, (float) 10, (float) (short) 100, (double) 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.lang.Object obj8 = barRenderer0.clone();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color10 = java.awt.Color.red;
        boolean boolean11 = blockContainer9.equals((java.lang.Object) color10);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color10);
        java.awt.Font font14 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color15, (float) 1L, textMeasurer17);
        org.jfree.chart.text.TextLine textLine19 = textBlock18.getLastLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock18.draw(graphics2D20, (float) 100, (float) (byte) 1, textBlockAnchor23, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock18.setLineAlignment(horizontalAlignment28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (short) -1, 0.0d, rectangleAnchor37);
        plotRenderingInfo31.setDataArea(rectangle2D38);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D38, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42);
        boolean boolean47 = horizontalAlignment28.equals((java.lang.Object) defaultStatisticalCategoryDataset42);
        org.jfree.data.general.DatasetGroup datasetGroup48 = defaultStatisticalCategoryDataset42.getGroup();
        org.jfree.data.Range range50 = defaultStatisticalCategoryDataset42.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean55 = numberAxis54.isPositiveArrowVisible();
        numberAxis54.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = null;
        numberAxis54.setMarkerBand(markerAxisBand59);
        double double61 = numberAxis54.getUpperBound();
        java.text.NumberFormat numberFormat62 = numberAxis54.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        barRenderer63.setGradientPaintTransformer(gradientPaintTransformer64);
        barRenderer63.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator69 = barRenderer63.getLegendItemToolTipGenerator();
        boolean boolean72 = barRenderer63.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer63);
        boolean boolean74 = categoryPlot73.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot73.setDomainAxisLocation(4, axisLocation76);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot73);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer80 = categoryPlot73.getRenderer((int) (short) 100);
        categoryPlot73.clearDomainMarkers((-655360));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNull(textLine19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(datasetGroup48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertNull(numberFormat62);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNull(categoryItemRenderer80);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("AxisLocation.TOP_OR_RIGHT", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        boolean boolean75 = categoryPlot69.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis76 = categoryPlot69.getRangeAxis();
        categoryPlot69.clearDomainMarkers();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(valueAxis76);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition1.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic4.getShapeLocation();
        boolean boolean8 = legendGraphic4.isShapeOutlineVisible();
        legendGraphic4.setLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D18 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, (double) (short) -1, 0.0d, rectangleAnchor21);
        java.awt.Shape shape23 = null;
        boolean boolean24 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D22, shape23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str26 = color25.toString();
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D22, (java.awt.Paint) color25, stroke27, (java.awt.Paint) color28);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D22);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font33 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis32.setLabelFont(font33);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis32.setMarkerBand(markerAxisBand35);
        double double37 = numberAxis32.getLowerMargin();
        org.jfree.data.Range range38 = numberAxis32.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font41 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis40.setLabelFont(font41);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = null;
        numberAxis40.setMarkerBand(markerAxisBand43);
        double double45 = numberAxis40.getLowerMargin();
        org.jfree.data.Range range46 = numberAxis40.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font49 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis48.setLabelFont(font49);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = null;
        numberAxis48.setMarkerBand(markerAxisBand51);
        double double53 = numberAxis48.getLowerMargin();
        org.jfree.data.Range range54 = numberAxis48.getDefaultAutoRange();
        org.jfree.data.Range range55 = org.jfree.data.Range.combine(range46, range54);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range55, (-1.0d));
        org.jfree.data.Range range58 = org.jfree.data.Range.combine(range38, range55);
        try {
            java.lang.Object obj59 = legendGraphic4.draw(graphics2D11, rectangle2D22, (java.lang.Object) range55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str26.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(range58);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        java.awt.Stroke stroke62 = null;
        categoryPlot60.setOutlineStroke(stroke62);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = categoryPlot60.getRenderer();
        categoryPlot60.clearRangeAxes();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryItemRenderer64);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle11.getHorizontalAlignment();
        java.awt.Font font15 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        legendTitle11.setItemFont(font15);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setLabel("");
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font3 = textTitle2.getFont();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint11 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape10, paint11);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) (short) -1, 0.0d, rectangleAnchor29);
        java.awt.Shape shape31 = null;
        boolean boolean32 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D30, shape31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str34 = color33.toString();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D30, (java.awt.Paint) color33, stroke35, (java.awt.Paint) color36);
        objectList18.set((int) '4', (java.lang.Object) color33);
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape10, stroke17, (java.awt.Paint) color33);
        java.text.AttributedString attributedString40 = legendItem39.getAttributedLabel();
        java.awt.Paint paint41 = legendItem39.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("1", font3, paint41);
        java.awt.Font font43 = textFragment42.getFont();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D46, (float) (byte) 10, (float) 0, textAnchor49, (double) (byte) -1, (float) (short) 10, (float) 255);
        try {
            float float54 = textFragment42.calculateBaselineOffset(graphics2D44, textAnchor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str34.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(attributedString40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(textAnchor49);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        categoryAxis62.setLowerMargin((double) 0L);
        categoryAxis62.setCategoryLabelPositionOffset((int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer65 = null;
        barRenderer64.setGradientPaintTransformer(gradientPaintTransformer65);
        barRenderer64.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator70 = barRenderer64.getLegendItemToolTipGenerator();
        boolean boolean73 = barRenderer64.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int74 = barRenderer64.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer64);
        java.lang.Object obj76 = legendTitle75.clone();
        java.awt.Paint paint77 = legendTitle75.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment78 = legendTitle75.getHorizontalAlignment();
        jFreeChart63.addLegend(legendTitle75);
        boolean boolean80 = jFreeChart63.isBorderVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNull(paint77);
        org.junit.Assert.assertNotNull(horizontalAlignment78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = jFreeChart63.getCategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer65 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer66 = null;
        barRenderer65.setGradientPaintTransformer(gradientPaintTransformer66);
        java.awt.Stroke stroke68 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer65.setBaseOutlineStroke(stroke68);
        categoryPlot64.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer65);
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = null;
        org.jfree.chart.util.Layer layer72 = null;
        try {
            categoryPlot64.addDomainMarker(categoryMarker71, layer72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(categoryPlot64);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis9.setLabelFont(font10);
        numberAxis1.setTickLabelFont(font10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem8 = legendItemCollection6.get((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer12.setBaseOutlineStroke(stroke15);
        java.awt.Shape shape19 = barRenderer12.getItemShape(0, 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, rectangleAnchor20, (double) (-1), (double) (-1L));
        numberAxis1.setRightArrow(shape23);
        java.awt.Font font25 = numberAxis1.getTickLabelFont();
        numberAxis1.setUpperMargin((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = numberAxis1.getMarkerBand();
        boolean boolean29 = numberAxis1.isVisible();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = blockBorder34.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis36.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj39 = categoryAxis36.clone();
        boolean boolean40 = rectangleInsets35.equals((java.lang.Object) categoryAxis36);
        double double42 = rectangleInsets35.extendHeight((double) (-1L));
        org.jfree.chart.util.Size2D size2D49 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, (double) (short) -1, 0.0d, rectangleAnchor52);
        java.awt.Shape shape54 = null;
        boolean boolean55 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D53, shape54);
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str57 = color56.toString();
        java.awt.Stroke stroke58 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D53, (java.awt.Paint) color56, stroke58, (java.awt.Paint) color59);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity61 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D53);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str63 = lengthAdjustmentType62.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets35.createAdjustedRectangle(rectangle2D53, lengthAdjustmentType62, lengthAdjustmentType64);
        java.awt.geom.Point2D point2D66 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) (short) 100, rectangle2D65);
        org.jfree.chart.axis.AxisSpace axisSpace67 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace68 = new org.jfree.chart.axis.AxisSpace();
        axisSpace67.ensureAtLeast(axisSpace68);
        double double70 = axisSpace68.getRight();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace68.add((double) (short) -1, rectangleEdge72);
        double double74 = numberAxis1.java2DToValue((double) (-16777216), rectangle2D65, rectangleEdge72);
        numberAxis1.setLabel("1");
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(markerAxisBand28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str57.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(lengthAdjustmentType62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "CONTRACT" + "'", str63.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(point2D66);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 164483.00980392157d + "'", double74 == 164483.00980392157d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.lang.Object obj8 = barRenderer0.clone();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color10 = java.awt.Color.red;
        boolean boolean11 = blockContainer9.equals((java.lang.Object) color10);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color10);
        java.awt.Font font14 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color15, (float) 1L, textMeasurer17);
        org.jfree.chart.text.TextLine textLine19 = textBlock18.getLastLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock18.draw(graphics2D20, (float) 100, (float) (byte) 1, textBlockAnchor23, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock18.setLineAlignment(horizontalAlignment28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (short) -1, 0.0d, rectangleAnchor37);
        plotRenderingInfo31.setDataArea(rectangle2D38);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D38, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42);
        boolean boolean47 = horizontalAlignment28.equals((java.lang.Object) defaultStatisticalCategoryDataset42);
        org.jfree.data.general.DatasetGroup datasetGroup48 = defaultStatisticalCategoryDataset42.getGroup();
        org.jfree.data.Range range50 = defaultStatisticalCategoryDataset42.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean55 = numberAxis54.isPositiveArrowVisible();
        numberAxis54.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = null;
        numberAxis54.setMarkerBand(markerAxisBand59);
        double double61 = numberAxis54.getUpperBound();
        java.text.NumberFormat numberFormat62 = numberAxis54.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        barRenderer63.setGradientPaintTransformer(gradientPaintTransformer64);
        barRenderer63.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator69 = barRenderer63.getLegendItemToolTipGenerator();
        boolean boolean72 = barRenderer63.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer63);
        boolean boolean74 = categoryPlot73.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot73.setDomainAxisLocation(4, axisLocation76);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot73);
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str80 = axisLocation79.toString();
        categoryPlot73.setRangeAxisLocation(axisLocation79);
        org.jfree.chart.plot.Marker marker82 = null;
        org.jfree.chart.util.Layer layer83 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot73.addRangeMarker(marker82, layer83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNull(textLine19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(datasetGroup48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertNull(numberFormat62);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str80.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(layer83);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 15, 10.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition(175, itemLabelPosition9, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis1.setLabelFont(font2);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        double double6 = numberAxis1.getLowerMargin();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis9.setLabelFont(font10);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis9.setMarkerBand(markerAxisBand12);
        double double14 = numberAxis9.getLowerMargin();
        org.jfree.data.Range range15 = numberAxis9.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis17.setLabelFont(font18);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis17.setMarkerBand(markerAxisBand20);
        double double22 = numberAxis17.getLowerMargin();
        org.jfree.data.Range range23 = numberAxis17.getDefaultAutoRange();
        org.jfree.data.Range range24 = org.jfree.data.Range.combine(range15, range23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, (-1.0d));
        org.jfree.data.Range range27 = org.jfree.data.Range.combine(range7, range24);
        double double28 = range24.getLength();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color1 = java.awt.Color.red;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) color1);
        int int3 = color1.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-65536) + "'", int3 == (-65536));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        java.awt.Font font30 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color31, (float) 1L, textMeasurer33);
        org.jfree.chart.text.TextLine textLine35 = textBlock34.getLastLine();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock34.draw(graphics2D36, (float) 100, (float) (byte) 1, textBlockAnchor39, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock34.setLineAlignment(horizontalAlignment44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) (short) -1, 0.0d, rectangleAnchor53);
        plotRenderingInfo47.setDataArea(rectangle2D54);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D54, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58);
        boolean boolean63 = horizontalAlignment44.equals((java.lang.Object) defaultStatisticalCategoryDataset58);
        java.util.List list64 = defaultStatisticalCategoryDataset58.getColumnKeys();
        java.lang.Comparable comparable65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset58, comparable65);
        legendItemBlockContainer66.setMargin(3.0d, (double) 10L, Double.NaN, (double) (short) 100);
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer73 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator76 = barRenderer73.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean78 = barRenderer73.equals((java.lang.Object) (-1.0d));
        int int79 = barRenderer73.getRowCount();
        boolean boolean80 = barRenderer73.getBaseSeriesVisible();
        barRenderer73.setSeriesVisible(3, (java.lang.Boolean) true, false);
        org.jfree.chart.title.TextTitle textTitle87 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint88 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean89 = textTitle87.equals((java.lang.Object) paint88);
        boolean boolean90 = textTitle87.getExpandToFitSpace();
        java.lang.Object obj91 = textTitle87.clone();
        java.awt.geom.Rectangle2D rectangle2D92 = textTitle87.getBounds();
        barRenderer73.setSeriesShape(0, (java.awt.Shape) rectangle2D92);
        java.awt.Color color96 = java.awt.Color.getColor("ClassContext", 255);
        try {
            java.lang.Object obj97 = legendItemBlockContainer66.draw(graphics2D72, rectangle2D92, (java.lang.Object) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNull(textLine35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNull(categoryURLGenerator76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(rectangle2D92);
        org.junit.Assert.assertNotNull(color96);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 15);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean5 = textTitle3.equals((java.lang.Object) paint4);
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) (short) -1, 0.0d, rectangleAnchor16);
        java.awt.Shape shape18 = null;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D17, shape18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str21 = color20.toString();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D17, (java.awt.Paint) color20, stroke22, (java.awt.Paint) color23);
        textTitle3.setBounds(rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.TOP;
        double double27 = numberAxis0.lengthToJava2D((double) 10L, rectangle2D17, rectangleEdge26);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = numberAxis0.getTickUnit();
        org.jfree.data.RangeType rangeType29 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = numberAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertNotNull(rangeType29);
        org.junit.Assert.assertNotNull(numberTickUnit30);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        java.awt.Paint paint15 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        barRenderer0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color17, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        barRenderer0.setSeriesURLGenerator((int) (byte) 10, categoryURLGenerator21, true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint28 = barRenderer26.lookupSeriesPaint(0);
        java.awt.Paint paint30 = barRenderer26.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj31 = barRenderer26.clone();
        java.awt.Paint paint33 = barRenderer26.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = barRenderer26.getLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean37 = numberAxis36.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat38 = numberAxis36.getNumberFormatOverride();
        numberAxis36.setInverted(true);
        boolean boolean41 = legendItemCollection34.equals((java.lang.Object) numberAxis36);
        numberAxis36.setLabelAngle((double) ' ');
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font47 = textTitle46.getFont();
        org.jfree.chart.event.TitleChangeListener titleChangeListener48 = null;
        textTitle46.addChangeListener(titleChangeListener48);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis52.setTickLabelInsets(rectangleInsets57);
        java.lang.Object obj59 = numberAxis52.clone();
        numberAxis52.setTickMarkInsideLength(10.0f);
        numberAxis52.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.axis.AxisState axisState65 = null;
        org.jfree.chart.util.Size2D size2D72 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D76 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D72, (double) (short) -1, 0.0d, rectangleAnchor75);
        java.awt.Shape shape77 = null;
        boolean boolean78 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D76, shape77);
        java.awt.Color color79 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str80 = color79.toString();
        java.awt.Stroke stroke81 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color82 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem83 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D76, (java.awt.Paint) color79, stroke81, (java.awt.Paint) color82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = null;
        java.util.List list85 = numberAxis52.refreshTicks(graphics2D64, axisState65, rectangle2D76, rectangleEdge84);
        textTitle46.draw(graphics2D50, rectangle2D76);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity89 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 96.0d, (java.awt.Shape) rectangle2D76, "JFreeChart version java.awt.Color[r=255,g=255,b=64].\njava.awt.Color[r=0,g=0,b=128].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).JFreeChart java.awt.Color[r=255,g=255,b=64] (http://www.jfree.org/jfreechart/index.html).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=255,g=255,b=64]", "{0}");
        barRenderer0.drawRangeGridline(graphics2D24, categoryPlot25, (org.jfree.chart.axis.ValueAxis) numberAxis36, rectangle2D76, (double) (byte) 10);
        double double92 = numberAxis36.getUpperBound();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str80.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(list85);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.0d + "'", double92 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("JFreeChart");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis1.setMarkerBand(markerAxisBand11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.jfree.chart.axis.Axis axis14 = axisChangeEvent13.getAxis();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(axis14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.Plot plot2 = numberAxis1.getPlot();
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(64, (-14336));
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) '#', categoryItemLabelGenerator4, false);
        java.awt.Font font7 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (short) -1, 0.0d, rectangleAnchor13);
        java.awt.Shape shape15 = null;
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D14, shape15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str18 = color17.toString();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D14, (java.awt.Paint) color17, stroke19, (java.awt.Paint) color20);
        objectList2.set((int) '4', (java.lang.Object) color17);
        java.lang.String str23 = color17.toString();
        try {
            paintList0.setPaint((-655360), (java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str23.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) 'a');
        java.awt.Stroke stroke12 = barRenderer0.getItemOutlineStroke((int) (short) 0, (int) ' ');
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double3 = rectangleInsets1.calculateLeftOutset(10.0d);
        double double5 = rectangleInsets1.calculateLeftInset(0.0d);
        boolean boolean6 = datasetRenderingOrder0.equals((java.lang.Object) 0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer7.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        barRenderer7.setBaseURLGenerator(categoryURLGenerator11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = barRenderer7.getToolTipGenerator((int) (short) 0, (int) 'a');
        boolean boolean17 = datasetRenderingOrder0.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = legendTitle11.getSources();
        org.jfree.chart.block.BlockContainer blockContainer25 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = barRenderer26.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = null;
        barRenderer26.setBaseURLGenerator(categoryURLGenerator30, true);
        barRenderer26.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation35 = null;
        boolean boolean36 = barRenderer26.removeAnnotation(categoryAnnotation35);
        org.jfree.chart.block.BorderArrangement borderArrangement37 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment38, verticalAlignment39, 100.0d, (double) (-1));
        java.awt.Image image46 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo50 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image46, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo50.setName("CONTRACT");
        boolean boolean53 = flowArrangement42.equals((java.lang.Object) projectInfo50);
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer26, (org.jfree.chart.block.Arrangement) borderArrangement37, (org.jfree.chart.block.Arrangement) flowArrangement42);
        blockContainer25.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement42);
        legendTitle11.setWrapper(blockContainer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = legendTitle11.getLegendItemGraphicEdge();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertNull(categoryURLGenerator29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        barRenderer0.setBaseItemLabelFont(font11);
        boolean boolean17 = barRenderer0.isItemLabelVisible(0, 0);
        barRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        double double3 = axisSpace1.getRight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace1.add((double) (short) -1, rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace1.add((double) (short) 10, rectangleEdge8);
        double double10 = axisSpace1.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        axisSpace11.ensureAtLeast(axisSpace12);
        double double14 = axisSpace12.getLeft();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        boolean boolean16 = axisSpace12.equals((java.lang.Object) paint15);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range17, range18);
        org.jfree.data.Range range20 = rectangleConstraint19.getHeightRange();
        java.lang.String str21 = rectangleConstraint19.toString();
        boolean boolean22 = axisSpace12.equals((java.lang.Object) rectangleConstraint19);
        axisSpace1.ensureAtLeast(axisSpace12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str21.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        barRenderer0.setAutoPopulateSeriesShape(false);
        java.awt.Stroke stroke8 = barRenderer0.getBaseStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        barRenderer11.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer11.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = barRenderer11.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        barRenderer23.setGradientPaintTransformer(gradientPaintTransformer24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer23.setBaseOutlineStroke(stroke26);
        barRenderer23.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint34 = barRenderer32.lookupSeriesPaint(0);
        barRenderer32.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer32.getBaseNegativeItemLabelPosition();
        barRenderer23.setSeriesNegativeItemLabelPosition(100, itemLabelPosition38, false);
        barRenderer11.setSeriesPositiveItemLabelPosition(1, itemLabelPosition38);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition38);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator43 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator43, false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        categoryPlot69.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis76.setTickLabelInsets(rectangleInsets81);
        java.lang.Object obj83 = numberAxis76.clone();
        org.jfree.chart.plot.Plot plot84 = null;
        numberAxis76.setPlot(plot84);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand86 = null;
        numberAxis76.setMarkerBand(markerAxisBand86);
        numberAxis76.setLabelToolTip("ClassContext");
        categoryPlot69.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis76);
        categoryPlot69.setRangeGridlinesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent93 = null;
        categoryPlot69.rendererChanged(rendererChangeEvent93);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj83);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.configure();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        int int2 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        java.lang.Object obj22 = legendGraphic4.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendGraphic4.getShapeAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor23, textBlockAnchor24, categoryLabelWidthType25, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot60.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D10);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) 'a');
        legendItemEntity18.setToolTipText("ClassContext");
        org.jfree.data.general.Dataset dataset23 = legendItemEntity18.getDataset();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(dataset23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        java.util.List list35 = defaultStatisticalCategoryDataset29.getColumnKeys();
        defaultStatisticalCategoryDataset29.add((double) (byte) 10, (double) (byte) -1, (java.lang.Comparable) (-100.0d), (java.lang.Comparable) 1.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.lang.Object obj8 = barRenderer0.clone();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color10 = java.awt.Color.red;
        boolean boolean11 = blockContainer9.equals((java.lang.Object) color10);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color10);
        java.awt.Font font14 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color15, (float) 1L, textMeasurer17);
        org.jfree.chart.text.TextLine textLine19 = textBlock18.getLastLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock18.draw(graphics2D20, (float) 100, (float) (byte) 1, textBlockAnchor23, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock18.setLineAlignment(horizontalAlignment28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (short) -1, 0.0d, rectangleAnchor37);
        plotRenderingInfo31.setDataArea(rectangle2D38);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D38, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42);
        boolean boolean47 = horizontalAlignment28.equals((java.lang.Object) defaultStatisticalCategoryDataset42);
        org.jfree.data.general.DatasetGroup datasetGroup48 = defaultStatisticalCategoryDataset42.getGroup();
        org.jfree.data.Range range50 = defaultStatisticalCategoryDataset42.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean55 = numberAxis54.isPositiveArrowVisible();
        numberAxis54.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = null;
        numberAxis54.setMarkerBand(markerAxisBand59);
        double double61 = numberAxis54.getUpperBound();
        java.text.NumberFormat numberFormat62 = numberAxis54.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        barRenderer63.setGradientPaintTransformer(gradientPaintTransformer64);
        barRenderer63.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator69 = barRenderer63.getLegendItemToolTipGenerator();
        boolean boolean72 = barRenderer63.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer63);
        boolean boolean74 = categoryPlot73.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot73.setDomainAxisLocation(4, axisLocation76);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot73);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer80 = categoryPlot73.getRenderer((int) (short) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = categoryPlot73.getDomainAxisEdge((-1));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNull(textLine19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(datasetGroup48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertNull(numberFormat62);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNull(categoryItemRenderer80);
        org.junit.Assert.assertNotNull(rectangleEdge82);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis1.setMarkerBand(markerAxisBand11);
        numberAxis1.setUpperBound(10.0d);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        double double11 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.String str18 = legendItem17.getURLText();
        boolean boolean19 = legendItem17.isLineVisible();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ClassContext" + "'", str18.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = jFreeChart63.getCategoryPlot();
        categoryPlot64.clearDomainMarkers();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(categoryPlot64);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Font font2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color3, (float) 1L, textMeasurer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray11 = new float[] { (short) 0, (byte) -1, (short) -1 };
        float[] floatArray12 = color7.getRGBColorComponents(floatArray11);
        float[] floatArray13 = color3.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color0.getRGBColorComponents(floatArray12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Font font17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color18, (float) 1L, textMeasurer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray26 = new float[] { (short) 0, (byte) -1, (short) -1 };
        float[] floatArray27 = color22.getRGBColorComponents(floatArray26);
        float[] floatArray28 = color18.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color15.getRGBColorComponents(floatArray27);
        float[] floatArray30 = color0.getRGBColorComponents(floatArray27);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition7);
        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setMinimumBarLength((double) (-16777216));
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        java.awt.Shape shape7 = barRenderer0.getItemShape(0, 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (-1), (double) (-1L));
        java.awt.Paint paint12 = null;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean3 = textTitle1.equals((java.lang.Object) paint2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.lang.Object obj5 = textTitle1.clone();
        textTitle1.setNotify(false);
        textTitle1.setID("TextAnchor.CENTER_RIGHT");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        int int6 = barRenderer0.getRowCount();
        java.awt.Paint paint7 = barRenderer0.getBaseFillPaint();
        java.awt.Paint paint9 = null;
        try {
            barRenderer0.setSeriesOutlinePaint((-14336), paint9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle11.setVerticalAlignment(verticalAlignment13);
        java.awt.Font font15 = legendTitle11.getItemFont();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        int int2 = keyedObjects2D0.getRowCount();
        java.lang.Comparable comparable3 = null;
        keyedObjects2D0.removeColumn(comparable3);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer1.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer1.setBaseSeriesVisible(false);
        boolean boolean13 = sortOrder0.equals((java.lang.Object) barRenderer1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer1.getBaseItemLabelGenerator();
        boolean boolean15 = barRenderer1.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (short) 10);
        java.lang.String str6 = rectangleConstraint5.toString();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]" + "'", str6.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image3, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo7.setInfo("CONTRACT");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        barRenderer0.setBaseItemLabelFont(font11);
        boolean boolean17 = barRenderer0.isItemLabelVisible(0, 0);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 1, (java.lang.Boolean) false, true);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint22);
        barRenderer0.setSeriesItemLabelsVisible(2, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.String str18 = legendItem17.getURLText();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint22 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape21, paint22);
        legendGraphic23.setShapeOutlineVisible(false);
        legendGraphic23.setLineVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer28 = legendGraphic23.getFillPaintTransformer();
        legendItem17.setFillPaintTransformer(gradientPaintTransformer28);
        int int30 = legendItem17.getSeriesIndex();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ClassContext" + "'", str18.equals("ClassContext"));
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(gradientPaintTransformer28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.lang.Boolean boolean7 = barRenderer0.getSeriesCreateEntities((int) 'a');
        java.awt.Paint paint8 = barRenderer0.getBasePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        barRenderer9.setGradientPaintTransformer(gradientPaintTransformer10);
        barRenderer9.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = barRenderer9.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint18 = barRenderer16.lookupSeriesPaint(0);
        java.awt.Font font20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer16.setSeriesItemLabelFont(1, font20, false);
        boolean boolean23 = barRenderer16.getIncludeBaseInRange();
        boolean boolean24 = barRenderer16.getAutoPopulateSeriesStroke();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer16.setBaseOutlinePaint((java.awt.Paint) color25);
        java.awt.Paint paint27 = barRenderer16.getBaseItemLabelPaint();
        boolean boolean28 = legendItemCollection15.equals((java.lang.Object) barRenderer16);
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (short) -1, 0.0d, rectangleAnchor38);
        java.awt.Shape shape40 = null;
        boolean boolean41 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D39, shape40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str43 = color42.toString();
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D39, (java.awt.Paint) color42, stroke44, (java.awt.Paint) color45);
        java.lang.Comparable comparable47 = legendItem46.getSeriesKey();
        boolean boolean48 = legendItem46.isLineVisible();
        java.lang.String str49 = legendItem46.getToolTipText();
        java.awt.Stroke stroke50 = legendItem46.getLineStroke();
        boolean boolean51 = barRenderer16.equals((java.lang.Object) stroke50);
        barRenderer0.setBaseStroke(stroke50, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str43.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(comparable47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        boolean boolean14 = barRenderer7.getIncludeBaseInRange();
        boolean boolean15 = barRenderer7.getAutoPopulateSeriesStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer7.setBaseOutlinePaint((java.awt.Paint) color16);
        java.awt.Paint paint18 = barRenderer7.getBaseItemLabelPaint();
        boolean boolean19 = legendItemCollection6.equals((java.lang.Object) barRenderer7);
        double double20 = barRenderer7.getLowerClip();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = barRenderer7.getToolTipGenerator((int) (short) -1, (int) ' ');
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean9 = textTitle7.equals((java.lang.Object) paint8);
        boolean boolean10 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, (double) (short) -1, 0.0d, rectangleAnchor20);
        java.awt.Shape shape22 = null;
        boolean boolean23 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D21, shape22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str25 = color24.toString();
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D21, (java.awt.Paint) color24, stroke26, (java.awt.Paint) color27);
        textTitle7.setBounds(rectangle2D21);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.TOP;
        double double31 = numberAxis4.lengthToJava2D((double) 10L, rectangle2D21, rectangleEdge30);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = numberAxis4.getTickUnit();
        java.lang.String str33 = numberTickUnit32.toString();
        try {
            org.jfree.data.xy.XYDataset xYDataset34 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) -1, 0.0d, 175, (java.lang.Comparable) str33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str25.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
        org.junit.Assert.assertNotNull(numberTickUnit32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "[size=1]" + "'", str33.equals("[size=1]"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj66 = textTitle65.clone();
        org.jfree.chart.event.TitleChangeListener titleChangeListener67 = null;
        textTitle65.addChangeListener(titleChangeListener67);
        jFreeChart63.addSubtitle((org.jfree.chart.title.Title) textTitle65);
        jFreeChart63.setTextAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo75 = null;
        java.awt.image.BufferedImage bufferedImage76 = jFreeChart63.createBufferedImage((int) '4', 255, 10, chartRenderingInfo75);
        java.awt.Paint paint77 = jFreeChart63.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(obj66);
        org.junit.Assert.assertNotNull(bufferedImage76);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.lang.String str8 = numberAxis1.getLabelToolTip();
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Font font11 = numberAxis1.getLabelFont();
        double double12 = numberAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0E-8d + "'", double12 == 1.0E-8d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RangeType.NEGATIVE");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Locale locale4 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration5 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(locale4);
        org.junit.Assert.assertNotNull(strEnumeration5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        legendGraphic4.setLineVisible(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendGraphic4.getShapeAnchor();
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) (short) -1, 0.0d, rectangleAnchor19);
        java.awt.Shape shape21 = null;
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D20, shape21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str24 = color23.toString();
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D20, (java.awt.Paint) color23, stroke25, (java.awt.Paint) color26);
        int int28 = legendItem27.getDatasetIndex();
        int int29 = legendItem27.getSeriesIndex();
        java.awt.Stroke stroke30 = legendItem27.getLineStroke();
        java.awt.Shape shape31 = legendItem27.getLine();
        legendGraphic4.setShape(shape31);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str24.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        double double3 = axisSpace1.getLeft();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        boolean boolean5 = axisSpace1.equals((java.lang.Object) paint4);
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, range7);
        org.jfree.data.Range range9 = rectangleConstraint8.getHeightRange();
        java.lang.String str10 = rectangleConstraint8.toString();
        boolean boolean11 = axisSpace1.equals((java.lang.Object) rectangleConstraint8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis14.setTickLabelInsets(rectangleInsets19);
        java.lang.Object obj21 = numberAxis14.clone();
        numberAxis14.setTickMarkInsideLength(10.0f);
        numberAxis14.setFixedAutoRange((double) '4');
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (short) -1, 0.0d, rectangleAnchor37);
        java.awt.Shape shape39 = null;
        boolean boolean40 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D38, shape39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str42 = color41.toString();
        java.awt.Stroke stroke43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D38, (java.awt.Paint) color41, stroke43, (java.awt.Paint) color44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        java.util.List list47 = numberAxis14.refreshTicks(graphics2D26, axisState27, rectangle2D38, rectangleEdge46);
        try {
            java.awt.geom.Rectangle2D rectangle2D48 = axisSpace1.expand(rectangle2D12, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str10.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str42.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(list47);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis1.setLabelFont(font2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.Paint paint5 = numberAxis1.getTickLabelPaint();
        numberAxis1.setLowerBound((-2.0d));
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryItemEntity15.getDataset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint19 = barRenderer17.lookupSeriesPaint(0);
        java.awt.Paint paint21 = barRenderer17.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj22 = barRenderer17.clone();
        java.lang.Boolean boolean24 = barRenderer17.getSeriesCreateEntities((int) 'a');
        java.awt.Paint paint25 = barRenderer17.getBasePaint();
        boolean boolean26 = categoryItemEntity15.equals((java.lang.Object) paint25);
        java.lang.Comparable comparable27 = categoryItemEntity15.getRowKey();
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + ' ' + "'", comparable27.equals(' '));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer0.getSeriesToolTipGenerator((int) '4');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator12);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition7);
        double double9 = barRenderer0.getMinimumBarLength();
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint15 = barRenderer13.lookupSeriesPaint(0);
        java.awt.Paint paint17 = barRenderer13.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj18 = barRenderer13.clone();
        java.awt.Paint paint20 = barRenderer13.lookupSeriesPaint((int) (short) -1);
        java.lang.Object obj21 = barRenderer13.clone();
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color23 = java.awt.Color.red;
        boolean boolean24 = blockContainer22.equals((java.lang.Object) color23);
        barRenderer13.setBaseOutlinePaint((java.awt.Paint) color23);
        java.awt.Font font27 = null;
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color28, (float) 1L, textMeasurer30);
        org.jfree.chart.text.TextLine textLine32 = textBlock31.getLastLine();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor36 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock31.draw(graphics2D33, (float) 100, (float) (byte) 1, textBlockAnchor36, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock31.setLineAlignment(horizontalAlignment41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        org.jfree.chart.util.Size2D size2D47 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D51 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, (double) (short) -1, 0.0d, rectangleAnchor50);
        plotRenderingInfo44.setDataArea(rectangle2D51);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset55 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D51, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset55, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset55);
        boolean boolean60 = horizontalAlignment41.equals((java.lang.Object) defaultStatisticalCategoryDataset55);
        org.jfree.data.general.DatasetGroup datasetGroup61 = defaultStatisticalCategoryDataset55.getGroup();
        org.jfree.data.Range range63 = defaultStatisticalCategoryDataset55.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean68 = numberAxis67.isPositiveArrowVisible();
        numberAxis67.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand72 = null;
        numberAxis67.setMarkerBand(markerAxisBand72);
        double double74 = numberAxis67.getUpperBound();
        java.text.NumberFormat numberFormat75 = numberAxis67.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer76 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer77 = null;
        barRenderer76.setGradientPaintTransformer(gradientPaintTransformer77);
        barRenderer76.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator82 = barRenderer76.getLegendItemToolTipGenerator();
        boolean boolean85 = barRenderer76.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot86 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset55, categoryAxis65, (org.jfree.chart.axis.ValueAxis) numberAxis67, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer76);
        boolean boolean87 = categoryPlot86.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation89 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot86.setDomainAxisLocation(4, axisLocation89);
        barRenderer13.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot86);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer93 = categoryPlot86.getRenderer((int) (short) 100);
        java.awt.Stroke stroke94 = categoryPlot86.getOutlineStroke();
        barRenderer0.setSeriesOutlineStroke(0, stroke94, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNull(textLine32);
        org.junit.Assert.assertNotNull(textBlockAnchor36);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(datasetGroup61);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.0d + "'", double74 == 10.0d);
        org.junit.Assert.assertNull(numberFormat75);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator82);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(axisLocation89);
        org.junit.Assert.assertNull(categoryItemRenderer93);
        org.junit.Assert.assertNotNull(stroke94);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
//        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (short) -1, 0.0d, rectangleAnchor11);
//        java.awt.Shape shape13 = null;
//        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D12, shape13);
//        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
//        java.lang.String str16 = color15.toString();
//        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
//        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D12, (java.awt.Paint) color15, stroke17, (java.awt.Paint) color18);
//        objectList0.set((int) '4', (java.lang.Object) color15);
//        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.END;
//        boolean boolean22 = objectList0.equals((java.lang.Object) categoryAnchor21);
//        org.jfree.chart.ui.ProjectInfo projectInfo23 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo24 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo23.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo24);
//        java.lang.String str26 = projectInfo24.getVersion();
//        java.lang.String str27 = projectInfo24.getInfo();
//        boolean boolean28 = categoryAnchor21.equals((java.lang.Object) projectInfo24);
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo33 = new org.jfree.chart.ui.BasicProjectInfo("", "rect", "UnitType.ABSOLUTE", "");
//        projectInfo24.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo33);
//        org.junit.Assert.assertNotNull(rectangleAnchor11);
//        org.junit.Assert.assertNotNull(rectangle2D12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(color15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str16.equals("java.awt.Color[r=255,g=255,b=64]"));
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(categoryAnchor21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(projectInfo23);
//        org.junit.Assert.assertNotNull(projectInfo24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{0}" + "'", str26.equals("{0}"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str27.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        int int11 = color9.getTransparency();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str5 = color4.toString();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=255,b=64]", font2, (java.awt.Paint) color4, (float) (-14336));
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        barRenderer9.setGradientPaintTransformer(gradientPaintTransformer10);
        barRenderer9.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer9.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer9.setBaseSeriesVisible(false);
        boolean boolean21 = sortOrder8.equals((java.lang.Object) barRenderer9);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine();
        boolean boolean23 = sortOrder8.equals((java.lang.Object) textLine22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = textLine22.calculateDimensions(graphics2D24);
        boolean boolean26 = textFragment7.equals((java.lang.Object) graphics2D24);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str5.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryItemEntity15.getDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        java.util.List list35 = defaultStatisticalCategoryDataset29.getColumnKeys();
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, true);
        java.util.List list38 = defaultStatisticalCategoryDataset29.getRowKeys();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot60.removeChangeListener(plotChangeListener61);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo64);
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot60.zoomDomainAxes((double) 2.0f, plotRenderingInfo65, point2D66);
        java.awt.geom.Rectangle2D rectangle2D68 = plotRenderingInfo65.getPlotArea();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(rectangle2D68);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        double double24 = legendTitle11.getHeight();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = legendTitle11.getHorizontalAlignment();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        boolean boolean75 = categoryPlot69.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis76 = categoryPlot69.getRangeAxis();
        org.jfree.chart.util.SortOrder sortOrder77 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.BarRenderer barRenderer78 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer79 = null;
        barRenderer78.setGradientPaintTransformer(gradientPaintTransformer79);
        barRenderer78.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer78.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer78.setBaseSeriesVisible(false);
        boolean boolean90 = sortOrder77.equals((java.lang.Object) barRenderer78);
        categoryPlot69.setRowRenderingOrder(sortOrder77);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(valueAxis76);
        org.junit.Assert.assertNotNull(sortOrder77);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer11.setBaseOutlineStroke(stroke14);
        barRenderer11.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        barRenderer20.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer20.getBaseNegativeItemLabelPosition();
        barRenderer11.setSeriesNegativeItemLabelPosition(100, itemLabelPosition26, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        int int32 = barRenderer0.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        org.jfree.chart.axis.ValueAxis valueAxis76 = categoryPlot69.getRangeAxisForDataset((int) '#');
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertNotNull(valueAxis76);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        categoryPlot69.setRangeCrosshairLockedOnData(false);
        categoryPlot69.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        int int77 = categoryPlot69.getRangeAxisIndex(valueAxis76);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        double double6 = rectangleInsets4.extendHeight((double) 10.0f);
        org.jfree.chart.axis.TickType tickType7 = org.jfree.chart.axis.TickType.MINOR;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        boolean boolean9 = tickType7.equals((java.lang.Object) color8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        barRenderer10.setGradientPaintTransformer(gradientPaintTransformer11);
        barRenderer10.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer10.getLegendItemToolTipGenerator();
        boolean boolean19 = barRenderer10.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int20 = barRenderer10.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer10);
        java.lang.Object obj22 = legendTitle21.clone();
        boolean boolean23 = tickType7.equals((java.lang.Object) legendTitle21);
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle21.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets4.createOutsetRectangle(rectangle2D24, false, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 62.0d + "'", double6 == 62.0d);
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setSeriesFillPaint((int) (short) 1, paint4);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint10 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape9, paint10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = null;
        textLine12.draw(graphics2D13, 1.0f, 0.0f, textAnchor16, (float) 255, 100.0f, (double) 100);
        boolean boolean21 = legendGraphic11.equals((java.lang.Object) 0.0f);
        java.awt.Font font23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer26 = null;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, (java.awt.Paint) color24, (float) 1L, textMeasurer26);
        legendGraphic11.setFillPaint((java.awt.Paint) color24);
        barRenderer0.setSeriesItemLabelPaint((int) (short) 0, (java.awt.Paint) color24, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock27);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        java.lang.Object obj8 = numberAxis1.clone();
        numberAxis1.setTickMarkInsideLength(10.0f);
        numberAxis1.setFixedAutoRange((double) '4');
        numberAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer65 = null;
        barRenderer64.setGradientPaintTransformer(gradientPaintTransformer65);
        barRenderer64.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator70 = barRenderer64.getLegendItemToolTipGenerator();
        boolean boolean73 = barRenderer64.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int74 = barRenderer64.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer64);
        java.lang.Object obj76 = legendTitle75.clone();
        java.awt.Paint paint77 = legendTitle75.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment78 = legendTitle75.getHorizontalAlignment();
        jFreeChart63.addLegend(legendTitle75);
        boolean boolean80 = legendTitle75.getNotify();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNull(paint77);
        org.junit.Assert.assertNotNull(horizontalAlignment78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        barRenderer0.setBaseItemLabelFont(font11);
        boolean boolean17 = barRenderer0.isItemLabelVisible(0, 0);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(itemLabelPosition19);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        double double6 = categoryAxis0.getUpperMargin();
        float float7 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.lang.Comparable comparable8 = null;
        try {
            categoryAxis0.addCategoryLabelToolTip(comparable8, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = null;
        boolean boolean2 = strokeList0.equals(obj1);
        java.lang.Object obj3 = strokeList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        java.awt.Color color75 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot69.setRangeCrosshairPaint((java.awt.Paint) color75);
        org.jfree.chart.renderer.category.BarRenderer barRenderer77 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint79 = barRenderer77.lookupSeriesPaint(0);
        java.awt.Paint paint81 = barRenderer77.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj82 = barRenderer77.clone();
        barRenderer77.setAutoPopulateSeriesShape(false);
        java.awt.Color color85 = java.awt.Color.cyan;
        barRenderer77.setBasePaint((java.awt.Paint) color85);
        java.awt.Paint[] paintArray87 = new java.awt.Paint[] { color75, color85 };
        java.awt.Paint[] paintArray88 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray89 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray90 = null;
        java.awt.Stroke[] strokeArray91 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray92 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier93 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray87, paintArray88, paintArray89, strokeArray90, strokeArray91, shapeArray92);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNull(paint81);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(paintArray87);
        org.junit.Assert.assertNotNull(paintArray88);
        org.junit.Assert.assertNotNull(paintArray89);
        org.junit.Assert.assertNotNull(strokeArray91);
        org.junit.Assert.assertNotNull(shapeArray92);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer1.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer1.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesPaint(0);
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer8.setSeriesItemLabelFont(1, font12, false);
        barRenderer1.setBaseItemLabelFont(font12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        barRenderer16.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer16.setBaseOutlineStroke(stroke19);
        barRenderer16.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        java.awt.Paint paint26 = barRenderer16.lookupSeriesPaint((int) (short) -1);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE2", font12, paint26);
        java.awt.Paint paint28 = labelBlock27.getPaint();
        java.lang.String str29 = labelBlock27.getURLText();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot60.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle11.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateLeftOutset(10.0d);
        java.lang.String str27 = rectangleInsets24.toString();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = blockBorder29.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj34 = categoryAxis31.clone();
        boolean boolean35 = rectangleInsets30.equals((java.lang.Object) categoryAxis31);
        double double37 = rectangleInsets30.extendHeight((double) (-1L));
        org.jfree.chart.util.Size2D size2D44 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, (double) (short) -1, 0.0d, rectangleAnchor47);
        java.awt.Shape shape49 = null;
        boolean boolean50 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D48, shape49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str52 = color51.toString();
        java.awt.Stroke stroke53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D48, (java.awt.Paint) color51, stroke53, (java.awt.Paint) color54);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity56 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D48);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str58 = lengthAdjustmentType57.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets30.createAdjustedRectangle(rectangle2D48, lengthAdjustmentType57, lengthAdjustmentType59);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets24.createAdjustedRectangle(rectangle2D48, lengthAdjustmentType61, lengthAdjustmentType62);
        legendTitle11.setItemLabelPadding(rectangleInsets24);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str27.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str52.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "CONTRACT" + "'", str58.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        java.lang.Comparable comparable16 = categoryItemEntity15.getColumnKey();
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100L + "'", comparable16.equals(100L));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Font font2 = textTitle1.getFont();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        textTitle1.setURLText("[size=1]");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer11.setBaseOutlineStroke(stroke14);
        barRenderer11.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        barRenderer20.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer20.getBaseNegativeItemLabelPosition();
        barRenderer11.setSeriesNegativeItemLabelPosition(100, itemLabelPosition26, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = barRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator35 = barRenderer0.getURLGenerator(100, (int) (byte) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNull(categoryURLGenerator35);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        java.awt.Shape shape8 = numberAxis1.getDownArrow();
        numberAxis1.setLabel("CONTRACT");
        numberAxis1.setLabelToolTip("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj66 = textTitle65.clone();
        org.jfree.chart.event.TitleChangeListener titleChangeListener67 = null;
        textTitle65.addChangeListener(titleChangeListener67);
        jFreeChart63.addSubtitle((org.jfree.chart.title.Title) textTitle65);
        jFreeChart63.setTextAntiAlias(false);
        jFreeChart63.setTitle("");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNotNull(obj66);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer0.getSeriesToolTipGenerator((-1));
        boolean boolean4 = barRenderer0.getBaseSeriesVisible();
        barRenderer0.setMinimumBarLength((double) 64);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(1, font4, false);
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer11.setBaseOutlineStroke(stroke14);
        barRenderer11.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesPaint(0);
        barRenderer20.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer20.getBaseNegativeItemLabelPosition();
        barRenderer11.setSeriesNegativeItemLabelPosition(100, itemLabelPosition26, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator29);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = barRenderer0.getLegendItems();
        java.awt.Shape shape35 = barRenderer0.getItemShape((int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (short) -1, 0.0d, rectangleAnchor11);
        java.awt.Shape shape13 = null;
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D12, shape13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D12, rectangleEdge15);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D12);
        numberAxis5.setLeftArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer20.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean25 = barRenderer20.equals((java.lang.Object) (-1.0d));
        barRenderer20.setBaseCreateEntities(false, false);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer20.setBaseItemLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        barRenderer20.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition32);
        java.awt.Font font35 = null;
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer38 = null;
        org.jfree.chart.text.TextBlock textBlock39 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, (java.awt.Paint) color36, (float) 1L, textMeasurer38);
        int int40 = color36.getAlpha();
        barRenderer20.setBasePaint((java.awt.Paint) color36);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint46 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic47 = new org.jfree.chart.title.LegendGraphic(shape45, paint46);
        legendGraphic47.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = legendGraphic47.getShapeLocation();
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str52 = color51.toString();
        legendGraphic47.setLinePaint((java.awt.Paint) color51);
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("", "", "", "RectangleEdge.LEFT", (java.awt.Shape) rectangle2D12, (java.awt.Paint) color36, stroke42, (java.awt.Paint) color51);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(textBlock39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str52.equals("java.awt.Color[r=0,g=0,b=128]"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = legendTitle11.getSources();
        org.jfree.chart.block.BlockFrame blockFrame25 = legendTitle11.getFrame();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertNotNull(blockFrame25);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis2.setLabelFont(font3);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        double double7 = numberAxis2.getLowerMargin();
        org.jfree.data.Range range8 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range8);
        double double10 = range8.getUpperBound();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.block.BorderArrangement borderArrangement11 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 100.0d, (double) (-1));
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RangeType.NEGATIVE", "hi!", "CONTRACT", image20, "AxisLocation.TOP_OR_RIGHT", "CONTRACT", "java.awt.Color[r=0,g=0,b=128]");
        projectInfo24.setName("CONTRACT");
        boolean boolean27 = flowArrangement16.equals((java.lang.Object) projectInfo24);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement16);
        java.awt.Font font30 = null;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color31, (float) 1L, textMeasurer33);
        org.jfree.chart.text.TextLine textLine35 = textBlock34.getLastLine();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock34.draw(graphics2D36, (float) 100, (float) (byte) 1, textBlockAnchor39, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock34.setLineAlignment(horizontalAlignment44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) (short) -1, 0.0d, rectangleAnchor53);
        plotRenderingInfo47.setDataArea(rectangle2D54);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D54, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset58);
        boolean boolean63 = horizontalAlignment44.equals((java.lang.Object) defaultStatisticalCategoryDataset58);
        java.util.List list64 = defaultStatisticalCategoryDataset58.getColumnKeys();
        java.lang.Comparable comparable65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement11, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset58, comparable65);
        java.lang.Comparable comparable67 = legendItemBlockContainer66.getSeriesKey();
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis73.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo78 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo78);
        org.jfree.chart.util.Size2D size2D82 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D86 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D82, (double) (short) -1, 0.0d, rectangleAnchor85);
        plotRenderingInfo79.setDataArea(rectangle2D86);
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = null;
        double double89 = categoryAxis73.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D86, rectangleEdge88);
        java.awt.Stroke stroke90 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color91 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.LegendItem legendItem92 = new org.jfree.chart.LegendItem("{0}", "[size=1]", "ClassContext", "", (java.awt.Shape) rectangle2D86, stroke90, (java.awt.Paint) color91);
        java.lang.Object obj93 = null;
        try {
            java.lang.Object obj94 = legendItemBlockContainer66.draw(graphics2D68, rectangle2D86, obj93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNull(textLine35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNull(comparable67);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNotNull(rectangle2D86);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(stroke90);
        org.junit.Assert.assertNotNull(color91);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        java.lang.String str3 = projectInfo1.getVersion();
//        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        projectInfo5.setCopyright("java.awt.Color[r=0,g=0,b=128]");
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo5.getLibraries();
//        java.util.List list11 = null;
//        projectInfo5.setContributors(list11);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
//        org.junit.Assert.assertNotNull(projectInfo4);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertNotNull(libraryArray10);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        java.awt.Paint paint15 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        barRenderer0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color17, true);
        barRenderer0.setIncludeBaseInRange(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("{0}", font1, paint2);
        java.awt.Paint paint4 = textFragment3.getPaint();
        float float5 = textFragment3.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        categoryPlot60.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot60.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.title.LegendTitle legendTitle65 = jFreeChart63.getLegend((int) (short) 100);
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.lang.String str68 = textTitle67.getText();
        java.lang.Object obj69 = textTitle67.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent70 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle67);
        jFreeChart63.titleChanged(titleChangeEvent70);
        org.jfree.chart.renderer.category.BarRenderer barRenderer72 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer73 = null;
        barRenderer72.setGradientPaintTransformer(gradientPaintTransformer73);
        barRenderer72.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator78 = barRenderer72.getLegendItemToolTipGenerator();
        boolean boolean81 = barRenderer72.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int82 = barRenderer72.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle83 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer72);
        java.lang.Object obj84 = legendTitle83.clone();
        java.awt.Paint paint85 = legendTitle83.getBackgroundPaint();
        java.awt.Shape shape88 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint89 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic90 = new org.jfree.chart.title.LegendGraphic(shape88, paint89);
        legendGraphic90.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor93 = legendGraphic90.getShapeLocation();
        legendTitle83.setLegendItemGraphicAnchor(rectangleAnchor93);
        java.lang.String str95 = legendTitle83.getID();
        jFreeChart63.addSubtitle((org.jfree.chart.title.Title) legendTitle83);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryAxis62);
        org.junit.Assert.assertNull(legendTitle65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ClassContext" + "'", str68.equals("ClassContext"));
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(obj84);
        org.junit.Assert.assertNull(paint85);
        org.junit.Assert.assertNotNull(shape88);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(rectangleAnchor93);
        org.junit.Assert.assertNull(str95);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        boolean boolean14 = barRenderer7.getIncludeBaseInRange();
        boolean boolean15 = barRenderer7.getAutoPopulateSeriesStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer7.setBaseOutlinePaint((java.awt.Paint) color16);
        java.awt.Paint paint18 = barRenderer7.getBaseItemLabelPaint();
        boolean boolean19 = legendItemCollection6.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) (short) -1, 0.0d, rectangleAnchor29);
        java.awt.Shape shape31 = null;
        boolean boolean32 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D30, shape31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str34 = color33.toString();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D30, (java.awt.Paint) color33, stroke35, (java.awt.Paint) color36);
        java.lang.Comparable comparable38 = legendItem37.getSeriesKey();
        boolean boolean39 = legendItem37.isLineVisible();
        java.lang.String str40 = legendItem37.getToolTipText();
        java.awt.Stroke stroke41 = legendItem37.getLineStroke();
        boolean boolean42 = barRenderer7.equals((java.lang.Object) stroke41);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator44 = null;
        barRenderer7.setSeriesItemLabelGenerator(10, categoryItemLabelGenerator44, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer47 = barRenderer7.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str34.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(comparable38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer47);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.PieDataset pieDataset37 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(pieDataset37);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj6 = categoryAxis3.clone();
        boolean boolean7 = rectangleInsets2.equals((java.lang.Object) categoryAxis3);
        double double9 = rectangleInsets2.extendHeight((double) (-1L));
        double double11 = rectangleInsets2.trimWidth((double) '4');
        double double13 = rectangleInsets2.trimHeight((double) 0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 50.0d + "'", double11 == 50.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-2.0d) + "'", double13 == (-2.0d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = categoryPlot69.getOrientation();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertNotNull(plotOrientation75);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj5 = barRenderer0.clone();
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.lang.Object obj8 = barRenderer0.clone();
        int int9 = barRenderer0.getRowCount();
        barRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        double double3 = axisSpace1.getRight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace1.add((double) (short) -1, rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace1.add((double) (short) 10, rectangleEdge8);
        java.awt.Font font11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color12, (float) 1L, textMeasurer14);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        java.awt.Font font18 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color19, (float) 1L, textMeasurer21);
        org.jfree.chart.text.TextLine textLine23 = textBlock22.getLastLine();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock22.draw(graphics2D24, (float) 100, (float) (byte) 1, textBlockAnchor27, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock22.setLineAlignment(horizontalAlignment32);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        org.jfree.chart.util.Size2D size2D38 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, (double) (short) -1, 0.0d, rectangleAnchor41);
        plotRenderingInfo35.setDataArea(rectangle2D42);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset46 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity49 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D42, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset46, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset46);
        boolean boolean51 = horizontalAlignment32.equals((java.lang.Object) defaultStatisticalCategoryDataset46);
        textBlock15.setLineAlignment(horizontalAlignment32);
        boolean boolean53 = rectangleEdge8.equals((java.lang.Object) textBlock15);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNull(textLine16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertNull(textLine23);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint13 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, paint13);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape12, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList20 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) (short) -1, 0.0d, rectangleAnchor31);
        java.awt.Shape shape33 = null;
        boolean boolean34 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D32, shape33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str36 = color35.toString();
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D32, (java.awt.Paint) color35, stroke37, (java.awt.Paint) color38);
        objectList20.set((int) '4', (java.lang.Object) color35);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape12, stroke19, (java.awt.Paint) color35);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color35);
        double double43 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str36.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesPaint(0);
        java.awt.Paint paint6 = barRenderer2.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj7 = barRenderer2.clone();
        java.awt.Paint paint10 = barRenderer2.getItemPaint((int) (short) 10, 0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer13 = new org.jfree.chart.text.G2TextMeasurer(graphics2D12);
        try {
            org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.RIGHT", font1, paint10, (float) (short) 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.getHeight();
        size2D2.setWidth((double) (-1));
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis1.setLabelFont(font2);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        double double6 = numberAxis1.getLowerMargin();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis9.setLabelFont(font10);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis9.setMarkerBand(markerAxisBand12);
        double double14 = numberAxis9.getLowerMargin();
        org.jfree.data.Range range15 = numberAxis9.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis17.setLabelFont(font18);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis17.setMarkerBand(markerAxisBand20);
        double double22 = numberAxis17.getLowerMargin();
        org.jfree.data.Range range23 = numberAxis17.getDefaultAutoRange();
        org.jfree.data.Range range24 = org.jfree.data.Range.combine(range15, range23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, (-1.0d));
        org.jfree.data.Range range27 = org.jfree.data.Range.combine(range7, range24);
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=64]", font29);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint33 = barRenderer31.lookupSeriesPaint(0);
        java.awt.Paint paint35 = barRenderer31.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj36 = barRenderer31.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = null;
        barRenderer31.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition38);
        double double40 = barRenderer31.getMinimumBarLength();
        boolean boolean41 = textLine30.equals((java.lang.Object) barRenderer31);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = barRenderer31.getBaseItemLabelGenerator();
        boolean boolean43 = range27.equals((java.lang.Object) categoryItemLabelGenerator42);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape5, paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendGraphic7.getMargin();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        double double11 = rectangleInsets8.calculateLeftOutset((double) 2.0f);
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke2, rectangleInsets8);
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        java.awt.Paint paint14 = lineBorder12.getPaint();
        java.awt.Stroke stroke15 = lineBorder12.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        int int4 = barRenderer0.getRowCount();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke((-1), (int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection74 = categoryPlot69.getDomainMarkers(layer73);
        boolean boolean75 = categoryPlot69.isDomainGridlinesVisible();
        int int76 = categoryPlot69.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation78 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot69.setDomainAxisLocation(0, axisLocation78);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 15 + "'", int76 == 15);
        org.junit.Assert.assertNotNull(axisLocation78);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer0.removeAnnotation(categoryAnnotation9);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer0.getItemLabelGenerator((int) 'a', (int) (byte) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        try {
            barRenderer0.setSeriesToolTipGenerator((-655360), categoryToolTipGenerator17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4, true);
        barRenderer0.setMaximumBarWidth((double) 0L);
        java.awt.Color color9 = java.awt.Color.BLUE;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesPaint(0);
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer11.setSeriesItemLabelFont(1, font15, false);
        boolean boolean18 = barRenderer11.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer11.setBaseURLGenerator(categoryURLGenerator19, true);
        barRenderer11.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer11.getPositiveItemLabelPosition((int) '4', (int) (short) -1);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition26);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets6);
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (short) -1, 0.0d, rectangleAnchor13);
        java.awt.Shape shape15 = null;
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D14, shape15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets6.createInsetRectangle(rectangle2D14);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        barRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic4.getShapeLocation();
        boolean boolean8 = legendGraphic4.isShapeOutlineVisible();
        legendGraphic4.setLineVisible(false);
        org.jfree.chart.block.BlockFrame blockFrame11 = legendGraphic4.getFrame();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(blockFrame11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RangeType.NEGATIVE");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("RangeType.NEGATIVE");
        java.util.Locale locale6 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj8 = jFreeChartResources0.getObject("CONTRACT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key CONTRACT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(locale6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = categoryLabelPosition1.getLabelAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font1, (java.awt.Paint) color2, (float) (byte) 0);
        float float5 = textFragment4.getBaselineOffset();
        java.awt.Paint paint6 = textFragment4.getPaint();
        float float7 = textFragment4.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        barRenderer0.setBaseSeriesVisible(false);
        boolean boolean12 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        java.awt.Paint paint17 = barRenderer0.getSeriesItemLabelPaint((int) (short) -1);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setSeriesStroke(0, stroke19);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint30 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape29, paint30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendGraphic31.getMargin();
        org.jfree.chart.util.UnitType unitType33 = rectangleInsets32.getUnitType();
        double double35 = rectangleInsets32.calculateLeftOutset((double) 2.0f);
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color24, stroke26, rectangleInsets32);
        legendTitle11.setLegendItemGraphicPadding(rectangleInsets32);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint40 = barRenderer38.lookupSeriesPaint(0);
        java.awt.Font font42 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer38.setSeriesItemLabelFont(1, font42, false);
        boolean boolean45 = barRenderer38.getIncludeBaseInRange();
        boolean boolean46 = barRenderer38.getAutoPopulateSeriesStroke();
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer38.setBaseOutlinePaint((java.awt.Paint) color47);
        java.awt.Paint paint49 = barRenderer38.getBaseItemLabelPaint();
        boolean boolean50 = rectangleInsets32.equals((java.lang.Object) barRenderer38);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(unitType33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 64, (double) 10L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, 0.0d, rectangleAnchor9);
        java.awt.Shape shape11 = null;
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D10, shape11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color13, stroke15, (java.awt.Paint) color16);
        java.lang.Comparable comparable18 = legendItem17.getSeriesKey();
        java.awt.Shape shape19 = legendItem17.getLine();
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape19, "TextAnchor.CENTER_RIGHT", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, paint7);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) (short) 0, 0.0f, (float) (short) -1);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ObjectList objectList14 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, (double) (short) -1, 0.0d, rectangleAnchor25);
        java.awt.Shape shape27 = null;
        boolean boolean28 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D26, shape27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str30 = color29.toString();
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D26, (java.awt.Paint) color29, stroke31, (java.awt.Paint) color32);
        objectList14.set((int) '4', (java.lang.Object) color29);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "java.awt.Color[r=0,g=0,b=128]", shape6, stroke13, (java.awt.Paint) color29);
        java.text.AttributedString attributedString36 = legendItem35.getAttributedLabel();
        java.awt.Paint paint37 = legendItem35.getOutlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke40 = numberAxis39.getAxisLineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis42.setTickLabelInsets(rectangleInsets47);
        java.lang.Object obj49 = numberAxis42.clone();
        boolean boolean50 = numberAxis42.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis42.getTickLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder52 = new org.jfree.chart.block.LineBorder(paint37, stroke40, rectangleInsets51);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str30.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(attributedString36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        boolean boolean61 = categoryPlot60.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot60.setDomainAxisLocation(4, axisLocation63);
        org.jfree.chart.plot.PlotOrientation plotOrientation65 = categoryPlot60.getOrientation();
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer67 = null;
        barRenderer66.setGradientPaintTransformer(gradientPaintTransformer67);
        barRenderer66.setBaseSeriesVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator71 = null;
        barRenderer66.setBaseItemLabelGenerator(categoryItemLabelGenerator71);
        java.awt.Paint paint73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer66.setBaseItemLabelPaint(paint73, false);
        boolean boolean76 = plotOrientation65.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(plotOrientation65);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound(96.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.text.TextLine textLine15 = textBlock5.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = null;
        try {
            textBlock5.setLineAlignment(horizontalAlignment16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNull(textLine15);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (short) -1, 0.0d, rectangleAnchor7);
        plotRenderingInfo1.setDataArea(rectangle2D8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D8, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryItemEntity15.getDataset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint19 = barRenderer17.lookupSeriesPaint(0);
        java.awt.Paint paint21 = barRenderer17.getSeriesOutlinePaint((int) (short) 100);
        java.lang.Object obj22 = barRenderer17.clone();
        java.lang.Boolean boolean24 = barRenderer17.getSeriesCreateEntities((int) 'a');
        java.awt.Paint paint25 = barRenderer17.getBasePaint();
        boolean boolean26 = categoryItemEntity15.equals((java.lang.Object) paint25);
        java.lang.String str27 = categoryItemEntity15.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis1.setLabelFont(font2);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        double double6 = numberAxis1.getLowerMargin();
        numberAxis1.setLabelToolTip("MINOR");
        java.awt.Font font9 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setLabelURL("ItemLabelAnchor.INSIDE2");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            numberAxis1.setLabelInsets(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(numberFormat3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (byte) 10, 2.0d, (int) '#', (java.lang.Comparable) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        java.awt.Paint paint73 = categoryPlot69.getDomainGridlinePaint();
        java.awt.Paint paint74 = categoryPlot69.getRangeGridlinePaint();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(paint74);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getPositiveItemLabelPosition((-655360), 2);
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) (short) -1, 0.0d, rectangleAnchor26);
        java.awt.Shape shape28 = null;
        boolean boolean29 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D27, shape28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str31 = color30.toString();
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D27, (java.awt.Paint) color30, stroke32, (java.awt.Paint) color33);
        java.lang.Comparable comparable35 = legendItem34.getSeriesKey();
        java.awt.Paint paint36 = legendItem34.getLinePaint();
        barRenderer0.setBaseOutlinePaint(paint36, false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str31.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(comparable35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        double double18 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) (short) -1, 0.0d, rectangleAnchor27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list30 = categoryAxis0.refreshTicks(graphics2D20, axisState21, rectangle2D28, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition12);
        java.awt.Paint paint15 = barRenderer0.lookupSeriesPaint((int) (short) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        barRenderer0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color17, true);
        barRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = legendTitle11.getSources();
        java.awt.Font font26 = null;
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer29 = null;
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, (java.awt.Paint) color27, (float) 1L, textMeasurer29);
        org.jfree.chart.text.TextLine textLine31 = textBlock30.getLastLine();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor35 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock30.draw(graphics2D32, (float) 100, (float) (byte) 1, textBlockAnchor35, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock30.setLineAlignment(horizontalAlignment40);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        org.jfree.chart.util.Size2D size2D46 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, (double) (short) -1, 0.0d, rectangleAnchor49);
        plotRenderingInfo43.setDataArea(rectangle2D50);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset54 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity57 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D50, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset54, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset54);
        boolean boolean59 = horizontalAlignment40.equals((java.lang.Object) defaultStatisticalCategoryDataset54);
        org.jfree.data.general.DatasetGroup datasetGroup60 = defaultStatisticalCategoryDataset54.getGroup();
        org.jfree.data.Range range62 = defaultStatisticalCategoryDataset54.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean67 = numberAxis66.isPositiveArrowVisible();
        numberAxis66.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand71 = null;
        numberAxis66.setMarkerBand(markerAxisBand71);
        double double73 = numberAxis66.getUpperBound();
        java.text.NumberFormat numberFormat74 = numberAxis66.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer75 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer76 = null;
        barRenderer75.setGradientPaintTransformer(gradientPaintTransformer76);
        barRenderer75.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator81 = barRenderer75.getLegendItemToolTipGenerator();
        boolean boolean84 = barRenderer75.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset54, categoryAxis64, (org.jfree.chart.axis.ValueAxis) numberAxis66, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer75);
        categoryPlot85.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis87 = categoryPlot85.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart88 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot85);
        org.jfree.chart.title.TextTitle textTitle90 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj91 = textTitle90.clone();
        org.jfree.chart.event.TitleChangeListener titleChangeListener92 = null;
        textTitle90.addChangeListener(titleChangeListener92);
        jFreeChart88.addSubtitle((org.jfree.chart.title.Title) textTitle90);
        jFreeChart88.setTextAntiAlias(false);
        int int97 = jFreeChart88.getSubtitleCount();
        boolean boolean98 = jFreeChart88.isBorderVisible();
        legendTitle11.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart88);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNull(textLine31);
        org.junit.Assert.assertNotNull(textBlockAnchor35);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(datasetGroup60);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 10.0d + "'", double73 == 10.0d);
        org.junit.Assert.assertNull(numberFormat74);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(categoryAxis87);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 2 + "'", int97 == 2);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) ' ');
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (short) -1, 0.0d, rectangleAnchor12);
        plotRenderingInfo6.setDataArea(rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D13, rectangleEdge15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj25 = categoryAxis22.clone();
        boolean boolean26 = rectangleInsets21.equals((java.lang.Object) categoryAxis22);
        double double28 = rectangleInsets21.extendHeight((double) (-1L));
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (short) -1, 0.0d, rectangleAnchor38);
        java.awt.Shape shape40 = null;
        boolean boolean41 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D39, shape40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str43 = color42.toString();
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("RangeType.NEGATIVE", "java.awt.Color[r=0,g=0,b=128]", "", "ClassContext", (java.awt.Shape) rectangle2D39, (java.awt.Paint) color42, stroke44, (java.awt.Paint) color45);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity47 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str49 = lengthAdjustmentType48.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets21.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType48, lengthAdjustmentType50);
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D51, (double) 0.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D57 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D57, (double) (short) -1, 0.0d, rectangleAnchor60);
        java.awt.Shape shape62 = null;
        boolean boolean63 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D61, shape62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D61, rectangleEdge64);
        org.jfree.chart.entity.ChartEntity chartEntity67 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D61, "{0}");
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str69 = rectangleEdge68.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge68);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo73);
        org.jfree.chart.util.Size2D size2D77 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor80 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D81 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D77, (double) (short) -1, 0.0d, rectangleAnchor80);
        plotRenderingInfo74.setDataArea(rectangle2D81);
        plotRenderingInfo72.addSubplotInfo(plotRenderingInfo74);
        int int84 = plotRenderingInfo74.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D85 = plotRenderingInfo74.getDataArea();
        try {
            org.jfree.chart.axis.AxisState axisState86 = categoryAxis0.draw(graphics2D17, (double) 64, rectangle2D51, rectangle2D61, rectangleEdge68, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str43.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "CONTRACT" + "'", str49.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "RectangleEdge.LEFT" + "'", str69.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(rectangleAnchor80);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(rectangle2D85);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Color color2 = java.awt.Color.getColor("CONTRACT", 64);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        double double3 = axisSpace1.getLeft();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        boolean boolean5 = axisSpace1.equals((java.lang.Object) paint4);
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, range7);
        org.jfree.data.Range range9 = rectangleConstraint8.getHeightRange();
        java.lang.String str10 = rectangleConstraint8.toString();
        boolean boolean11 = axisSpace1.equals((java.lang.Object) rectangleConstraint8);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint8.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str10.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(0);
        barRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition6.getTextAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) 'a');
        int int10 = barRenderer0.getColumnCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.lang.Object obj12 = legendTitle11.clone();
        java.awt.Paint paint13 = legendTitle11.getBackgroundPaint();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, paint17);
        legendGraphic18.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendGraphic18.getShapeLocation();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        java.lang.String str23 = legendTitle11.getID();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint30 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape29, paint30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendGraphic31.getMargin();
        org.jfree.chart.util.UnitType unitType33 = rectangleInsets32.getUnitType();
        double double35 = rectangleInsets32.calculateLeftOutset((double) 2.0f);
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color24, stroke26, rectangleInsets32);
        legendTitle11.setLegendItemGraphicPadding(rectangleInsets32);
        java.awt.Font font38 = legendTitle11.getItemFont();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(unitType33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesPaint(0);
        barRenderer0.setBaseFillPaint(paint6, true);
        barRenderer0.setBaseSeriesVisible(false, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) 'a');
        java.awt.Paint paint15 = barRenderer0.getSeriesPaint((int) (byte) -1);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke3);
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesPaint(0);
        barRenderer9.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer9.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesNegativeItemLabelPosition(100, itemLabelPosition15, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        java.awt.Stroke stroke21 = barRenderer0.getSeriesOutlineStroke((int) 'a');
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseStroke(stroke22);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) 1L, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock5.draw(graphics2D7, (float) 100, (float) (byte) 1, textBlockAnchor10, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock5.setLineAlignment(horizontalAlignment15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (short) -1, 0.0d, rectangleAnchor24);
        plotRenderingInfo18.setDataArea(rectangle2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D25, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29);
        boolean boolean34 = horizontalAlignment15.equals((java.lang.Object) defaultStatisticalCategoryDataset29);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultStatisticalCategoryDataset29.getGroup();
        org.jfree.data.Range range37 = defaultStatisticalCategoryDataset29.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean42 = numberAxis41.isPositiveArrowVisible();
        numberAxis41.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis41.setMarkerBand(markerAxisBand46);
        double double48 = numberAxis41.getUpperBound();
        java.text.NumberFormat numberFormat49 = numberAxis41.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        barRenderer50.setGradientPaintTransformer(gradientPaintTransformer51);
        barRenderer50.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = barRenderer50.getLegendItemToolTipGenerator();
        boolean boolean59 = barRenderer50.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset29, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot60.removeChangeListener(plotChangeListener61);
        float float63 = categoryPlot60.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator67 = barRenderer64.getURLGenerator((int) (byte) 0, (int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator68 = null;
        barRenderer64.setBaseURLGenerator(categoryURLGenerator68, true);
        barRenderer64.setMaximumBarWidth((double) 0L);
        java.awt.Color color73 = java.awt.Color.BLUE;
        barRenderer64.setBaseOutlinePaint((java.awt.Paint) color73);
        int int75 = categoryPlot60.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer64);
        java.awt.Stroke stroke76 = categoryPlot60.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 1.0f + "'", float63 == 1.0f);
        org.junit.Assert.assertNull(categoryURLGenerator67);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape5, paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendGraphic7.getMargin();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        double double11 = rectangleInsets8.calculateLeftOutset((double) 2.0f);
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke2, rectangleInsets8);
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesPaint(0);
        java.awt.Font font19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer15.setSeriesItemLabelFont(1, font19, false);
        boolean boolean22 = barRenderer15.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = null;
        barRenderer15.setBaseURLGenerator(categoryURLGenerator23, true);
        barRenderer15.setBaseCreateEntities(false);
        boolean boolean28 = verticalAlignment14.equals((java.lang.Object) false);
        boolean boolean29 = lineBorder12.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        categoryPlot69.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis76.setTickLabelInsets(rectangleInsets81);
        java.lang.Object obj83 = numberAxis76.clone();
        org.jfree.chart.plot.Plot plot84 = null;
        numberAxis76.setPlot(plot84);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand86 = null;
        numberAxis76.setMarkerBand(markerAxisBand86);
        numberAxis76.setLabelToolTip("ClassContext");
        categoryPlot69.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis76);
        categoryPlot69.setRangeGridlinesVisible(false);
        java.awt.Image image93 = categoryPlot69.getBackgroundImage();
        int int94 = categoryPlot69.getDomainAxisCount();
        categoryPlot69.setOutlineVisible(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj83);
        org.junit.Assert.assertNull(image93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis1.setLabelFont(font2);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        numberAxis1.centerRange((double) ' ');
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        textLine5.draw(graphics2D6, 1.0f, 0.0f, textAnchor9, (float) 255, 100.0f, (double) 100);
        boolean boolean14 = legendGraphic4.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) 1L, textMeasurer19);
        legendGraphic4.setFillPaint((java.awt.Paint) color17);
        java.lang.Object obj22 = legendGraphic4.clone();
        java.awt.geom.Rectangle2D rectangle2D23 = legendGraphic4.getBounds();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint27 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, paint27);
        legendGraphic4.setLine(shape26);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("VerticalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesPaint(0);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer7.setSeriesItemLabelFont(1, font11, false);
        boolean boolean14 = barRenderer7.getIncludeBaseInRange();
        boolean boolean15 = barRenderer7.getAutoPopulateSeriesStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        barRenderer7.setBaseOutlinePaint((java.awt.Paint) color16);
        java.awt.Paint paint18 = barRenderer7.getBaseItemLabelPaint();
        boolean boolean19 = legendItemCollection6.equals((java.lang.Object) barRenderer7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        barRenderer7.setBaseToolTipGenerator(categoryToolTipGenerator20, false);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = categoryAxis0.clone();
        categoryAxis0.setAxisLineVisible(true);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color9 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font8, (java.awt.Paint) color9, (float) (byte) 0);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0, font8);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean17 = numberAxis16.isPositiveArrowVisible();
        numberAxis16.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis16.setMarkerBand(markerAxisBand21);
        java.lang.String str23 = numberAxis16.getLabelToolTip();
        numberAxis16.setAutoRangeStickyZero(true);
        java.awt.Font font26 = numberAxis16.getLabelFont();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (short) -1, 0.0d, rectangleAnchor37);
        java.awt.Shape shape39 = null;
        boolean boolean40 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D38, shape39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D38, rectangleEdge41);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D38);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D38);
        numberAxis31.setLeftArrow((java.awt.Shape) rectangle2D38);
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color27.createContext(colorModel28, rectangle29, rectangle2D38, affineTransform46, renderingHints47);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer51 = new org.jfree.chart.text.G2TextMeasurer(graphics2D50);
        org.jfree.chart.text.TextBlock textBlock52 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, (java.awt.Paint) color27, (float) 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer51);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT", font26);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertNotNull(textBlock52);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (byte) 10);
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, paint3);
        legendGraphic4.setShapeOutlineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic4.getShapeLocation();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str9 = color8.toString();
        legendGraphic4.setLinePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendGraphic4.getShapeAnchor();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str9.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis6.setLabelFont(font7);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis6.setMarkerBand(markerAxisBand9);
        double double11 = numberAxis6.getLowerMargin();
        org.jfree.data.Range range12 = numberAxis6.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis14.setLabelFont(font15);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis14.setMarkerBand(markerAxisBand17);
        double double19 = numberAxis14.getLowerMargin();
        org.jfree.data.Range range20 = numberAxis14.getDefaultAutoRange();
        org.jfree.data.Range range21 = org.jfree.data.Range.combine(range12, range20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint2.toRangeWidth(range21);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator((int) (byte) 0, (int) (short) -1);
        boolean boolean5 = barRenderer0.equals((java.lang.Object) (-1.0d));
        barRenderer0.setBaseCreateEntities(false, false);
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 1L, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock14.draw(graphics2D16, (float) 100, (float) (byte) 1, textBlockAnchor19, 1.0f, (float) '4', (double) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock14.setLineAlignment(horizontalAlignment24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(10.0d, (double) (byte) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (short) -1, 0.0d, rectangleAnchor33);
        plotRenderingInfo27.setDataArea(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "ItemLabelAnchor.INSIDE2", "CONTRACT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) ' ', (java.lang.Comparable) 100L);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38);
        boolean boolean43 = horizontalAlignment24.equals((java.lang.Object) defaultStatisticalCategoryDataset38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = defaultStatisticalCategoryDataset38.getGroup();
        org.jfree.data.Range range46 = defaultStatisticalCategoryDataset38.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean51 = numberAxis50.isPositiveArrowVisible();
        numberAxis50.setRangeAboutValue((double) 10.0f, (double) (short) 0);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis50.setMarkerBand(markerAxisBand55);
        double double57 = numberAxis50.getUpperBound();
        java.text.NumberFormat numberFormat58 = numberAxis50.getNumberFormatOverride();
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        barRenderer59.setGradientPaintTransformer(gradientPaintTransformer60);
        barRenderer59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer59.getLegendItemToolTipGenerator();
        boolean boolean68 = barRenderer59.isItemLabelVisible((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener70 = null;
        categoryPlot69.removeChangeListener(plotChangeListener70);
        barRenderer0.setPlot(categoryPlot69);
        categoryPlot69.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100L, (double) '4', (double) (byte) 10);
        numberAxis76.setTickLabelInsets(rectangleInsets81);
        java.lang.Object obj83 = numberAxis76.clone();
        org.jfree.chart.plot.Plot plot84 = null;
        numberAxis76.setPlot(plot84);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand86 = null;
        numberAxis76.setMarkerBand(markerAxisBand86);
        numberAxis76.setLabelToolTip("ClassContext");
        categoryPlot69.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis76);
        categoryPlot69.setRangeGridlinesVisible(false);
        java.awt.Image image93 = categoryPlot69.getBackgroundImage();
        org.jfree.chart.util.RectangleInsets rectangleInsets94 = categoryPlot69.getAxisOffset();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(datasetGroup44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertNull(numberFormat58);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj83);
        org.junit.Assert.assertNull(image93);
        org.junit.Assert.assertNotNull(rectangleInsets94);
    }
}

