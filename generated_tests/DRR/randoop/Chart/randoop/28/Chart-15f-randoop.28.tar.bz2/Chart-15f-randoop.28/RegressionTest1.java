import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Image image20 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot25.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot25.setInsets(rectangleInsets27, false);
        xYPlot25.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot25.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot25.setBackgroundPaint(paint34);
        xYPlot4.setOutlinePaint(paint34);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D37.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font41 = categoryAxis3D37.getTickLabelFont((java.lang.Comparable) numberTickUnit40);
        java.awt.Paint paint43 = categoryAxis3D37.getTickLabelPaint((java.lang.Comparable) 45.0d);
        xYPlot4.setRangeTickBandPaint(paint43);
        java.awt.Paint[] paintArray45 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot51.setRangeTickBandPaint((java.awt.Paint) color52);
        java.awt.Paint[] paintArray54 = new java.awt.Paint[] { color52 };
        java.awt.Stroke[] strokeArray55 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke57 = numberAxis3D56.getAxisLineStroke();
        java.awt.Paint paint58 = numberAxis3D56.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset59, valueAxis60, valueAxis61, xYItemRenderer62);
        org.jfree.data.xy.XYDataset xYDataset64 = xYPlot63.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot63.setInsets(rectangleInsets65, false);
        numberAxis3D56.setTickLabelInsets(rectangleInsets65);
        numberAxis3D56.setFixedDimension(Double.NaN);
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D56.setTickMarkStroke(stroke71);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D73 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke74 = numberAxis3D73.getAxisLineStroke();
        java.awt.Stroke[] strokeArray75 = new java.awt.Stroke[] { stroke71, stroke74 };
        org.jfree.chart.title.TextTitle textTitle76 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font77 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle76.setFont(font77);
        java.awt.geom.Rectangle2D rectangle2D79 = textTitle76.getBounds();
        java.awt.Shape[] shapeArray80 = new java.awt.Shape[] { rectangle2D79 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier81 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray45, paintArray46, paintArray54, strokeArray55, strokeArray75, shapeArray80);
        java.awt.Paint paint82 = defaultDrawingSupplier81.getNextFillPaint();
        xYPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier81);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberTickUnit40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(paintArray46);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paintArray54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNull(xYDataset64);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(strokeArray75);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(shapeArray80);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        float float12 = xYPlot4.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        java.awt.Stroke stroke19 = xYPlot17.getDomainZeroBaselineStroke();
        xYPlot4.setRangeGridlineStroke(stroke19);
        xYPlot4.mapDatasetToDomainAxis((int) (short) -1, (int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot4.getDomainAxis(10);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot31.setRangeTickBandPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot31.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo36, point2D37);
        xYPlot31.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D41.setRange((double) 0.0f, (double) ' ');
        boolean boolean45 = numberAxis3D41.isAutoTickUnitSelection();
        int int46 = xYPlot31.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D41);
        java.awt.Shape shape47 = numberAxis3D41.getRightArrow();
        numberAxis3D41.setNegativeArrowVisible(false);
        xYPlot4.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj10 = textTitle9.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle9.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.setAutoTickUnitSelection(false, true);
        boolean boolean16 = textTitle9.equals((java.lang.Object) numberAxis3D12);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setRange((double) 0.0f, (double) ' ');
        boolean boolean22 = numberAxis3D18.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = numberAxis3D18.getDefaultAutoRange();
        boolean boolean24 = numberAxis3D18.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, polarItemRenderer25);
        boolean boolean27 = polarPlot26.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis28 = polarPlot26.getAxis();
        boolean boolean29 = numberAxis3D12.hasListener((java.util.EventListener) polarPlot26);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle33.setFont(font34);
        java.awt.geom.Rectangle2D rectangle2D36 = textTitle33.getBounds();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, valueAxis39, xYItemRenderer40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot41.setRangeTickBandPaint((java.awt.Paint) color42);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset45, valueAxis46, valueAxis47, xYItemRenderer48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot49.setRangeTickBandPaint((java.awt.Paint) color50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot49.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo54, point2D55);
        xYPlot49.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D59.setRange((double) 0.0f, (double) ' ');
        boolean boolean63 = numberAxis3D59.isAutoTickUnitSelection();
        int int64 = xYPlot49.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D59);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D65 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D65.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, (org.jfree.chart.axis.ValueAxis) numberAxis3D65, xYItemRenderer69);
        org.jfree.data.Range range71 = xYPlot41.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D59);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = xYPlot41.getRangeAxisEdge();
        double double73 = numberAxis3D31.valueToJava2D(0.0d, rectangle2D36, rectangleEdge72);
        java.awt.geom.Point2D point2D74 = null;
        org.jfree.chart.plot.PlotState plotState75 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        polarPlot26.draw(graphics2D30, rectangle2D36, point2D74, plotState75, plotRenderingInfo76);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        boolean boolean80 = categoryPlot0.render(graphics2D8, rectangle2D36, 255, plotRenderingInfo79);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer81 = null;
        categoryPlot0.setRenderer(categoryItemRenderer81);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        textTitle0.setNotify(false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setAggregatedItemsKey((java.lang.Comparable) "java.awt.Color[r=0,g=128,b=0]");
        org.jfree.chart.util.TableOrder tableOrder5 = multiplePiePlot2.getDataExtractOrder();
        multiplePiePlot1.setDataExtractOrder(tableOrder5);
        org.junit.Assert.assertNotNull(tableOrder5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        textTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle1.setMargin(rectangleInsets5);
        categoryAxis3D0.setLabelInsets(rectangleInsets5);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) '#');
        categoryAxis3D0.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis3D0.getTickLabelInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) ' ');
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Shape shape20 = numberAxis3D14.getRightArrow();
        numberAxis3D14.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis3D14.setMarkerBand(markerAxisBand23);
        java.awt.Font font25 = numberAxis3D14.getLabelFont();
        boolean boolean26 = numberAxis3D14.isTickMarksVisible();
        java.awt.Shape shape27 = numberAxis3D14.getLeftArrow();
        numberAxis3D14.setRange(0.0d, (double) (byte) 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        xYPlot4.setDomainAxis(0, valueAxis14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker17.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        java.awt.Paint paint21 = valueMarker17.getLabelPaint();
        org.jfree.chart.util.Layer layer22 = null;
        try {
            xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker17, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke1 = numberAxis3D0.getAxisLineStroke();
        java.awt.Paint paint2 = numberAxis3D0.getAxisLinePaint();
        numberAxis3D0.configure();
        java.awt.Shape shape4 = numberAxis3D0.getLeftArrow();
        boolean boolean5 = numberAxis3D0.isNegativeArrowVisible();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setRange((double) 0.0f, (double) ' ');
        boolean boolean11 = numberAxis3D7.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = numberAxis3D7.getDefaultAutoRange();
        boolean boolean13 = numberAxis3D7.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, polarItemRenderer14);
        boolean boolean16 = polarPlot15.isRangeZoomable();
        java.awt.Font font17 = polarPlot15.getAngleLabelFont();
        numberAxis3D0.setTickLabelFont(font17);
        boolean boolean19 = numberAxis3D0.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        java.awt.Stroke stroke6 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        xYPlot4.setRangeGridlinesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot4.setOutlinePaint(paint11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot4.getRangeAxisEdge();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        float float4 = categoryAxis3D3.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font6 = categoryAxis3D3.getTickLabelFont((java.lang.Comparable) 1.0d);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D3);
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.String str4 = textTitle3.getURLText();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setMaximumLabelWidth(Double.NaN);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot12.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo17, point2D18);
        xYPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setRange((double) 0.0f, (double) ' ');
        boolean boolean26 = numberAxis3D22.isAutoTickUnitSelection();
        int int27 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        java.awt.Shape shape28 = numberAxis3D22.getRightArrow();
        numberAxis3D22.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis3D22.setMarkerBand(markerAxisBand31);
        java.awt.Font font33 = numberAxis3D22.getLabelFont();
        ringPlot5.setLabelFont(font33);
        textTitle3.setFont(font33);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 100.0f, font33);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        basicProjectInfo4.setName("Category Plot");
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot15.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo20, point2D21);
        xYPlot15.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setRange((double) 0.0f, (double) ' ');
        boolean boolean29 = numberAxis3D25.isAutoTickUnitSelection();
        int int30 = xYPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        java.awt.Shape shape31 = numberAxis3D25.getRightArrow();
        numberAxis3D25.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis3D25.getTickUnit();
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit34);
        polarPlot9.setRadiusGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = polarPlot9.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit34);
        org.junit.Assert.assertNotNull(plotOrientation38);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        java.awt.Stroke stroke4 = piePlot3D1.getLabelLinkStroke();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj7 = textTitle6.clone();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot13.setRangeTickBandPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot13.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo18, point2D19);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D23.setRange((double) 0.0f, (double) ' ');
        boolean boolean27 = numberAxis3D23.isAutoTickUnitSelection();
        int int28 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D29.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, xYItemRenderer33);
        boolean boolean35 = textTitle6.equals((java.lang.Object) xYDataset8);
        java.awt.Font font36 = textTitle6.getFont();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle40.setFont(font41);
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle40.getBounds();
        java.awt.geom.AffineTransform affineTransform44 = null;
        java.awt.RenderingHints renderingHints45 = null;
        java.awt.PaintContext paintContext46 = color37.createContext(colorModel38, rectangle39, rectangle2D43, affineTransform44, renderingHints45);
        org.jfree.chart.text.TextLine textLine47 = new org.jfree.chart.text.TextLine("hi!", font36, (java.awt.Paint) color37);
        boolean boolean48 = piePlot3D1.equals((java.lang.Object) font36);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(paintContext46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Shape shape2 = ringPlot0.getLegendItemShape();
        ringPlot0.setSeparatorsVisible(true);
        ringPlot0.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot6.setRangeTickBandPaint((java.awt.Paint) color7);
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color7 };
        java.awt.Stroke[] strokeArray10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke12 = numberAxis3D11.getAxisLineStroke();
        java.awt.Paint paint13 = numberAxis3D11.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot18.setInsets(rectangleInsets20, false);
        numberAxis3D11.setTickLabelInsets(rectangleInsets20);
        numberAxis3D11.setFixedDimension(Double.NaN);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D11.setTickMarkStroke(stroke26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke29 = numberAxis3D28.getAxisLineStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke26, stroke29 };
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle31.setFont(font32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle31.getBounds();
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] { rectangle2D34 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray9, strokeArray10, strokeArray30, shapeArray35);
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextFillPaint();
        java.awt.Paint paint38 = defaultDrawingSupplier36.getNextPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke40 = numberAxis3D39.getAxisLineStroke();
        boolean boolean41 = defaultDrawingSupplier36.equals((java.lang.Object) numberAxis3D39);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("", 255, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot5.getDataset();
        java.awt.Stroke stroke7 = xYPlot5.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (org.jfree.chart.plot.Plot) xYPlot5);
        java.util.List list11 = xYPlot5.getAnnotations();
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        float float2 = textFragment1.getBaselineOffset();
        java.lang.String str3 = textFragment1.getText();
        java.awt.Font font4 = textFragment1.getFont();
        float float5 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        blockParams0.setGenerateEntities(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator2);
        double double4 = piePlot3D1.getStartAngle();
        float float5 = piePlot3D1.getForegroundAlpha();
        piePlot3D1.setForegroundAlpha(1.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Shape shape2 = ringPlot0.getLegendItemShape();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor6 = new org.jfree.chart.plot.PieLabelDistributor(192);
        pieLabelDistributor6.clear();
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("PlotOrientation.VERTICAL");
        java.util.List list3 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "Rotation.CLOCKWISE", (-3.0d), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Image image20 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot25.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot25.setInsets(rectangleInsets27, false);
        xYPlot25.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot25.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot25.setBackgroundPaint(paint34);
        xYPlot4.setOutlinePaint(paint34);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        java.awt.Stroke stroke6 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot4.getFixedDomainAxisSpace();
        java.awt.Paint paint8 = null;
        xYPlot4.setRangeTickBandPaint(paint8);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot15.setInsets(rectangleInsets17, false);
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = blockContainer10.equals((java.lang.Object) xYPlot15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str26 = rectangleAnchor25.toString();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D27.setRange((double) 0.0f, (double) ' ');
        boolean boolean31 = numberAxis3D27.isAutoTickUnitSelection();
        java.awt.Paint paint32 = numberAxis3D27.getTickLabelPaint();
        boolean boolean33 = rectangleAnchor25.equals((java.lang.Object) numberAxis3D27);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot38.setRangeTickBandPaint((java.awt.Paint) color39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        xYPlot38.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo43, point2D44);
        float float46 = xYPlot38.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot51.getDataset();
        java.awt.Stroke stroke53 = xYPlot51.getDomainZeroBaselineStroke();
        xYPlot38.setRangeGridlineStroke(stroke53);
        numberAxis3D27.setTickMarkStroke(stroke53);
        xYPlot15.setRangeGridlineStroke(stroke53);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleAnchor.CENTER" + "'", str26.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.5f + "'", float46 == 0.5f);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke1 = numberAxis3D0.getAxisLineStroke();
        java.awt.Paint paint2 = numberAxis3D0.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot7.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot7.setInsets(rectangleInsets9, false);
        numberAxis3D0.setTickLabelInsets(rectangleInsets9);
        double double14 = rectangleInsets9.extendHeight((double) (-1));
        double double16 = rectangleInsets9.trimWidth((double) 255);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 253.0d + "'", double16 == 253.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        int int2 = categoryPlot0.getDomainAxisCount();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, (double) 0, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "java.awt.Color[r=0,g=128,b=0]");
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection3.addAll(legendItemCollection4);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        ringPlot0.setCircular(false);
        java.awt.Paint paint6 = ringPlot0.getShadowPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj9 = textTitle8.clone();
        textTitle8.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle8.setMargin(rectangleInsets12);
        categoryAxis3D7.setLabelInsets(rectangleInsets12);
        categoryAxis3D7.setMaximumCategoryLabelWidthRatio((float) '#');
        categoryAxis3D7.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis3D7.getTickLabelInsets();
        ringPlot0.setLabelPadding(rectangleInsets19);
        ringPlot0.setMinimumArcAngleToDraw((double) (short) 0);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        xYPlot4.notifyListeners(plotChangeEvent6);
        xYPlot4.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace10, false);
        org.junit.Assert.assertNull(xYDataset5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        xYPlot4.notifyListeners(plotChangeEvent6);
        boolean boolean8 = xYPlot4.isOutlineVisible();
        int int9 = xYPlot4.getRangeAxisCount();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle7.setFont(font8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color4.createContext(colorModel5, rectangle6, rectangle2D10, affineTransform11, renderingHints12);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj15 = textTitle0.draw(graphics2D3, (java.awt.geom.Rectangle2D) rectangle6, (java.lang.Object) font14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot20.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo25, point2D26);
        xYPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D30.setRange((double) 0.0f, (double) ' ');
        boolean boolean34 = numberAxis3D30.isAutoTickUnitSelection();
        int int35 = xYPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Shape shape36 = numberAxis3D30.getRightArrow();
        numberAxis3D30.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis3D30.setMarkerBand(markerAxisBand39);
        java.awt.Font font41 = numberAxis3D30.getLabelFont();
        textTitle0.setFont(font41);
        java.awt.Paint paint43 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        java.lang.Object obj8 = piePlot3D6.clone();
        piePlot3D6.setDepthFactor((double) (byte) 1);
        piePlot3D6.setIgnoreNullValues(true);
        piePlot3D6.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D6);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot21.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot21.setInsets(rectangleInsets23, false);
        xYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color33);
        xYPlot21.setBackgroundPaint((java.awt.Paint) color33);
        boolean boolean36 = textTitle16.equals((java.lang.Object) xYPlot21);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent37 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = titleChangeEvent37.getType();
        jFreeChart15.titleChanged(titleChangeEvent37);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent42 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 10, jFreeChart15, (int) (short) 10, (int) '#');
        java.awt.Stroke stroke43 = jFreeChart15.getBorderStroke();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = piePlot0.getURLGenerator();
        java.awt.Paint paint2 = piePlot0.getShadowPaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle10.setFont(font11);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle10.getBounds();
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color7.createContext(colorModel8, rectangle9, rectangle2D13, affineTransform14, renderingHints15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj18 = textTitle3.draw(graphics2D6, (java.awt.geom.Rectangle2D) rectangle9, (java.lang.Object) font17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot23.setRangeTickBandPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot23.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo28, point2D29);
        xYPlot23.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D33.setRange((double) 0.0f, (double) ' ');
        boolean boolean37 = numberAxis3D33.isAutoTickUnitSelection();
        int int38 = xYPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        java.awt.Shape shape39 = numberAxis3D33.getRightArrow();
        numberAxis3D33.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand42);
        java.awt.Font font44 = numberAxis3D33.getLabelFont();
        textTitle3.setFont(font44);
        piePlot0.setLabelFont(font44);
        java.lang.Object obj47 = piePlot0.clone();
        org.junit.Assert.assertNull(pieURLGenerator1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (short) 1);
        boolean boolean5 = range3.contains((double) 10L);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range3, 0.05d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) (short) 1);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (double) '4', 0.0d);
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range15, (double) 0.5f, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, range7, lengthConstraintType8, (double) (byte) 0, range15, lengthConstraintType19);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range15, (-18.0d));
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range15, (double) ' ', true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) textAnchor2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot8.setRangeTickBandPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot8.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo13, point2D14);
        xYPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setRange((double) 0.0f, (double) ' ');
        boolean boolean22 = numberAxis3D18.isAutoTickUnitSelection();
        int int23 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        boolean boolean24 = standardPieSectionLabelGenerator1.equals((java.lang.Object) numberAxis3D18);
        double double25 = numberAxis3D18.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis26.setRange(range27);
        numberAxis3D18.setRangeWithMargins(range27);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        java.lang.Object obj8 = piePlot3D6.clone();
        piePlot3D6.setDepthFactor((double) (byte) 1);
        piePlot3D6.setIgnoreNullValues(true);
        piePlot3D6.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D6);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot21.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot21.setInsets(rectangleInsets23, false);
        xYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color33);
        xYPlot21.setBackgroundPaint((java.awt.Paint) color33);
        boolean boolean36 = textTitle16.equals((java.lang.Object) xYPlot21);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent37 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = titleChangeEvent37.getType();
        jFreeChart15.titleChanged(titleChangeEvent37);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent42 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 10, jFreeChart15, (int) (short) 10, (int) '#');
        jFreeChart15.setNotify(false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke1 = numberAxis3D0.getAxisLineStroke();
        java.awt.Paint paint2 = numberAxis3D0.getAxisLinePaint();
        numberAxis3D0.configure();
        java.awt.Shape shape4 = numberAxis3D0.getLeftArrow();
        boolean boolean5 = numberAxis3D0.isNegativeArrowVisible();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setRange((double) 0.0f, (double) ' ');
        boolean boolean11 = numberAxis3D7.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = numberAxis3D7.getDefaultAutoRange();
        boolean boolean13 = numberAxis3D7.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, polarItemRenderer14);
        boolean boolean16 = polarPlot15.isRangeZoomable();
        java.awt.Font font17 = polarPlot15.getAngleLabelFont();
        numberAxis3D0.setTickLabelFont(font17);
        org.jfree.data.RangeType rangeType19 = numberAxis3D0.getRangeType();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rangeType19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { "java.awt.Color[r=0,g=128,b=0]", 0.2d, 8 };
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 12.0d, Double.NaN };
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray9);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray6, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint2 = piePlot3D1.getLabelOutlinePaint();
        java.lang.Object obj3 = piePlot3D1.clone();
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setIgnoreNullValues(true);
        piePlot3D1.setLabelLinksVisible(true);
        java.lang.Object obj10 = piePlot3D1.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot5.setRangeTickBandPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot5.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo10, point2D11);
        xYPlot5.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setRange((double) 0.0f, (double) ' ');
        boolean boolean19 = numberAxis3D15.isAutoTickUnitSelection();
        int int20 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D21.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, xYItemRenderer25);
        boolean boolean27 = numberAxis3D21.isTickLabelsVisible();
        boolean boolean28 = numberAxis3D21.isPositiveArrowVisible();
        java.awt.Stroke stroke29 = numberAxis3D21.getTickMarkStroke();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean8 = piePlot6.equals((java.lang.Object) "XY Plot");
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = ringPlot9.getSimpleLabelOffset();
        double double12 = rectangleInsets10.calculateLeftOutset((double) 10L);
        piePlot6.setLabelPadding(rectangleInsets10);
        double double15 = rectangleInsets10.calculateBottomOutset((double) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.812499999999999d + "'", double12 == 2.812499999999999d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getText();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(blockFrame2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(100);
        double double13 = xYPlot4.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot20.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo25, point2D26);
        xYPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D30.setRange((double) 0.0f, (double) ' ');
        boolean boolean34 = numberAxis3D30.isAutoTickUnitSelection();
        int int35 = xYPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D36.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, xYItemRenderer40);
        xYPlot4.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, false);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace44, false);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation();
        boolean boolean14 = xYPlot4.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange((-1.0d));
        numberAxis0.setInverted(false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        java.lang.Object obj12 = jFreeChart11.clone();
        jFreeChart11.setBackgroundImageAlignment(100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart11.createBufferedImage(0, (int) (short) -1, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot4.setRangeAxisLocation((int) (short) 100, axisLocation8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getRangeAxisEdge();
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge12);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.util.List list8 = categoryPlot0.getCategoriesForAxis(categoryAxis7);
        categoryAxis7.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(100);
        xYPlot4.setWeight(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        int int16 = xYPlot4.getIndexOf(xYItemRenderer15);
        xYPlot4.setRangeCrosshairValue((double) (byte) 1);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) '4', (double) (short) 0);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color16);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color16);
        java.lang.String str19 = color16.toString();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=0,g=128,b=0]" + "'", str19.equals("java.awt.Color[r=0,g=128,b=0]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        textTitle0.setWidth((double) 0.0f);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        java.lang.Object obj8 = piePlot3D6.clone();
        piePlot3D6.setDepthFactor((double) (byte) 1);
        piePlot3D6.setIgnoreNullValues(true);
        piePlot3D6.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D6);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot21.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot21.setInsets(rectangleInsets23, false);
        xYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color33);
        xYPlot21.setBackgroundPaint((java.awt.Paint) color33);
        boolean boolean36 = textTitle16.equals((java.lang.Object) xYPlot21);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent37 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = titleChangeEvent37.getType();
        jFreeChart15.titleChanged(titleChangeEvent37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D40.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font44 = categoryAxis3D40.getTickLabelFont((java.lang.Comparable) numberTickUnit43);
        java.awt.Paint paint46 = categoryAxis3D40.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart15.setBorderPaint(paint46);
        boolean boolean48 = jFreeChart15.isNotify();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = null;
        try {
            java.awt.image.BufferedImage bufferedImage54 = jFreeChart15.createBufferedImage(0, (int) 'a', (int) ' ', chartRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertNotNull(numberTickUnit43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        double double2 = size2D0.height;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot7.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot7.setInsets(rectangleInsets9, false);
        xYPlot7.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot7.getRangeAxis(100);
        double double16 = xYPlot7.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot23.setRangeTickBandPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot23.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo28, point2D29);
        xYPlot23.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D33.setRange((double) 0.0f, (double) ' ');
        boolean boolean37 = numberAxis3D33.isAutoTickUnitSelection();
        int int38 = xYPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D39.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer43);
        xYPlot7.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, false);
        java.lang.Object obj47 = numberAxis3D33.clone();
        boolean boolean48 = size2D0.equals((java.lang.Object) numberAxis3D33);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedWidth(0.2d);
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) (short) 1);
        boolean boolean11 = range9.contains((double) 10L);
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range9, 0.05d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) (short) 1);
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range18, (double) '4', 0.0d);
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range21, (double) 0.5f, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, range13, lengthConstraintType14, (double) (byte) 0, range21, lengthConstraintType25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint5.toRangeHeight(range21);
        double double28 = range21.getLowerBound();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        double double7 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset();
        java.lang.String str9 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker1.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets4.trimHeight((double) (-1L));
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D7.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double17 = rectangleInsets15.calculateLeftInset((double) (short) 10);
        numberAxis3D11.setTickLabelInsets(rectangleInsets15);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle20.setFont(font21);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle20.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double25 = numberAxis3D11.java2DToValue((double) 0.0f, rectangle2D23, rectangleEdge24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot30.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot30.setInsets(rectangleInsets32, false);
        xYPlot30.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot30.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str39 = rectangleEdge38.toString();
        java.util.List list40 = categoryAxis3D7.refreshTicks(graphics2D9, axisState10, rectangle2D23, rectangleEdge38);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets4.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType41, lengthAdjustmentType42);
        java.lang.Class<?> wildcardClass44 = rectangle2D43.getClass();
        try {
            java.util.EventListener[] eventListenerArray45 = valueMarker1.getListeners((java.lang.Class) wildcardClass44);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.geom.Rectangle2D$Double; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.0d) + "'", double6 == (-3.0d));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleEdge.TOP" + "'", str39.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(wildcardClass44);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj3 = textTitle2.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment4, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke9 = numberAxis3D8.getAxisLineStroke();
        boolean boolean10 = flowArrangement7.equals((java.lang.Object) numberAxis3D8);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7);
        java.util.List list12 = blockContainer11.getBlocks();
        projectInfo0.setContributors(list12);
        projectInfo0.addOptionalLibrary("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart11.createBufferedImage(10, (int) (byte) -1, (int) (byte) 100, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setRange((double) 0.0f, (double) ' ');
        numberAxis3D0.resizeRange((double) 0.0f);
        numberAxis3D0.setTickMarkOutsideLength((float) 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot12.zoomDomainAxes((double) (-1.0f), plotRenderingInfo15, point2D16, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot19.zoomDomainAxes((double) (-1.0f), plotRenderingInfo22, point2D23, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        java.lang.String str27 = categoryPlot19.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot32.getDataset();
        java.awt.Stroke stroke34 = xYPlot32.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker38.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer41 = null;
        xYPlot32.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker38, layer41);
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker38, layer43);
        categoryPlot12.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker38);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot12.getRangeAxisLocation();
        xYPlot4.setRangeAxisLocation(100, axisLocation46);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Category Plot" + "'", str27.equals("Category Plot"));
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot5.setRangeTickBandPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot5.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo10, point2D11);
        xYPlot5.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setRange((double) 0.0f, (double) ' ');
        boolean boolean19 = numberAxis3D15.isAutoTickUnitSelection();
        int int20 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D15);
        java.awt.Shape shape21 = numberAxis3D15.getRightArrow();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, polarItemRenderer22);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot4.setRangeAxisLocation((int) (short) 100, axisLocation8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getRangeAxisEdge();
        java.lang.String str13 = rectangleEdge12.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.LEFT" + "'", str13.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot11.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo16, point2D17);
        xYPlot11.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D21.setRange((double) 0.0f, (double) ' ');
        boolean boolean25 = numberAxis3D21.isAutoTickUnitSelection();
        int int26 = xYPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        java.awt.Image image27 = xYPlot11.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot33.getDataset();
        xYPlot33.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYPlot33.rendererChanged(rendererChangeEvent38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot33.getDomainAxisLocation();
        xYPlot11.setDomainAxisLocation((int) (byte) 10, axisLocation40, true);
        boolean boolean43 = piePlot6.equals((java.lang.Object) true);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = piePlot6.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem46 = legendItemCollection44.get((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(legendItemCollection44);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "VerticalAlignment.CENTER", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot15.setInsets(rectangleInsets17, false);
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = blockContainer10.equals((java.lang.Object) xYPlot15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke26 = numberAxis3D25.getAxisLineStroke();
        java.awt.Paint paint27 = numberAxis3D25.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot32.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot32.setInsets(rectangleInsets34, false);
        numberAxis3D25.setTickLabelInsets(rectangleInsets34);
        xYPlot15.setInsets(rectangleInsets34);
        xYPlot15.clearRangeMarkers();
        xYPlot15.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Image image20 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot25.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot25.setInsets(rectangleInsets27, false);
        xYPlot25.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot25.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot25.setBackgroundPaint(paint34);
        xYPlot4.setOutlinePaint(paint34);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D37.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font41 = categoryAxis3D37.getTickLabelFont((java.lang.Comparable) numberTickUnit40);
        java.awt.Paint paint43 = categoryAxis3D37.getTickLabelPaint((java.lang.Comparable) 45.0d);
        xYPlot4.setRangeTickBandPaint(paint43);
        xYPlot4.setRangeCrosshairValue(12.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberTickUnit40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        java.lang.String str5 = basicProjectInfo4.getCopyright();
        java.awt.Image image9 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo13 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.CENTER", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", image9, "XY Plot", "RectangleAnchor.CENTER", "PlotOrientation.VERTICAL");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot15.setInsets(rectangleInsets17, false);
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = blockContainer10.equals((java.lang.Object) xYPlot15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke26 = numberAxis3D25.getAxisLineStroke();
        java.awt.Paint paint27 = numberAxis3D25.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot32.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot32.setInsets(rectangleInsets34, false);
        numberAxis3D25.setTickLabelInsets(rectangleInsets34);
        xYPlot15.setInsets(rectangleInsets34);
        xYPlot15.clearRangeMarkers();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        xYPlot15.markerChanged(markerChangeEvent40);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge();
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryPlot0.setDomainGridlinePaint(paint8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(categoryAnchor10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        float float12 = xYPlot4.getBackgroundImageAlpha();
        java.awt.Image image13 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot18.setInsets(rectangleInsets20, false);
        xYPlot4.setAxisOffset(rectangleInsets20);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot4.rendererChanged(rendererChangeEvent24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNull(image13);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.awt.Paint paint5 = piePlot3D4.getLabelOutlinePaint();
        java.lang.Object obj6 = piePlot3D4.clone();
        piePlot3D4.setDepthFactor((double) (byte) 1);
        piePlot3D4.setIgnoreNullValues(true);
        piePlot3D4.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D4);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot19.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot19.setInsets(rectangleInsets21, false);
        xYPlot19.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot30.setRangeTickBandPaint((java.awt.Paint) color31);
        xYPlot19.setBackgroundPaint((java.awt.Paint) color31);
        boolean boolean34 = textTitle14.equals((java.lang.Object) xYPlot19);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = titleChangeEvent35.getType();
        jFreeChart13.titleChanged(titleChangeEvent35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D38.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font42 = categoryAxis3D38.getTickLabelFont((java.lang.Comparable) numberTickUnit41);
        java.awt.Paint paint44 = categoryAxis3D38.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart13.setBorderPaint(paint44);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj47 = textTitle46.clone();
        textTitle46.setID("{0}");
        double double50 = textTitle46.getHeight();
        org.jfree.chart.event.TitleChangeListener titleChangeListener51 = null;
        textTitle46.removeChangeListener(titleChangeListener51);
        jFreeChart13.addSubtitle((org.jfree.chart.title.Title) textTitle46);
        org.jfree.chart.title.TextTitle textTitle54 = jFreeChart13.getTitle();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart13);
        org.jfree.chart.plot.Plot plot56 = jFreeChart13.getPlot();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(textTitle54);
        org.junit.Assert.assertNotNull(plot56);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D2.setRange((double) 0.0f, (double) ' ');
        boolean boolean6 = numberAxis3D2.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = numberAxis3D2.getDefaultAutoRange();
        boolean boolean8 = numberAxis3D2.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer9);
        boolean boolean11 = polarPlot10.isRangeZoomable();
        java.awt.Stroke stroke12 = polarPlot10.getRadiusGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke12, rectangleInsets13);
        java.awt.Paint paint15 = lineBorder14.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = lineBorder14.getInsets();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot22.setRangeTickBandPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        xYPlot22.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo27, point2D28);
        xYPlot22.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D32.setRange((double) 0.0f, (double) ' ');
        boolean boolean36 = numberAxis3D32.isAutoTickUnitSelection();
        int int37 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        xYPlot22.setFixedDomainAxisSpace(axisSpace38, false);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, valueAxis44, xYItemRenderer45);
        org.jfree.data.xy.XYDataset xYDataset47 = xYPlot46.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot46.setInsets(rectangleInsets48, false);
        java.lang.String str51 = rectangleInsets48.toString();
        double double53 = rectangleInsets48.calculateRightOutset((double) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double56 = rectangleInsets54.trimHeight((double) (-1L));
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D57 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D57.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.axis.AxisState axisState60 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D61 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D61.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double67 = rectangleInsets65.calculateLeftInset((double) (short) 10);
        numberAxis3D61.setTickLabelInsets(rectangleInsets65);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font71 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle70.setFont(font71);
        java.awt.geom.Rectangle2D rectangle2D73 = textTitle70.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double75 = numberAxis3D61.java2DToValue((double) 0.0f, rectangle2D73, rectangleEdge74);
        org.jfree.data.xy.XYDataset xYDataset76 = null;
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer79 = null;
        org.jfree.chart.plot.XYPlot xYPlot80 = new org.jfree.chart.plot.XYPlot(xYDataset76, valueAxis77, valueAxis78, xYItemRenderer79);
        org.jfree.data.xy.XYDataset xYDataset81 = xYPlot80.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot80.setInsets(rectangleInsets82, false);
        xYPlot80.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = xYPlot80.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str89 = rectangleEdge88.toString();
        java.util.List list90 = categoryAxis3D57.refreshTicks(graphics2D59, axisState60, rectangle2D73, rectangleEdge88);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType91 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType92 = null;
        java.awt.geom.Rectangle2D rectangle2D93 = rectangleInsets54.createAdjustedRectangle(rectangle2D73, lengthAdjustmentType91, lengthAdjustmentType92);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType94 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType95 = null;
        java.awt.geom.Rectangle2D rectangle2D96 = rectangleInsets48.createAdjustedRectangle(rectangle2D93, lengthAdjustmentType94, lengthAdjustmentType95);
        xYPlot22.drawBackgroundImage(graphics2D41, rectangle2D96);
        lineBorder14.draw(graphics2D17, rectangle2D96);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(xYDataset47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str51.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-3.0d) + "'", double56 == (-3.0d));
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertEquals((double) double75, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataset81);
        org.junit.Assert.assertNotNull(rectangleInsets82);
        org.junit.Assert.assertNotNull(rectangleEdge88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "RectangleEdge.TOP" + "'", str89.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(list90);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertNotNull(rectangle2D96);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Image image20 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot25.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot25.setInsets(rectangleInsets27, false);
        xYPlot25.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot25.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot25.setBackgroundPaint(paint34);
        xYPlot4.setOutlinePaint(paint34);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D37.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font41 = categoryAxis3D37.getTickLabelFont((java.lang.Comparable) numberTickUnit40);
        java.awt.Paint paint43 = categoryAxis3D37.getTickLabelPaint((java.lang.Comparable) 45.0d);
        xYPlot4.setRangeTickBandPaint(paint43);
        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYPlot4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberTickUnit40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        categoryPlot0.setAnchorValue((double) (short) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot10.getDataset();
        java.awt.Stroke stroke12 = xYPlot10.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot10.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker16.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer19 = null;
        xYPlot10.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker16, layer19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = valueMarker16.getLabelOffsetType();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj23 = textTitle22.clone();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot29.setRangeTickBandPaint((java.awt.Paint) color30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot29.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo34, point2D35);
        xYPlot29.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D39.setRange((double) 0.0f, (double) ' ');
        boolean boolean43 = numberAxis3D39.isAutoTickUnitSelection();
        int int44 = xYPlot29.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D39);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D45.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, xYItemRenderer49);
        boolean boolean51 = textTitle22.equals((java.lang.Object) xYDataset24);
        java.awt.Font font52 = textTitle22.getFont();
        valueMarker16.setLabelFont(font52);
        org.jfree.chart.util.Layer layer54 = null;
        try {
            boolean boolean55 = categoryPlot0.removeDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker16, layer54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font52);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        float float1 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.awt.Stroke stroke2 = categoryAxis3D0.getAxisLineStroke();
        categoryAxis3D0.setCategoryMargin((double) (byte) -1);
        categoryAxis3D0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        textTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle1.setMargin(rectangleInsets5);
        categoryAxis3D0.setLabelInsets(rectangleInsets5);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) '#');
        categoryAxis3D0.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis3D0.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis3D0.getTickLabelInsets();
        double double14 = categoryAxis3D0.getCategoryMargin();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(100);
        double double13 = xYPlot4.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot20.setRangeTickBandPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot20.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo25, point2D26);
        xYPlot20.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D30.setRange((double) 0.0f, (double) ' ');
        boolean boolean34 = numberAxis3D30.isAutoTickUnitSelection();
        int int35 = xYPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D36.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, xYItemRenderer40);
        xYPlot4.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, false);
        java.awt.Paint paint45 = xYPlot4.getQuadrantPaint(0);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNull(paint45);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        java.awt.Stroke stroke6 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        xYPlot4.setRangeGridlinesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot4.setOutlinePaint(paint11);
        int int13 = xYPlot4.getSeriesCount();
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = ringPlot14.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot20.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray22 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot20.setRenderers(xYItemRendererArray22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot20.getDomainMarkers(layer24);
        java.awt.Color color28 = java.awt.Color.getColor("", (int) '#');
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color28);
        ringPlot14.setBaseSectionOutlinePaint((java.awt.Paint) color28);
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color28);
        boolean boolean32 = xYPlot4.isRangeZoomable();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertNotNull(xYItemRendererArray22);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint2 = piePlot3D1.getLabelOutlinePaint();
        int int3 = piePlot3D1.getBackgroundImageAlignment();
        boolean boolean4 = piePlot3D1.getSectionOutlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = piePlot3D1.getLegendItems();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (short) 1);
        boolean boolean4 = range2.contains((double) 10L);
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range2, 0.05d);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range6, range8);
        org.jfree.data.Range range13 = org.jfree.data.Range.shift(range6, 0.2d, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((-3.0d));
        boolean boolean3 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        float float12 = xYPlot4.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        java.awt.Stroke stroke19 = xYPlot17.getDomainZeroBaselineStroke();
        xYPlot4.setRangeGridlineStroke(stroke19);
        xYPlot4.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot4.getDataset(1);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = valueMarker27.getLabelAnchor();
        org.jfree.chart.util.Layer layer29 = null;
        try {
            xYPlot4.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker27, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        categoryPlot0.setAnchorValue((double) (short) 10);
        categoryPlot0.configureRangeAxes();
        java.awt.Color color8 = java.awt.Color.getColor("", (int) '#');
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setSimpleLabels(false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        boolean boolean4 = piePlot3D1.getDarkerSides();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range12, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint15.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D17 = blockContainer10.arrange(graphics2D11, rectangleConstraint15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(size2D17);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        try {
            java.lang.String str5 = jFreeChartResources0.getString("java.awt.Color[r=0,g=128,b=0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=0,g=128,b=0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Category Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        ringPlot0.setCircular(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean9 = standardPieSectionLabelGenerator7.equals((java.lang.Object) textAnchor8);
        java.text.NumberFormat numberFormat10 = standardPieSectionLabelGenerator7.getNumberFormat();
        ringPlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str4 = lengthConstraintType3.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LengthConstraintType.FIXED" + "'", str4.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = rectangleConstraint3.calculateConstrainedSize(size2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = ringPlot1.getLabelGenerator();
        ringPlot1.setCircular(false);
        java.awt.Paint paint7 = ringPlot1.getShadowPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj10 = textTitle9.clone();
        textTitle9.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle9.setMargin(rectangleInsets13);
        categoryAxis3D8.setLabelInsets(rectangleInsets13);
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio((float) '#');
        categoryAxis3D8.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis3D8.getTickLabelInsets();
        ringPlot1.setLabelPadding(rectangleInsets20);
        boolean boolean22 = projectInfo0.equals((java.lang.Object) ringPlot1);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator2);
        double double4 = piePlot3D1.getStartAngle();
        float float5 = piePlot3D1.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot10.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot10.setInsets(rectangleInsets12, false);
        xYPlot10.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color22);
        xYPlot10.setBackgroundPaint((java.awt.Paint) color22);
        java.awt.Stroke stroke25 = xYPlot10.getRangeCrosshairStroke();
        piePlot3D1.setLabelLinkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = null;
        try {
            piePlot3D1.setLabelPadding(rectangleInsets27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        java.awt.Stroke stroke17 = xYPlot15.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot15.getSeriesRenderingOrder();
        xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder18);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot4.getRangeAxisForDataset(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 2 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(100);
        double double13 = xYPlot4.getDomainCrosshairValue();
        xYPlot4.setBackgroundImageAlpha((float) 1L);
        java.awt.Paint paint16 = xYPlot4.getBackgroundPaint();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot15.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo20, point2D21);
        xYPlot15.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setRange((double) 0.0f, (double) ' ');
        boolean boolean29 = numberAxis3D25.isAutoTickUnitSelection();
        int int30 = xYPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        java.awt.Shape shape31 = numberAxis3D25.getRightArrow();
        numberAxis3D25.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis3D25.getTickUnit();
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit34);
        java.awt.Stroke stroke36 = polarPlot9.getAngleGridlineStroke();
        boolean boolean37 = polarPlot9.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        float float12 = xYPlot4.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        java.awt.Stroke stroke19 = xYPlot17.getDomainZeroBaselineStroke();
        xYPlot4.setRangeGridlineStroke(stroke19);
        xYPlot4.mapDatasetToDomainAxis((int) (short) -1, (int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot4.getDomainAxis(10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D26.setRange((double) 0.0f, (double) ' ');
        boolean boolean30 = numberAxis3D26.isAutoTickUnitSelection();
        double double31 = numberAxis3D26.getLowerMargin();
        int int32 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D26);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot4.getLegendItems();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D34.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double40 = rectangleInsets38.calculateLeftInset((double) (short) 10);
        numberAxis3D34.setTickLabelInsets(rectangleInsets38);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font44 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle43.setFont(font44);
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle43.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double48 = numberAxis3D34.java2DToValue((double) 0.0f, rectangle2D46, rectangleEdge47);
        boolean boolean49 = numberAxis3D34.isTickMarksVisible();
        int int50 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D34);
        java.awt.Shape shape51 = numberAxis3D34.getDownArrow();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(shape51);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font4 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) numberTickUnit3);
        categoryAxis3D0.setCategoryMargin(0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot6.setRangeTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot6.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo11, point2D12);
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D16.setRange((double) 0.0f, (double) ' ');
        boolean boolean20 = numberAxis3D16.isAutoTickUnitSelection();
        int int21 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, xYItemRenderer26);
        boolean boolean28 = unitType0.equals((java.lang.Object) numberAxis3D22);
        numberAxis3D22.setAutoRangeMinimumSize(0.2d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D2.setRange((double) 0.0f, (double) ' ');
        boolean boolean6 = numberAxis3D2.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = numberAxis3D2.getDefaultAutoRange();
        boolean boolean8 = numberAxis3D2.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer9);
        boolean boolean11 = polarPlot10.isRangeZoomable();
        java.awt.Stroke stroke12 = polarPlot10.getRadiusGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke12, rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            lineBorder14.draw(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset5, (java.lang.Comparable) (-1), 100.0d, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Stroke stroke11 = piePlot10.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean8 = piePlot6.equals((java.lang.Object) "XY Plot");
        double double9 = piePlot6.getShadowXOffset();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        java.awt.Font font3 = textTitle0.getFont();
        textTitle0.setMargin(4.0d, (double) 100L, (double) 100L, (double) (short) 1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setAngleLabelsVisible(false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getSimpleLabelOffset();
        ringPlot0.setSectionDepth((double) (byte) 10);
        ringPlot0.setLabelLinkMargin((double) (short) -1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator7.setAttributedLabel((int) (byte) 1, attributedString9);
        ringPlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean15 = standardPieSectionLabelGenerator13.equals((java.lang.Object) textAnchor14);
        double[][] doubleArray18 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray18);
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset19, (int) (byte) 0);
        java.text.AttributedString attributedString23 = standardPieSectionLabelGenerator13.generateAttributedSectionLabel(pieDataset21, (java.lang.Comparable) "{0}");
        java.lang.Comparable comparable24 = null;
        try {
            java.lang.String str25 = standardPieSectionLabelGenerator7.generateSectionLabel(pieDataset21, comparable24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertNull(attributedString23);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isRangeZoomable();
        java.lang.String str11 = polarPlot9.getPlotType();
        polarPlot9.clearCornerTextItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        polarPlot9.rendererChanged(rendererChangeEvent13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray6 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getDomainMarkers(layer8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = new org.jfree.chart.LegendItemCollection();
        xYPlot4.setFixedLegendItems(legendItemCollection10);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(xYItemRendererArray6);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        java.lang.Object obj8 = piePlot3D6.clone();
        piePlot3D6.setDepthFactor((double) (byte) 1);
        piePlot3D6.setIgnoreNullValues(true);
        piePlot3D6.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D6);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot21.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot21.setInsets(rectangleInsets23, false);
        xYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color33);
        xYPlot21.setBackgroundPaint((java.awt.Paint) color33);
        boolean boolean36 = textTitle16.equals((java.lang.Object) xYPlot21);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent37 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = titleChangeEvent37.getType();
        jFreeChart15.titleChanged(titleChangeEvent37);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent42 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 10, jFreeChart15, (int) (short) 10, (int) '#');
        jFreeChart15.setTextAntiAlias(false);
        boolean boolean45 = jFreeChart15.isBorderVisible();
        org.jfree.chart.title.LegendTitle legendTitle46 = null;
        try {
            jFreeChart15.addLegend(legendTitle46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearAnnotations();
        java.util.List list7 = categoryPlot5.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot5.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot18.setInsets(rectangleInsets20, false);
        xYPlot18.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot18.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot18.setRangeGridlinePaint(paint27);
        java.awt.geom.Point2D point2D29 = xYPlot18.getQuadrantOrigin();
        categoryPlot5.zoomDomainAxes((-1.0d), plotRenderingInfo13, point2D29, false);
        categoryPlot0.zoomRangeAxes((double) ' ', plotRenderingInfo4, point2D29, false);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        org.jfree.data.xy.XYDataset xYDataset39 = xYPlot38.getDataset();
        xYPlot38.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = null;
        xYPlot38.rendererChanged(rendererChangeEvent43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot38.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation45, true);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset48, valueAxis49, valueAxis50, xYItemRenderer51);
        org.jfree.data.xy.XYDataset xYDataset53 = xYPlot52.getDataset();
        java.awt.Stroke stroke54 = xYPlot52.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder55 = xYPlot52.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker58.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot52.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker58, layer61);
        try {
            boolean boolean63 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(xYDataset39);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNull(xYDataset53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(seriesRenderingOrder55);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle0.setTextAlignment(horizontalAlignment3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        piePlot3D6.setMaximumLabelWidth((double) (byte) 10);
        double double9 = piePlot3D6.getLabelGap();
        java.awt.Font font10 = piePlot3D6.getLabelFont();
        textTitle0.setFont(font10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot6.setInsets(rectangleInsets8, false);
        xYPlot6.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot17.setRangeTickBandPaint((java.awt.Paint) color18);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color18);
        boolean boolean21 = textTitle1.equals((java.lang.Object) xYPlot6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle1.getVerticalAlignment();
        java.awt.Font font23 = textTitle1.getFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.clearAnnotations();
        categoryPlot24.configureDomainAxes();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("Polar Plot", font23, (org.jfree.chart.plot.Plot) categoryPlot24, false);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        java.awt.Stroke stroke6 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker10.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer13 = null;
        xYPlot4.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker10, layer13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = valueMarker10.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = valueMarker10.getLabelOffsetType();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "{0}", numberArray8);
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset9, 0);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(pieDataset11);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setLowerMargin((double) (short) 100);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (short) 100);
        java.awt.Font font6 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "Rotation.CLOCKWISE", "PlotOrientation.VERTICAL");
        java.awt.Shape shape4 = chartEntity3.getArea();
        java.awt.Shape shape5 = chartEntity3.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("java.awt.Color[r=0,g=0,b=0]", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        java.util.List list11 = blockContainer10.getBlocks();
        java.util.List list12 = blockContainer10.getBlocks();
        blockContainer10.clear();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot2.getURLGenerator();
        java.awt.Paint paint4 = piePlot2.getShadowPaint();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj6 = textTitle5.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle5.getVerticalAlignment();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle12.setFont(font13);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle12.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color9.createContext(colorModel10, rectangle11, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj20 = textTitle5.draw(graphics2D8, (java.awt.geom.Rectangle2D) rectangle11, (java.lang.Object) font19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot25.setRangeTickBandPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot25.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo30, point2D31);
        xYPlot25.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D35.setRange((double) 0.0f, (double) ' ');
        boolean boolean39 = numberAxis3D35.isAutoTickUnitSelection();
        int int40 = xYPlot25.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D35);
        java.awt.Shape shape41 = numberAxis3D35.getRightArrow();
        numberAxis3D35.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = null;
        numberAxis3D35.setMarkerBand(markerAxisBand44);
        java.awt.Font font46 = numberAxis3D35.getLabelFont();
        textTitle5.setFont(font46);
        piePlot2.setLabelFont(font46);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=192,g=0,b=0]", font46);
        org.jfree.chart.text.TextFragment textFragment50 = new org.jfree.chart.text.TextFragment("RectangleEdge.TOP", font46);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment3, 0.0d, (double) 100L);
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        boolean boolean11 = columnArrangement6.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        boolean boolean13 = columnArrangement6.equals((java.lang.Object) textBlockAnchor12);
        java.lang.String str14 = textBlockAnchor12.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str14.equals("TextBlockAnchor.TOP_LEFT"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot12.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo17, point2D18);
        xYPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setRange((double) 0.0f, (double) ' ');
        boolean boolean26 = numberAxis3D22.isAutoTickUnitSelection();
        int int27 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D28.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer32);
        org.jfree.data.Range range34 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        java.awt.Paint paint35 = xYPlot4.getRangeGridlinePaint();
        java.lang.Object obj36 = xYPlot4.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge();
        java.lang.String str8 = categoryPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot13.getDataset();
        java.awt.Stroke stroke15 = xYPlot13.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker19.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot13.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker19, layer22);
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker19, layer24);
        boolean boolean26 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        java.awt.Paint paint3 = textTitle0.getPaint();
        java.awt.Font font4 = textTitle0.getFont();
        java.lang.String str5 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = piePlot0.getURLGenerator();
        boolean boolean2 = piePlot0.getSimpleLabels();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot7.setRangeTickBandPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot7.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo12, point2D13);
        xYPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setRange((double) 0.0f, (double) ' ');
        boolean boolean21 = numberAxis3D17.isAutoTickUnitSelection();
        int int22 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D17);
        java.awt.Image image23 = xYPlot7.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot29.getDataset();
        xYPlot29.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYPlot29.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot29.getDomainAxisLocation();
        xYPlot7.setDomainAxisLocation((int) (byte) 10, axisLocation36, true);
        org.jfree.chart.axis.AxisSpace axisSpace39 = xYPlot7.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        xYPlot7.zoomRangeAxes((double) 0L, plotRenderingInfo41, point2D42);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent44 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.JFreeChart jFreeChart45 = plotChangeEvent44.getChart();
        piePlot0.notifyListeners(plotChangeEvent44);
        java.awt.Image image47 = piePlot0.getBackgroundImage();
        org.junit.Assert.assertNull(pieURLGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(axisSpace39);
        org.junit.Assert.assertNull(jFreeChart45);
        org.junit.Assert.assertNull(image47);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle0.setFont(font1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        try {
            textTitle0.setHorizontalAlignment(horizontalAlignment3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        double double5 = rectangleConstraint4.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge();
        java.lang.String str8 = categoryPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot13.getDataset();
        java.awt.Stroke stroke15 = xYPlot13.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker19.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot13.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker19, layer22);
        org.jfree.chart.util.Layer layer24 = null;
        try {
            boolean boolean25 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        java.lang.Object obj12 = jFreeChart11.clone();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot18.setInsets(rectangleInsets20, false);
        xYPlot18.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot29.setRangeTickBandPaint((java.awt.Paint) color30);
        xYPlot18.setBackgroundPaint((java.awt.Paint) color30);
        boolean boolean33 = textTitle13.equals((java.lang.Object) xYPlot18);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent34 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = titleChangeEvent34.getType();
        jFreeChart11.titleChanged(titleChangeEvent34);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType35);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        blockContainer10.setPadding(rectangleInsets11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj14 = textTitle13.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle13.getVerticalAlignment();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle20.setFont(font21);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle20.getBounds();
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color17.createContext(colorModel18, rectangle19, rectangle2D23, affineTransform24, renderingHints25);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj28 = textTitle13.draw(graphics2D16, (java.awt.geom.Rectangle2D) rectangle19, (java.lang.Object) font27);
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        blockContainer10.clear();
        org.jfree.chart.block.Arrangement arrangement31 = blockContainer10.getArrangement();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(arrangement31);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        xYPlot4.setDomainAxis(0, valueAxis14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D17.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D21.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double27 = rectangleInsets25.calculateLeftInset((double) (short) 10);
        numberAxis3D21.setTickLabelInsets(rectangleInsets25);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle30.setFont(font31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double35 = numberAxis3D21.java2DToValue((double) 0.0f, rectangle2D33, rectangleEdge34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot40.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot40.setInsets(rectangleInsets42, false);
        xYPlot40.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = xYPlot40.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str49 = rectangleEdge48.toString();
        java.util.List list50 = categoryAxis3D17.refreshTicks(graphics2D19, axisState20, rectangle2D33, rectangleEdge48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.CrosshairState crosshairState53 = null;
        boolean boolean54 = xYPlot4.render(graphics2D16, rectangle2D33, (int) ' ', plotRenderingInfo52, crosshairState53);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = xYPlot4.getDomainMarkers(1, layer56);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "RectangleEdge.TOP" + "'", str49.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(collection57);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.setAutoTickUnitSelection(false, true);
        numberAxis3D10.setAutoTickUnitSelection(true);
        numberAxis3D10.setPositiveArrowVisible(false);
        numberAxis3D10.setNegativeArrowVisible(false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D21.setRange((double) 0.0f, (double) ' ');
        boolean boolean25 = numberAxis3D21.isAutoTickUnitSelection();
        org.jfree.data.Range range26 = numberAxis3D21.getDefaultAutoRange();
        boolean boolean27 = numberAxis3D21.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer28);
        boolean boolean30 = polarPlot29.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot35.setRangeTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        xYPlot35.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo40, point2D41);
        xYPlot35.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D45.setRange((double) 0.0f, (double) ' ');
        boolean boolean49 = numberAxis3D45.isAutoTickUnitSelection();
        int int50 = xYPlot35.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D45);
        java.awt.Shape shape51 = numberAxis3D45.getRightArrow();
        numberAxis3D45.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit54 = numberAxis3D45.getTickUnit();
        polarPlot29.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit54);
        numberAxis3D10.setTickUnit(numberTickUnit54);
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit54);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(numberTickUnit54);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj10 = textTitle9.clone();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot16.setRangeTickBandPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot16.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo21, point2D22);
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D26.setRange((double) 0.0f, (double) ' ');
        boolean boolean30 = numberAxis3D26.isAutoTickUnitSelection();
        int int31 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D32.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer36);
        boolean boolean38 = textTitle9.equals((java.lang.Object) xYDataset11);
        java.awt.Font font39 = textTitle9.getFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel41 = null;
        java.awt.Rectangle rectangle42 = null;
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font44 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle43.setFont(font44);
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle43.getBounds();
        java.awt.geom.AffineTransform affineTransform47 = null;
        java.awt.RenderingHints renderingHints48 = null;
        java.awt.PaintContext paintContext49 = color40.createContext(colorModel41, rectangle42, rectangle2D46, affineTransform47, renderingHints48);
        org.jfree.chart.text.TextLine textLine50 = new org.jfree.chart.text.TextLine("hi!", font39, (java.awt.Paint) color40);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color40);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(paintContext49);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot6.setRangeTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot6.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo11, point2D12);
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D16.setRange((double) 0.0f, (double) ' ');
        boolean boolean20 = numberAxis3D16.isAutoTickUnitSelection();
        int int21 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        java.awt.Shape shape22 = numberAxis3D16.getRightArrow();
        numberAxis3D16.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis3D16.setMarkerBand(markerAxisBand25);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot0.getRangeMarkers((-1), layer29);
        categoryPlot0.setRangeCrosshairValue((double) (short) 0, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(collection30);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot4.setBackgroundPaint(paint13);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj16 = textTitle15.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle15.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setAutoTickUnitSelection(false, true);
        boolean boolean22 = textTitle15.equals((java.lang.Object) numberAxis3D18);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.setRange((double) 0.0f, (double) ' ');
        boolean boolean28 = numberAxis3D24.isAutoTickUnitSelection();
        org.jfree.data.Range range29 = numberAxis3D24.getDefaultAutoRange();
        boolean boolean30 = numberAxis3D24.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, polarItemRenderer31);
        boolean boolean33 = polarPlot32.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis34 = polarPlot32.getAxis();
        boolean boolean35 = numberAxis3D18.hasListener((java.util.EventListener) polarPlot32);
        boolean boolean36 = numberAxis3D18.getAutoRangeStickyZero();
        int int37 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset38, valueAxis39, valueAxis40, xYItemRenderer41);
        org.jfree.data.xy.XYDataset xYDataset43 = xYPlot42.getDataset();
        java.awt.Stroke stroke44 = xYPlot42.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder45 = xYPlot42.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker48.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer51 = null;
        xYPlot42.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker48, layer51);
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker48);
        java.awt.Paint paint54 = valueMarker48.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = valueMarker48.getLabelAnchor();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(seriesRenderingOrder45);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.Color color1 = java.awt.Color.gray;
        float[] floatArray7 = new float[] { 0.0f, (byte) 10, '4', (short) -1, ' ' };
        float[] floatArray8 = color1.getComponents(floatArray7);
        float[] floatArray9 = color0.getRGBColorComponents(floatArray8);
        float[] floatArray16 = new float[] { 'a', 10L, (-1L), 0.5f, (short) 10, 8 };
        float[] floatArray17 = color0.getColorComponents(floatArray16);
        java.awt.Color color18 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot6.setRangeTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot6.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo11, point2D12);
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D16.setRange((double) 0.0f, (double) ' ');
        boolean boolean20 = numberAxis3D16.isAutoTickUnitSelection();
        int int21 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, xYItemRenderer26);
        boolean boolean28 = unitType0.equals((java.lang.Object) numberAxis3D22);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets(unitType0, 33.0d, (double) 2, (-3.0d), (double) (short) -1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("java.awt.Color[r=0,g=128,b=0]");
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font4 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) numberTickUnit3);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Font font8 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (short) 1);
        boolean boolean4 = range2.contains((double) 10L);
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range2, 0.05d);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range6, range8);
        double double12 = range8.constrain((-3.0d));
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) 100);
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo4.getOptionalLibraries();
        basicProjectInfo4.setInfo("java.awt.Color[r=192,g=0,b=0]");
        basicProjectInfo4.setLicenceName("VerticalAlignment.CENTER");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoTickUnitSelection(false, true);
        numberAxis3D0.setAutoTickUnitSelection(true);
        numberAxis3D0.setPositiveArrowVisible(false);
        org.jfree.data.RangeType rangeType8 = numberAxis3D0.getRangeType();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D0.setUpArrow(shape9);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (byte) 0);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset3);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, (double) 0);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset3);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment3, 0.0d, (double) 100L);
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        boolean boolean11 = columnArrangement6.equals((java.lang.Object) rectangleConstraint10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj13 = textTitle12.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle12.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle12.setTextAlignment(horizontalAlignment15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setAutoTickUnitSelection(false, true);
        numberAxis3D17.setRangeAboutValue((double) (short) 100, (double) '4');
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = numberAxis3D17.getTickUnit();
        columnArrangement6.add((org.jfree.chart.block.Block) textTitle12, (java.lang.Object) numberAxis3D17);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(numberTickUnit24);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        xYPlot4.setFixedLegendItems(legendItemCollection9);
        org.jfree.chart.plot.Plot plot11 = xYPlot4.getRootPlot();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot17.setInsets(rectangleInsets19, false);
        xYPlot17.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot28.setRangeTickBandPaint((java.awt.Paint) color29);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color29);
        boolean boolean32 = textTitle12.equals((java.lang.Object) xYPlot17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = titleChangeEvent33.getType();
        jFreeChart11.titleChanged(titleChangeEvent33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D36.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font40 = categoryAxis3D36.getTickLabelFont((java.lang.Comparable) numberTickUnit39);
        java.awt.Paint paint42 = categoryAxis3D36.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart11.setBorderPaint(paint42);
        boolean boolean44 = jFreeChart11.isNotify();
        java.awt.Image image45 = null;
        jFreeChart11.setBackgroundImage(image45);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(numberTickUnit39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        ringPlot0.setStartAngle((double) (short) 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke1 = numberAxis3D0.getAxisLineStroke();
        java.awt.Paint paint2 = numberAxis3D0.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot7.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot7.setInsets(rectangleInsets9, false);
        numberAxis3D0.setTickLabelInsets(rectangleInsets9);
        numberAxis3D0.setFixedDimension(Double.NaN);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D0.setTickMarkStroke(stroke15);
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude(range18, (double) (short) 1);
        boolean boolean22 = range20.contains((double) 10L);
        org.jfree.data.Range range24 = org.jfree.data.Range.expandToInclude(range20, 0.05d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range27 = null;
        org.jfree.data.Range range29 = org.jfree.data.Range.expandToInclude(range27, (double) (short) 1);
        org.jfree.data.Range range32 = org.jfree.data.Range.expand(range29, (double) '4', 0.0d);
        org.jfree.data.Range range35 = org.jfree.data.Range.shift(range32, (double) 0.5f, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, range24, lengthConstraintType25, (double) (byte) 0, range32, lengthConstraintType36);
        numberAxis3D0.setRangeWithMargins(range24);
        numberAxis3D0.setLowerBound((double) 1L);
        java.awt.Stroke stroke41 = numberAxis3D0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Shape shape20 = numberAxis3D14.getRightArrow();
        numberAxis3D14.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = numberAxis3D14.getTickUnit();
        java.awt.Paint paint24 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean25 = numberAxis3D14.equals((java.lang.Object) paint24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator2);
        double double4 = piePlot3D1.getStartAngle();
        float float5 = piePlot3D1.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot10.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot10.setInsets(rectangleInsets12, false);
        xYPlot10.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color22);
        xYPlot10.setBackgroundPaint((java.awt.Paint) color22);
        java.awt.Stroke stroke25 = xYPlot10.getRangeCrosshairStroke();
        piePlot3D1.setLabelLinkStroke(stroke25);
        java.awt.Paint paint27 = piePlot3D1.getLabelPaint();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        piePlot3D1.setLabelShadowPaint(paint28);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { (short) 10, 1, "RectangleEdge.LEFT", (byte) 10, "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { 15 };
        double[][] doubleArray10 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray10);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray7, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle0.setFont(font1);
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle0.getBounds();
        double double4 = textTitle0.getContentYOffset();
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle0.getFrame();
        textTitle0.setNotify(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        float float1 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        categoryAxis3D0.setCategoryMargin((double) (byte) 0);
        java.lang.Object obj4 = categoryAxis3D0.clone();
        categoryAxis3D0.setMaximumCategoryLabelLines((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke7 = xYPlot4.getDomainGridlineStroke();
        int int8 = xYPlot4.getSeriesCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        java.lang.String str12 = xYPlot4.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot17.setInsets(rectangleInsets19, false);
        xYPlot17.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot17.getRangeAxis(100);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot30.getDataset();
        java.awt.Stroke stroke32 = xYPlot30.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot30.zoomRangeAxes((double) '4', plotRenderingInfo34, point2D35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, valueAxis39, xYItemRenderer40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot41.setRangeTickBandPaint((java.awt.Paint) color42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot41.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo46, point2D47);
        xYPlot41.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D51.setRange((double) 0.0f, (double) ' ');
        boolean boolean55 = numberAxis3D51.isAutoTickUnitSelection();
        int int56 = xYPlot41.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D51);
        java.awt.Image image57 = xYPlot41.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset59, valueAxis60, valueAxis61, xYItemRenderer62);
        org.jfree.data.xy.XYDataset xYDataset64 = xYPlot63.getDataset();
        xYPlot63.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent68 = null;
        xYPlot63.rendererChanged(rendererChangeEvent68);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot63.getDomainAxisLocation();
        xYPlot41.setDomainAxisLocation((int) (byte) 10, axisLocation70, true);
        xYPlot30.setRangeAxisLocation(axisLocation70, false);
        xYPlot17.setRangeAxisLocation(axisLocation70, true);
        org.jfree.chart.axis.AxisLocation axisLocation78 = xYPlot17.getRangeAxisLocation((int) (byte) 100);
        xYPlot4.setRangeAxisLocation(axisLocation78, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNull(image57);
        org.junit.Assert.assertNull(xYDataset64);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(axisLocation78);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isRangeZoomable();
        java.lang.String str11 = polarPlot9.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot9.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Shape shape2 = ringPlot0.getLegendItemShape();
        ringPlot0.setSeparatorsVisible(true);
        ringPlot0.setPieIndex(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint4 = ringPlot0.getBaseSectionOutlinePaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle8.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color5.createContext(colorModel6, rectangle7, rectangle2D11, affineTransform12, renderingHints13);
        java.lang.String str15 = color5.toString();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator17);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str15.equals("java.awt.Color[r=192,g=0,b=0]"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D2.setRange((double) 0.0f, (double) ' ');
        boolean boolean6 = numberAxis3D2.isAutoTickUnitSelection();
        java.awt.Paint paint7 = numberAxis3D2.getTickLabelPaint();
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot13.setRangeTickBandPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot13.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo18, point2D19);
        float float21 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.data.xy.XYDataset xYDataset27 = xYPlot26.getDataset();
        java.awt.Stroke stroke28 = xYPlot26.getDomainZeroBaselineStroke();
        xYPlot13.setRangeGridlineStroke(stroke28);
        numberAxis3D2.setTickMarkStroke(stroke28);
        boolean boolean31 = numberAxis3D2.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setRange((double) 0.0f, (double) ' ');
        boolean boolean4 = numberAxis3D0.isAutoTickUnitSelection();
        double double5 = numberAxis3D0.getUpperMargin();
        java.awt.Paint paint6 = numberAxis3D0.getTickLabelPaint();
        numberAxis3D0.setRangeAboutValue((double) ' ', 100.0d);
        double double10 = numberAxis3D0.getLowerBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D0.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-18.0d) + "'", double10 == (-18.0d));
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setRange((double) 0.0f, (double) ' ');
        boolean boolean4 = numberAxis3D0.isAutoTickUnitSelection();
        java.awt.Paint paint5 = numberAxis3D0.getTickLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomDomainAxes((double) (-1.0f), plotRenderingInfo9, point2D10, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot6.getDomainAxisEdge();
        java.lang.String str14 = categoryPlot6.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot19.getDataset();
        java.awt.Stroke stroke21 = xYPlot19.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker25.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer28 = null;
        xYPlot19.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker25, layer28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25, layer30);
        numberAxis3D0.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        java.lang.Number[] numberArray35 = new java.lang.Number[] {};
        java.lang.Number[] numberArray36 = new java.lang.Number[] {};
        java.lang.Number[] numberArray37 = new java.lang.Number[] {};
        java.lang.Number[] numberArray38 = new java.lang.Number[] {};
        java.lang.Number[] numberArray39 = new java.lang.Number[] {};
        java.lang.Number[] numberArray40 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray35, numberArray36, numberArray37, numberArray38, numberArray39, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "{0}", numberArray41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot6.getRendererForDataset(categoryDataset42);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset42);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets2.trimHeight((double) (-1L));
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D5.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double15 = rectangleInsets13.calculateLeftInset((double) (short) 10);
        numberAxis3D9.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle18.setFont(font19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = numberAxis3D9.java2DToValue((double) 0.0f, rectangle2D21, rectangleEdge22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot28.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot28.setInsets(rectangleInsets30, false);
        xYPlot28.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot28.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str37 = rectangleEdge36.toString();
        java.util.List list38 = categoryAxis3D5.refreshTicks(graphics2D7, axisState8, rectangle2D21, rectangleEdge36);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets2.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType39, lengthAdjustmentType40);
        try {
            ringPlot0.drawOutline(graphics2D1, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleEdge.TOP" + "'", str37.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setMaximumLabelWidth(Double.NaN);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot8.setRangeTickBandPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot8.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo13, point2D14);
        xYPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setRange((double) 0.0f, (double) ' ');
        boolean boolean22 = numberAxis3D18.isAutoTickUnitSelection();
        int int23 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        java.awt.Shape shape24 = numberAxis3D18.getRightArrow();
        numberAxis3D18.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = null;
        numberAxis3D18.setMarkerBand(markerAxisBand27);
        java.awt.Font font29 = numberAxis3D18.getLabelFont();
        ringPlot1.setLabelFont(font29);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("{0}", font29);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean2 = dateRange0.contains(10.0d);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot4.setBackgroundPaint(paint13);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj16 = textTitle15.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle15.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setAutoTickUnitSelection(false, true);
        boolean boolean22 = textTitle15.equals((java.lang.Object) numberAxis3D18);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.setRange((double) 0.0f, (double) ' ');
        boolean boolean28 = numberAxis3D24.isAutoTickUnitSelection();
        org.jfree.data.Range range29 = numberAxis3D24.getDefaultAutoRange();
        boolean boolean30 = numberAxis3D24.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, polarItemRenderer31);
        boolean boolean33 = polarPlot32.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis34 = polarPlot32.getAxis();
        boolean boolean35 = numberAxis3D18.hasListener((java.util.EventListener) polarPlot32);
        boolean boolean36 = numberAxis3D18.getAutoRangeStickyZero();
        int int37 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset38, valueAxis39, valueAxis40, xYItemRenderer41);
        org.jfree.data.xy.XYDataset xYDataset43 = xYPlot42.getDataset();
        java.awt.Stroke stroke44 = xYPlot42.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder45 = xYPlot42.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker48.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer51 = null;
        xYPlot42.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker48, layer51);
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker48);
        java.lang.String str54 = xYPlot4.getPlotType();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(seriesRenderingOrder45);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "XY Plot" + "'", str54.equals("XY Plot"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        piePlot3D1.setLabelLinksVisible(true);
        float float6 = piePlot3D1.getBackgroundImageAlpha();
        piePlot3D1.setDarkerSides(true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertNotNull(strEnumeration4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint2 = piePlot3D1.getLabelOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator3);
        boolean boolean5 = piePlot3D1.getIgnoreNullValues();
        boolean boolean6 = piePlot3D1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge((int) 'a');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        float float6 = categoryAxis3D5.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font8 = categoryAxis3D5.getTickLabelFont((java.lang.Comparable) 1.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        float float10 = categoryAxis3D9.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font12 = categoryAxis3D9.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Paint paint13 = categoryAxis3D9.getTickLabelPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj16 = textTitle15.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle15.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment17, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke22 = numberAxis3D21.getAxisLineStroke();
        boolean boolean23 = flowArrangement20.equals((java.lang.Object) numberAxis3D21);
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot29.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot29.setInsets(rectangleInsets31, false);
        xYPlot29.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot29.getDomainAxisEdge((int) (byte) 100);
        boolean boolean38 = blockContainer24.equals((java.lang.Object) xYPlot29);
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean40 = blockContainer24.equals((java.lang.Object) date39);
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color42 = java.awt.Color.yellow;
        piePlot41.setLabelOutlinePaint((java.awt.Paint) color42);
        categoryAxis3D9.setTickLabelPaint((java.lang.Comparable) date39, (java.awt.Paint) color42);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray45 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D5, categoryAxis3D9 };
        categoryPlot0.setDomainAxes(categoryAxisArray45);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(categoryAxisArray45);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        textTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle1.setMargin(rectangleInsets5);
        categoryAxis3D0.setLabelInsets(rectangleInsets5);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) '#');
        categoryAxis3D0.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis3D0.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis3D0.getTickLabelInsets();
        java.lang.String str15 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) (short) 100);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100, 1.0f, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Image image20 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.data.xy.XYDataset xYDataset27 = xYPlot26.getDataset();
        xYPlot26.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        xYPlot26.rendererChanged(rendererChangeEvent31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot26.getDomainAxisLocation();
        xYPlot4.setDomainAxisLocation((int) (byte) 10, axisLocation33, true);
        org.jfree.chart.axis.AxisSpace axisSpace36 = xYPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot4.zoomRangeAxes((double) 0L, plotRenderingInfo38, point2D39);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        java.awt.Stroke stroke42 = xYPlot4.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray6 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace8, false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot4.getLegendItems();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(xYItemRendererArray6);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double3 = rectangleInsets1.trimHeight((double) (-1L));
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D4.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D8.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double14 = rectangleInsets12.calculateLeftInset((double) (short) 10);
        numberAxis3D8.setTickLabelInsets(rectangleInsets12);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle17.setFont(font18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle17.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double22 = numberAxis3D8.java2DToValue((double) 0.0f, rectangle2D20, rectangleEdge21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot27.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot27.setInsets(rectangleInsets29, false);
        xYPlot27.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot27.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str36 = rectangleEdge35.toString();
        java.util.List list37 = categoryAxis3D4.refreshTicks(graphics2D6, axisState7, rectangle2D20, rectangleEdge35);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets1.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType38, lengthAdjustmentType39);
        java.lang.Class<?> wildcardClass41 = rectangle2D40.getClass();
        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass41);
        java.lang.ClassLoader classLoader43 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass41);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-3.0d) + "'", double3 == (-3.0d));
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleEdge.TOP" + "'", str36.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(classLoader43);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        xYPlot4.notifyListeners(plotChangeEvent6);
        boolean boolean8 = xYPlot4.isOutlineVisible();
        java.awt.Color color9 = java.awt.Color.RED;
        xYPlot4.setBackgroundPaint((java.awt.Paint) color9);
        xYPlot4.clearRangeMarkers();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setRange((double) 0.0f, (double) ' ');
        boolean boolean4 = numberAxis3D0.isAutoTickUnitSelection();
        java.lang.Object obj5 = numberAxis3D0.clone();
        numberAxis3D0.setTickMarkOutsideLength((-1.0f));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray6 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace8, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        xYPlot4.datasetChanged(datasetChangeEvent11);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(xYItemRendererArray6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainGridlinesVisible(false);
        xYPlot4.setBackgroundAlpha((float) (-1));
        xYPlot4.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot4.getRenderer();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(xYItemRenderer14);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot12.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo17, point2D18);
        xYPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setRange((double) 0.0f, (double) ' ');
        boolean boolean26 = numberAxis3D22.isAutoTickUnitSelection();
        int int27 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D28.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer32);
        org.jfree.data.Range range34 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color35);
        int int37 = color35.getAlpha();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle8.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color5.createContext(colorModel6, rectangle7, rectangle2D11, affineTransform12, renderingHints13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj16 = textTitle1.draw(graphics2D4, (java.awt.geom.Rectangle2D) rectangle7, (java.lang.Object) font15);
        java.awt.Paint paint17 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint17, 0.0f, (int) (short) 100, textMeasurer20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock21.draw(graphics2D22, 0.0f, (float) (short) 100, textBlockAnchor25, 0.5f, (float) 8, (-3.0d));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textBlock21.getLineAlignment();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj33 = textTitle32.clone();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot39.setRangeTickBandPaint((java.awt.Paint) color40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot39.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo44, point2D45);
        xYPlot39.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.setRange((double) 0.0f, (double) ' ');
        boolean boolean53 = numberAxis3D49.isAutoTickUnitSelection();
        int int54 = xYPlot39.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D49);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D55.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, (org.jfree.chart.axis.ValueAxis) numberAxis3D55, xYItemRenderer59);
        boolean boolean61 = textTitle32.equals((java.lang.Object) xYDataset34);
        java.awt.Font font62 = textTitle32.getFont();
        java.awt.Color color63 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font67 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle66.setFont(font67);
        java.awt.geom.Rectangle2D rectangle2D69 = textTitle66.getBounds();
        java.awt.geom.AffineTransform affineTransform70 = null;
        java.awt.RenderingHints renderingHints71 = null;
        java.awt.PaintContext paintContext72 = color63.createContext(colorModel64, rectangle65, rectangle2D69, affineTransform70, renderingHints71);
        org.jfree.chart.text.TextLine textLine73 = new org.jfree.chart.text.TextLine("hi!", font62, (java.awt.Paint) color63);
        org.jfree.chart.text.TextFragment textFragment75 = new org.jfree.chart.text.TextFragment("hi!");
        float float76 = textFragment75.getBaselineOffset();
        textLine73.removeFragment(textFragment75);
        textBlock21.addLine(textLine73);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(paintContext72);
        org.junit.Assert.assertTrue("'" + float76 + "' != '" + 0.0f + "'", float76 == 0.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot17.setInsets(rectangleInsets19, false);
        xYPlot17.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot28.setRangeTickBandPaint((java.awt.Paint) color29);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color29);
        boolean boolean32 = textTitle12.equals((java.lang.Object) xYPlot17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = titleChangeEvent33.getType();
        jFreeChart11.titleChanged(titleChangeEvent33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D36.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font40 = categoryAxis3D36.getTickLabelFont((java.lang.Comparable) numberTickUnit39);
        java.awt.Paint paint42 = categoryAxis3D36.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart11.setBorderPaint(paint42);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj45 = textTitle44.clone();
        textTitle44.setID("{0}");
        double double48 = textTitle44.getHeight();
        org.jfree.chart.event.TitleChangeListener titleChangeListener49 = null;
        textTitle44.removeChangeListener(titleChangeListener49);
        jFreeChart11.addSubtitle((org.jfree.chart.title.Title) textTitle44);
        org.jfree.chart.title.TextTitle textTitle52 = jFreeChart11.getTitle();
        double[][] doubleArray55 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray55);
        org.jfree.data.general.PieDataset pieDataset58 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset56, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot(pieDataset58);
        boolean boolean61 = piePlot59.equals((java.lang.Object) "XY Plot");
        org.jfree.chart.plot.RingPlot ringPlot62 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = ringPlot62.getSimpleLabelOffset();
        double double65 = rectangleInsets63.calculateLeftOutset((double) 10L);
        piePlot59.setLabelPadding(rectangleInsets63);
        textTitle52.setMargin(rectangleInsets63);
        double double68 = rectangleInsets63.getLeft();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(numberTickUnit39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(textTitle52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(pieDataset58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 2.812499999999999d + "'", double65 == 2.812499999999999d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.18d + "'", double68 == 0.18d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 'a', (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setRange((double) 0.0f, (double) ' ');
        boolean boolean8 = numberAxis3D4.isAutoTickUnitSelection();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint2.toRangeHeight(range9);
        boolean boolean12 = range9.contains((double) 8);
        double double13 = range9.getUpperBound();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot10.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo15, point2D16);
        xYPlot10.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setRange((double) 0.0f, (double) ' ');
        boolean boolean24 = numberAxis3D20.isAutoTickUnitSelection();
        int int25 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D26.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer30);
        boolean boolean32 = textTitle3.equals((java.lang.Object) xYDataset5);
        java.awt.Font font33 = textTitle3.getFont();
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle37.setFont(font38);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle37.getBounds();
        java.awt.geom.AffineTransform affineTransform41 = null;
        java.awt.RenderingHints renderingHints42 = null;
        java.awt.PaintContext paintContext43 = color34.createContext(colorModel35, rectangle36, rectangle2D40, affineTransform41, renderingHints42);
        org.jfree.chart.text.TextLine textLine44 = new org.jfree.chart.text.TextLine("hi!", font33, (java.awt.Paint) color34);
        boolean boolean45 = ringPlot0.equals((java.lang.Object) textLine44);
        ringPlot0.setInnerSeparatorExtension((double) 8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(paintContext43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        xYPlot18.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        xYPlot18.axisChanged(axisChangeEvent23);
        java.awt.geom.Point2D point2D25 = xYPlot18.getQuadrantOrigin();
        polarPlot9.zoomDomainAxes((double) 0L, plotRenderingInfo13, point2D25);
        java.awt.Color color27 = java.awt.Color.lightGray;
        int int28 = color27.getRed();
        polarPlot9.setRadiusGridlinePaint((java.awt.Paint) color27);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot34.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot34.setInsets(rectangleInsets36, false);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        xYPlot34.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = xYPlot34.getOrientation();
        double double42 = xYPlot34.getDomainCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        xYPlot34.setFixedDomainAxisSpace(axisSpace43);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D(pieDataset45);
        piePlot3D46.setMaximumLabelWidth((double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D51 = new org.jfree.chart.plot.PiePlot3D(pieDataset50);
        java.awt.Paint paint52 = piePlot3D51.getLabelOutlinePaint();
        java.lang.Object obj53 = piePlot3D51.clone();
        piePlot3D51.setDepthFactor((double) (byte) 1);
        piePlot3D51.setIgnoreNullValues(true);
        piePlot3D51.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart60 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D51);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset62, valueAxis63, valueAxis64, xYItemRenderer65);
        org.jfree.data.xy.XYDataset xYDataset67 = xYPlot66.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot66.setInsets(rectangleInsets68, false);
        xYPlot66.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot(xYDataset73, valueAxis74, valueAxis75, xYItemRenderer76);
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot77.setRangeTickBandPaint((java.awt.Paint) color78);
        xYPlot66.setBackgroundPaint((java.awt.Paint) color78);
        boolean boolean81 = textTitle61.equals((java.lang.Object) xYPlot66);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent82 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle61);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType83 = titleChangeEvent82.getType();
        jFreeChart60.titleChanged(titleChangeEvent82);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent87 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 10, jFreeChart60, (int) (short) 10, (int) '#');
        jFreeChart60.setTextAntiAlias(false);
        xYPlot34.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart60);
        boolean boolean91 = color27.equals((java.lang.Object) jFreeChart60);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 192 + "'", int28 == 192);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNull(xYDataset67);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType83);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setAutoTickUnitSelection(false, true);
        boolean boolean7 = textTitle0.equals((java.lang.Object) numberAxis3D3);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setRange((double) 0.0f, (double) ' ');
        boolean boolean13 = numberAxis3D9.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = numberAxis3D9.getDefaultAutoRange();
        boolean boolean15 = numberAxis3D9.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer16);
        boolean boolean18 = polarPlot17.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot17.getAxis();
        boolean boolean20 = numberAxis3D3.hasListener((java.util.EventListener) polarPlot17);
        java.awt.Stroke stroke21 = polarPlot17.getAngleGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        polarPlot17.setDataset(xYDataset22);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets4.calculateLeftInset((double) (short) 10);
        numberAxis3D0.setTickLabelInsets(rectangleInsets4);
        numberAxis3D0.setLabelURL("");
        java.awt.Stroke stroke10 = numberAxis3D0.getAxisLineStroke();
        numberAxis3D0.setRange((double) (-1), (double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj3 = textTitle2.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment4, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke9 = numberAxis3D8.getAxisLineStroke();
        boolean boolean10 = flowArrangement7.equals((java.lang.Object) numberAxis3D8);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7);
        java.util.List list12 = blockContainer11.getBlocks();
        projectInfo0.setContributors(list12);
        projectInfo0.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot12.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo17, point2D18);
        xYPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setRange((double) 0.0f, (double) ' ');
        boolean boolean26 = numberAxis3D22.isAutoTickUnitSelection();
        int int27 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D28.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer32);
        org.jfree.data.Range range34 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot4.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D37.setLabelPaint((java.awt.Paint) color38);
        int int40 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D37);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str1.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot15.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo20, point2D21);
        xYPlot15.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setRange((double) 0.0f, (double) ' ');
        boolean boolean29 = numberAxis3D25.isAutoTickUnitSelection();
        int int30 = xYPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        java.awt.Shape shape31 = numberAxis3D25.getRightArrow();
        numberAxis3D25.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis3D25.getTickUnit();
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit34);
        polarPlot9.setRadiusGridlinesVisible(true);
        java.awt.Font font38 = polarPlot9.getAngleLabelFont();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit34);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot17.setInsets(rectangleInsets19, false);
        xYPlot17.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot28.setRangeTickBandPaint((java.awt.Paint) color29);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color29);
        boolean boolean32 = textTitle12.equals((java.lang.Object) xYPlot17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = titleChangeEvent33.getType();
        jFreeChart11.titleChanged(titleChangeEvent33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D36.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font40 = categoryAxis3D36.getTickLabelFont((java.lang.Comparable) numberTickUnit39);
        java.awt.Paint paint42 = categoryAxis3D36.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart11.setBorderPaint(paint42);
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        ringPlot44.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = ringPlot44.getLabelGenerator();
        try {
            jFreeChart11.setTextAntiAlias((java.lang.Object) ringPlot44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.RingPlot@5c7c9ab2 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(numberTickUnit39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator47);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        java.awt.Paint paint6 = xYPlot4.getDomainTickBandPaint();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot5.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot5.setInsets(rectangleInsets7, false);
        xYPlot5.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot16.setRangeTickBandPaint((java.awt.Paint) color17);
        xYPlot5.setBackgroundPaint((java.awt.Paint) color17);
        boolean boolean20 = textTitle0.equals((java.lang.Object) xYPlot5);
        xYPlot5.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot8.getDataset();
        java.awt.Stroke stroke10 = xYPlot8.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot8.zoomRangeAxes((double) '4', plotRenderingInfo12, point2D13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot19.setRangeTickBandPaint((java.awt.Paint) color20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot19.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo24, point2D25);
        xYPlot19.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D29.setRange((double) 0.0f, (double) ' ');
        boolean boolean33 = numberAxis3D29.isAutoTickUnitSelection();
        int int34 = xYPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D29);
        java.awt.Image image35 = xYPlot19.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, valueAxis39, xYItemRenderer40);
        org.jfree.data.xy.XYDataset xYDataset42 = xYPlot41.getDataset();
        xYPlot41.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        xYPlot41.rendererChanged(rendererChangeEvent46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot41.getDomainAxisLocation();
        xYPlot19.setDomainAxisLocation((int) (byte) 10, axisLocation48, true);
        xYPlot8.setRangeAxisLocation(axisLocation48, false);
        categoryPlot0.setDomainAxisLocation(10, axisLocation48, true);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 10, (int) (short) 100, plotRenderingInfo59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNull(image35);
        org.junit.Assert.assertNull(xYDataset42);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNull(valueAxis56);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) "{0}");
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        piePlot3D1.setMinimumArcAngleToDraw((double) (short) 10);
        java.awt.Paint paint6 = piePlot3D1.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("Category Plot");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        xYPlot4.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot4.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        int int12 = xYPlot4.getIndexOf(xYItemRenderer11);
        xYPlot4.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItemCollection4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean2 = multiplePiePlot0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "java.awt.Color[r=0,g=128,b=0]");
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        double double4 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint2 = piePlot3D1.getLabelOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot7.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot7.setInsets(rectangleInsets9, false);
        xYPlot7.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot7.getRangeAxis(100);
        java.awt.Stroke stroke16 = xYPlot7.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot21.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo26, point2D27);
        xYPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D31.setRange((double) 0.0f, (double) ' ');
        boolean boolean35 = numberAxis3D31.isAutoTickUnitSelection();
        int int36 = xYPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        int int37 = xYPlot21.getSeriesCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = xYPlot21.getInsets();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder(paint2, stroke16, rectangleInsets38);
        java.lang.String str40 = rectangleInsets38.toString();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str40.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "{0}", numberArray8);
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset9, 0);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.Rotation rotation1 = ringPlot0.getDirection();
        double double2 = ringPlot0.getSectionDepth();
        int int3 = ringPlot0.getPieIndex();
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        java.lang.String str12 = xYPlot4.getPlotType();
        xYPlot4.setBackgroundAlpha(100.0f);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot4.getRangeMarkers(0, layer16);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        java.util.List list7 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection3 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot15.setInsets(rectangleInsets17, false);
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = blockContainer10.equals((java.lang.Object) xYPlot15);
        java.lang.Object obj25 = blockContainer10.clone();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot31.setRangeTickBandPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot31.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo36, point2D37);
        xYPlot31.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D41.setRange((double) 0.0f, (double) ' ');
        boolean boolean45 = numberAxis3D41.isAutoTickUnitSelection();
        int int46 = xYPlot31.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D41);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D47.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis3D47, xYItemRenderer51);
        numberAxis3D41.setLabelAngle(90.0d);
        numberAxis3D41.setAutoRangeStickyZero(false);
        boolean boolean57 = blockContainer10.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setAutoTickUnitSelection(false, true);
        boolean boolean7 = textTitle0.equals((java.lang.Object) numberAxis3D3);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setRange((double) 0.0f, (double) ' ');
        boolean boolean13 = numberAxis3D9.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = numberAxis3D9.getDefaultAutoRange();
        boolean boolean15 = numberAxis3D9.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer16);
        boolean boolean18 = polarPlot17.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot17.getAxis();
        boolean boolean20 = numberAxis3D3.hasListener((java.util.EventListener) polarPlot17);
        polarPlot17.removeCornerTextItem("Polar Plot");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D26.setRange((double) 0.0f, (double) ' ');
        boolean boolean30 = numberAxis3D26.isAutoTickUnitSelection();
        org.jfree.data.Range range31 = numberAxis3D26.getDefaultAutoRange();
        boolean boolean32 = numberAxis3D26.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, polarItemRenderer33);
        boolean boolean35 = polarPlot34.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis36 = polarPlot34.getAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset39, valueAxis40, valueAxis41, xYItemRenderer42);
        org.jfree.data.xy.XYDataset xYDataset44 = xYPlot43.getDataset();
        xYPlot43.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = null;
        xYPlot43.axisChanged(axisChangeEvent48);
        java.awt.geom.Point2D point2D50 = xYPlot43.getQuadrantOrigin();
        polarPlot34.zoomDomainAxes((double) 0L, plotRenderingInfo38, point2D50);
        polarPlot17.zoomDomainAxes((double) 10L, plotRenderingInfo24, point2D50);
        org.jfree.data.xy.XYDataset xYDataset53 = polarPlot17.getDataset();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertNull(xYDataset53);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("{0}", "");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setAutoTickUnitSelection(false, true);
        boolean boolean7 = textTitle0.equals((java.lang.Object) numberAxis3D3);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setRange((double) 0.0f, (double) ' ');
        boolean boolean13 = numberAxis3D9.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = numberAxis3D9.getDefaultAutoRange();
        boolean boolean15 = numberAxis3D9.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer16);
        boolean boolean18 = polarPlot17.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot17.getAxis();
        boolean boolean20 = numberAxis3D3.hasListener((java.util.EventListener) polarPlot17);
        boolean boolean21 = polarPlot17.isDomainZoomable();
        polarPlot17.setAngleLabelsVisible(true);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot28.setRangeTickBandPaint((java.awt.Paint) color29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot28.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo33, point2D34);
        xYPlot28.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D38.setRange((double) 0.0f, (double) ' ');
        boolean boolean42 = numberAxis3D38.isAutoTickUnitSelection();
        int int43 = xYPlot28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D38);
        java.awt.Shape shape44 = numberAxis3D38.getRightArrow();
        numberAxis3D38.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis3D38.setMarkerBand(markerAxisBand47);
        org.jfree.data.Range range49 = polarPlot17.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D38);
        polarPlot17.setAngleLabelsVisible(true);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        xYPlot4.setFixedLegendItems(legendItemCollection9);
        java.awt.Stroke stroke11 = xYPlot4.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (byte) 0);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset3);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, (double) 0);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset3);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        polarPlot9.removeCornerTextItem("TextBlockAnchor.TOP_LEFT");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot15.setInsets(rectangleInsets17, false);
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = blockContainer10.equals((java.lang.Object) xYPlot15);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D(pieDataset25);
        java.awt.Paint paint27 = piePlot3D26.getLabelOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot32.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot32.setInsets(rectangleInsets34, false);
        xYPlot32.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot32.getRangeAxis(100);
        java.awt.Stroke stroke41 = xYPlot32.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, valueAxis44, xYItemRenderer45);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot46.setRangeTickBandPaint((java.awt.Paint) color47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        xYPlot46.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo51, point2D52);
        xYPlot46.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D56.setRange((double) 0.0f, (double) ' ');
        boolean boolean60 = numberAxis3D56.isAutoTickUnitSelection();
        int int61 = xYPlot46.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D56);
        int int62 = xYPlot46.getSeriesCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = xYPlot46.getInsets();
        org.jfree.chart.block.LineBorder lineBorder64 = new org.jfree.chart.block.LineBorder(paint27, stroke41, rectangleInsets63);
        blockContainer10.setFrame((org.jfree.chart.block.BlockFrame) lineBorder64);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets63);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint2 = piePlot3D1.getLabelOutlinePaint();
        int int3 = piePlot3D1.getBackgroundImageAlignment();
        boolean boolean4 = piePlot3D1.getSectionOutlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeZeroBaselinePaint(paint10);
        boolean boolean12 = piePlot3D1.equals((java.lang.Object) xYPlot9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint4 = ringPlot0.getBaseSectionOutlinePaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle8.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color5.createContext(colorModel6, rectangle7, rectangle2D11, affineTransform12, renderingHints13);
        java.lang.String str15 = color5.toString();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color5);
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle21.setFont(font22);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle21.getBounds();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot29.setRangeTickBandPaint((java.awt.Paint) color30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot37.setRangeTickBandPaint((java.awt.Paint) color38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        xYPlot37.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo42, point2D43);
        xYPlot37.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D47.setRange((double) 0.0f, (double) ' ');
        boolean boolean51 = numberAxis3D47.isAutoTickUnitSelection();
        int int52 = xYPlot37.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D53.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis3D47, (org.jfree.chart.axis.ValueAxis) numberAxis3D53, xYItemRenderer57);
        org.jfree.data.Range range59 = xYPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D47);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = xYPlot29.getRangeAxisEdge();
        double double61 = numberAxis3D19.valueToJava2D(0.0d, rectangle2D24, rectangleEdge60);
        java.awt.geom.AffineTransform affineTransform62 = null;
        java.awt.RenderingHints renderingHints63 = null;
        java.awt.PaintContext paintContext64 = color5.createContext(colorModel17, rectangle18, rectangle2D24, affineTransform62, renderingHints63);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str15.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext64);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot4.setRangeGridlinePaint(paint13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot4.setDomainCrosshairPaint(paint15);
        xYPlot4.setRangeCrosshairVisible(false);
        java.lang.String str19 = xYPlot4.getPlotType();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "XY Plot" + "'", str19.equals("XY Plot"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        java.awt.Stroke stroke6 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker10.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer13 = null;
        xYPlot4.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker10, layer13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = valueMarker10.getLabelOffsetType();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj17 = textTitle16.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot23.setRangeTickBandPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot23.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo28, point2D29);
        xYPlot23.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D33.setRange((double) 0.0f, (double) ' ');
        boolean boolean37 = numberAxis3D33.isAutoTickUnitSelection();
        int int38 = xYPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D39.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer43);
        boolean boolean45 = textTitle16.equals((java.lang.Object) xYDataset18);
        java.awt.Font font46 = textTitle16.getFont();
        valueMarker10.setLabelFont(font46);
        java.awt.Paint paint48 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        valueMarker10.setOutlinePaint(paint48);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot15.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo20, point2D21);
        xYPlot15.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setRange((double) 0.0f, (double) ' ');
        boolean boolean29 = numberAxis3D25.isAutoTickUnitSelection();
        int int30 = xYPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        java.awt.Shape shape31 = numberAxis3D25.getRightArrow();
        numberAxis3D25.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis3D25.getTickUnit();
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit34);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D(pieDataset36);
        java.awt.Paint paint38 = piePlot3D37.getLabelOutlinePaint();
        polarPlot9.setRadiusGridlinePaint(paint38);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot9.setRadiusGridlineStroke(stroke40);
        polarPlot9.clearCornerTextItems();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot15.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo20, point2D21);
        xYPlot15.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setRange((double) 0.0f, (double) ' ');
        boolean boolean29 = numberAxis3D25.isAutoTickUnitSelection();
        int int30 = xYPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        java.awt.Shape shape31 = numberAxis3D25.getRightArrow();
        numberAxis3D25.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis3D25.getTickUnit();
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = polarPlot9.getAxis();
        org.jfree.data.Range range37 = valueAxis36.getRange();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit34);
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        piePlot3D1.setMinimumArcAngleToDraw((double) (short) 10);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3D1.getToolTipGenerator();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor(192);
        pieLabelDistributor8.clear();
        piePlot3D1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle7.setFont(font8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color4.createContext(colorModel5, rectangle6, rectangle2D10, affineTransform11, renderingHints12);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj15 = textTitle0.draw(graphics2D3, (java.awt.geom.Rectangle2D) rectangle6, (java.lang.Object) font14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        float float4 = categoryAxis3D3.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font6 = categoryAxis3D3.getTickLabelFont((java.lang.Comparable) 1.0d);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D3);
        java.awt.Stroke stroke8 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedHeight();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setRange((double) 0.0f, (double) ' ');
        boolean boolean15 = numberAxis3D11.isAutoTickUnitSelection();
        xYPlot9.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        double double17 = numberAxis3D11.getLowerBound();
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude(range18, (double) (short) 1);
        boolean boolean22 = range20.contains((double) 10L);
        numberAxis3D11.setRange(range20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint4.toRangeWidth(range20);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setRange((double) 0.0f, (double) ' ');
        boolean boolean5 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        boolean boolean7 = numberAxis3D1.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot18.setInsets(rectangleInsets20, false);
        xYPlot18.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot18.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot18.setBackgroundPaint(paint27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj30 = textTitle29.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = textTitle29.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D32.setAutoTickUnitSelection(false, true);
        boolean boolean36 = textTitle29.equals((java.lang.Object) numberAxis3D32);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D38.setRange((double) 0.0f, (double) ' ');
        boolean boolean42 = numberAxis3D38.isAutoTickUnitSelection();
        org.jfree.data.Range range43 = numberAxis3D38.getDefaultAutoRange();
        boolean boolean44 = numberAxis3D38.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, polarItemRenderer45);
        boolean boolean47 = polarPlot46.isAngleLabelsVisible();
        org.jfree.chart.axis.ValueAxis valueAxis48 = polarPlot46.getAxis();
        boolean boolean49 = numberAxis3D32.hasListener((java.util.EventListener) polarPlot46);
        boolean boolean50 = numberAxis3D32.getAutoRangeStickyZero();
        int int51 = xYPlot18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset54, valueAxis55, valueAxis56, xYItemRenderer57);
        org.jfree.data.xy.XYDataset xYDataset59 = xYPlot58.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot58.setInsets(rectangleInsets60, false);
        xYPlot58.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot58.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot58.setRangeGridlinePaint(paint67);
        java.awt.geom.Point2D point2D69 = xYPlot58.getQuadrantOrigin();
        xYPlot18.zoomRangeAxes((double) (byte) 1, plotRenderingInfo53, point2D69, true);
        polarPlot9.zoomRangeAxes((double) '#', plotRenderingInfo13, point2D69, false);
        polarPlot9.addCornerTextItem("PlotOrientation.VERTICAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D76 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D76.clearCategoryLabelToolTips();
        java.awt.Paint paint78 = categoryAxis3D76.getLabelPaint();
        polarPlot9.setAngleGridlinePaint(paint78);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNull(xYDataset59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(point2D69);
        org.junit.Assert.assertNotNull(paint78);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        xYPlot4.setFixedLegendItems(legendItemCollection9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot4.getOrientation();
        double double12 = xYPlot4.getDomainCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D(pieDataset15);
        piePlot3D16.setMaximumLabelWidth((double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        java.awt.Paint paint22 = piePlot3D21.getLabelOutlinePaint();
        java.lang.Object obj23 = piePlot3D21.clone();
        piePlot3D21.setDepthFactor((double) (byte) 1);
        piePlot3D21.setIgnoreNullValues(true);
        piePlot3D21.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D21);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = xYPlot36.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot36.setInsets(rectangleInsets38, false);
        xYPlot36.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, valueAxis45, xYItemRenderer46);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot47.setRangeTickBandPaint((java.awt.Paint) color48);
        xYPlot36.setBackgroundPaint((java.awt.Paint) color48);
        boolean boolean51 = textTitle31.equals((java.lang.Object) xYPlot36);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent52 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle31);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType53 = titleChangeEvent52.getType();
        jFreeChart30.titleChanged(titleChangeEvent52);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent57 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 10, jFreeChart30, (int) (short) 10, (int) '#');
        jFreeChart30.setTextAntiAlias(false);
        xYPlot4.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        xYPlot4.setRenderer(xYItemRenderer61);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType53);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setMaximumLabelWidth(Double.NaN);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot7.setRangeTickBandPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot7.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo12, point2D13);
        xYPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setRange((double) 0.0f, (double) ' ');
        boolean boolean21 = numberAxis3D17.isAutoTickUnitSelection();
        int int22 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D17);
        java.awt.Shape shape23 = numberAxis3D17.getRightArrow();
        numberAxis3D17.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis3D17.setMarkerBand(markerAxisBand26);
        java.awt.Font font28 = numberAxis3D17.getLabelFont();
        ringPlot0.setLabelFont(font28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = ringPlot0.getSimpleLabelOffset();
        boolean boolean31 = ringPlot0.getIgnoreNullValues();
        double double32 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0E-5d + "'", double32 == 1.0E-5d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight(0.0d);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        size2D5.height = (-3.0d);
        org.jfree.chart.util.Size2D size2D8 = rectangleConstraint4.calculateConstrainedSize(size2D5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        size2D9.height = (-3.0d);
        org.jfree.chart.util.Size2D size2D12 = rectangleConstraint4.calculateConstrainedSize(size2D9);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (short) 1);
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range2, (double) '4', 0.0d);
        java.lang.String str6 = range5.toString();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Range[1.0,1.0]" + "'", str6.equals("Range[1.0,1.0]"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot2.getURLGenerator();
        java.awt.Paint paint4 = piePlot2.getShadowPaint();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj6 = textTitle5.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle5.getVerticalAlignment();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle12.setFont(font13);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle12.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color9.createContext(colorModel10, rectangle11, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj20 = textTitle5.draw(graphics2D8, (java.awt.geom.Rectangle2D) rectangle11, (java.lang.Object) font19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot25.setRangeTickBandPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot25.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo30, point2D31);
        xYPlot25.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D35.setRange((double) 0.0f, (double) ' ');
        boolean boolean39 = numberAxis3D35.isAutoTickUnitSelection();
        int int40 = xYPlot25.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D35);
        java.awt.Shape shape41 = numberAxis3D35.getRightArrow();
        numberAxis3D35.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = null;
        numberAxis3D35.setMarkerBand(markerAxisBand44);
        java.awt.Font font46 = numberAxis3D35.getLabelFont();
        textTitle5.setFont(font46);
        piePlot2.setLabelFont(font46);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=192,g=0,b=0]", font46);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset50, valueAxis51, valueAxis52, xYItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset55 = xYPlot54.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot54.setInsets(rectangleInsets56, false);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset59, valueAxis60, valueAxis61, xYItemRenderer62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot63.setRangeTickBandPaint((java.awt.Paint) color64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        xYPlot63.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo68, point2D69);
        float float71 = xYPlot63.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer75 = null;
        org.jfree.chart.plot.XYPlot xYPlot76 = new org.jfree.chart.plot.XYPlot(xYDataset72, valueAxis73, valueAxis74, xYItemRenderer75);
        org.jfree.data.xy.XYDataset xYDataset77 = xYPlot76.getDataset();
        java.awt.Stroke stroke78 = xYPlot76.getDomainZeroBaselineStroke();
        xYPlot63.setRangeGridlineStroke(stroke78);
        java.awt.Paint paint80 = xYPlot63.getDomainCrosshairPaint();
        org.jfree.chart.block.BlockBorder blockBorder81 = new org.jfree.chart.block.BlockBorder(rectangleInsets56, paint80);
        org.jfree.chart.text.TextBlock textBlock82 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=192,g=0,b=0]", font46, paint80);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNull(xYDataset55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + float71 + "' != '" + 0.5f + "'", float71 == 0.5f);
        org.junit.Assert.assertNull(xYDataset77);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(textBlock82);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setRange((double) 0.0f, (double) ' ');
        boolean boolean9 = numberAxis3D5.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = numberAxis3D5.getDefaultAutoRange();
        boolean boolean11 = numberAxis3D5.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer12);
        boolean boolean14 = polarPlot13.isRangeZoomable();
        java.awt.Stroke stroke15 = polarPlot13.getRadiusGridlineStroke();
        ringPlot0.setBaseSectionOutlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        double double18 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        java.awt.Paint paint9 = xYPlot4.getDomainTickBandPaint();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setMaximumLabelWidth((double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Paint paint7 = piePlot3D6.getLabelOutlinePaint();
        java.lang.Object obj8 = piePlot3D6.clone();
        piePlot3D6.setDepthFactor((double) (byte) 1);
        piePlot3D6.setIgnoreNullValues(true);
        piePlot3D6.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D6);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot21.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot21.setInsets(rectangleInsets23, false);
        xYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color33);
        xYPlot21.setBackgroundPaint((java.awt.Paint) color33);
        boolean boolean36 = textTitle16.equals((java.lang.Object) xYPlot21);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent37 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = titleChangeEvent37.getType();
        jFreeChart15.titleChanged(titleChangeEvent37);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent42 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 10, jFreeChart15, (int) (short) 10, (int) '#');
        jFreeChart15.setTextAntiAlias(false);
        boolean boolean45 = jFreeChart15.isBorderVisible();
        org.jfree.chart.event.ChartChangeListener chartChangeListener46 = null;
        try {
            jFreeChart15.addChangeListener(chartChangeListener46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle8.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color5.createContext(colorModel6, rectangle7, rectangle2D11, affineTransform12, renderingHints13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj16 = textTitle1.draw(graphics2D4, (java.awt.geom.Rectangle2D) rectangle7, (java.lang.Object) font15);
        java.awt.Paint paint17 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint17, 0.0f, (int) (short) 100, textMeasurer20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock21.draw(graphics2D22, 0.0f, (float) (short) 100, textBlockAnchor25, 0.5f, (float) 8, (-3.0d));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textBlock21.getLineAlignment();
        org.jfree.chart.text.TextLine textLine31 = textBlock21.getLastLine();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNull(textLine31);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot6.setRangeTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot6.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo11, point2D12);
        xYPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D16.setRange((double) 0.0f, (double) ' ');
        boolean boolean20 = numberAxis3D16.isAutoTickUnitSelection();
        int int21 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        java.awt.Shape shape22 = numberAxis3D16.getRightArrow();
        numberAxis3D16.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis3D16.setMarkerBand(markerAxisBand25);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace28);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        java.lang.Object obj12 = jFreeChart11.clone();
        java.lang.Object obj13 = jFreeChart11.getTextAntiAlias();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge();
        java.lang.String str8 = categoryPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot13.getDataset();
        java.awt.Stroke stroke15 = xYPlot13.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker19.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot13.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker19, layer22);
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker19, layer24);
        categoryPlot0.setRangeCrosshairValue(33.0d, false);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(valueAxis31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        float float4 = categoryAxis3D3.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font6 = categoryAxis3D3.getTickLabelFont((java.lang.Comparable) 1.0d);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D3);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot8.setRangeTickBandPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot8.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo13, point2D14);
        xYPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setRange((double) 0.0f, (double) ' ');
        boolean boolean22 = numberAxis3D18.isAutoTickUnitSelection();
        int int23 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, xYItemRenderer28);
        boolean boolean30 = textTitle1.equals((java.lang.Object) xYDataset3);
        java.awt.Font font31 = textTitle1.getFont();
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel33 = null;
        java.awt.Rectangle rectangle34 = null;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font36 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle35.setFont(font36);
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle35.getBounds();
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color32.createContext(colorModel33, rectangle34, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("hi!", font31, (java.awt.Paint) color32);
        org.jfree.chart.text.TextFragment textFragment44 = new org.jfree.chart.text.TextFragment("hi!");
        float float45 = textFragment44.getBaselineOffset();
        textLine42.removeFragment(textFragment44);
        java.awt.Graphics2D graphics2D47 = null;
        try {
            org.jfree.chart.util.Size2D size2D48 = textFragment44.calculateDimensions(graphics2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot10.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo15, point2D16);
        xYPlot10.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setRange((double) 0.0f, (double) ' ');
        boolean boolean24 = numberAxis3D20.isAutoTickUnitSelection();
        int int25 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D26.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer30);
        boolean boolean32 = textTitle3.equals((java.lang.Object) xYDataset5);
        java.awt.Font font33 = textTitle3.getFont();
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle37.setFont(font38);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle37.getBounds();
        java.awt.geom.AffineTransform affineTransform41 = null;
        java.awt.RenderingHints renderingHints42 = null;
        java.awt.PaintContext paintContext43 = color34.createContext(colorModel35, rectangle36, rectangle2D40, affineTransform41, renderingHints42);
        org.jfree.chart.text.TextLine textLine44 = new org.jfree.chart.text.TextLine("hi!", font33, (java.awt.Paint) color34);
        boolean boolean45 = ringPlot0.equals((java.lang.Object) textLine44);
        org.jfree.chart.text.TextFragment textFragment46 = textLine44.getFirstTextFragment();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(paintContext43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(textFragment46);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        waferMapPlot1.setRenderer(waferMapRenderer2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot15.setInsets(rectangleInsets17, false);
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = blockContainer10.equals((java.lang.Object) xYPlot15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke26 = numberAxis3D25.getAxisLineStroke();
        java.awt.Paint paint27 = numberAxis3D25.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot32.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot32.setInsets(rectangleInsets34, false);
        numberAxis3D25.setTickLabelInsets(rectangleInsets34);
        xYPlot15.setInsets(rectangleInsets34);
        xYPlot15.clearRangeMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker41.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = valueMarker41.getLabelAnchor();
        java.awt.Paint paint45 = valueMarker41.getLabelPaint();
        xYPlot15.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = java.awt.Color.yellow;
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color1);
        int int3 = color1.getTransparency();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot17.setInsets(rectangleInsets19, false);
        xYPlot17.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot28.setRangeTickBandPaint((java.awt.Paint) color29);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color29);
        boolean boolean32 = textTitle12.equals((java.lang.Object) xYPlot17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = titleChangeEvent33.getType();
        jFreeChart11.titleChanged(titleChangeEvent33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D36.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font40 = categoryAxis3D36.getTickLabelFont((java.lang.Comparable) numberTickUnit39);
        java.awt.Paint paint42 = categoryAxis3D36.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart11.setBorderPaint(paint42);
        boolean boolean44 = jFreeChart11.isNotify();
        jFreeChart11.fireChartChanged();
        jFreeChart11.setAntiAlias(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(numberTickUnit39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setRange((double) 0.0f, (double) ' ');
        boolean boolean18 = numberAxis3D14.isAutoTickUnitSelection();
        int int19 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        java.awt.Image image20 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot25.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot25.setInsets(rectangleInsets27, false);
        xYPlot25.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot25.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot25.setBackgroundPaint(paint34);
        xYPlot4.setOutlinePaint(paint34);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D37.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font41 = categoryAxis3D37.getTickLabelFont((java.lang.Comparable) numberTickUnit40);
        java.awt.Paint paint43 = categoryAxis3D37.getTickLabelPaint((java.lang.Comparable) 45.0d);
        xYPlot4.setRangeTickBandPaint(paint43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset48, valueAxis49, valueAxis50, xYItemRenderer51);
        org.jfree.data.xy.XYDataset xYDataset53 = xYPlot52.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot52.setInsets(rectangleInsets54, false);
        xYPlot52.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = xYPlot52.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot52.setRangeGridlinePaint(paint61);
        java.awt.geom.Point2D point2D63 = xYPlot52.getQuadrantOrigin();
        xYPlot4.zoomRangeAxes((double) 1L, 90.0d, plotRenderingInfo47, point2D63);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberTickUnit40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(xYDataset53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(point2D63);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=0,b=0]");
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[] numberArray8 = new java.lang.Number[] {};
        java.lang.Number[] numberArray9 = new java.lang.Number[] {};
        java.lang.Number[] numberArray10 = new java.lang.Number[] {};
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray7, numberArray8, numberArray9, numberArray10, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "{0}", numberArray12);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset13);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle16.setFont(font17);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle16.getBounds();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D20.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double30 = rectangleInsets28.calculateLeftInset((double) (short) 10);
        numberAxis3D24.setTickLabelInsets(rectangleInsets28);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle33.setFont(font34);
        java.awt.geom.Rectangle2D rectangle2D36 = textTitle33.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double38 = numberAxis3D24.java2DToValue((double) 0.0f, rectangle2D36, rectangleEdge37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset39, valueAxis40, valueAxis41, xYItemRenderer42);
        org.jfree.data.xy.XYDataset xYDataset44 = xYPlot43.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot43.setInsets(rectangleInsets45, false);
        xYPlot43.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot43.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str52 = rectangleEdge51.toString();
        java.util.List list53 = categoryAxis3D20.refreshTicks(graphics2D22, axisState23, rectangle2D36, rectangleEdge51);
        double double54 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 255, (java.lang.Comparable) "java.awt.Color[r=0,g=0,b=0]", categoryDataset13, (double) (byte) 100, rectangle2D19, rectangleEdge51);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleEdge.TOP" + "'", str52.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D2.setRange((double) 0.0f, (double) ' ');
        boolean boolean6 = numberAxis3D2.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = numberAxis3D2.getDefaultAutoRange();
        boolean boolean8 = numberAxis3D2.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer9);
        boolean boolean11 = polarPlot10.isRangeZoomable();
        java.awt.Stroke stroke12 = polarPlot10.getRadiusGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke12, rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder14.getInsets();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean17 = lineBorder14.equals((java.lang.Object) textBlockAnchor16);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(100);
        double double13 = xYPlot4.getDomainCrosshairValue();
        xYPlot4.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "LengthConstraintType.FIXED", "");
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint2 = piePlot3D1.getLabelOutlinePaint();
        java.lang.Object obj3 = piePlot3D1.clone();
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setIgnoreNullValues(true);
        piePlot3D1.setLabelLinksVisible(true);
        java.awt.Paint paint11 = piePlot3D1.getSectionPaint((java.lang.Comparable) "TextAnchor.BASELINE_LEFT");
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Polar Plot");
        categoryAxis3D1.setCategoryLabelPositionOffset(0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot5.getDataset();
        java.awt.Stroke stroke7 = xYPlot5.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = piePlot11.getURLGenerator();
        boolean boolean13 = piePlot11.getSimpleLabels();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot18.setRangeTickBandPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot18.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo23, point2D24);
        xYPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D28.setRange((double) 0.0f, (double) ' ');
        boolean boolean32 = numberAxis3D28.isAutoTickUnitSelection();
        int int33 = xYPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        java.awt.Image image34 = xYPlot18.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot40.getDataset();
        xYPlot40.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = null;
        xYPlot40.rendererChanged(rendererChangeEvent45);
        org.jfree.chart.axis.AxisLocation axisLocation47 = xYPlot40.getDomainAxisLocation();
        xYPlot18.setDomainAxisLocation((int) (byte) 10, axisLocation47, true);
        org.jfree.chart.axis.AxisSpace axisSpace50 = xYPlot18.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        xYPlot18.zoomRangeAxes((double) 0L, plotRenderingInfo52, point2D53);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.JFreeChart jFreeChart56 = plotChangeEvent55.getChart();
        piePlot11.notifyListeners(plotChangeEvent55);
        jFreeChart10.plotChanged(plotChangeEvent55);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D59 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D59.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.AxisState axisState62 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D63 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D63.setRange((double) 0.0f, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double69 = rectangleInsets67.calculateLeftInset((double) (short) 10);
        numberAxis3D63.setTickLabelInsets(rectangleInsets67);
        org.jfree.chart.title.TextTitle textTitle72 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font73 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle72.setFont(font73);
        java.awt.geom.Rectangle2D rectangle2D75 = textTitle72.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double77 = numberAxis3D63.java2DToValue((double) 0.0f, rectangle2D75, rectangleEdge76);
        org.jfree.data.xy.XYDataset xYDataset78 = null;
        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer81 = null;
        org.jfree.chart.plot.XYPlot xYPlot82 = new org.jfree.chart.plot.XYPlot(xYDataset78, valueAxis79, valueAxis80, xYItemRenderer81);
        org.jfree.data.xy.XYDataset xYDataset83 = xYPlot82.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets84 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot82.setInsets(rectangleInsets84, false);
        xYPlot82.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = xYPlot82.getDomainAxisEdge((int) (byte) 100);
        java.lang.String str91 = rectangleEdge90.toString();
        java.util.List list92 = categoryAxis3D59.refreshTicks(graphics2D61, axisState62, rectangle2D75, rectangleEdge90);
        jFreeChart10.setSubtitles(list92);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNull(axisSpace50);
        org.junit.Assert.assertNull(jFreeChart56);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataset83);
        org.junit.Assert.assertNotNull(rectangleInsets84);
        org.junit.Assert.assertNotNull(rectangleEdge90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "RectangleEdge.TOP" + "'", str91.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(list92);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo3, point2D4, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (-1.0f), plotRenderingInfo10, point2D11, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot7.getDomainAxisEdge();
        java.lang.String str15 = categoryPlot7.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot20.getDataset();
        java.awt.Stroke stroke22 = xYPlot20.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker26.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer29 = null;
        xYPlot20.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker26, layer29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker26, layer31);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot0.getDomainMarkers((int) (byte) 0, layer35);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.awt.Paint paint4 = piePlot3D3.getLabelOutlinePaint();
        java.lang.Object obj5 = piePlot3D3.clone();
        piePlot3D3.setDepthFactor((double) (byte) 1);
        piePlot3D3.setIgnoreNullValues(true);
        piePlot3D3.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D3);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot18.setInsets(rectangleInsets20, false);
        xYPlot18.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot29.setRangeTickBandPaint((java.awt.Paint) color30);
        xYPlot18.setBackgroundPaint((java.awt.Paint) color30);
        boolean boolean33 = textTitle13.equals((java.lang.Object) xYPlot18);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent34 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = titleChangeEvent34.getType();
        jFreeChart12.titleChanged(titleChangeEvent34);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D37.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font41 = categoryAxis3D37.getTickLabelFont((java.lang.Comparable) numberTickUnit40);
        java.awt.Paint paint43 = categoryAxis3D37.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart12.setBorderPaint(paint43);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj46 = textTitle45.clone();
        textTitle45.setID("{0}");
        double double49 = textTitle45.getHeight();
        org.jfree.chart.event.TitleChangeListener titleChangeListener50 = null;
        textTitle45.removeChangeListener(titleChangeListener50);
        jFreeChart12.addSubtitle((org.jfree.chart.title.Title) textTitle45);
        float float53 = jFreeChart12.getBackgroundImageAlpha();
        multiplePiePlot0.setPieChart(jFreeChart12);
        double double55 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType35);
        org.junit.Assert.assertNotNull(numberTickUnit40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.5f + "'", float53 == 0.5f);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setRange((double) 0.0f, (double) ' ');
        boolean boolean8 = numberAxis3D4.isAutoTickUnitSelection();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        boolean boolean10 = numberAxis3D4.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer11);
        boolean boolean13 = polarPlot12.isRangeZoomable();
        java.awt.Font font14 = polarPlot12.getAngleLabelFont();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("Polar Plot", font14, paint15, (float) 8);
        categoryAxis1.setTickLabelFont(font14);
        java.awt.Font font19 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        blockContainer10.setPadding(rectangleInsets11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj14 = textTitle13.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle13.getVerticalAlignment();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle20.setFont(font21);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle20.getBounds();
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color17.createContext(colorModel18, rectangle19, rectangle2D23, affineTransform24, renderingHints25);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj28 = textTitle13.draw(graphics2D16, (java.awt.geom.Rectangle2D) rectangle19, (java.lang.Object) font27);
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        blockContainer10.setPadding(10.0d, (double) 100L, 0.525d, 90.0d);
        java.util.List list35 = blockContainer10.getBlocks();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker1.setLabel("RectangleAnchor.CENTER");
        java.lang.Object obj4 = valueMarker1.clone();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setRange((double) 0.0f, (double) ' ');
        boolean boolean10 = numberAxis3D6.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = numberAxis3D6.getDefaultAutoRange();
        boolean boolean12 = numberAxis3D6.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, polarItemRenderer13);
        boolean boolean15 = polarPlot14.isRangeZoomable();
        java.awt.Font font16 = polarPlot14.getAngleLabelFont();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot14);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo9, point2D10);
        float float12 = xYPlot4.getBackgroundImageAlpha();
        java.awt.Image image13 = xYPlot4.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot18.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot18.setInsets(rectangleInsets20, false);
        xYPlot4.setAxisOffset(rectangleInsets20);
        xYPlot4.setRangeCrosshairValue((double) (-1L));
        java.awt.Paint paint26 = xYPlot4.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNull(image13);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Paint paint3 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.awt.Paint paint3 = piePlot3D2.getLabelOutlinePaint();
        java.lang.Object obj4 = piePlot3D2.clone();
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setIgnoreNullValues(true);
        piePlot3D2.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D2);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot17.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot17.setInsets(rectangleInsets19, false);
        xYPlot17.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot28.setRangeTickBandPaint((java.awt.Paint) color29);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color29);
        boolean boolean32 = textTitle12.equals((java.lang.Object) xYPlot17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = titleChangeEvent33.getType();
        jFreeChart11.titleChanged(titleChangeEvent33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D36.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font40 = categoryAxis3D36.getTickLabelFont((java.lang.Comparable) numberTickUnit39);
        java.awt.Paint paint42 = categoryAxis3D36.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart11.setBorderPaint(paint42);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj45 = textTitle44.clone();
        textTitle44.setID("{0}");
        double double48 = textTitle44.getHeight();
        org.jfree.chart.event.TitleChangeListener titleChangeListener49 = null;
        textTitle44.removeChangeListener(titleChangeListener49);
        jFreeChart11.addSubtitle((org.jfree.chart.title.Title) textTitle44);
        org.jfree.chart.title.TextTitle textTitle52 = jFreeChart11.getTitle();
        java.util.List list53 = jFreeChart11.getSubtitles();
        jFreeChart11.setTitle("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = jFreeChart11.getPadding();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(numberTickUnit39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(textTitle52);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(rectangleInsets56);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
        int int2 = objectList1.size();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.Rotation rotation4 = ringPlot3.getDirection();
        java.awt.Paint paint5 = ringPlot3.getLabelLinkPaint();
        boolean boolean6 = objectList1.equals((java.lang.Object) ringPlot3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot8.zoomDomainAxes((double) (-1.0f), plotRenderingInfo11, point2D12, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot15.zoomDomainAxes((double) (-1.0f), plotRenderingInfo18, point2D19, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot15.getDomainAxisEdge();
        java.lang.String str23 = categoryPlot15.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot28.getDataset();
        java.awt.Stroke stroke30 = xYPlot28.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = xYPlot28.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((-3.0d));
        valueMarker34.setLabel("RectangleAnchor.CENTER");
        org.jfree.chart.util.Layer layer37 = null;
        xYPlot28.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker34, layer37);
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot15.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker34, layer39);
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker34);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot8.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(100, axisLocation42, false);
        categoryPlot0.setDomainGridlinesVisible(false);
        int int47 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        java.util.List list2 = categoryPlot0.getAnnotations();
        categoryPlot0.setAnchorValue((double) (short) 10);
        categoryPlot0.configureRangeAxes();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot12.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo17, point2D18);
        xYPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setRange((double) 0.0f, (double) ' ');
        boolean boolean26 = numberAxis3D22.isAutoTickUnitSelection();
        int int27 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D28.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer32);
        org.jfree.data.Range range34 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        java.awt.Paint paint35 = xYPlot4.getRangeGridlinePaint();
        java.util.List list36 = xYPlot4.getAnnotations();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        double double3 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setMaximumLabelWidth(Double.NaN);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot7.setRangeTickBandPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot7.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo12, point2D13);
        xYPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setRange((double) 0.0f, (double) ' ');
        boolean boolean21 = numberAxis3D17.isAutoTickUnitSelection();
        int int22 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D17);
        java.awt.Shape shape23 = numberAxis3D17.getRightArrow();
        numberAxis3D17.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis3D17.setMarkerBand(markerAxisBand26);
        java.awt.Font font28 = numberAxis3D17.getLabelFont();
        ringPlot0.setLabelFont(font28);
        double double30 = ringPlot0.getShadowYOffset();
        ringPlot0.setBackgroundAlpha(0.0f);
        java.awt.Paint paint33 = ringPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setMaximumLabelWidth(Double.NaN);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot7.setRangeTickBandPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot7.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo12, point2D13);
        xYPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setRange((double) 0.0f, (double) ' ');
        boolean boolean21 = numberAxis3D17.isAutoTickUnitSelection();
        int int22 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D17);
        java.awt.Shape shape23 = numberAxis3D17.getRightArrow();
        numberAxis3D17.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis3D17.setMarkerBand(markerAxisBand26);
        java.awt.Font font28 = numberAxis3D17.getLabelFont();
        ringPlot0.setLabelFont(font28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = ringPlot0.getSimpleLabelOffset();
        boolean boolean31 = ringPlot0.getIgnoreNullValues();
        java.awt.Paint paint32 = ringPlot0.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        xYPlot4.mapDatasetToDomainAxis((-1), (int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot4.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.setRange((double) 0.0f, (double) ' ');
        boolean boolean16 = numberAxis3D12.isAutoTickUnitSelection();
        double double17 = numberAxis3D12.getUpperMargin();
        java.awt.Paint paint18 = numberAxis3D12.getTickLabelPaint();
        xYPlot4.setRangeCrosshairPaint(paint18);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint3.toFixedWidth(0.2d);
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) (short) 1);
        boolean boolean12 = range10.contains((double) 10L);
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range10, 0.05d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) (short) 1);
        org.jfree.data.Range range22 = org.jfree.data.Range.expand(range19, (double) '4', 0.0d);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range22, (double) 0.5f, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType26 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, range14, lengthConstraintType15, (double) (byte) 0, range22, lengthConstraintType26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint6.toRangeHeight(range22);
        boolean boolean29 = lengthConstraintType0.equals((java.lang.Object) range22);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(lengthConstraintType26);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle0.setTextAlignment(horizontalAlignment3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        java.awt.Paint paint9 = piePlot3D8.getLabelOutlinePaint();
        java.lang.Object obj10 = piePlot3D8.clone();
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setIgnoreNullValues(true);
        piePlot3D8.setLabelLinksVisible(true);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot23.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot23.setInsets(rectangleInsets25, false);
        xYPlot23.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot34.setRangeTickBandPaint((java.awt.Paint) color35);
        xYPlot23.setBackgroundPaint((java.awt.Paint) color35);
        boolean boolean38 = textTitle18.equals((java.lang.Object) xYPlot23);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent39 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = titleChangeEvent39.getType();
        jFreeChart17.titleChanged(titleChangeEvent39);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D42.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit45 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font46 = categoryAxis3D42.getTickLabelFont((java.lang.Comparable) numberTickUnit45);
        java.awt.Paint paint48 = categoryAxis3D42.getTickLabelPaint((java.lang.Comparable) 45.0d);
        jFreeChart17.setBorderPaint(paint48);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj51 = textTitle50.clone();
        textTitle50.setID("{0}");
        double double54 = textTitle50.getHeight();
        org.jfree.chart.event.TitleChangeListener titleChangeListener55 = null;
        textTitle50.removeChangeListener(titleChangeListener55);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle50);
        float float58 = jFreeChart17.getBackgroundImageAlpha();
        multiplePiePlot5.setPieChart(jFreeChart17);
        jFreeChart17.setTitle("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
        org.junit.Assert.assertNotNull(numberTickUnit45);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.5f + "'", float58 == 0.5f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        xYPlot4.setFixedLegendItems(legendItemCollection9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot4.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle8.setFont(font9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color5.createContext(colorModel6, rectangle7, rectangle2D11, affineTransform12, renderingHints13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.lang.Object obj16 = textTitle1.draw(graphics2D4, (java.awt.geom.Rectangle2D) rectangle7, (java.lang.Object) font15);
        java.awt.Paint paint17 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint17, 0.0f, (int) (short) 100, textMeasurer20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock21.draw(graphics2D22, 0.0f, (float) (short) 100, textBlockAnchor25, 0.5f, (float) 8, (-3.0d));
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj32 = textTitle31.clone();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot38.setRangeTickBandPaint((java.awt.Paint) color39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        xYPlot38.zoomRangeAxes((double) (short) 10, (-1.0d), plotRenderingInfo43, point2D44);
        xYPlot38.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D48.setRange((double) 0.0f, (double) ' ');
        boolean boolean52 = numberAxis3D48.isAutoTickUnitSelection();
        int int53 = xYPlot38.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D48);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D54.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, xYItemRenderer58);
        boolean boolean60 = textTitle31.equals((java.lang.Object) xYDataset33);
        java.awt.Font font61 = textTitle31.getFont();
        java.awt.Color color62 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel63 = null;
        java.awt.Rectangle rectangle64 = null;
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font66 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle65.setFont(font66);
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle65.getBounds();
        java.awt.geom.AffineTransform affineTransform69 = null;
        java.awt.RenderingHints renderingHints70 = null;
        java.awt.PaintContext paintContext71 = color62.createContext(colorModel63, rectangle64, rectangle2D68, affineTransform69, renderingHints70);
        org.jfree.chart.text.TextLine textLine72 = new org.jfree.chart.text.TextLine("hi!", font61, (java.awt.Paint) color62);
        textBlock21.addLine(textLine72);
        org.jfree.chart.text.TextFragment textFragment74 = textLine72.getLastTextFragment();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(paintContext71);
        org.junit.Assert.assertNotNull(textFragment74);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setIgnoreNullValues(false);
        piePlot3D1.setDarkerSides(true);
        java.awt.Paint paint6 = piePlot3D1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        ringPlot0.setSeparatorsVisible(true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot4.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot4.setInsets(rectangleInsets6, false);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            xYPlot4.handleClick((int) 'a', 0, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setRange((double) 0.0f, (double) ' ');
        boolean boolean9 = numberAxis3D5.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = numberAxis3D5.getDefaultAutoRange();
        boolean boolean11 = numberAxis3D5.isAutoRange();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer12);
        boolean boolean14 = polarPlot13.isRangeZoomable();
        java.awt.Stroke stroke15 = polarPlot13.getRadiusGridlineStroke();
        ringPlot0.setBaseSectionOutlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        java.util.List list18 = jFreeChart17.getSubtitles();
        java.lang.Object obj19 = jFreeChart17.getTextAntiAlias();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(obj19);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) '4', (double) (-1.0f));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke8 = numberAxis3D7.getAxisLineStroke();
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) numberAxis3D7);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot15.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot15.setInsets(rectangleInsets17, false);
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = blockContainer10.equals((java.lang.Object) xYPlot15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke26 = numberAxis3D25.getAxisLineStroke();
        java.awt.Paint paint27 = numberAxis3D25.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot32.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        xYPlot32.setInsets(rectangleInsets34, false);
        numberAxis3D25.setTickLabelInsets(rectangleInsets34);
        xYPlot15.setInsets(rectangleInsets34);
        xYPlot15.clearRangeMarkers();
        boolean boolean40 = xYPlot15.isRangeZoomable();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot4.setRangeAxisLocation((int) (short) 100, axisLocation8);
        xYPlot4.setDomainCrosshairValue(0.18d);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.awt.Paint paint3 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(paint3);
    }
}

