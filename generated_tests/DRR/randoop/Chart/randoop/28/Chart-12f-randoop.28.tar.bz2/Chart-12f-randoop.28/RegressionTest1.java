import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        double double4 = multiplePiePlot0.getLimit();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent5);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color8, color9, color10, color11, color12, color13 };
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color15, color16 };
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray14, paintArray17, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle26.getMargin();
        multiplePiePlot5.setInsets(rectangleInsets28);
        java.awt.Stroke stroke30 = null;
        multiplePiePlot5.setOutlineStroke(stroke30);
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color32 };
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Color color38 = java.awt.Color.PINK;
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color34, color35, color36, color37, color38, color39 };
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color41, color42 };
        java.awt.Stroke stroke44 = null;
        java.awt.Stroke[] strokeArray45 = new java.awt.Stroke[] { stroke44 };
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray40, paintArray43, strokeArray45, strokeArray46, shapeArray47);
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        multiplePiePlot0.setOutlineVisible(false);
        java.awt.Image image53 = multiplePiePlot0.getBackgroundImage();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
        org.junit.Assert.assertNull(image53);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        int int2 = pieLabelDistributor1.getItemCount();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        textTitle1.setMargin((double) 0L, (double) (-1), (double) (short) 1, (double) (byte) 1);
        java.lang.Object obj11 = textTitle1.clone();
        double double12 = textTitle1.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        pieSectionEntity7.setSectionIndex((-16698368));
        java.lang.String str10 = pieSectionEntity7.toString();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        pieSectionEntity7.setPieIndex(0);
        pieSectionEntity7.setSectionIndex(0);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 52, -16698368(8)" + "'", str10.equals("PieSection: 52, -16698368(8)"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.lang.Object obj3 = piePlot1.clone();
        org.jfree.chart.util.Rotation rotation4 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double5 = rotation4.getFactor();
        piePlot1.setDirection(rotation4);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.setBackgroundImageAlpha((float) (short) -1);
        try {
            org.jfree.chart.title.Title title11 = jFreeChart3.getSubtitle((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
//        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo4.getOptionalLibraries();
//        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo6.getOptionalLibraries();
//        projectInfo6.setInfo("hi!");
//        java.lang.String str10 = projectInfo6.getName();
//        java.awt.Image image11 = projectInfo6.getLogo();
//        projectInfo4.setLogo(image11);
//        multiplePiePlot0.setBackgroundImage(image11);
//        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
//        double double15 = piePlot14.getLabelGap();
//        double double16 = piePlot14.getMaximumExplodePercent();
//        org.jfree.chart.util.RectangleInsets rectangleInsets17 = piePlot14.getLabelPadding();
//        org.jfree.chart.urls.PieURLGenerator pieURLGenerator18 = null;
//        piePlot14.setLegendLabelURLGenerator(pieURLGenerator18);
//        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot14);
//        java.lang.Object obj21 = plotChangeEvent20.getSource();
//        multiplePiePlot0.notifyListeners(plotChangeEvent20);
//        org.junit.Assert.assertNull(categoryDataset1);
//        org.junit.Assert.assertNotNull(rectangleInsets2);
//        org.junit.Assert.assertNotNull(projectInfo4);
//        org.junit.Assert.assertNotNull(libraryArray5);
//        org.junit.Assert.assertNotNull(projectInfo6);
//        org.junit.Assert.assertNotNull(libraryArray7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(image11);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangleInsets17);
//        org.junit.Assert.assertNotNull(obj21);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setMargin((double) (short) 1, (double) (byte) 10, 0.0d, (double) 10.0f);
        textTitle2.setID("HorizontalAlignment.CENTER");
        java.awt.Color color13 = java.awt.Color.cyan;
        textTitle2.setPaint((java.awt.Paint) color13);
        int int15 = color13.getGreen();
        java.awt.Color color16 = java.awt.Color.orange;
        java.awt.Color color17 = color16.darker();
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Color color19 = java.awt.Color.GRAY;
        float[] floatArray20 = null;
        float[] floatArray21 = color19.getRGBColorComponents(floatArray20);
        float[] floatArray22 = color18.getRGBColorComponents(floatArray21);
        float[] floatArray23 = color16.getRGBColorComponents(floatArray21);
        float[] floatArray24 = color13.getColorComponents(floatArray21);
        float[] floatArray25 = color0.getColorComponents(floatArray24);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        java.lang.Object obj5 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle1.getVerticalAlignment();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle8.getMargin();
        java.lang.String str11 = textTitle8.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle8.getMargin();
        boolean boolean13 = verticalAlignment6.equals((java.lang.Object) rectangleInsets12);
        double double15 = rectangleInsets12.trimWidth(90.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 90.0d + "'", double15 == 90.0d);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
//        projectInfo0.setInfo("hi!");
//        java.lang.String str4 = projectInfo0.getName();
//        java.lang.String str5 = projectInfo0.getLicenceText();
//        projectInfo0.setVersion("org.jfree.data.UnknownKeyException: {0}");
//        java.lang.String str8 = projectInfo0.getInfo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(libraryArray1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        defaultKeyedValues2D1.addValue((java.lang.Number) 0.0d, (java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE", (java.lang.Comparable) (-16698368));
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 255, (java.lang.Comparable) "rect");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setTextAlignment(horizontalAlignment1);
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color8, color9, color10, color11, color12, color13 };
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color15, color16 };
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray14, paintArray17, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle26.getMargin();
        multiplePiePlot5.setInsets(rectangleInsets28);
        java.awt.Stroke stroke30 = null;
        multiplePiePlot5.setOutlineStroke(stroke30);
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color32 };
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Color color38 = java.awt.Color.PINK;
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color34, color35, color36, color37, color38, color39 };
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color41, color42 };
        java.awt.Stroke stroke44 = null;
        java.awt.Stroke[] strokeArray45 = new java.awt.Stroke[] { stroke44 };
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray40, paintArray43, strokeArray45, strokeArray46, shapeArray47);
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        java.awt.Image image51 = null;
        multiplePiePlot0.setBackgroundImage(image51);
        multiplePiePlot0.setOutlineVisible(false);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        float float10 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        textTitle12.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent15.setType(chartChangeEventType16);
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        titleChangeEvent15.setChart(jFreeChart18);
        jFreeChart3.titleChanged(titleChangeEvent15);
        org.jfree.chart.title.Title title21 = titleChangeEvent15.getTitle();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertNotNull(title21);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("{0}");
        boolean boolean7 = jFreeChartResources0.containsKey("TableOrder.BY_COLUMN");
        java.util.Locale locale8 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(locale8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot0.getLabelLinkStyle();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot0.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot0.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str14 = pieSectionEntity13.toString();
        pieSectionEntity13.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity13.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        int int19 = pieSectionEntity13.getPieIndex();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity27 = new org.jfree.chart.entity.PieSectionEntity(shape20, pieDataset21, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        pieSectionEntity13.setArea(shape20);
        int int29 = pieSectionEntity13.getPieIndex();
        boolean boolean30 = horizontalAlignment5.equals((java.lang.Object) int29);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 52, 52(8)" + "'", str14.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.addValue((double) (short) 0, (java.lang.Comparable) 100.0d, (java.lang.Comparable) 1.0f);
        defaultCategoryDataset0.removeRow((int) (short) 0);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        multiplePiePlot10.removeChangeListener(plotChangeListener11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot10);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle14.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int20 = chartColor19.getRGB();
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = chartColor19.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        legendTitle14.setBackgroundPaint((java.awt.Paint) chartColor19);
        piePlot9.setBaseSectionPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint29 = piePlot9.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator30 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        java.lang.String str33 = standardPieSectionLabelGenerator30.generateSectionLabel(pieDataset31, (java.lang.Comparable) 10.0f);
        piePlot9.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator30);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = piePlot9.getDrawingSupplier();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-16698368) + "'", int20 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(drawingSupplier36);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue((java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED", (java.lang.Comparable) "PieSection: 52, 52(8)");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: PieSection: 52, 52(8)");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        piePlot0.setBackgroundAlpha((float) ' ');
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle8.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment14, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17);
        boolean boolean19 = standardPieSectionLabelGenerator5.equals((java.lang.Object) flowArrangement17);
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator5.getPercentFormat();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        java.lang.String str23 = standardPieSectionLabelGenerator5.generateSectionLabel(pieDataset21, (java.lang.Comparable) 1.0d);
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator5);
        java.lang.Object obj25 = standardPieSectionLabelGenerator5.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setURLGenerator(pieURLGenerator2);
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor7);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        piePlot1.setURLGenerator(pieURLGenerator9);
        boolean boolean11 = pieLabelLinkStyle0.equals((java.lang.Object) pieURLGenerator9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor1.sort();
        java.lang.String str3 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels(0.0d, (double) 10);
        int int7 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setExpandToFitSpace(true);
        java.lang.Object obj5 = textTitle2.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle2.getMargin();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        multiplePiePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot7);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj12 = null;
        boolean boolean13 = defaultDrawingSupplier11.equals(obj12);
        boolean boolean14 = jFreeChart10.equals((java.lang.Object) defaultDrawingSupplier11);
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.awt.Color color18 = java.awt.Color.blue;
        piePlot17.setBaseSectionOutlinePaint((java.awt.Paint) color18);
        piePlot17.setMaximumLabelWidth(100.0d);
        java.awt.Color color22 = java.awt.Color.green;
        piePlot17.setBaseSectionOutlinePaint((java.awt.Paint) color22);
        textTitle2.setBackgroundPaint((java.awt.Paint) color22);
        java.awt.Color color25 = java.awt.Color.getColor("PieSection: 52, -16698368(8)", color22);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color4 = java.awt.Color.PINK;
        boolean boolean5 = defaultKeyedValues2D3.equals((java.lang.Object) color4);
        java.awt.Color color6 = java.awt.Color.getColor("", color4);
        java.awt.Color color7 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=1]", color6);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        defaultKeyedValues2D1.addValue((java.lang.Number) 0.0d, (java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE", (java.lang.Comparable) (-16698368));
        java.util.List list8 = defaultKeyedValues2D1.getColumnKeys();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) "-4,-4,4,4");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = null;
        piePlot21.setURLGenerator(pieURLGenerator22);
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot21.setLabelPaint((java.awt.Paint) chartColor27);
        java.awt.Paint paint29 = piePlot21.getLabelShadowPaint();
        piePlot1.setShadowPaint(paint29);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator31);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset21 = multiplePiePlot20.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = multiplePiePlot20.getInsets();
        org.jfree.chart.JFreeChart jFreeChart23 = multiplePiePlot20.getPieChart();
        double double24 = multiplePiePlot20.getLimit();
        java.awt.Font font25 = multiplePiePlot20.getNoDataMessageFont();
        textTitle14.setFont(font25);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(jFreeChart23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot0.setBaseSectionPaint((java.awt.Paint) color3);
        java.awt.Stroke stroke6 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        double double16 = rectangleInsets11.calculateTopInset((double) (byte) 100);
        piePlot0.setInsets(rectangleInsets11);
        java.awt.Stroke stroke18 = piePlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getTransparency();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        float[] floatArray8 = new float[] { 10L, 1L, 0, (short) 1 };
        float[] floatArray9 = color3.getRGBColorComponents(floatArray8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle16.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int22 = chartColor21.getRGB();
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.AffineTransform affineTransform26 = null;
        java.awt.RenderingHints renderingHints27 = null;
        java.awt.PaintContext paintContext28 = chartColor21.createContext(colorModel23, rectangle24, rectangle2D25, affineTransform26, renderingHints27);
        legendTitle16.setBackgroundPaint((java.awt.Paint) chartColor21);
        multiplePiePlot11.setOutlinePaint((java.awt.Paint) chartColor21);
        float[] floatArray31 = null;
        float[] floatArray32 = chartColor21.getColorComponents(floatArray31);
        float[] floatArray33 = color0.getComponents(colorSpace10, floatArray31);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16698368) + "'", int22 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext28);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable2 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, comparable2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        double double5 = piePlot0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 100, (float) (short) -1, 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-524308) + "'", int3 == (-524308));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.data.UnknownKeyException: hi!");
        java.text.AttributedString attributedString3 = null;
        try {
            standardPieSectionLabelGenerator1.setAttributedLabel((-524308), attributedString3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart3.getTitle();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int9 = chartColor8.getRGB();
        jFreeChart3.setBackgroundPaint((java.awt.Paint) chartColor8);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getLabelGap();
        double double13 = piePlot11.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot11.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        piePlot11.setLegendLabelURLGenerator(pieURLGenerator15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot11);
        java.lang.Object obj18 = plotChangeEvent17.getSource();
        jFreeChart3.plotChanged(plotChangeEvent17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.lang.Object obj23 = null;
        boolean boolean24 = textTitle21.equals(obj23);
        textTitle21.setHeight((double) 2);
        jFreeChart3.setTitle(textTitle21);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        multiplePiePlot29.removeChangeListener(plotChangeListener30);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot32);
        multiplePiePlot29.notifyListeners(plotChangeEvent33);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        textTitle36.setExpandToFitSpace(true);
        java.lang.Object obj39 = textTitle36.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle36.getMargin();
        double double42 = rectangleInsets40.trimHeight((double) (byte) 100);
        double double43 = rectangleInsets40.getBottom();
        multiplePiePlot29.setInsets(rectangleInsets40, true);
        double double47 = rectangleInsets40.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str50 = textTitle49.getText();
        java.lang.Object obj51 = null;
        boolean boolean52 = textTitle49.equals(obj51);
        textTitle49.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle49.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets40.createAdjustedRectangle(rectangle2D55, lengthAdjustmentType56, lengthAdjustmentType57);
        try {
            jFreeChart3.draw(graphics2D28, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(textTitle4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16698368) + "'", int9 == (-16698368));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 32.0d + "'", double47 == 32.0d);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        boolean boolean8 = jFreeChart3.isNotify();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        double double14 = textTitle11.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = textTitle11.getPosition();
        java.awt.Paint paint16 = textTitle11.getBackgroundPaint();
        java.lang.Object obj17 = textTitle11.clone();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle11.getBounds();
        try {
            jFreeChart3.addSubtitle(2, (org.jfree.chart.title.Title) textTitle11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Font font3 = multiplePiePlot0.getNoDataMessageFont();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = multiplePiePlot0.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = multiplePiePlot0.getInsets();
        org.jfree.chart.plot.Plot plot6 = multiplePiePlot0.getParent();
        java.lang.Object obj7 = multiplePiePlot0.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        int int9 = pieSectionEntity7.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        int int4 = defaultKeyedValues2D1.getRowCount();
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 1L);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 1, (java.lang.Comparable) 32.0d);
        try {
            java.lang.Number number12 = defaultKeyedValues2D1.getValue((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        boolean boolean2 = piePlot0.isCircular();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot0.getLegendLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = lineBorder3.getInsets();
        java.awt.Stroke stroke5 = lineBorder3.getStroke();
        piePlot0.setLabelOutlineStroke(stroke5);
        java.awt.Paint paint7 = null;
        try {
            piePlot0.setBaseSectionPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.RenderingHints renderingHints4 = jFreeChart3.getRenderingHints();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot5 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(renderingHints4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj16 = null;
        boolean boolean17 = defaultDrawingSupplier15.equals(obj16);
        boolean boolean18 = jFreeChart14.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart14.setBackgroundPaint(paint19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart14, chartChangeEventType26);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.lang.Object obj33 = null;
        boolean boolean34 = textTitle31.equals(obj33);
        textTitle31.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = textTitle31.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement40 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment37, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement40);
        org.jfree.chart.JFreeChart jFreeChart42 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer41, jFreeChart42);
        java.util.List list44 = blockContainer41.getBlocks();
        jFreeChart14.setSubtitles(list44);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(list44);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        java.awt.Paint paint6 = textTitle1.getBackgroundPaint();
        java.lang.Object obj7 = textTitle1.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle1.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle1.getPadding();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = lineBorder8.getInsets();
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle12.getMargin();
        java.lang.String str15 = textTitle12.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle12.getMargin();
        boolean boolean17 = textTitle12.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color19 };
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color21, color22, color23, color24, color25, color26 };
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color28, color29 };
        java.awt.Stroke stroke31 = null;
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Stroke[] strokeArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray20, paintArray27, paintArray30, strokeArray32, strokeArray33, shapeArray34);
        java.awt.Paint paint36 = defaultDrawingSupplier35.getNextOutlinePaint();
        multiplePiePlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str40 = textTitle39.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle39.getMargin();
        multiplePiePlot18.setInsets(rectangleInsets41);
        java.awt.Stroke stroke43 = null;
        multiplePiePlot18.setOutlineStroke(stroke43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str48 = textTitle47.getText();
        java.lang.Object obj49 = null;
        boolean boolean50 = textTitle47.equals(obj49);
        textTitle47.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle47.getBounds();
        multiplePiePlot18.drawBackgroundImage(graphics2D45, rectangle2D53);
        textTitle12.setBounds(rectangle2D53);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets9.createOutsetRectangle(rectangle2D53);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets5.createInsetRectangle(rectangle2D56, true, true);
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder61 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color60);
        double double63 = rectangleInsets5.extendWidth((double) (byte) 1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list2 = projectInfo1.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = projectInfo3.getLogo();
        java.util.List list5 = projectInfo3.getContributors();
        projectInfo1.setContributors(list5);
        java.lang.String str7 = projectInfo1.toString();
        projectInfo1.setCopyright("hi!");
        boolean boolean10 = objectList0.equals((java.lang.Object) projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Image image8 = jFreeChart3.getBackgroundImage();
        jFreeChart3.setBackgroundImageAlpha((float) '4');
        jFreeChart3.setNotify(false);
        jFreeChart3.setNotify(true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.lang.String str4 = projectInfo0.toString();
        java.lang.String str5 = projectInfo0.getLicenceText();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle12.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int18 = chartColor17.getRGB();
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = chartColor17.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        legendTitle12.setBackgroundPaint((java.awt.Paint) chartColor17);
        piePlot7.setBaseSectionPaint((java.awt.Paint) chartColor17);
        java.awt.Paint paint27 = piePlot7.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        java.lang.String str31 = standardPieSectionLabelGenerator28.generateSectionLabel(pieDataset29, (java.lang.Comparable) 10.0f);
        piePlot7.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator28);
        boolean boolean33 = projectInfo0.equals((java.lang.Object) piePlot7);
        org.jfree.chart.block.Arrangement arrangement34 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str38 = textTitle37.getText();
        java.lang.Object obj39 = null;
        boolean boolean40 = textTitle37.equals(obj39);
        textTitle37.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = textTitle37.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement46 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment35, verticalAlignment43, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement46);
        try {
            org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, arrangement34, (org.jfree.chart.block.Arrangement) flowArrangement46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16698368) + "'", int18 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(verticalAlignment43);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        textTitle1.setToolTipText("PieSection: 52, -16698368(8)");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color4 = java.awt.Color.cyan;
        paintMap0.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color4);
        java.awt.Paint paint7 = paintMap0.getPaint((java.lang.Comparable) 0.08d);
        java.awt.Color color9 = java.awt.Color.BLACK;
        paintMap0.put((java.lang.Comparable) "RectangleAnchor.BOTTOM_RIGHT", (java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        piePlot1.setForegroundAlpha((float) (byte) 100);
        piePlot1.setLabelLinksVisible(true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setURLGenerator(pieURLGenerator7);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation2);
        double double4 = rotation2.getFactor();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        double double12 = textTitle9.getWidth();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        java.lang.Object obj14 = textTitle9.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        java.awt.Stroke stroke20 = defaultDrawingSupplier17.getNextStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier17.getNextPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color8, color9, color10, color11, color12, color13 };
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color15, color16 };
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray14, paintArray17, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle26.getMargin();
        multiplePiePlot5.setInsets(rectangleInsets28);
        java.awt.Stroke stroke30 = null;
        multiplePiePlot5.setOutlineStroke(stroke30);
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color32 };
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Color color38 = java.awt.Color.PINK;
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color34, color35, color36, color37, color38, color39 };
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color41, color42 };
        java.awt.Stroke stroke44 = null;
        java.awt.Stroke[] strokeArray45 = new java.awt.Stroke[] { stroke44 };
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray40, paintArray43, strokeArray45, strokeArray46, shapeArray47);
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        java.awt.Image image51 = null;
        multiplePiePlot0.setBackgroundImage(image51);
        double double53 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.Object obj0 = null;
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int9 = chartColor8.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor8);
        java.awt.Color color11 = chartColor8.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot12);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj17 = null;
        boolean boolean18 = defaultDrawingSupplier16.equals(obj17);
        boolean boolean19 = jFreeChart15.equals((java.lang.Object) defaultDrawingSupplier16);
        java.awt.Paint paint20 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart15.setBackgroundPaint(paint20);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        textTitle23.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent26 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle23);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent26.setType(chartChangeEventType27);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart15, chartChangeEventType27);
        org.jfree.chart.JFreeChart jFreeChart30 = chartChangeEvent29.getChart();
        int int31 = jFreeChart30.getBackgroundImageAlignment();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        textTitle33.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent36 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle33);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = titleChangeEvent36.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        titleChangeEvent36.setType(chartChangeEventType38);
        java.lang.String str40 = chartChangeEventType38.toString();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart30, chartChangeEventType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16698368) + "'", int9 == (-16698368));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(chartChangeEventType27);
        org.junit.Assert.assertNotNull(jFreeChart30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str40.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        double double3 = piePlot0.getLabelGap();
        int int4 = piePlot0.getPieIndex();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot0.getLabelDistributor();
        abstractPieLabelDistributor5.clear();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = defaultDrawingSupplier8.equals(obj9);
        boolean boolean11 = jFreeChart7.equals((java.lang.Object) defaultDrawingSupplier8);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        double double16 = textTitle13.getWidth();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        boolean boolean19 = multiplePiePlot0.isSubplot();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        multiplePiePlot3.removeChangeListener(plotChangeListener4);
        java.awt.Font font6 = multiplePiePlot3.getNoDataMessageFont();
        piePlot1.setLabelFont(font6);
        double double8 = piePlot1.getShadowXOffset();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = piePlot10.getToolTipGenerator();
        java.awt.Color color13 = java.awt.Color.orange;
        java.awt.Color color14 = color13.darker();
        java.awt.Color color15 = java.awt.Color.YELLOW;
        java.awt.Color color16 = java.awt.Color.GRAY;
        float[] floatArray17 = null;
        float[] floatArray18 = color16.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color15.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color13.getRGBColorComponents(floatArray18);
        piePlot10.setSectionOutlinePaint((java.lang.Comparable) "RectangleAnchor.BOTTOM", (java.awt.Paint) color13);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot10);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        piePlot0.setLabelGap((double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        piePlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (short) 10, (int) '#', 8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle13.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment19, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color25 };
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color27, color28, color29, color30, color31, color32 };
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color34, color35 };
        java.awt.Stroke stroke37 = null;
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke37 };
        java.awt.Stroke[] strokeArray39 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray40 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray33, paintArray36, strokeArray38, strokeArray39, shapeArray40);
        java.awt.Paint paint42 = defaultDrawingSupplier41.getNextOutlinePaint();
        multiplePiePlot24.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier41);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str46 = textTitle45.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = textTitle45.getMargin();
        multiplePiePlot24.setInsets(rectangleInsets47);
        java.awt.Stroke stroke49 = null;
        multiplePiePlot24.setOutlineStroke(stroke49);
        java.awt.Color color51 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray52 = new java.awt.Paint[] { color51 };
        java.awt.Color color53 = java.awt.Color.PINK;
        java.awt.Color color54 = java.awt.Color.PINK;
        java.awt.Color color55 = java.awt.Color.PINK;
        java.awt.Color color56 = java.awt.Color.PINK;
        java.awt.Color color57 = java.awt.Color.PINK;
        java.awt.Color color58 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray59 = new java.awt.Paint[] { color53, color54, color55, color56, color57, color58 };
        java.awt.Color color60 = java.awt.Color.PINK;
        java.awt.Color color61 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray62 = new java.awt.Paint[] { color60, color61 };
        java.awt.Stroke stroke63 = null;
        java.awt.Stroke[] strokeArray64 = new java.awt.Stroke[] { stroke63 };
        java.awt.Stroke[] strokeArray65 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray66 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier67 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray52, paintArray59, paintArray62, strokeArray64, strokeArray65, shapeArray66);
        multiplePiePlot24.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier67);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot24.setOutlineStroke(stroke69);
        boolean boolean71 = blockContainer23.equals((java.lang.Object) stroke69);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("");
        textTitle73.setExpandToFitSpace(true);
        java.lang.Object obj76 = textTitle73.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = textTitle73.getMargin();
        double double79 = rectangleInsets77.trimHeight((double) 100.0f);
        double double81 = rectangleInsets77.calculateBottomInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder82 = new org.jfree.chart.block.LineBorder((java.awt.Paint) chartColor10, stroke69, rectangleInsets77);
        piePlot0.setBaseSectionOutlineStroke(stroke69);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertNotNull(shapeArray40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paintArray59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(paintArray62);
        org.junit.Assert.assertNotNull(strokeArray64);
        org.junit.Assert.assertNotNull(strokeArray65);
        org.junit.Assert.assertNotNull(shapeArray66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 100.0d + "'", double79 == 100.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        java.lang.Object obj2 = objectList1.clone();
        java.lang.Object obj3 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot0.getDataExtractOrder();
        multiplePiePlot0.setNoDataMessage("Rotation.CLOCKWISE");
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(tableOrder17);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = null;
        piePlot21.setURLGenerator(pieURLGenerator22);
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot21.setLabelPaint((java.awt.Paint) chartColor27);
        java.awt.Paint paint29 = piePlot21.getLabelShadowPaint();
        piePlot1.setShadowPaint(paint29);
        boolean boolean31 = piePlot1.getIgnoreZeroValues();
        double double32 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = legendTitle3.getSources();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle3.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getItemLabelPadding();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(legendItemSourceArray6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean13 = rectangleEdge11.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle14.setTextAlignment(horizontalAlignment15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        textTitle19.setExpandToFitSpace(true);
        java.lang.Object obj22 = textTitle19.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle19.getMargin();
        double double25 = rectangleInsets23.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType26 = rectangleInsets23.getUnitType();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font7, (java.awt.Paint) color8, rectangleEdge11, horizontalAlignment15, verticalAlignment17, rectangleInsets23);
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment17, 10.0d, 90.0d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        multiplePiePlot31.removeChangeListener(plotChangeListener32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent35 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot34);
        multiplePiePlot31.notifyListeners(plotChangeEvent35);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        textTitle38.setExpandToFitSpace(true);
        java.lang.Object obj41 = textTitle38.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle38.getMargin();
        double double44 = rectangleInsets42.trimHeight((double) (byte) 100);
        double double45 = rectangleInsets42.getBottom();
        multiplePiePlot31.setInsets(rectangleInsets42, true);
        boolean boolean48 = columnArrangement30.equals((java.lang.Object) multiplePiePlot31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(unitType26);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        double double18 = rectangleInsets15.getBottom();
        double double20 = rectangleInsets15.calculateTopInset((double) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        multiplePiePlot21.removeChangeListener(plotChangeListener22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot24);
        multiplePiePlot21.notifyListeners(plotChangeEvent25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        textTitle28.setExpandToFitSpace(true);
        java.lang.Object obj31 = textTitle28.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = textTitle28.getMargin();
        double double34 = rectangleInsets32.trimHeight((double) (byte) 100);
        double double35 = rectangleInsets32.getBottom();
        multiplePiePlot21.setInsets(rectangleInsets32, true);
        double double39 = rectangleInsets32.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str42 = textTitle41.getText();
        java.lang.Object obj43 = null;
        boolean boolean44 = textTitle41.equals(obj43);
        textTitle41.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle41.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets32.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType48, lengthAdjustmentType49);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets15.createInsetRectangle(rectangle2D47, false, true);
        piePlot1.drawBackgroundImage(graphics2D9, rectangle2D47);
        double double55 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 32.0d + "'", double39 == 32.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color0 = java.awt.Color.CYAN;
        java.awt.Color color1 = java.awt.Color.ORANGE;
        float[] floatArray6 = new float[] { 10L, 1L, 0, (short) 1 };
        float[] floatArray7 = color1.getRGBColorComponents(floatArray6);
        java.awt.color.ColorSpace colorSpace8 = color1.getColorSpace();
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Color color10 = java.awt.Color.GRAY;
        float[] floatArray11 = null;
        float[] floatArray12 = color10.getRGBColorComponents(floatArray11);
        float[] floatArray13 = color9.getRGBColorComponents(floatArray12);
        try {
            float[] floatArray14 = color0.getComponents(colorSpace8, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot0.setLabelPaint((java.awt.Paint) chartColor6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot0.setURLGenerator(pieURLGenerator8);
        double double10 = piePlot0.getStartAngle();
        piePlot0.setMinimumArcAngleToDraw((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = null;
        boolean boolean2 = defaultDrawingSupplier0.equals(obj1);
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        textTitle1.setMargin(8.0d, (double) (short) 0, 100.0d, 0.08d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        boolean boolean8 = jFreeChart3.isNotify();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = lineBorder18.getInsets();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = textTitle22.getMargin();
        java.lang.String str25 = textTitle22.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle22.getMargin();
        boolean boolean27 = textTitle22.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color29 };
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray37 = new java.awt.Paint[] { color31, color32, color33, color34, color35, color36 };
        java.awt.Color color38 = java.awt.Color.PINK;
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color38, color39 };
        java.awt.Stroke stroke41 = null;
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] { stroke41 };
        java.awt.Stroke[] strokeArray43 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray44 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray37, paintArray40, strokeArray42, strokeArray43, shapeArray44);
        java.awt.Paint paint46 = defaultDrawingSupplier45.getNextOutlinePaint();
        multiplePiePlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str50 = textTitle49.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = textTitle49.getMargin();
        multiplePiePlot28.setInsets(rectangleInsets51);
        java.awt.Stroke stroke53 = null;
        multiplePiePlot28.setOutlineStroke(stroke53);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str58 = textTitle57.getText();
        java.lang.Object obj59 = null;
        boolean boolean60 = textTitle57.equals(obj59);
        textTitle57.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle57.getBounds();
        multiplePiePlot28.drawBackgroundImage(graphics2D55, rectangle2D63);
        textTitle22.setBounds(rectangle2D63);
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets19.createOutsetRectangle(rectangle2D63);
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets15.createInsetRectangle(rectangle2D66, true, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = null;
        try {
            jFreeChart3.draw(graphics2D9, rectangle2D66, chartRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(strokeArray43);
        org.junit.Assert.assertNotNull(shapeArray44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D69);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        boolean boolean9 = jFreeChart3.getAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart3.getLegend();
        java.awt.Image image11 = jFreeChart3.getBackgroundImage();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Color color1 = java.awt.Color.getColor("rect");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        java.lang.String str5 = textTitle1.getURLText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot0.getLegendLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = lineBorder3.getInsets();
        java.awt.Stroke stroke5 = lineBorder3.getStroke();
        piePlot0.setLabelOutlineStroke(stroke5);
        piePlot0.setCircular(true, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot2);
        int int6 = defaultCategoryDataset0.getRowCount();
        try {
            java.lang.Comparable comparable8 = defaultCategoryDataset0.getRowKey((-65536));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -65536");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        boolean boolean3 = multiplePiePlot1.equals((java.lang.Object) color2);
        float float4 = multiplePiePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        double double3 = piePlot2.getLabelGap();
        double double4 = piePlot2.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot2.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot2.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        java.lang.Object obj12 = textTitle9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getMargin();
        double double15 = rectangleInsets13.trimHeight((double) (byte) 100);
        double double16 = rectangleInsets13.getBottom();
        double double18 = rectangleInsets13.calculateTopInset((double) (byte) 100);
        piePlot2.setInsets(rectangleInsets13);
        boolean boolean20 = lineBorder0.equals((java.lang.Object) rectangleInsets13);
        double double22 = rectangleInsets13.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 10L);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) 0.08d);
        java.lang.Object obj5 = paintMap0.clone();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle8.getHorizontalAlignment();
        double double13 = textTitle8.getHeight();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str15 = color14.toString();
        textTitle8.setBackgroundPaint((java.awt.Paint) color14);
        paintMap0.put((java.lang.Comparable) (-16777216), (java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str15.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.setValue((java.lang.Number) 100, (java.lang.Comparable) 0, (java.lang.Comparable) "org.jfree.data.UnknownKeyException: {0}");
        try {
            java.lang.Comparable comparable8 = defaultKeyedValues2D1.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = lineBorder8.getInsets();
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle12.getMargin();
        java.lang.String str15 = textTitle12.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle12.getMargin();
        boolean boolean17 = textTitle12.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color19 };
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color21, color22, color23, color24, color25, color26 };
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color28, color29 };
        java.awt.Stroke stroke31 = null;
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Stroke[] strokeArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray20, paintArray27, paintArray30, strokeArray32, strokeArray33, shapeArray34);
        java.awt.Paint paint36 = defaultDrawingSupplier35.getNextOutlinePaint();
        multiplePiePlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str40 = textTitle39.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle39.getMargin();
        multiplePiePlot18.setInsets(rectangleInsets41);
        java.awt.Stroke stroke43 = null;
        multiplePiePlot18.setOutlineStroke(stroke43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str48 = textTitle47.getText();
        java.lang.Object obj49 = null;
        boolean boolean50 = textTitle47.equals(obj49);
        textTitle47.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle47.getBounds();
        multiplePiePlot18.drawBackgroundImage(graphics2D45, rectangle2D53);
        textTitle12.setBounds(rectangle2D53);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets9.createOutsetRectangle(rectangle2D53);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets5.createInsetRectangle(rectangle2D56, true, true);
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder61 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color60);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.block.LineBorder lineBorder63 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = lineBorder63.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = lineBorder63.getInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot66 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener67 = null;
        multiplePiePlot66.removeChangeListener(plotChangeListener67);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot69 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent70 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot69);
        multiplePiePlot66.notifyListeners(plotChangeEvent70);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("");
        textTitle73.setExpandToFitSpace(true);
        java.lang.Object obj76 = textTitle73.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = textTitle73.getMargin();
        double double79 = rectangleInsets77.trimHeight((double) (byte) 100);
        double double80 = rectangleInsets77.getBottom();
        multiplePiePlot66.setInsets(rectangleInsets77, true);
        double double84 = rectangleInsets77.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle86 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str87 = textTitle86.getText();
        java.lang.Object obj88 = null;
        boolean boolean89 = textTitle86.equals(obj88);
        textTitle86.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D92 = textTitle86.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType93 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType94 = null;
        java.awt.geom.Rectangle2D rectangle2D95 = rectangleInsets77.createAdjustedRectangle(rectangle2D92, lengthAdjustmentType93, lengthAdjustmentType94);
        java.awt.geom.Rectangle2D rectangle2D96 = rectangleInsets65.createInsetRectangle(rectangle2D92);
        try {
            blockBorder61.draw(graphics2D62, rectangle2D96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 100.0d + "'", double79 == 100.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 32.0d + "'", double84 == 32.0d);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "" + "'", str87.equals(""));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(rectangle2D92);
        org.junit.Assert.assertNotNull(rectangle2D95);
        org.junit.Assert.assertNotNull(rectangle2D96);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        double double6 = textTitle1.getHeight();
        textTitle1.setWidth((double) (-1L));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        multiplePiePlot9.removeChangeListener(plotChangeListener10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot9);
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart12.getTitle();
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int18 = chartColor17.getRGB();
        jFreeChart12.setBackgroundPaint((java.awt.Paint) chartColor17);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle1.setHorizontalAlignment(horizontalAlignment21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(textTitle13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16698368) + "'", int18 == (-16698368));
        org.junit.Assert.assertNotNull(horizontalAlignment21);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        java.lang.Object obj9 = pieSectionEntity7.clone();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        boolean boolean18 = pieSectionEntity7.equals((java.lang.Object) double17);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color4 = java.awt.Color.cyan;
        paintMap0.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color4);
        java.awt.Paint paint7 = paintMap0.getPaint((java.lang.Comparable) 0.08d);
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        paintMap0.put((java.lang.Comparable) (-1.0f), (java.awt.Paint) chartColor12);
        java.awt.Color color14 = java.awt.Color.PINK;
        boolean boolean15 = paintMap0.equals((java.lang.Object) color14);
        java.lang.Object obj16 = paintMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.setBackgroundImageAlpha((float) (short) -1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) 52, (double) 0.5f, 108.0d, (double) (-1.0f));
        double double16 = rectangleInsets15.getTop();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        textTitle18.setExpandToFitSpace(true);
        double double21 = textTitle18.getWidth();
        java.awt.Paint paint22 = textTitle18.getBackgroundPaint();
        double double23 = textTitle18.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = textTitle18.getPadding();
        double double26 = rectangleInsets24.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.lang.Object obj30 = null;
        boolean boolean31 = textTitle28.equals(obj30);
        textTitle28.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets24.createInsetRectangle(rectangle2D34, false, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets15.createAdjustedRectangle(rectangle2D34, lengthAdjustmentType38, lengthAdjustmentType39);
        java.awt.geom.Point2D point2D41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        try {
            jFreeChart3.draw(graphics2D10, rectangle2D40, point2D41, chartRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color16, color17, color18, color19, color20, color21 };
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke stroke26 = null;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray22, paintArray25, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextOutlinePaint();
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str35 = textTitle34.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle34.getMargin();
        multiplePiePlot13.setInsets(rectangleInsets36);
        java.awt.Stroke stroke38 = null;
        multiplePiePlot13.setOutlineStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray41 = new java.awt.Paint[] { color40 };
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Color color43 = java.awt.Color.PINK;
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Color color45 = java.awt.Color.PINK;
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray48 = new java.awt.Paint[] { color42, color43, color44, color45, color46, color47 };
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { color49, color50 };
        java.awt.Stroke stroke52 = null;
        java.awt.Stroke[] strokeArray53 = new java.awt.Stroke[] { stroke52 };
        java.awt.Stroke[] strokeArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray41, paintArray48, paintArray51, strokeArray53, strokeArray54, shapeArray55);
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot13.setOutlineStroke(stroke58);
        boolean boolean60 = blockContainer12.equals((java.lang.Object) stroke58);
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str63 = textTitle62.getText();
        java.lang.Object obj64 = null;
        boolean boolean65 = textTitle62.equals(obj64);
        textTitle62.setHeight((double) 2);
        double double68 = textTitle62.getContentXOffset();
        blockContainer12.add((org.jfree.chart.block.Block) textTitle62, (java.lang.Object) "PieSection: 52, 52(8)");
        boolean boolean71 = blockContainer12.isEmpty();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintArray48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(strokeArray53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        java.awt.Paint paint6 = textTitle1.getBackgroundPaint();
        java.lang.Object obj7 = textTitle1.clone();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle1.getBounds();
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textTitle1.arrange(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setMargin((double) (short) 1, (double) (byte) 10, 0.0d, (double) 10.0f);
        textTitle1.setID("HorizontalAlignment.CENTER");
        java.awt.Color color12 = java.awt.Color.cyan;
        textTitle1.setPaint((java.awt.Paint) color12);
        int int14 = color12.getGreen();
        int int15 = color12.getAlpha();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        piePlot1.setStartAngle((double) (byte) 100);
        java.awt.Stroke stroke11 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 'a');
        double double12 = piePlot1.getStartAngle();
        int int13 = piePlot1.getPieIndex();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.calculateTopInset((double) 100.0f);
        double double8 = rectangleInsets4.calculateBottomOutset((double) 8);
        jFreeChart3.setPadding(rectangleInsets4);
        jFreeChart3.setBackgroundImageAlpha((float) ' ');
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = projectInfo2.getLogo();
        java.util.List list4 = projectInfo2.getContributors();
        projectInfo0.setContributors(list4);
        java.lang.String str6 = projectInfo0.toString();
        projectInfo0.setCopyright("hi!");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.Color color1 = java.awt.Color.red;
        int int2 = color1.getRGB();
        java.awt.Color color3 = java.awt.Color.ORANGE;
        float[] floatArray8 = new float[] { 10L, 1L, 0, (short) 1 };
        float[] floatArray9 = color3.getRGBColorComponents(floatArray8);
        float[] floatArray10 = color1.getRGBColorComponents(floatArray8);
        float[] floatArray11 = color0.getRGBColorComponents(floatArray10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-65536) + "'", int2 == (-65536));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        try {
            java.awt.image.BufferedImage bufferedImage7 = jFreeChart3.createBufferedImage((-1), 100, chartRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        piePlot1.setCircular(false, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list3 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.awt.Stroke stroke3 = multiplePiePlot1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        java.awt.Paint paint2 = null;
        multiplePiePlot0.setOutlinePaint(paint2);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "HorizontalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        multiplePiePlot0.setDataset(categoryDataset6);
        org.jfree.chart.JFreeChart jFreeChart8 = multiplePiePlot0.getPieChart();
        multiplePiePlot0.setLimit(0.0d);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(jFreeChart8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        java.lang.String str3 = horizontalAlignment0.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment4, (double) 100, (double) (byte) 1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.lang.Object obj12 = null;
        boolean boolean13 = textTitle10.equals(obj12);
        textTitle10.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle10.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment16, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        java.lang.Object obj25 = textTitle22.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle22.getMargin();
        boolean boolean27 = blockContainer20.equals((java.lang.Object) textTitle22);
        java.lang.Object obj28 = blockContainer20.clone();
        blockContainer20.clear();
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity37 = new org.jfree.chart.entity.PieSectionEntity(shape30, pieDataset31, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str38 = pieSectionEntity37.toString();
        java.lang.String str39 = pieSectionEntity37.getShapeType();
        columnArrangement7.add((org.jfree.chart.block.Block) blockContainer20, (java.lang.Object) pieSectionEntity37);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PieSection: 52, 52(8)" + "'", str38.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "rect" + "'", str39.equals("rect"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle1.draw(graphics2D5, rectangle2D6);
        java.awt.Paint paint8 = textTitle1.getPaint();
        textTitle1.setHeight((double) (byte) 10);
        java.awt.Paint paint11 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            piePlot0.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle1.getPadding();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        java.lang.Object obj12 = textTitle9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getMargin();
        double double15 = rectangleInsets13.trimHeight((double) (byte) 100);
        double double16 = rectangleInsets13.getTop();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = lineBorder17.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = lineBorder17.getInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        multiplePiePlot20.removeChangeListener(plotChangeListener21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot23);
        multiplePiePlot20.notifyListeners(plotChangeEvent24);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        textTitle27.setExpandToFitSpace(true);
        java.lang.Object obj30 = textTitle27.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = textTitle27.getMargin();
        double double33 = rectangleInsets31.trimHeight((double) (byte) 100);
        double double34 = rectangleInsets31.getBottom();
        multiplePiePlot20.setInsets(rectangleInsets31, true);
        double double38 = rectangleInsets31.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str41 = textTitle40.getText();
        java.lang.Object obj42 = null;
        boolean boolean43 = textTitle40.equals(obj42);
        textTitle40.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle40.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets31.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType47, lengthAdjustmentType48);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets19.createInsetRectangle(rectangle2D46);
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets13.createInsetRectangle(rectangle2D50);
        rectangleInsets7.trim(rectangle2D51);
        org.jfree.chart.entity.ChartEntity chartEntity53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D51);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 32.0d + "'", double38 == 32.0d);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("java.awt.Color[r=128,g=255,b=255]");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        java.lang.Throwable[] throwableArray7 = unknownKeyException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]" + "'", str2.equals("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.Object obj5 = titleChangeEvent4.getSource();
        org.jfree.chart.JFreeChart jFreeChart6 = titleChangeEvent4.getChart();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.awt.Font font5 = textTitle1.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str7 = horizontalAlignment6.toString();
        java.lang.String str8 = horizontalAlignment6.toString();
        textTitle1.setTextAlignment(horizontalAlignment6);
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int18 = chartColor17.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor17);
        java.awt.Color color20 = chartColor17.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        multiplePiePlot21.removeChangeListener(plotChangeListener22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot21);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj26 = null;
        boolean boolean27 = defaultDrawingSupplier25.equals(obj26);
        boolean boolean28 = jFreeChart24.equals((java.lang.Object) defaultDrawingSupplier25);
        java.awt.Paint paint29 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart24.setBackgroundPaint(paint29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        textTitle32.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent35.setType(chartChangeEventType36);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart24, chartChangeEventType36);
        textTitle1.setPaint((java.awt.Paint) color20);
        java.awt.Color color42 = java.awt.Color.getColor("PieSection: 52, 52(8)", (int) (short) 1);
        textTitle1.setBackgroundPaint((java.awt.Paint) color42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = textTitle1.getPadding();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HorizontalAlignment.CENTER" + "'", str8.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16698368) + "'", int18 == (-16698368));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        double double3 = piePlot0.getLabelGap();
        int int4 = piePlot0.getPieIndex();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor7.sort();
        java.lang.String str9 = pieLabelDistributor7.toString();
        pieLabelDistributor7.distributeLabels(0.0d, (double) 10);
        piePlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        double double15 = piePlot14.getLabelGap();
        double double16 = piePlot14.getMaximumExplodePercent();
        piePlot14.setBackgroundAlpha((float) ' ');
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.lang.Object obj24 = null;
        boolean boolean25 = textTitle22.equals(obj24);
        textTitle22.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = textTitle22.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment28, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement31);
        boolean boolean33 = standardPieSectionLabelGenerator19.equals((java.lang.Object) flowArrangement31);
        java.text.NumberFormat numberFormat34 = standardPieSectionLabelGenerator19.getPercentFormat();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        java.lang.String str37 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset35, (java.lang.Comparable) 1.0d);
        piePlot14.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        piePlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        org.jfree.data.general.PieDataset pieDataset40 = null;
        java.lang.String str42 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset40, (java.lang.Comparable) "RectangleAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(numberFormat34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("PieSection: 52, 52(8)");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name PieSection: 52, 52(8), locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        int int4 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D1.getColumnKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=1]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        boolean boolean4 = piePlot0.getLabelLinksVisible();
        org.jfree.chart.util.Rotation rotation5 = piePlot0.getDirection();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        paintMap0.put((java.lang.Comparable) "Other", (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) (byte) 10, 0, (java.lang.Comparable) 0.4d, "Rotation.CLOCKWISE", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Paint paint8 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Paint paint10 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        java.lang.Object obj8 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.lang.Object obj9 = null;
        boolean boolean10 = textTitle7.equals(obj9);
        textTitle7.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = textTitle7.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment13, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement16);
        boolean boolean18 = standardPieSectionLabelGenerator4.equals((java.lang.Object) flowArrangement16);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setToolTipText("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        pieSectionEntity7.setPieIndex((int) (short) 100);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setOutlineStroke(stroke8);
        java.awt.Shape shape10 = piePlot1.getLegendItemShape();
        java.awt.Paint paint11 = null;
        try {
            piePlot1.setLabelLinkPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color4 };
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color6, color7, color8, color9, color10, color11 };
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color13, color14 };
        java.awt.Stroke stroke16 = null;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke16 };
        java.awt.Stroke[] strokeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray19 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray12, paintArray15, strokeArray17, strokeArray18, shapeArray19);
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextOutlinePaint();
        multiplePiePlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        java.awt.Stroke stroke23 = defaultDrawingSupplier20.getNextStroke();
        java.awt.Stroke stroke24 = defaultDrawingSupplier20.getNextOutlineStroke();
        strokeMap0.put((java.lang.Comparable) 0L, stroke24);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot26);
        boolean boolean28 = strokeMap0.equals((java.lang.Object) plotChangeEvent27);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        piePlot0.setCircular(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            piePlot0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets3.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        boolean boolean4 = piePlot0.getLabelLinksVisible();
        boolean boolean5 = piePlot0.isCircular();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.util.List list8 = jFreeChart3.getSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart3.getLegend(2);
        java.awt.Image image11 = null;
        jFreeChart3.setBackgroundImage(image11);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendTitle10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.lang.Object obj5 = textTitle1.clone();
        java.awt.Paint paint6 = textTitle1.getPaint();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Color color9 = java.awt.Color.blue;
        piePlot8.setBaseSectionOutlinePaint((java.awt.Paint) color9);
        piePlot8.setMaximumLabelWidth(100.0d);
        piePlot8.setLabelLinksVisible(false);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot8.setOutlineStroke(stroke15);
        boolean boolean17 = textTitle1.equals((java.lang.Object) stroke15);
        java.awt.Graphics2D graphics2D18 = null;
        try {
            org.jfree.chart.util.Size2D size2D19 = textTitle1.arrange(graphics2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        piePlot0.setSectionOutlinesVisible(true);
        piePlot0.setLabelLinksVisible(true);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = piePlot0.getLabelLinkStyle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint10 = piePlot1.getSectionPaint((java.lang.Comparable) "");
        double double11 = piePlot1.getLabelGap();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "HorizontalAlignment.CENTER");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = lineBorder8.getInsets();
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle12.getMargin();
        java.lang.String str15 = textTitle12.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle12.getMargin();
        boolean boolean17 = textTitle12.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color19 };
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color21, color22, color23, color24, color25, color26 };
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color28, color29 };
        java.awt.Stroke stroke31 = null;
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Stroke[] strokeArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray20, paintArray27, paintArray30, strokeArray32, strokeArray33, shapeArray34);
        java.awt.Paint paint36 = defaultDrawingSupplier35.getNextOutlinePaint();
        multiplePiePlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str40 = textTitle39.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle39.getMargin();
        multiplePiePlot18.setInsets(rectangleInsets41);
        java.awt.Stroke stroke43 = null;
        multiplePiePlot18.setOutlineStroke(stroke43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str48 = textTitle47.getText();
        java.lang.Object obj49 = null;
        boolean boolean50 = textTitle47.equals(obj49);
        textTitle47.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle47.getBounds();
        multiplePiePlot18.drawBackgroundImage(graphics2D45, rectangle2D53);
        textTitle12.setBounds(rectangle2D53);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets9.createOutsetRectangle(rectangle2D53);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets5.createInsetRectangle(rectangle2D56, true, true);
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder61 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = blockBorder61.getInsets();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        double double3 = piePlot0.getLabelGap();
        double double4 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot2);
        try {
            java.lang.Comparable comparable7 = defaultCategoryDataset0.getColumnKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "org.jfree.chart.ChartColor[r=1,g=52,b=0]", "VerticalAlignment.TOP", "VerticalAlignment.TOP");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        java.lang.Object obj7 = plotChangeEvent6.getSource();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        java.awt.Image image12 = jFreeChart11.getBackgroundImage();
        boolean boolean13 = jFreeChart11.getAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart11.removeProgressListener(chartProgressListener14);
        jFreeChart11.clearSubtitles();
        plotChangeEvent6.setChart(jFreeChart11);
        org.jfree.chart.ui.ProjectInfo projectInfo18 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list19 = projectInfo18.getContributors();
        try {
            jFreeChart11.setSubtitles(list19);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.ui.Contributor cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(image12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(projectInfo18);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = multiplePiePlot0.getAggregatedItemsPaint();
        double double4 = multiplePiePlot0.getLimit();
        multiplePiePlot0.zoom((double) (-1L));
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle9.getMargin();
        java.lang.String str12 = textTitle9.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getMargin();
        boolean boolean14 = textTitle9.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color16 };
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color18, color19, color20, color21, color22, color23 };
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color25, color26 };
        java.awt.Stroke stroke28 = null;
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Stroke[] strokeArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray17, paintArray24, paintArray27, strokeArray29, strokeArray30, shapeArray31);
        java.awt.Paint paint33 = defaultDrawingSupplier32.getNextOutlinePaint();
        multiplePiePlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier32);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = textTitle36.getMargin();
        multiplePiePlot15.setInsets(rectangleInsets38);
        java.awt.Stroke stroke40 = null;
        multiplePiePlot15.setOutlineStroke(stroke40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str45 = textTitle44.getText();
        java.lang.Object obj46 = null;
        boolean boolean47 = textTitle44.equals(obj46);
        textTitle44.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D50 = textTitle44.getBounds();
        multiplePiePlot15.drawBackgroundImage(graphics2D42, rectangle2D50);
        textTitle9.setBounds(rectangle2D50);
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D50, "Other");
        java.awt.geom.Point2D point2D55 = null;
        org.jfree.chart.plot.PlotState plotState56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            multiplePiePlot0.draw(graphics2D7, rectangle2D50, point2D55, plotState56, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot0.setLabelPaint((java.awt.Paint) chartColor6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot0.setURLGenerator(pieURLGenerator8);
        double double10 = piePlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder13.getInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        multiplePiePlot16.removeChangeListener(plotChangeListener17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot19);
        multiplePiePlot16.notifyListeners(plotChangeEvent20);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        textTitle23.setExpandToFitSpace(true);
        java.lang.Object obj26 = textTitle23.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle23.getMargin();
        double double29 = rectangleInsets27.trimHeight((double) (byte) 100);
        double double30 = rectangleInsets27.getBottom();
        multiplePiePlot16.setInsets(rectangleInsets27, true);
        double double34 = rectangleInsets27.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.lang.Object obj38 = null;
        boolean boolean39 = textTitle36.equals(obj38);
        textTitle36.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle36.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets27.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType43, lengthAdjustmentType44);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets15.createInsetRectangle(rectangle2D42);
        try {
            legendTitle11.draw(graphics2D12, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 32.0d + "'", double34 == 32.0d);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        double double18 = rectangleInsets11.trimHeight((double) ' ');
        double double20 = rectangleInsets11.calculateBottomInset((double) 1L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 32.0d + "'", double18 == 32.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        boolean boolean3 = multiplePiePlot1.equals((java.lang.Object) color2);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = java.awt.Color.GRAY;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        float[] floatArray8 = color4.getRGBColorComponents(floatArray7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.lang.Object obj12 = null;
        boolean boolean13 = textTitle10.equals(obj12);
        textTitle10.setMargin((double) (short) 1, (double) (byte) 10, 0.0d, (double) 10.0f);
        textTitle10.setID("HorizontalAlignment.CENTER");
        java.awt.Color color21 = java.awt.Color.cyan;
        textTitle10.setPaint((java.awt.Paint) color21);
        int int23 = color21.getGreen();
        java.awt.Color color24 = java.awt.Color.orange;
        java.awt.Color color25 = color24.darker();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Color color27 = java.awt.Color.GRAY;
        float[] floatArray28 = null;
        float[] floatArray29 = color27.getRGBColorComponents(floatArray28);
        float[] floatArray30 = color26.getRGBColorComponents(floatArray29);
        float[] floatArray31 = color24.getRGBColorComponents(floatArray29);
        float[] floatArray32 = color21.getColorComponents(floatArray29);
        float[] floatArray33 = color4.getRGBColorComponents(floatArray29);
        try {
            float[] floatArray34 = color2.getComponents(floatArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        textTitle1.setPadding((double) 'a', (double) 2, 10.0d, 0.0d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        jFreeChart14.clearSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart14.createBufferedImage(100, (int) '#', 128, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 128");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNull(textTitle15);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        boolean boolean6 = piePlot1.getIgnoreZeroValues();
        piePlot1.setSimpleLabels(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int7 = color6.getAlpha();
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = null;
        try {
            piePlot0.setBaseSectionOutlinePaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        defaultKeyedValues2D1.setValue((java.lang.Number) 3, (java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        java.lang.Object obj9 = pieSectionEntity7.clone();
        java.awt.Shape shape10 = pieSectionEntity7.getArea();
        pieSectionEntity7.setSectionIndex((int) (byte) 100);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot0.getLabelLinkStyle();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot0.setURLGenerator(pieURLGenerator5);
        double double7 = piePlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Image image8 = jFreeChart3.getBackgroundImage();
        java.awt.Paint paint9 = null;
        jFreeChart3.setBackgroundPaint(paint9);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart3.getSubtitle((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        int int5 = piePlot0.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setExpandToFitSpace(true);
        double double11 = textTitle8.getWidth();
        java.awt.Paint paint12 = textTitle8.getBackgroundPaint();
        double double13 = textTitle8.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle8.getPadding();
        double double16 = rectangleInsets14.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str19 = textTitle18.getText();
        java.lang.Object obj20 = null;
        boolean boolean21 = textTitle18.equals(obj20);
        textTitle18.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle18.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets14.createInsetRectangle(rectangle2D24, false, false);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24);
        java.awt.geom.Point2D point2D29 = null;
        org.jfree.chart.plot.PlotState plotState30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            piePlot0.draw(graphics2D6, rectangle2D24, point2D29, plotState30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        piePlot1.setCircular(false, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        piePlot1.setForegroundAlpha((float) (byte) 100);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        piePlot0.setLabelGap((double) (short) 10);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot0.getToolTipGenerator();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot0.axisChanged(axisChangeEvent6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.lang.String str4 = projectInfo0.toString();
        java.lang.String str5 = projectInfo0.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo6.getOptionalLibraries();
        projectInfo6.setInfo("hi!");
        java.lang.String str10 = projectInfo6.getName();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        java.awt.Image image12 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(image12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("rect", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setMargin((double) (short) 1, (double) (byte) 10, 0.0d, (double) 10.0f);
        java.awt.Paint paint10 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.lang.Object obj9 = textTitle1.draw(graphics2D6, rectangle2D7, (java.lang.Object) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = textTitle1.getPosition();
        java.awt.Font font11 = textTitle1.getFont();
        textTitle1.setToolTipText("Other");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str1);
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        multiplePiePlot0.setNoDataMessage("RectangleAnchor.BOTTOM_RIGHT");
        float float7 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.ChartColor chartColor15 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int16 = chartColor15.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor15);
        java.awt.Color color18 = chartColor15.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        multiplePiePlot19.removeChangeListener(plotChangeListener20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj24 = null;
        boolean boolean25 = defaultDrawingSupplier23.equals(obj24);
        boolean boolean26 = jFreeChart22.equals((java.lang.Object) defaultDrawingSupplier23);
        java.awt.Paint paint27 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart22.setBackgroundPaint(paint27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        textTitle30.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent33.setType(chartChangeEventType34);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color18, jFreeChart22, chartChangeEventType34);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color18);
        int int38 = color18.getRGB();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-16698368) + "'", int16 == (-16698368));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-16496128) + "'", int38 == (-16496128));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.5f);
        java.awt.Paint paint5 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.14d);
        int int6 = piePlot1.getPieIndex();
        double double7 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart3.getTitle();
        jFreeChart3.clearSubtitles();
        org.junit.Assert.assertNull(textTitle4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = null;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        java.lang.Class<?> wildcardClass5 = shapeArray4.getClass();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        int int8 = color6.getTransparency();
        java.awt.Color color9 = color6.darker();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        try {
            java.lang.Comparable comparable3 = defaultCategoryDataset0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getParent();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color4 = java.awt.Color.cyan;
        paintMap0.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color4);
        boolean boolean7 = paintMap0.containsKey((java.lang.Comparable) "PieSection: 52, 52(15)");
        java.awt.Paint paint9 = paintMap0.getPaint((java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean4 = rectangleEdge2.equals((java.lang.Object) rectangleInsets3);
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle8.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment14, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17);
        boolean boolean19 = standardPieSectionLabelGenerator5.equals((java.lang.Object) flowArrangement17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str21 = horizontalAlignment20.toString();
        java.lang.String str22 = horizontalAlignment20.toString();
        java.lang.String str23 = horizontalAlignment20.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment20, verticalAlignment24, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setExpandToFitSpace(true);
        java.lang.Object obj32 = textTitle29.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj34 = null;
        boolean boolean35 = defaultDrawingSupplier33.equals(obj34);
        columnArrangement27.add((org.jfree.chart.block.Block) textTitle29, (java.lang.Object) defaultDrawingSupplier33);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) flowArrangement17, (org.jfree.chart.block.Arrangement) columnArrangement27);
        legendTitle37.setPadding((double) (byte) 10, (double) 'a', (double) 'a', (double) 0L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = legendTitle37.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot45 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        multiplePiePlot45.removeChangeListener(plotChangeListener46);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot48 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot48);
        multiplePiePlot45.notifyListeners(plotChangeEvent49);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("");
        textTitle52.setExpandToFitSpace(true);
        java.lang.Object obj55 = textTitle52.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = textTitle52.getMargin();
        double double58 = rectangleInsets56.trimHeight((double) (byte) 100);
        double double59 = rectangleInsets56.getBottom();
        multiplePiePlot45.setInsets(rectangleInsets56, true);
        double double63 = rectangleInsets56.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str66 = textTitle65.getText();
        java.lang.Object obj67 = null;
        boolean boolean68 = textTitle65.equals(obj67);
        textTitle65.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D71 = textTitle65.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets56.createAdjustedRectangle(rectangle2D71, lengthAdjustmentType72, lengthAdjustmentType73);
        java.lang.Object obj75 = null;
        try {
            java.lang.Object obj76 = legendTitle37.draw(graphics2D44, rectangle2D74, obj75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "HorizontalAlignment.CENTER" + "'", str21.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.CENTER" + "'", str22.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "HorizontalAlignment.CENTER" + "'", str23.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 100.0d + "'", double58 == 100.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 32.0d + "'", double63 == 32.0d);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(rectangle2D74);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color8, color9, color10, color11, color12, color13 };
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color15, color16 };
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray14, paintArray17, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle26.getMargin();
        multiplePiePlot5.setInsets(rectangleInsets28);
        java.awt.Stroke stroke30 = null;
        multiplePiePlot5.setOutlineStroke(stroke30);
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color32 };
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Color color38 = java.awt.Color.PINK;
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color34, color35, color36, color37, color38, color39 };
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color41, color42 };
        java.awt.Stroke stroke44 = null;
        java.awt.Stroke[] strokeArray45 = new java.awt.Stroke[] { stroke44 };
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray40, paintArray43, strokeArray45, strokeArray46, shapeArray47);
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        java.awt.Image image51 = null;
        multiplePiePlot0.setBackgroundImage(image51);
        java.lang.Comparable comparable53 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + "Other" + "'", comparable53.equals("Other"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color27 };
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color29, color30, color31, color32, color33, color34 };
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color36, color37 };
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray35, paintArray38, strokeArray40, strokeArray41, shapeArray42);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot45 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset46 = multiplePiePlot45.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = multiplePiePlot45.getInsets();
        org.jfree.chart.JFreeChart jFreeChart48 = multiplePiePlot45.getPieChart();
        double double49 = multiplePiePlot45.getLimit();
        java.awt.Font font50 = multiplePiePlot45.getNoDataMessageFont();
        boolean boolean51 = defaultDrawingSupplier43.equals((java.lang.Object) multiplePiePlot45);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNull(categoryDataset46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(jFreeChart48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Rotation.CLOCKWISE", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("hi!");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (-65536), 0.0d, (double) (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color4 = java.awt.Color.cyan;
        paintMap0.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D11 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list12 = defaultKeyedValues2D11.getRowKeys();
        jFreeChart9.setSubtitles(list12);
        jFreeChart9.setBackgroundImageAlpha((float) (short) -1);
        jFreeChart9.removeLegend();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D18 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list19 = defaultKeyedValues2D18.getRowKeys();
        jFreeChart9.setSubtitles(list19);
        boolean boolean21 = paintMap0.equals((java.lang.Object) jFreeChart9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getLabelLinkMargin();
        piePlot1.setExplodePercent((java.lang.Comparable) 0, (double) 0L);
        org.jfree.chart.util.Rotation rotation12 = piePlot1.getDirection();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNotNull(rotation12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "HorizontalAlignment.CENTER");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HorizontalAlignment.CENTER" + "'", str4.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int10 = chartColor9.getRGB();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = chartColor9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        legendTitle4.setBackgroundPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle4.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle4.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle4.getLegendItemGraphicAnchor();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = legendTitle4.getHorizontalAlignment();
        legendTitle4.setPadding((double) (byte) 0, (double) (-1), 10.0d, (double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16698368) + "'", int10 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint4 = jFreeChart3.getBorderPaint();
        jFreeChart3.setBackgroundImageAlignment(52);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        java.awt.Paint paint3 = piePlot0.getLabelLinkPaint();
        java.awt.Paint paint5 = piePlot0.getSectionPaint((java.lang.Comparable) 3);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        projectInfo0.setVersion("ChartChangeEventType.NEW_DATASET");
        projectInfo0.setLicenceName("-4,-4,4,4");
        java.lang.String str10 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-4,-4,4,4" + "'", str10.equals("-4,-4,4,4"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.lang.Object obj5 = textTitle1.clone();
        java.awt.Paint paint6 = textTitle1.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle1.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.awt.Font font5 = textTitle1.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str7 = horizontalAlignment6.toString();
        java.lang.String str8 = horizontalAlignment6.toString();
        textTitle1.setTextAlignment(horizontalAlignment6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot10);
        org.jfree.chart.plot.Plot plot12 = multiplePiePlot10.getParent();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot10);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle13.getLegendItemGraphicEdge();
        textTitle1.setPosition(rectangleEdge14);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HorizontalAlignment.CENTER" + "'", str8.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot1.getLabelLinkStyle();
        java.awt.Image image5 = piePlot1.getBackgroundImage();
        piePlot1.setStartAngle(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=128,g=255,b=255]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.util.List list4 = projectInfo0.getContributors();
        projectInfo0.setVersion("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        java.awt.Color color4 = java.awt.Color.pink;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        float[] floatArray7 = new float[] { 52 };
        try {
            float[] floatArray8 = color4.getRGBColorComponents(floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.util.List list2 = defaultCategoryDataset0.getColumnKeys();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultCategoryDataset3.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        multiplePiePlot5.removeChangeListener(plotChangeListener6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot8);
        multiplePiePlot5.notifyListeners(plotChangeEvent9);
        java.awt.Paint paint11 = multiplePiePlot5.getAggregatedItemsPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        multiplePiePlot5.setInsets(rectangleInsets12, true);
        boolean boolean15 = datasetGroup4.equals((java.lang.Object) true);
        defaultCategoryDataset0.setGroup(datasetGroup4);
        try {
            defaultCategoryDataset0.removeColumn((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        piePlot0.setBackgroundAlpha((float) ' ');
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle8.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment14, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17);
        boolean boolean19 = standardPieSectionLabelGenerator5.equals((java.lang.Object) flowArrangement17);
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator5.getPercentFormat();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        java.lang.String str23 = standardPieSectionLabelGenerator5.generateSectionLabel(pieDataset21, (java.lang.Comparable) 1.0d);
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator5);
        java.text.NumberFormat numberFormat25 = standardPieSectionLabelGenerator5.getNumberFormat();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(numberFormat25);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 1, (float) 128, (float) 175);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-141358) + "'", int3 == (-141358));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        multiplePiePlot5.removeChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle13.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment19, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22);
        boolean boolean24 = standardPieSectionLabelGenerator10.equals((java.lang.Object) flowArrangement22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str26 = horizontalAlignment25.toString();
        java.lang.String str27 = horizontalAlignment25.toString();
        java.lang.String str28 = horizontalAlignment25.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment25, verticalAlignment29, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setExpandToFitSpace(true);
        java.lang.Object obj37 = textTitle34.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj39 = null;
        boolean boolean40 = defaultDrawingSupplier38.equals(obj39);
        columnArrangement32.add((org.jfree.chart.block.Block) textTitle34, (java.lang.Object) defaultDrawingSupplier38);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.block.Arrangement arrangement43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) columnArrangement32, arrangement43);
        java.lang.String str45 = piePlot0.getPlotType();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator46 = piePlot0.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "HorizontalAlignment.CENTER" + "'", str26.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "HorizontalAlignment.CENTER" + "'", str27.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.CENTER" + "'", str28.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Pie Plot" + "'", str45.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator46);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        double double8 = rectangleInsets5.getTop();
        double double10 = rectangleInsets5.extendHeight((double) (-1));
        double double12 = rectangleInsets5.calculateTopInset((double) 0.5f);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("org.jfree.data.UnknownKeyException: hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        double double3 = piePlot0.getLabelGap();
        int int4 = piePlot0.getPieIndex();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot0.getLabelDistributor();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list7 = defaultCategoryDataset6.getRowKeys();
        defaultCategoryDataset6.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) abstractPieLabelDistributor5, (org.jfree.data.general.Dataset) defaultCategoryDataset6);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord13 = null;
        try {
            abstractPieLabelDistributor5.addPieLabelRecord(pieLabelRecord13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.lang.String str4 = projectInfo0.toString();
        java.lang.String str5 = projectInfo0.getName();
        projectInfo0.setLicenceName("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 0.4d, comparable3, (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        textTitle1.setID("Multiple Pie Plot");
        java.lang.Object obj6 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        try {
            java.lang.Object obj5 = jFreeChartResources0.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setOutlineStroke(stroke8);
        java.awt.Shape shape10 = piePlot1.getLegendItemShape();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset0.removeRow((int) (short) 0);
        java.util.List list8 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.incrementValue((double) (-524308), (java.lang.Comparable) 0.0d, (java.lang.Comparable) "RectangleAnchor.CENTER");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: RectangleAnchor.CENTER");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = legendTitle4.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle4.getLegendItemGraphicAnchor();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        textTitle10.setExpandToFitSpace(true);
        java.lang.Object obj13 = textTitle10.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle10.getMargin();
        double double16 = rectangleInsets14.trimHeight((double) (byte) 100);
        double double17 = rectangleInsets14.getTop();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = lineBorder18.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = lineBorder18.getInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        multiplePiePlot21.removeChangeListener(plotChangeListener22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot24);
        multiplePiePlot21.notifyListeners(plotChangeEvent25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        textTitle28.setExpandToFitSpace(true);
        java.lang.Object obj31 = textTitle28.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = textTitle28.getMargin();
        double double34 = rectangleInsets32.trimHeight((double) (byte) 100);
        double double35 = rectangleInsets32.getBottom();
        multiplePiePlot21.setInsets(rectangleInsets32, true);
        double double39 = rectangleInsets32.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str42 = textTitle41.getText();
        java.lang.Object obj43 = null;
        boolean boolean44 = textTitle41.equals(obj43);
        textTitle41.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle41.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets32.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType48, lengthAdjustmentType49);
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets20.createInsetRectangle(rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets14.createInsetRectangle(rectangle2D51);
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle("");
        textTitle54.setExpandToFitSpace(true);
        java.lang.Object obj57 = textTitle54.clone();
        try {
            java.lang.Object obj58 = legendTitle4.draw(graphics2D8, rectangle2D52, (java.lang.Object) textTitle54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 32.0d + "'", double39 == 32.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeColumn((-16698368));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = null;
        boolean boolean2 = defaultDrawingSupplier0.equals(obj1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        textTitle4.setExpandToFitSpace(true);
        java.lang.Object obj7 = textTitle4.clone();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        textTitle4.draw(graphics2D8, rectangle2D9);
        java.awt.Paint paint11 = textTitle4.getPaint();
        textTitle4.setHeight((double) (byte) 10);
        boolean boolean14 = defaultDrawingSupplier0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.awt.Image image4 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(image4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        java.text.NumberFormat numberFormat15 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        java.lang.String str18 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset16, (java.lang.Comparable) '#');
        java.lang.String str19 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0}" + "'", str19.equals("{0}"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot0.setLabelPaint((java.awt.Paint) chartColor6);
        java.awt.Paint paint8 = piePlot0.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Color color11 = java.awt.Color.blue;
        piePlot10.setBaseSectionOutlinePaint((java.awt.Paint) color11);
        piePlot10.setMaximumLabelWidth(100.0d);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot10.setBaseSectionPaint((java.awt.Paint) color15);
        double double17 = piePlot10.getLabelLinkMargin();
        piePlot10.setExplodePercent((java.lang.Comparable) 0, (double) 0L);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D22 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        multiplePiePlot25.removeChangeListener(plotChangeListener26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot25);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot25);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle29.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor34 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int35 = chartColor34.getRGB();
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = chartColor34.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        legendTitle29.setBackgroundPaint((java.awt.Paint) chartColor34);
        piePlot24.setBaseSectionPaint((java.awt.Paint) chartColor34);
        java.awt.Paint paint44 = piePlot24.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator45 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset46 = null;
        java.lang.String str48 = standardPieSectionLabelGenerator45.generateSectionLabel(pieDataset46, (java.lang.Comparable) 10.0f);
        piePlot24.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator45);
        boolean boolean50 = defaultKeyedValues2D22.equals((java.lang.Object) standardPieSectionLabelGenerator45);
        piePlot10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator45);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str54 = textTitle53.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = textTitle53.getMargin();
        java.lang.String str56 = textTitle53.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = textTitle53.getMargin();
        boolean boolean58 = textTitle53.getExpandToFitSpace();
        java.awt.Font font59 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle53.setFont(font59);
        boolean boolean61 = standardPieSectionLabelGenerator45.equals((java.lang.Object) textTitle53);
        piePlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator45);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-16698368) + "'", int35 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.Rotation rotation3 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot0.setDirection(rotation3);
        boolean boolean6 = rotation3.equals((java.lang.Object) 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Image image8 = jFreeChart3.getBackgroundImage();
        java.awt.Paint paint9 = null;
        jFreeChart3.setBackgroundPaint(paint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart3.getPadding();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        multiplePiePlot5.removeChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle13.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment19, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22);
        boolean boolean24 = standardPieSectionLabelGenerator10.equals((java.lang.Object) flowArrangement22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str26 = horizontalAlignment25.toString();
        java.lang.String str27 = horizontalAlignment25.toString();
        java.lang.String str28 = horizontalAlignment25.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment25, verticalAlignment29, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setExpandToFitSpace(true);
        java.lang.Object obj37 = textTitle34.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj39 = null;
        boolean boolean40 = defaultDrawingSupplier38.equals(obj39);
        columnArrangement32.add((org.jfree.chart.block.Block) textTitle34, (java.lang.Object) defaultDrawingSupplier38);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.block.Arrangement arrangement43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) columnArrangement32, arrangement43);
        legendTitle44.setHeight((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "HorizontalAlignment.CENTER" + "'", str26.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "HorizontalAlignment.CENTER" + "'", str27.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.CENTER" + "'", str28.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray6 = jFreeChartResources0.getStringArray("-4,-4,4,4");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key -4,-4,4,4");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(strEnumeration4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.lang.Object obj8 = jFreeChart3.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart3.getPadding();
        org.jfree.chart.plot.Plot plot10 = jFreeChart3.getPlot();
        java.awt.Paint paint11 = null;
        jFreeChart3.setBackgroundPaint(paint11);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        defaultKeyedValues2D1.addValue((java.lang.Number) (byte) -1, (java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE", (java.lang.Comparable) 1.0d);
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = lineBorder8.getInsets();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        double double11 = piePlot10.getLabelGap();
        double double12 = piePlot10.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot10.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = null;
        piePlot10.setLegendLabelURLGenerator(pieURLGenerator14);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        textTitle17.setExpandToFitSpace(true);
        java.lang.Object obj20 = textTitle17.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle17.getMargin();
        double double23 = rectangleInsets21.trimHeight((double) (byte) 100);
        double double24 = rectangleInsets21.getBottom();
        double double26 = rectangleInsets21.calculateTopInset((double) (byte) 100);
        piePlot10.setInsets(rectangleInsets21);
        boolean boolean28 = lineBorder8.equals((java.lang.Object) rectangleInsets21);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        textTitle31.setExpandToFitSpace(true);
        java.lang.Object obj34 = textTitle31.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = textTitle31.getMargin();
        double double37 = rectangleInsets35.trimHeight((double) 100.0f);
        double double39 = rectangleInsets35.calculateTopOutset((double) 0L);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot40 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray42 = new java.awt.Paint[] { color41 };
        java.awt.Color color43 = java.awt.Color.PINK;
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Color color45 = java.awt.Color.PINK;
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Color color48 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray49 = new java.awt.Paint[] { color43, color44, color45, color46, color47, color48 };
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Color color51 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray52 = new java.awt.Paint[] { color50, color51 };
        java.awt.Stroke stroke53 = null;
        java.awt.Stroke[] strokeArray54 = new java.awt.Stroke[] { stroke53 };
        java.awt.Stroke[] strokeArray55 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray56 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier57 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray42, paintArray49, paintArray52, strokeArray54, strokeArray55, shapeArray56);
        java.awt.Paint paint58 = defaultDrawingSupplier57.getNextOutlinePaint();
        multiplePiePlot40.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier57);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str62 = textTitle61.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = textTitle61.getMargin();
        multiplePiePlot40.setInsets(rectangleInsets63);
        java.awt.Stroke stroke65 = null;
        multiplePiePlot40.setOutlineStroke(stroke65);
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str70 = textTitle69.getText();
        java.lang.Object obj71 = null;
        boolean boolean72 = textTitle69.equals(obj71);
        textTitle69.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D75 = textTitle69.getBounds();
        multiplePiePlot40.drawBackgroundImage(graphics2D67, rectangle2D75);
        rectangleInsets35.trim(rectangle2D75);
        lineBorder8.draw(graphics2D29, rectangle2D75);
        java.awt.Stroke stroke79 = lineBorder8.getStroke();
        boolean boolean80 = defaultKeyedValues2D1.equals((java.lang.Object) lineBorder8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paintArray42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paintArray49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(strokeArray55);
        org.junit.Assert.assertNotNull(shapeArray56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        java.lang.Object obj5 = piePlot0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str5 = horizontalAlignment4.toString();
        java.lang.String str6 = horizontalAlignment4.toString();
        java.lang.String str7 = horizontalAlignment4.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment8, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        java.lang.Object obj16 = textTitle13.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj18 = null;
        boolean boolean19 = defaultDrawingSupplier17.equals(obj18);
        columnArrangement11.add((org.jfree.chart.block.Block) textTitle13, (java.lang.Object) defaultDrawingSupplier17);
        java.awt.Stroke stroke21 = defaultDrawingSupplier17.getNextStroke();
        java.awt.Shape shape22 = defaultDrawingSupplier17.getNextShape();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.util.TableOrder tableOrder24 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot25);
        org.jfree.chart.plot.Plot plot27 = multiplePiePlot25.getParent();
        java.lang.String str28 = multiplePiePlot25.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset29 = multiplePiePlot25.getDataset();
        multiplePiePlot25.setNoDataMessage("RectangleAnchor.BOTTOM_RIGHT");
        org.jfree.chart.util.TableOrder tableOrder32 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot25.setDataExtractOrder(tableOrder32);
        boolean boolean34 = tableOrder24.equals((java.lang.Object) multiplePiePlot25);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HorizontalAlignment.CENTER" + "'", str5.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HorizontalAlignment.CENTER" + "'", str6.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(tableOrder24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Multiple Pie Plot" + "'", str28.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset29);
        org.junit.Assert.assertNotNull(tableOrder32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot1.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        projectInfo0.setVersion("hi!");
        java.util.List list8 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Image image8 = jFreeChart3.getBackgroundImage();
        jFreeChart3.setBackgroundImageAlpha((float) '4');
        jFreeChart3.setNotify(false);
        boolean boolean13 = jFreeChart3.getAntiAlias();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        boolean boolean8 = jFreeChart3.isNotify();
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        double double4 = legendTitle3.getContentXOffset();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        double double4 = rectangleInsets3.getBottom();
        double double5 = rectangleInsets3.getLeft();
        double double6 = rectangleInsets3.getBottom();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 10L);
        java.awt.Paint paint4 = paintMap0.getPaint((java.lang.Comparable) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = null;
        piePlot2.setSectionOutlinePaint((java.lang.Comparable) "PieSection: 52, 52(8)", paint4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: {0}", font1, (org.jfree.chart.plot.Plot) piePlot2, true);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D10 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color11 = java.awt.Color.PINK;
        boolean boolean12 = defaultKeyedValues2D10.equals((java.lang.Object) color11);
        java.awt.Color color13 = java.awt.Color.getColor("", color11);
        piePlot2.setLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        boolean boolean9 = jFreeChart3.getAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart3.getLegend();
        org.jfree.chart.title.Title title11 = null;
        try {
            jFreeChart3.addSubtitle(title11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(legendTitle10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        boolean boolean2 = objectList0.equals(obj1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int14 = chartColor13.getRGB();
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = chartColor13.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        legendTitle8.setBackgroundPaint((java.awt.Paint) chartColor13);
        multiplePiePlot3.setOutlinePaint((java.awt.Paint) chartColor13);
        float[] floatArray23 = null;
        float[] floatArray24 = chartColor13.getColorComponents(floatArray23);
        boolean boolean25 = objectList0.equals((java.lang.Object) chartColor13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-16698368) + "'", int14 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        double double5 = textTitle1.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle1.getPosition();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (-16777216));
        double double4 = rectangleInsets0.trimHeight((double) (short) -1);
        double double6 = rectangleInsets0.calculateBottomOutset((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        double double3 = piePlot0.getStartAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setHeight((double) 2);
        java.lang.String str7 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle1.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        textTitle1.setPosition(rectangleEdge9);
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        double double16 = piePlot15.getLabelGap();
        double double17 = piePlot15.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot15.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = null;
        piePlot15.setLegendLabelURLGenerator(pieURLGenerator19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        java.lang.Object obj25 = textTitle22.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle22.getMargin();
        double double28 = rectangleInsets26.trimHeight((double) (byte) 100);
        double double29 = rectangleInsets26.getBottom();
        double double31 = rectangleInsets26.calculateTopInset((double) (byte) 100);
        piePlot15.setInsets(rectangleInsets26);
        boolean boolean33 = lineBorder13.equals((java.lang.Object) rectangleInsets26);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        textTitle36.setExpandToFitSpace(true);
        java.lang.Object obj39 = textTitle36.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle36.getMargin();
        double double42 = rectangleInsets40.trimHeight((double) 100.0f);
        double double44 = rectangleInsets40.calculateTopOutset((double) 0L);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot45 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray47 = new java.awt.Paint[] { color46 };
        java.awt.Color color48 = java.awt.Color.PINK;
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Color color51 = java.awt.Color.PINK;
        java.awt.Color color52 = java.awt.Color.PINK;
        java.awt.Color color53 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray54 = new java.awt.Paint[] { color48, color49, color50, color51, color52, color53 };
        java.awt.Color color55 = java.awt.Color.PINK;
        java.awt.Color color56 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] { color55, color56 };
        java.awt.Stroke stroke58 = null;
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] { stroke58 };
        java.awt.Stroke[] strokeArray60 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray61 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier62 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray47, paintArray54, paintArray57, strokeArray59, strokeArray60, shapeArray61);
        java.awt.Paint paint63 = defaultDrawingSupplier62.getNextOutlinePaint();
        multiplePiePlot45.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier62);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str67 = textTitle66.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = textTitle66.getMargin();
        multiplePiePlot45.setInsets(rectangleInsets68);
        java.awt.Stroke stroke70 = null;
        multiplePiePlot45.setOutlineStroke(stroke70);
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.title.TextTitle textTitle74 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str75 = textTitle74.getText();
        java.lang.Object obj76 = null;
        boolean boolean77 = textTitle74.equals(obj76);
        textTitle74.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D80 = textTitle74.getBounds();
        multiplePiePlot45.drawBackgroundImage(graphics2D72, rectangle2D80);
        rectangleInsets40.trim(rectangle2D80);
        lineBorder13.draw(graphics2D34, rectangle2D80);
        textTitle1.setBounds(rectangle2D80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.025d + "'", double16 == 0.025d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(paintArray47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paintArray54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(strokeArray60);
        org.junit.Assert.assertNotNull(shapeArray61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int3 = java.awt.Color.HSBtoRGB((float) 10L, (float) (-65536), (float) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-65280) + "'", int3 == (-65280));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        objectList0.clear();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        textTitle4.setExpandToFitSpace(true);
        java.lang.Object obj7 = textTitle4.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle4.getMargin();
        double double10 = rectangleInsets8.trimHeight((double) 100.0f);
        double double12 = rectangleInsets8.calculateTopOutset((double) 0L);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color16, color17, color18, color19, color20, color21 };
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke stroke26 = null;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray22, paintArray25, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextOutlinePaint();
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str35 = textTitle34.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle34.getMargin();
        multiplePiePlot13.setInsets(rectangleInsets36);
        java.awt.Stroke stroke38 = null;
        multiplePiePlot13.setOutlineStroke(stroke38);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str43 = textTitle42.getText();
        java.lang.Object obj44 = null;
        boolean boolean45 = textTitle42.equals(obj44);
        textTitle42.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D48 = textTitle42.getBounds();
        multiplePiePlot13.drawBackgroundImage(graphics2D40, rectangle2D48);
        rectangleInsets8.trim(rectangle2D48);
        int int51 = objectList0.indexOf((java.lang.Object) rectangle2D48);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int7 = color6.getAlpha();
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.lang.Class<?> wildcardClass9 = piePlot0.getClass();
        double double10 = piePlot0.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle8.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment14, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17);
        boolean boolean19 = standardPieSectionLabelGenerator5.equals((java.lang.Object) flowArrangement17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str21 = horizontalAlignment20.toString();
        java.lang.String str22 = horizontalAlignment20.toString();
        java.lang.String str23 = horizontalAlignment20.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment20, verticalAlignment24, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setExpandToFitSpace(true);
        java.lang.Object obj32 = textTitle29.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj34 = null;
        boolean boolean35 = defaultDrawingSupplier33.equals(obj34);
        columnArrangement27.add((org.jfree.chart.block.Block) textTitle29, (java.lang.Object) defaultDrawingSupplier33);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) flowArrangement17, (org.jfree.chart.block.Arrangement) columnArrangement27);
        java.awt.Paint paint38 = legendTitle37.getBackgroundPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "HorizontalAlignment.CENTER" + "'", str21.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.CENTER" + "'", str22.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "HorizontalAlignment.CENTER" + "'", str23.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.plot.Plot plot5 = jFreeChart3.getPlot();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle1.getPadding();
        double double9 = rectangleInsets7.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.lang.Object obj13 = null;
        boolean boolean14 = textTitle11.equals(obj13);
        textTitle11.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets7.createInsetRectangle(rectangle2D17, false, false);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "PieSection: 52, 52(15)");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image11 = projectInfo10.getLogo();
        jFreeChart3.setBackgroundImage(image11);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(image11);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) 100.0f);
        double double9 = rectangleInsets5.calculateRightInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = null;
        piePlot1.setShadowPaint(paint2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        java.awt.Paint paint11 = blockBorder9.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder9.getInsets();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.Rotation rotation3 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot0.setDirection(rotation3);
        piePlot0.setSimpleLabels(true);
        double double7 = piePlot0.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        multiplePiePlot1.setOutlineVisible(false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.chart.plot.Plot plot7 = plotChangeEvent6.getPlot();
        multiplePiePlot1.notifyListeners(plotChangeEvent6);
        try {
            multiplePiePlot1.setBackgroundImageAlpha((float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setToolTipText("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE");
        java.lang.Object obj15 = pieSectionEntity7.clone();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator16 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator17 = null;
        try {
            java.lang.String str18 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator16, uRLTagFragmentGenerator17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        boolean boolean5 = jFreeChart3.getAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener6 = null;
        jFreeChart3.removeProgressListener(chartProgressListener6);
        java.lang.Object obj8 = jFreeChart3.clone();
        java.awt.Stroke stroke9 = null;
        jFreeChart3.setBorderStroke(stroke9);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot2);
        int int6 = defaultCategoryDataset0.getRowCount();
        try {
            java.lang.Comparable comparable8 = defaultCategoryDataset0.getRowKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: PieLabelLinkStyle.QUAD_CURVE");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        double double16 = rectangleInsets11.calculateTopInset((double) (byte) 100);
        piePlot0.setInsets(rectangleInsets11);
        int int18 = piePlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = null;
        piePlot2.setSectionOutlinePaint((java.lang.Comparable) "PieSection: 52, 52(8)", paint4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: {0}", font1, (org.jfree.chart.plot.Plot) piePlot2, true);
        float float8 = jFreeChart7.getBackgroundImageAlpha();
        boolean boolean9 = jFreeChart7.isNotify();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int3 = java.awt.Color.HSBtoRGB((float) (-16496128), (float) (-1L), (float) (-16777216));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setLicenceText("RectangleAnchor.BOTTOM");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        piePlot1.markerChanged(markerChangeEvent9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 0.0f);
        strokeMap0.clear();
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.setValue((java.lang.Number) 100, (java.lang.Comparable) 0, (java.lang.Comparable) "org.jfree.data.UnknownKeyException: {0}");
        java.lang.Comparable comparable8 = defaultKeyedValues2D1.getRowKey(0);
        java.lang.Object obj9 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0 + "'", comparable8.equals(0));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.setBackgroundImageAlpha((float) (short) -1);
        jFreeChart3.setBorderVisible(false);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        java.lang.String str3 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.BOTTOM" + "'", str3.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot0.getDataExtractOrder();
        multiplePiePlot0.zoom((double) 128);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(tableOrder17);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = color9.darker();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) (short) 100, 4.0d, (double) 100L, 4.0d, (java.awt.Paint) color10);
        java.awt.Paint paint12 = blockBorder11.getPaint();
        legendTitle4.setBackgroundPaint(paint12);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
//        projectInfo0.setName("");
//        java.lang.String str4 = projectInfo0.getName();
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image6 = projectInfo5.getLogo();
//        java.util.List list7 = projectInfo5.getContributors();
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo9.getOptionalLibraries();
//        projectInfo9.setName("");
//        java.lang.String str13 = projectInfo9.toString();
//        projectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo9);
//        org.jfree.chart.ui.ProjectInfo projectInfo15 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray16 = projectInfo15.getOptionalLibraries();
//        projectInfo15.setName("");
//        java.lang.String str19 = projectInfo15.toString();
//        java.lang.String str20 = projectInfo15.getLicenceText();
//        projectInfo9.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(libraryArray1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertNotNull(image6);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertNotNull(projectInfo9);
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " version org.jfree.data.UnknownKeyException: hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY : org.jfree.data.UnknownKeyException: hi! (hi!). org.jfree.data.UnknownKeyException: hi! (hi!).\n LICENCE TERMS:\nRectangleAnchor.BOTTOM" + "'", str13.equals(" version org.jfree.data.UnknownKeyException: hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY : org.jfree.data.UnknownKeyException: hi! (hi!). org.jfree.data.UnknownKeyException: hi! (hi!).\n LICENCE TERMS:\nRectangleAnchor.BOTTOM"));
//        org.junit.Assert.assertNotNull(projectInfo15);
//        org.junit.Assert.assertNotNull(libraryArray16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + " version org.jfree.data.UnknownKeyException: hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY : org.jfree.data.UnknownKeyException: hi! (hi!). org.jfree.data.UnknownKeyException: hi! (hi!).\n LICENCE TERMS:\nRectangleAnchor.BOTTOM" + "'", str19.equals(" version org.jfree.data.UnknownKeyException: hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY : org.jfree.data.UnknownKeyException: hi! (hi!). org.jfree.data.UnknownKeyException: hi! (hi!).\n LICENCE TERMS:\nRectangleAnchor.BOTTOM"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str20.equals("RectangleAnchor.BOTTOM"));
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.util.List list2 = projectInfo0.getContributors();
//        java.lang.String str3 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str3.equals("org.jfree.data.UnknownKeyException: hi!"));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle3.getItemContainer();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(blockContainer4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color2 = java.awt.Color.getColor("{0}", color1);
        java.awt.Color color3 = color2.brighter();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        java.lang.String str2 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TableOrder.BY_COLUMN" + "'", str2.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle(" version org.jfree.data.UnknownKeyException: hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY : org.jfree.data.UnknownKeyException: hi! (hi!). org.jfree.data.UnknownKeyException: hi! (hi!).\n LICENCE TERMS:\nRectangleAnchor.BOTTOM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("Multiple Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Multiple Pie Plot");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot0.getLegendLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = lineBorder3.getInsets();
        java.awt.Stroke stroke5 = lineBorder3.getStroke();
        piePlot0.setLabelOutlineStroke(stroke5);
        java.awt.Paint paint7 = piePlot0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Color color2 = java.awt.Color.PINK;
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color2, color3, color4, color5, color6, color7 };
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color9, color10 };
        java.awt.Stroke stroke12 = null;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray8, paintArray11, strokeArray13, strokeArray14, shapeArray15);
        java.awt.Color color17 = java.awt.Color.GRAY;
        float[] floatArray18 = null;
        float[] floatArray19 = color17.getRGBColorComponents(floatArray18);
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Color color22 = java.awt.Color.WHITE;
        java.awt.Paint paint23 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color17, color20, color21, color22, paint23, color24 };
        java.awt.Stroke[] strokeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray25, strokeArray26, strokeArray27, shapeArray28);
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextOutlinePaint();
        java.lang.Object obj31 = defaultDrawingSupplier29.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        java.awt.Paint paint21 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator22);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        defaultKeyedValues2D1.addValue((java.lang.Number) 0.0d, (java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE", (java.lang.Comparable) (-16698368));
        java.util.List list8 = defaultKeyedValues2D1.getColumnKeys();
        defaultKeyedValues2D1.addValue((java.lang.Number) 1, (java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) "java.awt.Color[r=255,g=175,b=175]");
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle14.getMargin();
        double double17 = rectangleInsets16.getTop();
        double double19 = rectangleInsets16.calculateBottomOutset((double) (byte) 10);
        boolean boolean20 = defaultKeyedValues2D1.equals((java.lang.Object) double19);
        java.util.List list21 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        textTitle1.setPadding((double) 'a', (double) 2, 10.0d, 0.0d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        jFreeChart14.clearSubtitles();
        jFreeChart14.setTextAntiAlias(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNull(textTitle15);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent5);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryDataset4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot1.getRootPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(plot3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-524308));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("{0}");
        boolean boolean7 = jFreeChartResources0.containsKey("TableOrder.BY_COLUMN");
        java.util.Set<java.lang.String> strSet8 = jFreeChartResources0.keySet();
        java.util.Locale locale9 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(locale9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.util.List list2 = defaultCategoryDataset0.getColumnKeys();
        java.lang.Object obj3 = defaultCategoryDataset0.clone();
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 8);
        defaultCategoryDataset0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 3, (java.lang.Comparable) 128);
        try {
            defaultCategoryDataset0.removeRow(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str9 = pieSectionEntity8.toString();
        pieSectionEntity8.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity8.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        java.awt.Shape shape14 = pieSectionEntity8.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape14, "");
        boolean boolean17 = horizontalAlignment0.equals((java.lang.Object) chartEntity16);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PieSection: 52, 52(8)" + "'", str9.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle8.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment14, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17);
        boolean boolean19 = standardPieSectionLabelGenerator5.equals((java.lang.Object) flowArrangement17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str21 = horizontalAlignment20.toString();
        java.lang.String str22 = horizontalAlignment20.toString();
        java.lang.String str23 = horizontalAlignment20.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment20, verticalAlignment24, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setExpandToFitSpace(true);
        java.lang.Object obj32 = textTitle29.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj34 = null;
        boolean boolean35 = defaultDrawingSupplier33.equals(obj34);
        columnArrangement27.add((org.jfree.chart.block.Block) textTitle29, (java.lang.Object) defaultDrawingSupplier33);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) flowArrangement17, (org.jfree.chart.block.Arrangement) columnArrangement27);
        legendTitle37.setPadding((double) (byte) 10, (double) 'a', (double) 'a', (double) 0L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = legendTitle37.getHorizontalAlignment();
        legendTitle37.setNotify(false);
        java.awt.Font font47 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean50 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge49);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean53 = rectangleEdge51.equals((java.lang.Object) rectangleInsets52);
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle54.setTextAlignment(horizontalAlignment55);
        org.jfree.chart.util.VerticalAlignment verticalAlignment57 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("");
        textTitle59.setExpandToFitSpace(true);
        java.lang.Object obj62 = textTitle59.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = textTitle59.getMargin();
        double double65 = rectangleInsets63.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType66 = rectangleInsets63.getUnitType();
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font47, (java.awt.Paint) color48, rectangleEdge51, horizontalAlignment55, verticalAlignment57, rectangleInsets63);
        legendTitle37.setItemFont(font47);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "HorizontalAlignment.CENTER" + "'", str21.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.CENTER" + "'", str22.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "HorizontalAlignment.CENTER" + "'", str23.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertNotNull(verticalAlignment57);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(unitType66);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        multiplePiePlot5.removeChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle13.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment19, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22);
        boolean boolean24 = standardPieSectionLabelGenerator10.equals((java.lang.Object) flowArrangement22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str26 = horizontalAlignment25.toString();
        java.lang.String str27 = horizontalAlignment25.toString();
        java.lang.String str28 = horizontalAlignment25.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment25, verticalAlignment29, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setExpandToFitSpace(true);
        java.lang.Object obj37 = textTitle34.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj39 = null;
        boolean boolean40 = defaultDrawingSupplier38.equals(obj39);
        columnArrangement32.add((org.jfree.chart.block.Block) textTitle34, (java.lang.Object) defaultDrawingSupplier38);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.block.Arrangement arrangement43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) columnArrangement32, arrangement43);
        java.lang.String str45 = piePlot0.getPlotType();
        java.awt.Paint paint46 = piePlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "HorizontalAlignment.CENTER" + "'", str26.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "HorizontalAlignment.CENTER" + "'", str27.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.CENTER" + "'", str28.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Pie Plot" + "'", str45.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        double double16 = rectangleInsets11.calculateTopInset((double) (byte) 100);
        piePlot0.setInsets(rectangleInsets11);
        double double18 = rectangleInsets11.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset15, (java.lang.Comparable) '#');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle19.getMargin();
        boolean boolean22 = standardPieSectionLabelGenerator0.equals((java.lang.Object) textTitle19);
        java.lang.Object obj23 = standardPieSectionLabelGenerator0.clone();
        java.lang.String str24 = standardPieSectionLabelGenerator0.getLabelFormat();
        java.lang.String str25 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0}" + "'", str25.equals("{0}"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        double double12 = textTitle9.getWidth();
        java.lang.Object obj13 = textTitle9.clone();
        java.awt.Paint paint14 = textTitle9.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = textTitle9.getPosition();
        textTitle1.setPosition(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean13 = rectangleEdge11.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle14.setTextAlignment(horizontalAlignment15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        textTitle19.setExpandToFitSpace(true);
        java.lang.Object obj22 = textTitle19.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle19.getMargin();
        double double25 = rectangleInsets23.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType26 = rectangleInsets23.getUnitType();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font7, (java.awt.Paint) color8, rectangleEdge11, horizontalAlignment15, verticalAlignment17, rectangleInsets23);
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment17, 10.0d, 90.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment31, 0.0d, (double) 1);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean36 = columnArrangement34.equals((java.lang.Object) color35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(unitType26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setToolTipText("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator13 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator14 = null;
        try {
            java.lang.String str15 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator13, uRLTagFragmentGenerator14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 0.4d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D11 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list12 = defaultKeyedValues2D11.getRowKeys();
        jFreeChart9.setSubtitles(list12);
        java.awt.Image image14 = jFreeChart9.getBackgroundImage();
        jFreeChart9.setBackgroundImageAlpha((float) '4');
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        double double20 = piePlot19.getLabelGap();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot19);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        java.awt.Color color24 = java.awt.Color.blue;
        piePlot23.setBaseSectionOutlinePaint((java.awt.Paint) color24);
        piePlot23.setMaximumLabelWidth(100.0d);
        java.awt.Paint paint29 = piePlot23.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Paint paint30 = piePlot23.getLabelOutlinePaint();
        java.awt.Stroke stroke31 = piePlot23.getBaseSectionOutlineStroke();
        piePlot19.setLabelOutlineStroke(stroke31);
        jFreeChart9.setBorderStroke(stroke31);
        multiplePiePlot0.setOutlineStroke(stroke31);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.025d + "'", double20 == 0.025d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        int int4 = defaultKeyedValues2D1.getRowCount();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) "HorizontalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color2 };
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color4, color5, color6, color7, color8, color9 };
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color11, color12 };
        java.awt.Stroke stroke14 = null;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke14 };
        java.awt.Stroke[] strokeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray10, paintArray13, strokeArray15, strokeArray16, shapeArray17);
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextOutlinePaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean21 = defaultDrawingSupplier18.equals((java.lang.Object) paint20);
        piePlot1.setLabelBackgroundPaint(paint20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator23 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(pieURLGenerator23);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Paint paint8 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        piePlot1.setBackgroundImageAlignment((int) '#');
        java.awt.Shape shape12 = piePlot1.getLegendItemShape();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels((double) (byte) 0, 10.0d);
        pieLabelDistributor1.clear();
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setExpandToFitSpace(true);
        java.lang.Object obj24 = textTitle21.clone();
        java.awt.Font font25 = textTitle21.getFont();
        blockContainer12.add((org.jfree.chart.block.Block) textTitle21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        multiplePiePlot27.removeChangeListener(plotChangeListener28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot27);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot27);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle31.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor36 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int37 = chartColor36.getRGB();
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.AffineTransform affineTransform41 = null;
        java.awt.RenderingHints renderingHints42 = null;
        java.awt.PaintContext paintContext43 = chartColor36.createContext(colorModel38, rectangle39, rectangle2D40, affineTransform41, renderingHints42);
        legendTitle31.setBackgroundPaint((java.awt.Paint) chartColor36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendTitle31.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle31.setLegendItemGraphicAnchor(rectangleAnchor46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle31.setLegendItemGraphicLocation(rectangleAnchor48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = legendTitle31.getLegendItemGraphicAnchor();
        org.jfree.chart.PaintMap paintMap51 = new org.jfree.chart.PaintMap();
        boolean boolean53 = paintMap51.containsKey((java.lang.Comparable) (short) -1);
        blockContainer12.add((org.jfree.chart.block.Block) legendTitle31, (java.lang.Object) paintMap51);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("");
        textTitle56.setExpandToFitSpace(true);
        java.lang.Object obj59 = textTitle56.clone();
        double double60 = textTitle56.getWidth();
        java.awt.Font font61 = textTitle56.getFont();
        boolean boolean62 = blockContainer12.equals((java.lang.Object) font61);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-16698368) + "'", int37 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext43);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color5 };
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color7, color8, color9, color10, color11, color12 };
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color14, color15 };
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Stroke[] strokeArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray13, paintArray16, strokeArray18, strokeArray19, shapeArray20);
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        multiplePiePlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str26 = textTitle25.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle25.getMargin();
        multiplePiePlot4.setInsets(rectangleInsets27);
        multiplePiePlot4.zoom(108.0d);
        try {
            jFreeChart3.setTextAntiAlias((java.lang.Object) multiplePiePlot4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.MultiplePiePlot@77f774eb incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        java.lang.String str3 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Other", "PieSection: 52, -16698368(8)", "java.awt.Color[r=128,g=255,b=255]", "PieLabelLinkStyle.QUAD_CURVE", "TableOrder.BY_COLUMN");
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        java.awt.Paint paint21 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        java.lang.String str25 = standardPieSectionLabelGenerator22.generateSectionLabel(pieDataset23, (java.lang.Comparable) 10.0f);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator22);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        double double28 = piePlot27.getLabelGap();
        double double29 = piePlot27.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot27.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator31 = null;
        piePlot27.setLegendLabelURLGenerator(pieURLGenerator31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        piePlot27.setLabelOutlinePaint((java.awt.Paint) color33);
        java.lang.Class<?> wildcardClass36 = piePlot27.getClass();
        boolean boolean37 = standardPieSectionLabelGenerator22.equals((java.lang.Object) wildcardClass36);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.025d + "'", double28 == 0.025d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color4 = java.awt.Color.cyan;
        paintMap0.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color4);
        boolean boolean7 = paintMap0.containsKey((java.lang.Comparable) "PieSection: 52, 52(15)");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.lang.Object obj12 = null;
        boolean boolean13 = textTitle10.equals(obj12);
        textTitle10.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle10.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment16, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color22 };
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color24, color25, color26, color27, color28, color29 };
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color31, color32 };
        java.awt.Stroke stroke34 = null;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] { stroke34 };
        java.awt.Stroke[] strokeArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray30, paintArray33, strokeArray35, strokeArray36, shapeArray37);
        java.awt.Paint paint39 = defaultDrawingSupplier38.getNextOutlinePaint();
        multiplePiePlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str43 = textTitle42.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = textTitle42.getMargin();
        multiplePiePlot21.setInsets(rectangleInsets44);
        java.awt.Stroke stroke46 = null;
        multiplePiePlot21.setOutlineStroke(stroke46);
        java.awt.Color color48 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray49 = new java.awt.Paint[] { color48 };
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Color color51 = java.awt.Color.PINK;
        java.awt.Color color52 = java.awt.Color.PINK;
        java.awt.Color color53 = java.awt.Color.PINK;
        java.awt.Color color54 = java.awt.Color.PINK;
        java.awt.Color color55 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray56 = new java.awt.Paint[] { color50, color51, color52, color53, color54, color55 };
        java.awt.Color color57 = java.awt.Color.PINK;
        java.awt.Color color58 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray59 = new java.awt.Paint[] { color57, color58 };
        java.awt.Stroke stroke60 = null;
        java.awt.Stroke[] strokeArray61 = new java.awt.Stroke[] { stroke60 };
        java.awt.Stroke[] strokeArray62 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray63 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier64 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray49, paintArray56, paintArray59, strokeArray61, strokeArray62, shapeArray63);
        multiplePiePlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier64);
        java.awt.Stroke stroke66 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot21.setOutlineStroke(stroke66);
        boolean boolean68 = blockContainer20.equals((java.lang.Object) stroke66);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str71 = textTitle70.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = textTitle70.getMargin();
        java.lang.String str73 = textTitle70.getURLText();
        java.lang.Object obj74 = textTitle70.clone();
        double double75 = textTitle70.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = textTitle70.getPadding();
        blockContainer20.add((org.jfree.chart.block.Block) textTitle70);
        boolean boolean78 = paintMap0.equals((java.lang.Object) blockContainer20);
        boolean boolean79 = blockContainer20.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paintArray49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(paintArray56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paintArray59);
        org.junit.Assert.assertNotNull(strokeArray61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(shapeArray63);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "" + "'", str71.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 52, 52(15)");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        boolean boolean6 = piePlot1.isSubplot();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int15 = chartColor14.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor14);
        piePlot1.setLabelOutlinePaint((java.awt.Paint) chartColor14);
        boolean boolean18 = piePlot1.getIgnoreZeroValues();
        java.awt.Paint paint19 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16698368) + "'", int15 == (-16698368));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int11 = chartColor10.getRGB();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = chartColor10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.block.BlockContainer blockContainer19 = legendTitle5.getItemContainer();
        boolean boolean20 = objectList0.equals((java.lang.Object) legendTitle5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle5.getLegendItemGraphicAnchor();
        java.awt.Paint paint22 = legendTitle5.getItemPaint();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getText();
        java.lang.Object obj26 = null;
        boolean boolean27 = textTitle24.equals(obj26);
        textTitle24.setHeight((double) 2);
        java.lang.String str30 = textTitle24.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = textTitle24.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge32);
        boolean boolean34 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge32);
        textTitle24.setPosition(rectangleEdge32);
        legendTitle5.setPosition(rectangleEdge32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = legendTitle5.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot(pieDataset38);
        java.awt.Color color40 = java.awt.Color.blue;
        piePlot39.setBaseSectionOutlinePaint((java.awt.Paint) color40);
        piePlot39.setMaximumLabelWidth(100.0d);
        boolean boolean44 = piePlot39.isSubplot();
        org.jfree.chart.ChartColor chartColor52 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int53 = chartColor52.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder54 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor52);
        piePlot39.setLabelOutlinePaint((java.awt.Paint) chartColor52);
        int int56 = chartColor52.getGreen();
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor52);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16698368) + "'", int11 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(blockContainer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16698368) + "'", int53 == (-16698368));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 52 + "'", int56 == 52);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setExpandToFitSpace(true);
        java.lang.Object obj24 = textTitle21.clone();
        java.awt.Font font25 = textTitle21.getFont();
        blockContainer12.add((org.jfree.chart.block.Block) textTitle21);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.lang.Object obj30 = null;
        boolean boolean31 = textTitle28.equals(obj30);
        textTitle28.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle28.getBounds();
        blockContainer12.add((org.jfree.chart.block.Block) textTitle28);
        double double36 = textTitle28.getContentXOffset();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) '#', 8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.lang.Object obj8 = null;
        boolean boolean9 = textTitle6.equals(obj8);
        textTitle6.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle6.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment12, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color18 };
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color20, color21, color22, color23, color24, color25 };
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color27, color28 };
        java.awt.Stroke stroke30 = null;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke30 };
        java.awt.Stroke[] strokeArray32 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray26, paintArray29, strokeArray31, strokeArray32, shapeArray33);
        java.awt.Paint paint35 = defaultDrawingSupplier34.getNextOutlinePaint();
        multiplePiePlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str39 = textTitle38.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle38.getMargin();
        multiplePiePlot17.setInsets(rectangleInsets40);
        java.awt.Stroke stroke42 = null;
        multiplePiePlot17.setOutlineStroke(stroke42);
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray45 = new java.awt.Paint[] { color44 };
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Color color48 = java.awt.Color.PINK;
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Color color51 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray52 = new java.awt.Paint[] { color46, color47, color48, color49, color50, color51 };
        java.awt.Color color53 = java.awt.Color.PINK;
        java.awt.Color color54 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray55 = new java.awt.Paint[] { color53, color54 };
        java.awt.Stroke stroke56 = null;
        java.awt.Stroke[] strokeArray57 = new java.awt.Stroke[] { stroke56 };
        java.awt.Stroke[] strokeArray58 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray45, paintArray52, paintArray55, strokeArray57, strokeArray58, shapeArray59);
        multiplePiePlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        java.awt.Stroke stroke62 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot17.setOutlineStroke(stroke62);
        boolean boolean64 = blockContainer16.equals((java.lang.Object) stroke62);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("");
        textTitle66.setExpandToFitSpace(true);
        java.lang.Object obj69 = textTitle66.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = textTitle66.getMargin();
        double double72 = rectangleInsets70.trimHeight((double) 100.0f);
        double double74 = rectangleInsets70.calculateBottomInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder75 = new org.jfree.chart.block.LineBorder((java.awt.Paint) chartColor3, stroke62, rectangleInsets70);
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = lineBorder75.getInsets();
        java.awt.Color color77 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace78 = color77.getColorSpace();
        boolean boolean79 = lineBorder75.equals((java.lang.Object) color77);
        java.awt.Stroke stroke80 = lineBorder75.getStroke();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(paintArray55);
        org.junit.Assert.assertNotNull(strokeArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 100.0d + "'", double72 == 100.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(colorSpace78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(stroke80);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.data.general.DatasetGroup datasetGroup7 = piePlot0.getDatasetGroup();
        java.awt.Paint paint8 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle3.getHorizontalAlignment();
        double double8 = textTitle3.getHeight();
        boolean boolean9 = strokeMap0.equals((java.lang.Object) textTitle3);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        textTitle3.setPosition(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.setBackgroundImageAlpha((float) (short) -1);
        org.jfree.chart.event.ChartProgressListener chartProgressListener10 = null;
        jFreeChart3.removeProgressListener(chartProgressListener10);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj16 = null;
        boolean boolean17 = defaultDrawingSupplier15.equals(obj16);
        boolean boolean18 = jFreeChart14.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart14.setBackgroundPaint(paint19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart14, chartChangeEventType26);
        org.jfree.chart.JFreeChart jFreeChart29 = chartChangeEvent28.getChart();
        int int30 = jFreeChart29.getBackgroundImageAlignment();
        org.jfree.chart.PaintMap paintMap31 = new org.jfree.chart.PaintMap();
        boolean boolean33 = paintMap31.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color35 = java.awt.Color.cyan;
        paintMap31.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color35);
        jFreeChart29.setBorderPaint((java.awt.Paint) color35);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertNotNull(jFreeChart29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ChartChangeEventType.NEW_DATASET");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: ChartChangeEventType.NEW_DATASET" + "'", str2.equals("org.jfree.data.UnknownKeyException: ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        piePlot1.setForegroundAlpha((float) (byte) 100);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        java.awt.Color color6 = java.awt.Color.white;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot7);
        multiplePiePlot4.notifyListeners(plotChangeEvent8);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        double double18 = rectangleInsets15.getBottom();
        multiplePiePlot4.setInsets(rectangleInsets15, true);
        piePlot1.setSimpleLabelOffset(rectangleInsets15);
        java.awt.Color color24 = java.awt.Color.getColor("{0}", (int) (short) 10);
        piePlot1.setShadowPaint((java.awt.Paint) color24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean4 = rectangleEdge2.equals((java.lang.Object) rectangleInsets3);
        java.lang.Object obj5 = null;
        boolean boolean6 = rectangleEdge2.equals(obj5);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        java.awt.Paint paint21 = piePlot1.getLabelShadowPaint();
        int int22 = piePlot1.getPieIndex();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        piePlot1.setLabelPaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color4 = java.awt.Color.cyan;
        paintMap0.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color4);
        java.awt.Paint paint7 = paintMap0.getPaint((java.lang.Comparable) 0.08d);
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image9 = projectInfo8.getLogo();
        boolean boolean10 = paintMap0.equals((java.lang.Object) projectInfo8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        textTitle3.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent6.setType(chartChangeEventType7);
        plotChangeEvent1.setType(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        java.lang.Object obj5 = textTitle1.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D11 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list12 = defaultKeyedValues2D11.getRowKeys();
        jFreeChart9.setSubtitles(list12);
        jFreeChart9.clearSubtitles();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        jFreeChart9.clearSubtitles();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        java.lang.Object obj5 = textTitle1.clone();
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle1.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment7, verticalAlignment8, 0.08d, (double) 100.0f);
        columnArrangement11.clear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart3.getTitle();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int9 = chartColor8.getRGB();
        jFreeChart3.setBackgroundPaint((java.awt.Paint) chartColor8);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle13.getMargin();
        java.lang.String str16 = textTitle13.getURLText();
        java.lang.Object obj17 = textTitle13.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        multiplePiePlot18.removeChangeListener(plotChangeListener19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot18);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D23 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list24 = defaultKeyedValues2D23.getRowKeys();
        jFreeChart21.setSubtitles(list24);
        jFreeChart21.clearSubtitles();
        textTitle13.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart21);
        try {
            jFreeChart3.addSubtitle((-1), (org.jfree.chart.title.Title) textTitle13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(textTitle4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16698368) + "'", int9 == (-16698368));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Image image5 = jFreeChart4.getBackgroundImage();
        jFreeChart4.removeLegend();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setExpandToFitSpace(true);
        double double11 = textTitle8.getWidth();
        java.awt.Paint paint12 = textTitle8.getBackgroundPaint();
        double double13 = textTitle8.getContentYOffset();
        jFreeChart4.removeSubtitle((org.jfree.chart.title.Title) textTitle8);
        java.awt.RenderingHints renderingHints15 = jFreeChart4.getRenderingHints();
        boolean boolean16 = jFreeChart4.isNotify();
        boolean boolean17 = horizontalAlignment0.equals((java.lang.Object) boolean16);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(renderingHints15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        projectInfo0.setVersion("ChartChangeEventType.NEW_DATASET");
        projectInfo0.setLicenceName("-4,-4,4,4");
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        java.lang.String str10 = verticalAlignment9.toString();
        java.lang.String str11 = verticalAlignment9.toString();
        boolean boolean12 = color1.equals((java.lang.Object) verticalAlignment9);
        java.awt.Color color13 = java.awt.Color.getColor("org.jfree.data.UnknownKeyException: ChartChangeEventType.NEW_DATASET", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "VerticalAlignment.CENTER" + "'", str10.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "VerticalAlignment.CENTER" + "'", str11.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = legendTitle4.getVerticalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer7 = legendTitle4.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockContainer7.getPadding();
        double double10 = rectangleInsets8.calculateLeftOutset((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(blockContainer7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle3.getHorizontalAlignment();
        double double8 = textTitle3.getHeight();
        boolean boolean9 = strokeMap0.equals((java.lang.Object) textTitle3);
        java.lang.Object obj10 = strokeMap0.clone();
        strokeMap0.clear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot1.getLabelLinkStyle();
        java.awt.Image image5 = piePlot1.getBackgroundImage();
        piePlot1.setStartAngle(0.0d);
        java.awt.Paint paint8 = piePlot1.getOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot9.setURLGenerator(pieURLGenerator10);
        double double12 = piePlot9.getLabelGap();
        int int13 = piePlot9.getPieIndex();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = piePlot9.getLabelDistributor();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list16 = defaultCategoryDataset15.getRowKeys();
        defaultCategoryDataset15.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) abstractPieLabelDistributor14, (org.jfree.data.general.Dataset) defaultCategoryDataset15);
        piePlot1.datasetChanged(datasetChangeEvent21);
        java.awt.Paint paint23 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int10 = chartColor9.getRGB();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = chartColor9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        legendTitle4.setBackgroundPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle4.getLegendItemGraphicAnchor();
        java.awt.Paint paint19 = legendTitle4.getItemPaint();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16698368) + "'", int10 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.addValue((java.lang.Number) (byte) -1, (java.lang.Comparable) 0.5f, (java.lang.Comparable) 4.0d);
        int int7 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot5.getParent();
        java.lang.String str8 = multiplePiePlot5.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset9 = multiplePiePlot5.getDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color11 };
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color13, color14, color15, color16, color17, color18 };
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color20, color21 };
        java.awt.Stroke stroke23 = null;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke23 };
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray19, paintArray22, strokeArray24, strokeArray25, shapeArray26);
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextOutlinePaint();
        multiplePiePlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = textTitle31.getMargin();
        multiplePiePlot10.setInsets(rectangleInsets33);
        java.awt.Stroke stroke35 = null;
        multiplePiePlot10.setOutlineStroke(stroke35);
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color37 };
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Color color40 = java.awt.Color.PINK;
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Color color43 = java.awt.Color.PINK;
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray45 = new java.awt.Paint[] { color39, color40, color41, color42, color43, color44 };
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray48 = new java.awt.Paint[] { color46, color47 };
        java.awt.Stroke stroke49 = null;
        java.awt.Stroke[] strokeArray50 = new java.awt.Stroke[] { stroke49 };
        java.awt.Stroke[] strokeArray51 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray52 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier53 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray38, paintArray45, paintArray48, strokeArray50, strokeArray51, shapeArray52);
        multiplePiePlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier53);
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier53);
        boolean boolean56 = legendTitle4.equals((java.lang.Object) defaultDrawingSupplier53);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle4.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = null;
        try {
            legendTitle4.setItemLabelPadding(rectangleInsets58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Multiple Pie Plot" + "'", str8.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintArray48);
        org.junit.Assert.assertNotNull(strokeArray50);
        org.junit.Assert.assertNotNull(strokeArray51);
        org.junit.Assert.assertNotNull(shapeArray52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int14 = chartColor13.getRGB();
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = chartColor13.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        legendTitle8.setBackgroundPaint((java.awt.Paint) chartColor13);
        piePlot3.setBaseSectionPaint((java.awt.Paint) chartColor13);
        java.awt.Paint paint23 = piePlot3.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        java.lang.String str27 = standardPieSectionLabelGenerator24.generateSectionLabel(pieDataset25, (java.lang.Comparable) 10.0f);
        piePlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        boolean boolean29 = defaultKeyedValues2D1.equals((java.lang.Object) standardPieSectionLabelGenerator24);
        try {
            java.lang.Number number32 = defaultKeyedValues2D1.getValue(0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-16698368) + "'", int14 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("{0}");
        boolean boolean7 = jFreeChartResources0.containsKey("TableOrder.BY_COLUMN");
        boolean boolean9 = jFreeChartResources0.containsKey("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int11 = chartColor10.getRGB();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = chartColor10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor10);
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) chartColor10);
        java.lang.String str20 = chartColor10.toString();
        int int21 = chartColor10.getRed();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16698368) + "'", int11 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.chart.ChartColor[r=1,g=52,b=0]" + "'", str20.equals("org.jfree.chart.ChartColor[r=1,g=52,b=0]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Font font5 = legendTitle4.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle4.getPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle4.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        java.awt.Paint paint6 = textTitle1.getBackgroundPaint();
        java.lang.Object obj7 = textTitle1.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle1.getHorizontalAlignment();
        java.lang.Object obj9 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Image image8 = jFreeChart3.getBackgroundImage();
        java.awt.Paint paint9 = null;
        jFreeChart3.setBackgroundPaint(paint9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart3.createBufferedImage((int) (short) 0, (int) 'a', (double) 15, 52.0d, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = null;
        piePlot21.setURLGenerator(pieURLGenerator22);
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot21.setLabelPaint((java.awt.Paint) chartColor27);
        java.awt.Paint paint29 = piePlot21.getLabelShadowPaint();
        piePlot1.setShadowPaint(paint29);
        java.awt.Paint paint31 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.addValue((java.lang.Number) (byte) -1, (java.lang.Comparable) (byte) 100, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) 100.0f, (double) 0L, (double) 100L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        boolean boolean4 = piePlot0.getLabelLinksVisible();
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D11 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list12 = defaultKeyedValues2D11.getRowKeys();
        jFreeChart9.setSubtitles(list12);
        java.awt.Image image14 = jFreeChart9.getBackgroundImage();
        jFreeChart9.setBackgroundImageAlpha((float) '4');
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        double double20 = piePlot19.getLabelGap();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot19);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        java.awt.Color color24 = java.awt.Color.blue;
        piePlot23.setBaseSectionOutlinePaint((java.awt.Paint) color24);
        piePlot23.setMaximumLabelWidth(100.0d);
        java.awt.Paint paint29 = piePlot23.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Paint paint30 = piePlot23.getLabelOutlinePaint();
        java.awt.Stroke stroke31 = piePlot23.getBaseSectionOutlineStroke();
        piePlot19.setLabelOutlineStroke(stroke31);
        jFreeChart9.setBorderStroke(stroke31);
        piePlot0.setLabelLinkStroke(stroke31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.025d + "'", double20 == 0.025d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        textTitle1.setMargin((double) 0L, (double) (-1), (double) (short) 1, (double) (byte) 1);
        java.lang.Object obj11 = textTitle1.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot12);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle16.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int22 = chartColor21.getRGB();
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.AffineTransform affineTransform26 = null;
        java.awt.RenderingHints renderingHints27 = null;
        java.awt.PaintContext paintContext28 = chartColor21.createContext(colorModel23, rectangle24, rectangle2D25, affineTransform26, renderingHints27);
        legendTitle16.setBackgroundPaint((java.awt.Paint) chartColor21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = legendTitle16.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle16.setLegendItemGraphicAnchor(rectangleAnchor31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle16.setLegendItemGraphicLocation(rectangleAnchor33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = legendTitle16.getLegendItemGraphicAnchor();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = legendTitle16.getHorizontalAlignment();
        textTitle1.setTextAlignment(horizontalAlignment36);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16698368) + "'", int22 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext28);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot7);
        multiplePiePlot4.notifyListeners(plotChangeEvent8);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        double double18 = rectangleInsets15.getBottom();
        multiplePiePlot4.setInsets(rectangleInsets15, true);
        piePlot1.setSimpleLabelOffset(rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets15.createInsetRectangle(rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint4 = jFreeChart3.getBorderPaint();
        int int5 = jFreeChart3.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        boolean boolean8 = jFreeChart3.isNotify();
        java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage(128, (int) (short) 1);
        int int12 = jFreeChart3.getSubtitleCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(bufferedImage11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Font font3 = multiplePiePlot0.getNoDataMessageFont();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = multiplePiePlot0.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = multiplePiePlot0.getInsets();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list7 = defaultCategoryDataset6.getRowKeys();
        defaultCategoryDataset6.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset6.removeRow((int) (short) 0);
        java.util.List list14 = defaultCategoryDataset6.getRowKeys();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        defaultCategoryDataset6.addValue((java.lang.Number) (-65536), (java.lang.Comparable) "PieSection: 52, -16698368(8)", (java.lang.Comparable) "ChartChangeEventType.NEW_DATASET");
        org.jfree.data.general.DatasetGroup datasetGroup20 = defaultCategoryDataset6.getGroup();
        java.util.List list21 = defaultCategoryDataset6.getRowKeys();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(datasetGroup20);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        float float10 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle12.getMargin();
        jFreeChart3.setPadding(rectangleInsets14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            java.awt.image.BufferedImage bufferedImage21 = jFreeChart3.createBufferedImage((-16698368), (int) (byte) 1, (double) (byte) 1, 4.0d, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-16698368) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.lang.Object obj9 = textTitle1.draw(graphics2D6, rectangle2D7, (java.lang.Object) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = textTitle1.getPosition();
        java.awt.Font font11 = textTitle1.getFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle1.getPadding();
        textTitle1.setToolTipText("org.jfree.chart.ChartColor[r=1,g=52,b=0]");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        multiplePiePlot0.handleClick((int) (byte) 10, (-16698368), plotRenderingInfo5);
        java.awt.Font font7 = multiplePiePlot0.getNoDataMessageFont();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = java.awt.Color.blue;
        piePlot9.setBaseSectionOutlinePaint((java.awt.Paint) color10);
        piePlot9.setMaximumLabelWidth(100.0d);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot9.setBaseSectionOutlinePaint((java.awt.Paint) color14);
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot9);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        boolean boolean9 = jFreeChart3.getAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart3.getLegend();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        java.lang.Object obj16 = textTitle13.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle13.getMargin();
        double double19 = rectangleInsets17.trimHeight((double) 100.0f);
        double double21 = rectangleInsets17.calculateTopOutset((double) 0L);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        textTitle23.setExpandToFitSpace(true);
        double double26 = textTitle23.getWidth();
        java.awt.Paint paint27 = textTitle23.getBackgroundPaint();
        double double28 = textTitle23.getContentYOffset();
        double double29 = textTitle23.getContentYOffset();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets17.createInsetRectangle(rectangle2D30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double33 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D31, rectangleEdge32);
        try {
            jFreeChart3.draw(graphics2D11, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (short) 10, (int) '#', 8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.lang.Object obj13 = null;
        boolean boolean14 = textTitle11.equals(obj13);
        textTitle11.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle11.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment17, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color23 };
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray31 = new java.awt.Paint[] { color25, color26, color27, color28, color29, color30 };
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] { color32, color33 };
        java.awt.Stroke stroke35 = null;
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] { stroke35 };
        java.awt.Stroke[] strokeArray37 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray38 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray31, paintArray34, strokeArray36, strokeArray37, shapeArray38);
        java.awt.Paint paint40 = defaultDrawingSupplier39.getNextOutlinePaint();
        multiplePiePlot22.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str44 = textTitle43.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = textTitle43.getMargin();
        multiplePiePlot22.setInsets(rectangleInsets45);
        java.awt.Stroke stroke47 = null;
        multiplePiePlot22.setOutlineStroke(stroke47);
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray50 = new java.awt.Paint[] { color49 };
        java.awt.Color color51 = java.awt.Color.PINK;
        java.awt.Color color52 = java.awt.Color.PINK;
        java.awt.Color color53 = java.awt.Color.PINK;
        java.awt.Color color54 = java.awt.Color.PINK;
        java.awt.Color color55 = java.awt.Color.PINK;
        java.awt.Color color56 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] { color51, color52, color53, color54, color55, color56 };
        java.awt.Color color58 = java.awt.Color.PINK;
        java.awt.Color color59 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray60 = new java.awt.Paint[] { color58, color59 };
        java.awt.Stroke stroke61 = null;
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] { stroke61 };
        java.awt.Stroke[] strokeArray63 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray64 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray50, paintArray57, paintArray60, strokeArray62, strokeArray63, shapeArray64);
        multiplePiePlot22.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        java.awt.Stroke stroke67 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot22.setOutlineStroke(stroke67);
        boolean boolean69 = blockContainer21.equals((java.lang.Object) stroke67);
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle("");
        textTitle71.setExpandToFitSpace(true);
        java.lang.Object obj74 = textTitle71.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = textTitle71.getMargin();
        double double77 = rectangleInsets75.trimHeight((double) 100.0f);
        double double79 = rectangleInsets75.calculateBottomInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder80 = new org.jfree.chart.block.LineBorder((java.awt.Paint) chartColor8, stroke67, rectangleInsets75);
        piePlot0.setBackgroundPaint((java.awt.Paint) chartColor8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paintArray50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(paintArray60);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(shapeArray64);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.0d + "'", double77 == 100.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name HorizontalAlignment.CENTER, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = titleChangeEvent4.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        titleChangeEvent4.setType(chartChangeEventType6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        double double12 = textTitle9.getWidth();
        java.awt.Paint paint13 = textTitle9.getBackgroundPaint();
        textTitle9.setURLText("TableOrder.BY_COLUMN");
        boolean boolean16 = chartChangeEventType6.equals((java.lang.Object) textTitle9);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        textTitle20.setExpandToFitSpace(true);
        double double23 = textTitle20.getWidth();
        java.awt.Paint paint24 = textTitle20.getBackgroundPaint();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.lang.Object obj28 = textTitle20.draw(graphics2D25, rectangle2D26, (java.lang.Object) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = textTitle20.getPosition();
        java.awt.Font font30 = textTitle20.getFont();
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER", font30);
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator33 = null;
        piePlot32.setURLGenerator(pieURLGenerator33);
        org.jfree.chart.ChartColor chartColor38 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot32.setLabelPaint((java.awt.Paint) chartColor38);
        java.awt.Font font41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean44 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge43);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean47 = rectangleEdge45.equals((java.lang.Object) rectangleInsets46);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle48.setTextAlignment(horizontalAlignment49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("");
        textTitle53.setExpandToFitSpace(true);
        java.lang.Object obj56 = textTitle53.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = textTitle53.getMargin();
        double double59 = rectangleInsets57.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType60 = rectangleInsets57.getUnitType();
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font41, (java.awt.Paint) color42, rectangleEdge45, horizontalAlignment49, verticalAlignment51, rectangleInsets57);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment62 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str63 = horizontalAlignment62.toString();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot64 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent65 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot64);
        org.jfree.chart.plot.Plot plot66 = multiplePiePlot64.getParent();
        org.jfree.chart.JFreeChart jFreeChart67 = multiplePiePlot64.getPieChart();
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str70 = textTitle69.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = textTitle69.getMargin();
        java.awt.Paint paint72 = textTitle69.getPaint();
        jFreeChart67.setTitle(textTitle69);
        org.jfree.chart.util.VerticalAlignment verticalAlignment74 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle69.setVerticalAlignment(verticalAlignment74);
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str78 = textTitle77.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = textTitle77.getMargin();
        double double80 = rectangleInsets79.getTop();
        double double82 = rectangleInsets79.calculateBottomOutset((double) (byte) 10);
        org.jfree.chart.title.TextTitle textTitle83 = new org.jfree.chart.title.TextTitle("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", font30, (java.awt.Paint) chartColor38, rectangleEdge45, horizontalAlignment62, verticalAlignment74, rectangleInsets79);
        textTitle9.setHorizontalAlignment(horizontalAlignment62);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertNotNull(unitType60);
        org.junit.Assert.assertNotNull(horizontalAlignment62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "HorizontalAlignment.CENTER" + "'", str63.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNull(plot66);
        org.junit.Assert.assertNotNull(jFreeChart67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(verticalAlignment74);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "" + "'", str78.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset0.removeRow((int) (short) 0);
        java.util.List list8 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) "Pie Plot");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: Pie Plot");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean2 = unitType0.equals((java.lang.Object) '4');
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean4 = unitType0.equals((java.lang.Object) color3);
        java.lang.String str5 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.025d, (double) 0.0f, (double) 10.0f, 0.025d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UnitType.RELATIVE" + "'", str5.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.awt.Paint paint4 = piePlot0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        boolean boolean2 = objectList0.equals(obj1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot3.getParent();
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot3.getPieChart();
        java.awt.Paint paint7 = multiplePiePlot3.getBackgroundPaint();
        int int8 = objectList0.indexOf((java.lang.Object) paint7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Color color11 = java.awt.Color.blue;
        piePlot10.setBaseSectionOutlinePaint((java.awt.Paint) color11);
        piePlot10.setMaximumLabelWidth(100.0d);
        piePlot10.setLabelLinksVisible(false);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot10.setOutlineStroke(stroke17);
        boolean boolean19 = objectList0.equals((java.lang.Object) stroke17);
        java.lang.Object obj21 = objectList0.get(15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.CENTER", 2);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color6 = java.awt.Color.getColor("PieSection: 52, 52(8)", (int) (short) 1);
        java.awt.Color color7 = java.awt.Color.ORANGE;
        float[] floatArray12 = new float[] { 10L, 1L, 0, (short) 1 };
        float[] floatArray13 = color7.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color6.getRGBColorComponents(floatArray12);
        float[] floatArray15 = color3.getRGBComponents(floatArray12);
        float[] floatArray16 = color2.getComponents(floatArray15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        piePlot0.setLabelGap((double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        piePlot0.setDrawingSupplier(drawingSupplier5);
        java.awt.Stroke stroke7 = piePlot0.getOutlineStroke();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot8);
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.Title title12 = null;
        jFreeChart11.removeSubtitle(title12);
        float float14 = jFreeChart11.getBackgroundImageAlpha();
        piePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        java.awt.Paint paint2 = null;
        multiplePiePlot0.setOutlinePaint(paint2);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "HorizontalAlignment.CENTER");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle10.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = legendTitle10.getVerticalAlignment();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        legendTitle10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.brighter();
        boolean boolean16 = multiplePiePlot0.equals((java.lang.Object) color13);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-16496128), 0.0f, (float) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Font font3 = multiplePiePlot0.getNoDataMessageFont();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = multiplePiePlot0.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(jFreeChart5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("-4,-4,4,4", "hi!", "RectangleAnchor.BOTTOM_RIGHT", "", "");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.chart.plot.Plot plot8 = multiplePiePlot6.getParent();
        java.lang.String str9 = multiplePiePlot6.getPlotType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str11 = horizontalAlignment10.toString();
        java.lang.String str12 = horizontalAlignment10.toString();
        java.lang.String str13 = horizontalAlignment10.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment14, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        textTitle19.setExpandToFitSpace(true);
        java.lang.Object obj22 = textTitle19.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj24 = null;
        boolean boolean25 = defaultDrawingSupplier23.equals(obj24);
        columnArrangement17.add((org.jfree.chart.block.Block) textTitle19, (java.lang.Object) defaultDrawingSupplier23);
        java.awt.Stroke stroke27 = defaultDrawingSupplier23.getNextStroke();
        java.awt.Shape shape28 = defaultDrawingSupplier23.getNextShape();
        multiplePiePlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        org.jfree.chart.util.TableOrder tableOrder30 = multiplePiePlot6.getDataExtractOrder();
        boolean boolean31 = basicProjectInfo5.equals((java.lang.Object) multiplePiePlot6);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "HorizontalAlignment.CENTER" + "'", str11.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "HorizontalAlignment.CENTER" + "'", str12.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "HorizontalAlignment.CENTER" + "'", str13.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(tableOrder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.Comparable comparable8 = pieSectionEntity7.getSectionKey();
        java.lang.String str9 = pieSectionEntity7.getShapeCoords();
        java.lang.String str10 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionIndex((int) (byte) -1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 8 + "'", comparable8.equals(8));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-4,-4,4,4" + "'", str9.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 52, 52(8)" + "'", str10.equals("PieSection: 52, 52(8)"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        multiplePiePlot0.handleClick((int) (byte) 10, (-16698368), plotRenderingInfo5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        multiplePiePlot0.setDataset(categoryDataset7);
        java.lang.String str9 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.incrementValue((double) (short) -1, (java.lang.Comparable) " version org.jfree.data.UnknownKeyException: hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY : org.jfree.data.UnknownKeyException: hi! (hi!). org.jfree.data.UnknownKeyException: hi! (hi!).\n LICENCE TERMS:\nRectangleAnchor.BOTTOM", (java.lang.Comparable) (-65536));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -65536");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        piePlot1.setForegroundAlpha((float) (byte) 100);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        java.lang.Object obj6 = piePlot1.clone();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        java.awt.Paint paint21 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        java.lang.String str25 = standardPieSectionLabelGenerator22.generateSectionLabel(pieDataset23, (java.lang.Comparable) 10.0f);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator22);
        java.awt.Paint paint27 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint24 = piePlot1.getBaseSectionPaint();
        org.jfree.data.general.PieDataset pieDataset25 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieDataset25);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot0.setBaseSectionPaint((java.awt.Paint) color3);
        piePlot0.zoom(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getMaximumLabelWidth();
        boolean boolean9 = piePlot1.getSimpleLabels();
        piePlot1.setSimpleLabels(false);
        double double12 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Paint paint8 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        piePlot1.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        double double8 = rectangleInsets5.getBottom();
        double double10 = rectangleInsets5.calculateTopInset((double) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot14);
        multiplePiePlot11.notifyListeners(plotChangeEvent15);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        textTitle18.setExpandToFitSpace(true);
        java.lang.Object obj21 = textTitle18.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle18.getMargin();
        double double24 = rectangleInsets22.trimHeight((double) (byte) 100);
        double double25 = rectangleInsets22.getBottom();
        multiplePiePlot11.setInsets(rectangleInsets22, true);
        double double29 = rectangleInsets22.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.lang.Object obj33 = null;
        boolean boolean34 = textTitle31.equals(obj33);
        textTitle31.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle31.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets22.createAdjustedRectangle(rectangle2D37, lengthAdjustmentType38, lengthAdjustmentType39);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets5.createInsetRectangle(rectangle2D37, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D37, "Other", "org.jfree.chart.ChartColor[r=1,g=52,b=0]");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 32.0d + "'", double29 == 32.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.awt.Color color0 = java.awt.Color.CYAN;
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) rectangleInsets7);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle9.setTextAlignment(horizontalAlignment10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        double double20 = rectangleInsets18.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets18.getUnitType();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font2, (java.awt.Paint) color3, rectangleEdge6, horizontalAlignment10, verticalAlignment12, rectangleInsets18);
        java.lang.Object obj23 = null;
        boolean boolean24 = color3.equals(obj23);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.GRAY;
        float[] floatArray27 = null;
        float[] floatArray28 = color26.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color25.getRGBColorComponents(floatArray28);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.lang.Object obj33 = null;
        boolean boolean34 = textTitle31.equals(obj33);
        textTitle31.setMargin((double) (short) 1, (double) (byte) 10, 0.0d, (double) 10.0f);
        textTitle31.setID("HorizontalAlignment.CENTER");
        java.awt.Color color42 = java.awt.Color.cyan;
        textTitle31.setPaint((java.awt.Paint) color42);
        int int44 = color42.getGreen();
        java.awt.Color color45 = java.awt.Color.orange;
        java.awt.Color color46 = color45.darker();
        java.awt.Color color47 = java.awt.Color.YELLOW;
        java.awt.Color color48 = java.awt.Color.GRAY;
        float[] floatArray49 = null;
        float[] floatArray50 = color48.getRGBColorComponents(floatArray49);
        float[] floatArray51 = color47.getRGBColorComponents(floatArray50);
        float[] floatArray52 = color45.getRGBColorComponents(floatArray50);
        float[] floatArray53 = color42.getColorComponents(floatArray50);
        float[] floatArray54 = color25.getRGBColorComponents(floatArray50);
        float[] floatArray55 = color3.getColorComponents(floatArray50);
        try {
            float[] floatArray56 = color0.getRGBComponents(floatArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle1.getPosition();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean13 = rectangleEdge11.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle14.setTextAlignment(horizontalAlignment15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        textTitle19.setExpandToFitSpace(true);
        java.lang.Object obj22 = textTitle19.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle19.getMargin();
        double double25 = rectangleInsets23.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType26 = rectangleInsets23.getUnitType();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font7, (java.awt.Paint) color8, rectangleEdge11, horizontalAlignment15, verticalAlignment17, rectangleInsets23);
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment17, 10.0d, 90.0d);
        java.lang.String str31 = verticalAlignment17.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(unitType26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "VerticalAlignment.CENTER" + "'", str31.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        boolean boolean4 = piePlot0.getIgnoreZeroValues();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        multiplePiePlot5.removeChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle13.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment19, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22);
        boolean boolean24 = standardPieSectionLabelGenerator10.equals((java.lang.Object) flowArrangement22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str26 = horizontalAlignment25.toString();
        java.lang.String str27 = horizontalAlignment25.toString();
        java.lang.String str28 = horizontalAlignment25.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment25, verticalAlignment29, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setExpandToFitSpace(true);
        java.lang.Object obj37 = textTitle34.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj39 = null;
        boolean boolean40 = defaultDrawingSupplier38.equals(obj39);
        columnArrangement32.add((org.jfree.chart.block.Block) textTitle34, (java.lang.Object) defaultDrawingSupplier38);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.block.Arrangement arrangement43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) columnArrangement32, arrangement43);
        org.jfree.chart.ChartColor chartColor48 = new org.jfree.chart.ChartColor(52, 0, (int) (byte) 1);
        legendTitle44.setItemPaint((java.awt.Paint) chartColor48);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "HorizontalAlignment.CENTER" + "'", str26.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "HorizontalAlignment.CENTER" + "'", str27.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.CENTER" + "'", str28.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        int int2 = pieLabelDistributor1.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        multiplePiePlot3.removeChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D8 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list9 = defaultKeyedValues2D8.getRowKeys();
        jFreeChart6.setSubtitles(list9);
        jFreeChart6.clearSubtitles();
        boolean boolean12 = jFreeChart6.getAntiAlias();
        java.awt.RenderingHints renderingHints13 = jFreeChart6.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle14 = jFreeChart6.getTitle();
        try {
            multiplePiePlot0.setPieChart(jFreeChart6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(renderingHints13);
        org.junit.Assert.assertNull(textTitle14);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset15, (java.lang.Comparable) '#');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle19.getMargin();
        boolean boolean22 = standardPieSectionLabelGenerator0.equals((java.lang.Object) textTitle19);
        java.lang.Object obj23 = standardPieSectionLabelGenerator0.clone();
        java.lang.String str24 = standardPieSectionLabelGenerator0.getLabelFormat();
        java.text.AttributedString attributedString26 = standardPieSectionLabelGenerator0.getAttributedLabel(52);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
        org.junit.Assert.assertNull(attributedString26);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        boolean boolean6 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color10, color11, color12, color13, color14, color15 };
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color17, color18 };
        java.awt.Stroke stroke20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray23 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray16, paintArray19, strokeArray21, strokeArray22, shapeArray23);
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        multiplePiePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle28.getMargin();
        multiplePiePlot7.setInsets(rectangleInsets30);
        java.awt.Stroke stroke32 = null;
        multiplePiePlot7.setOutlineStroke(stroke32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.lang.Object obj38 = null;
        boolean boolean39 = textTitle36.equals(obj38);
        textTitle36.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle36.getBounds();
        multiplePiePlot7.drawBackgroundImage(graphics2D34, rectangle2D42);
        textTitle1.setBounds(rectangle2D42);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42, "java.awt.Color[r=255,g=175,b=175]", "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot48 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener49 = null;
        multiplePiePlot48.removeChangeListener(plotChangeListener49);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot48);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot48);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle52.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = legendTitle52.getVerticalAlignment();
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        legendTitle52.setBackgroundPaint((java.awt.Paint) color55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle52.setLegendItemGraphicAnchor(rectangleAnchor57);
        java.awt.geom.Point2D point2D59 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor57);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(point2D59);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        piePlot1.setForegroundAlpha((float) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Color color8 = java.awt.Color.blue;
        piePlot7.setBaseSectionOutlinePaint((java.awt.Paint) color8);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1.0f), (java.awt.Paint) color8);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        jFreeChart3.clearSubtitles();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart3.getPadding();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        jFreeChart3.setBorderStroke(stroke12);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj11 = null;
        boolean boolean12 = defaultDrawingSupplier10.equals(obj11);
        boolean boolean13 = jFreeChart9.equals((java.lang.Object) defaultDrawingSupplier10);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        int int15 = jFreeChart9.getSubtitleCount();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setToolTipText("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle14.getMargin();
        java.lang.String str17 = textTitle14.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = textTitle14.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color21 };
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color23, color24, color25, color26, color27, color28 };
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color30, color31 };
        java.awt.Stroke stroke33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke33 };
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray36 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray29, paintArray32, strokeArray34, strokeArray35, shapeArray36);
        java.awt.Paint paint38 = defaultDrawingSupplier37.getNextOutlinePaint();
        multiplePiePlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier37);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str42 = textTitle41.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = textTitle41.getMargin();
        multiplePiePlot20.setInsets(rectangleInsets43);
        java.awt.Stroke stroke45 = null;
        multiplePiePlot20.setOutlineStroke(stroke45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str50 = textTitle49.getText();
        java.lang.Object obj51 = null;
        boolean boolean52 = textTitle49.equals(obj51);
        textTitle49.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle49.getBounds();
        multiplePiePlot20.drawBackgroundImage(graphics2D47, rectangle2D55);
        textTitle14.setBounds(rectangle2D55);
        org.jfree.chart.entity.ChartEntity chartEntity59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D55, "Other");
        pieSectionEntity7.setArea((java.awt.Shape) rectangle2D55);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int10 = chartColor9.getRGB();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = chartColor9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        legendTitle4.setBackgroundPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle4.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle4.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle4.getLegendItemGraphicAnchor();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = legendTitle4.getHorizontalAlignment();
        double double25 = legendTitle4.getWidth();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        textTitle27.setExpandToFitSpace(true);
        java.lang.Object obj30 = textTitle27.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = textTitle27.getMargin();
        double double33 = rectangleInsets31.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets31.getUnitType();
        double double36 = rectangleInsets31.trimHeight(0.0d);
        legendTitle4.setItemLabelPadding(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16698368) + "'", int10 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle1.draw(graphics2D5, rectangle2D6);
        java.awt.Paint paint8 = textTitle1.getPaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        double double3 = piePlot0.getLabelGap();
        int int4 = piePlot0.getPieIndex();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot0.getLabelDistributor();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list7 = defaultCategoryDataset6.getRowKeys();
        defaultCategoryDataset6.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) abstractPieLabelDistributor5, (org.jfree.data.general.Dataset) defaultCategoryDataset6);
        try {
            java.lang.Comparable comparable14 = defaultCategoryDataset6.getRowKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.lang.String str25 = multiplePiePlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setOutlineStroke(stroke8);
        java.awt.Shape shape10 = piePlot1.getLegendItemShape();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle11);
        double double13 = piePlot1.getStartAngle();
        java.awt.Paint paint15 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) "org.jfree.chart.ChartColor[r=1,g=52,b=0]");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 90.0d + "'", double13 == 90.0d);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int14 = chartColor13.getRGB();
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = chartColor13.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        legendTitle8.setBackgroundPaint((java.awt.Paint) chartColor13);
        piePlot3.setBaseSectionPaint((java.awt.Paint) chartColor13);
        java.awt.Paint paint23 = piePlot3.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        java.lang.String str27 = standardPieSectionLabelGenerator24.generateSectionLabel(pieDataset25, (java.lang.Comparable) 10.0f);
        piePlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        boolean boolean29 = defaultKeyedValues2D1.equals((java.lang.Object) standardPieSectionLabelGenerator24);
        defaultKeyedValues2D1.clear();
        try {
            defaultKeyedValues2D1.removeRow(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-16698368) + "'", int14 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot0.getDataExtractOrder();
        java.lang.String str18 = tableOrder17.toString();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TableOrder.BY_COLUMN" + "'", str18.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color27 };
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color29, color30, color31, color32, color33, color34 };
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color36, color37 };
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray35, paintArray38, strokeArray40, strokeArray41, shapeArray42);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        java.awt.Stroke stroke45 = defaultDrawingSupplier43.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        boolean boolean5 = jFreeChart3.getAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener6 = null;
        jFreeChart3.removeProgressListener(chartProgressListener6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage(128, (int) (short) 0, chartRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (128) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = jFreeChart3.getPadding();
        java.lang.Object obj7 = jFreeChart3.clone();
        org.jfree.chart.event.ChartProgressListener chartProgressListener8 = null;
        jFreeChart3.removeProgressListener(chartProgressListener8);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = null;
        piePlot2.setSectionOutlinePaint((java.lang.Comparable) "PieSection: 52, 52(8)", paint4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: {0}", font1, (org.jfree.chart.plot.Plot) piePlot2, true);
        float float8 = jFreeChart7.getBackgroundImageAlpha();
        int int9 = jFreeChart7.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        objectList0.clear();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        multiplePiePlot3.removeChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot3);
        java.awt.Image image7 = jFreeChart6.getBackgroundImage();
        jFreeChart6.removeLegend();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        textTitle10.setExpandToFitSpace(true);
        double double13 = textTitle10.getWidth();
        java.awt.Paint paint14 = textTitle10.getBackgroundPaint();
        double double15 = textTitle10.getContentYOffset();
        jFreeChart6.removeSubtitle((org.jfree.chart.title.Title) textTitle10);
        boolean boolean17 = objectList0.equals((java.lang.Object) textTitle10);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = null;
        try {
            org.jfree.chart.util.Size2D size2D20 = textTitle10.arrange(graphics2D18, rectangleConstraint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        int int4 = defaultKeyedValues2D1.getRowCount();
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 1L);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 1, (java.lang.Comparable) 32.0d);
        try {
            java.lang.Number number12 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (-65280));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -65280");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset0.removeRow((int) (short) 0);
        java.util.List list8 = defaultCategoryDataset0.getRowKeys();
        int int9 = defaultCategoryDataset0.getRowCount();
        int int10 = defaultCategoryDataset0.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup12 = new org.jfree.data.general.DatasetGroup("PieLabelLinkStyle.QUAD_CURVE");
        defaultCategoryDataset0.setGroup(datasetGroup12);
        try {
            java.lang.Number number16 = defaultCategoryDataset0.getValue((int) 'a', (-16698368));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        java.awt.Shape shape13 = pieSectionEntity7.getArea();
        java.lang.Object obj14 = pieSectionEntity7.clone();
        org.jfree.data.general.PieDataset pieDataset15 = pieSectionEntity7.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(pieDataset15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        int int13 = pieSectionEntity7.getPieIndex();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity21 = new org.jfree.chart.entity.PieSectionEntity(shape14, pieDataset15, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        pieSectionEntity7.setArea(shape14);
        java.lang.String str23 = pieSectionEntity7.getShapeCoords();
        java.lang.String str24 = pieSectionEntity7.getURLText();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        java.awt.Color color27 = java.awt.Color.blue;
        piePlot26.setBaseSectionOutlinePaint((java.awt.Paint) color27);
        piePlot26.setMaximumLabelWidth(100.0d);
        piePlot26.setLabelLinksVisible(false);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot26.setOutlineStroke(stroke33);
        java.awt.Shape shape35 = piePlot26.getLegendItemShape();
        pieSectionEntity7.setArea(shape35);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-4,-4,4,4" + "'", str23.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = defaultDrawingSupplier8.equals(obj9);
        boolean boolean11 = jFreeChart7.equals((java.lang.Object) defaultDrawingSupplier8);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        double double16 = textTitle13.getWidth();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot20);
        org.jfree.chart.plot.Plot plot22 = multiplePiePlot20.getParent();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot20);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle23.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getPadding();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle23.getSources();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle23.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            jFreeChart7.draw(graphics2D19, rectangle2D27, chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        textTitle1.setID("Multiple Pie Plot");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle7.getMargin();
        double double10 = rectangleInsets9.getBottom();
        textTitle1.setPadding(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        boolean boolean6 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color10, color11, color12, color13, color14, color15 };
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color17, color18 };
        java.awt.Stroke stroke20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray23 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray16, paintArray19, strokeArray21, strokeArray22, shapeArray23);
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        multiplePiePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle28.getMargin();
        multiplePiePlot7.setInsets(rectangleInsets30);
        java.awt.Stroke stroke32 = null;
        multiplePiePlot7.setOutlineStroke(stroke32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.lang.Object obj38 = null;
        boolean boolean39 = textTitle36.equals(obj38);
        textTitle36.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle36.getBounds();
        multiplePiePlot7.drawBackgroundImage(graphics2D34, rectangle2D42);
        textTitle1.setBounds(rectangle2D42);
        java.awt.Font font45 = textTitle1.getFont();
        java.lang.String str46 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.util.List list2 = defaultCategoryDataset0.getColumnKeys();
        java.lang.Object obj3 = defaultCategoryDataset0.clone();
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 8);
        defaultCategoryDataset0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 3, (java.lang.Comparable) 128);
        int int11 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 0.14d);
        int int12 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getMaximumLabelWidth();
        boolean boolean9 = piePlot1.getSimpleLabels();
        piePlot1.setSimpleLabels(false);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        multiplePiePlot15.removeChangeListener(plotChangeListener16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot15);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot15);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int25 = chartColor24.getRGB();
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = chartColor24.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        legendTitle19.setBackgroundPaint((java.awt.Paint) chartColor24);
        piePlot14.setBaseSectionPaint((java.awt.Paint) chartColor24);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator35 = null;
        piePlot34.setURLGenerator(pieURLGenerator35);
        org.jfree.chart.ChartColor chartColor40 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot34.setLabelPaint((java.awt.Paint) chartColor40);
        java.awt.Paint paint42 = piePlot34.getLabelShadowPaint();
        piePlot14.setShadowPaint(paint42);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "VerticalAlignment.TOP", paint42);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-16698368) + "'", int25 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = legendTitle4.getVerticalAlignment();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        legendTitle4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color11 = java.awt.Color.getColor("{0}", color10);
        legendTitle4.setItemPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot1.getLabelLinkStyle();
        java.awt.Image image5 = piePlot1.getBackgroundImage();
        piePlot1.setStartAngle(0.0d);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        java.lang.Object obj12 = textTitle9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getMargin();
        double double15 = rectangleInsets13.trimHeight((double) 100.0f);
        double double17 = rectangleInsets13.calculateBottomInset(0.0d);
        piePlot1.setLabelPadding(rectangleInsets13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle6.getVerticalAlignment();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        legendTitle6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        double double16 = textTitle13.getWidth();
        java.awt.Paint paint17 = textTitle13.getBackgroundPaint();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.lang.Object obj21 = textTitle13.draw(graphics2D18, rectangle2D19, (java.lang.Object) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle13.getPosition();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        java.awt.Font font25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean31 = rectangleEdge29.equals((java.lang.Object) rectangleInsets30);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle32.setTextAlignment(horizontalAlignment33);
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        textTitle37.setExpandToFitSpace(true);
        java.lang.Object obj40 = textTitle37.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle37.getMargin();
        double double43 = rectangleInsets41.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType44 = rectangleInsets41.getUnitType();
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font25, (java.awt.Paint) color26, rectangleEdge29, horizontalAlignment33, verticalAlignment35, rectangleInsets41);
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot();
        double double47 = piePlot46.getLabelGap();
        double double48 = piePlot46.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = piePlot46.getLabelPadding();
        try {
            org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color11, rectangleEdge22, horizontalAlignment23, verticalAlignment35, rectangleInsets49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(unitType44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.025d + "'", double47 == 0.025d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(2, (int) (short) 100, (int) '4', floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setExpandToFitSpace(true);
        double double9 = textTitle6.getWidth();
        java.awt.Paint paint10 = textTitle6.getBackgroundPaint();
        double double11 = textTitle6.getContentYOffset();
        double double12 = textTitle6.getContentYOffset();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle6.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            jFreeChart3.draw(graphics2D4, rectangle2D13, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setExpandToFitSpace(true);
        java.lang.Object obj24 = textTitle21.clone();
        java.awt.Font font25 = textTitle21.getFont();
        blockContainer12.add((org.jfree.chart.block.Block) textTitle21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textTitle21.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        java.awt.Stroke stroke2 = lineBorder0.getStroke();
        java.awt.Stroke stroke3 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getMaximumLabelWidth();
        java.awt.Stroke stroke9 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        multiplePiePlot0.handleClick((int) (byte) 10, (-16698368), plotRenderingInfo5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        multiplePiePlot0.setDataset(categoryDataset7);
        java.lang.String str9 = multiplePiePlot0.getPlotType();
        float float10 = multiplePiePlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(8.0d, (java.lang.Comparable) 32.0d, (java.lang.Comparable) 32.0d);
        java.lang.Comparable comparable8 = defaultCategoryDataset0.getRowKey((int) (byte) 0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 32.0d + "'", comparable8.equals(32.0d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Image image7 = jFreeChart5.getBackgroundImage();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart5);
        org.junit.Assert.assertNull(textTitle6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        boolean boolean6 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color10, color11, color12, color13, color14, color15 };
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color17, color18 };
        java.awt.Stroke stroke20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray23 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray16, paintArray19, strokeArray21, strokeArray22, shapeArray23);
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        multiplePiePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle28.getMargin();
        multiplePiePlot7.setInsets(rectangleInsets30);
        java.awt.Stroke stroke32 = null;
        multiplePiePlot7.setOutlineStroke(stroke32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.lang.Object obj38 = null;
        boolean boolean39 = textTitle36.equals(obj38);
        textTitle36.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle36.getBounds();
        multiplePiePlot7.drawBackgroundImage(graphics2D34, rectangle2D42);
        textTitle1.setBounds(rectangle2D42);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42, "java.awt.Color[r=255,g=175,b=175]", "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]");
        java.awt.Shape shape48 = chartEntity47.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity(shape48, "VerticalAlignment.CENTER", "PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = java.awt.Color.magenta;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        piePlot0.setShadowPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        boolean boolean2 = tableOrder0.equals((java.lang.Object) verticalAlignment1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot3.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = multiplePiePlot3.getInsets();
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot3.getPieChart();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setExpandToFitSpace(true);
        boolean boolean11 = jFreeChart6.equals((java.lang.Object) true);
        org.jfree.chart.title.Title title12 = null;
        jFreeChart6.removeSubtitle(title12);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        textTitle15.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle15);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = titleChangeEvent18.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment1, jFreeChart6, chartChangeEventType19);
        org.jfree.chart.event.ChartChangeListener chartChangeListener21 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        piePlot1.setForegroundAlpha((float) (byte) 100);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        java.awt.Paint paint6 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot5);
        multiplePiePlot2.notifyListeners(plotChangeEvent6);
        java.awt.Paint paint8 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        multiplePiePlot2.setInsets(rectangleInsets9, true);
        boolean boolean12 = datasetGroup1.equals((java.lang.Object) true);
        java.lang.Object obj13 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double4 = piePlot2.getExplodePercent((java.lang.Comparable) (-1));
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("org.jfree.chart.ChartColor[r=1,g=52,b=0]", font5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        piePlot0.markerChanged(markerChangeEvent5);
        piePlot0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        piePlot0.setBackgroundAlpha((float) ' ');
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle8.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment14, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17);
        boolean boolean19 = standardPieSectionLabelGenerator5.equals((java.lang.Object) flowArrangement17);
        java.text.NumberFormat numberFormat20 = standardPieSectionLabelGenerator5.getPercentFormat();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        java.lang.String str23 = standardPieSectionLabelGenerator5.generateSectionLabel(pieDataset21, (java.lang.Comparable) 1.0d);
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator5);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity32 = new org.jfree.chart.entity.PieSectionEntity(shape25, pieDataset26, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str33 = pieSectionEntity32.toString();
        java.lang.Object obj34 = pieSectionEntity32.clone();
        java.awt.Shape shape35 = pieSectionEntity32.getArea();
        piePlot0.setLegendItemShape(shape35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PieSection: 52, 52(8)" + "'", str33.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        java.awt.Stroke stroke7 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Shape shape8 = null;
        try {
            piePlot0.setLegendItemShape(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(stroke7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        boolean boolean6 = piePlot1.isSubplot();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int15 = chartColor14.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor14);
        piePlot1.setLabelOutlinePaint((java.awt.Paint) chartColor14);
        boolean boolean18 = piePlot1.getIgnoreZeroValues();
        boolean boolean19 = piePlot1.getIgnoreNullValues();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16698368) + "'", int15 == (-16698368));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = null;
        try {
            org.jfree.chart.util.Size2D size2D22 = blockContainer12.arrange(graphics2D20, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.addValue((double) (short) 0, (java.lang.Comparable) 100.0d, (java.lang.Comparable) 1.0f);
        defaultCategoryDataset0.removeRow((int) (short) 0);
        java.lang.Object obj8 = defaultCategoryDataset0.clone();
        int int10 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 1);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        java.awt.Paint paint21 = piePlot1.getLabelShadowPaint();
        int int22 = piePlot1.getPieIndex();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor24 = new org.jfree.chart.plot.PieLabelDistributor(2);
        java.lang.String str25 = pieLabelDistributor24.toString();
        int int26 = pieLabelDistributor24.getItemCount();
        pieLabelDistributor24.clear();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor24);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.lang.String str4 = projectInfo0.getName();
        java.lang.String str5 = projectInfo0.getLicenceText();
        projectInfo0.setVersion("org.jfree.data.UnknownKeyException: {0}");
        projectInfo0.setVersion("org.jfree.data.UnknownKeyException: hi!");
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image11 = projectInfo10.getLogo();
        projectInfo0.setLogo(image11);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str5.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(image11);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setToolTipText("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.lang.Object obj20 = blockContainer12.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str22 = horizontalAlignment21.toString();
        java.lang.String str23 = horizontalAlignment21.toString();
        java.lang.String str24 = horizontalAlignment21.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment25, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        textTitle30.setExpandToFitSpace(true);
        java.lang.Object obj33 = textTitle30.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj35 = null;
        boolean boolean36 = defaultDrawingSupplier34.equals(obj35);
        columnArrangement28.add((org.jfree.chart.block.Block) textTitle30, (java.lang.Object) defaultDrawingSupplier34);
        blockContainer12.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement28);
        blockContainer12.setWidth((double) 100L);
        blockContainer12.setPadding((double) 255, (double) 255, 0.08d, (double) 10.0f);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot46 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        multiplePiePlot46.removeChangeListener(plotChangeListener47);
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot46);
        org.jfree.chart.title.TextTitle textTitle50 = jFreeChart49.getTitle();
        org.jfree.chart.ChartColor chartColor54 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int55 = chartColor54.getRGB();
        jFreeChart49.setBackgroundPaint((java.awt.Paint) chartColor54);
        org.jfree.chart.title.LegendTitle legendTitle57 = jFreeChart49.getLegend();
        blockContainer12.add((org.jfree.chart.block.Block) legendTitle57);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.CENTER" + "'", str22.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "HorizontalAlignment.CENTER" + "'", str23.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "HorizontalAlignment.CENTER" + "'", str24.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(textTitle50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-16698368) + "'", int55 == (-16698368));
        org.junit.Assert.assertNotNull(legendTitle57);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        textTitle1.setPadding((double) 'a', (double) 2, 10.0d, 0.0d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        jFreeChart14.clearSubtitles();
        org.jfree.chart.title.TextTitle textTitle18 = null;
        jFreeChart14.setTitle(textTitle18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNull(textTitle15);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle3.getSources();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        double double6 = textTitle1.getHeight();
        textTitle1.setWidth((double) (-1L));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle1.getHorizontalAlignment();
        java.lang.String str10 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        piePlot1.setLabelLinksVisible(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        defaultKeyedValues2D1.addValue((java.lang.Number) 0.0d, (java.lang.Comparable) "PieLabelLinkStyle.QUAD_CURVE", (java.lang.Comparable) (-16698368));
        java.lang.Object obj8 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        multiplePiePlot0.setInsets(rectangleInsets7, true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list11 = defaultCategoryDataset10.getRowKeys();
        defaultCategoryDataset10.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset10.removeRow((int) (short) 0);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10);
        defaultCategoryDataset10.setValue(1.0d, (java.lang.Comparable) 8, (java.lang.Comparable) 90.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.5f);
        piePlot1.setCircular(true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int15 = chartColor14.getRGB();
        jFreeChart9.setBackgroundPaint((java.awt.Paint) chartColor14);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        double double18 = piePlot17.getLabelGap();
        double double19 = piePlot17.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot17.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = null;
        piePlot17.setLegendLabelURLGenerator(pieURLGenerator21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot17);
        java.lang.Object obj24 = plotChangeEvent23.getSource();
        jFreeChart9.plotChanged(plotChangeEvent23);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str28 = textTitle27.getText();
        java.lang.Object obj29 = null;
        boolean boolean30 = textTitle27.equals(obj29);
        textTitle27.setHeight((double) 2);
        jFreeChart9.setTitle(textTitle27);
        java.awt.Stroke stroke34 = jFreeChart9.getBorderStroke();
        piePlot1.setOutlineStroke(stroke34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str37 = color36.toString();
        java.awt.Color color38 = color36.brighter();
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color36);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(textTitle10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16698368) + "'", int15 == (-16698368));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.025d + "'", double18 == 0.025d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str37.equals("java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("{0}");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset0.removeRow((int) (short) 0);
        org.jfree.data.general.DatasetGroup datasetGroup8 = defaultCategoryDataset0.getGroup();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(datasetGroup8);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.lang.Object obj20 = blockContainer12.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str22 = horizontalAlignment21.toString();
        java.lang.String str23 = horizontalAlignment21.toString();
        java.lang.String str24 = horizontalAlignment21.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment25, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        textTitle30.setExpandToFitSpace(true);
        java.lang.Object obj33 = textTitle30.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj35 = null;
        boolean boolean36 = defaultDrawingSupplier34.equals(obj35);
        columnArrangement28.add((org.jfree.chart.block.Block) textTitle30, (java.lang.Object) defaultDrawingSupplier34);
        blockContainer12.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement28);
        blockContainer12.setWidth((double) 100L);
        blockContainer12.setPadding((double) 255, (double) 255, 0.08d, (double) 10.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = blockContainer12.getPadding();
        blockContainer12.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.CENTER" + "'", str22.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "HorizontalAlignment.CENTER" + "'", str23.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "HorizontalAlignment.CENTER" + "'", str24.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets46);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.lang.String str3 = multiplePiePlot1.getNoDataMessage();
        java.lang.String str4 = multiplePiePlot1.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = defaultDrawingSupplier8.equals(obj9);
        boolean boolean11 = jFreeChart7.equals((java.lang.Object) defaultDrawingSupplier8);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        double double16 = textTitle13.getWidth();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        try {
            jFreeChart7.handleClick((int) (short) 1, (int) (byte) 0, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation2);
        java.lang.String str4 = rotation2.toString();
        java.lang.String str5 = rotation2.toString();
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean7 = rotation2.equals((java.lang.Object) unitType6);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Rotation.CLOCKWISE" + "'", str4.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Rotation.CLOCKWISE" + "'", str5.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        double double8 = piePlot1.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        double double18 = rectangleInsets15.getBottom();
        double double20 = rectangleInsets15.calculateTopInset((double) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        multiplePiePlot21.removeChangeListener(plotChangeListener22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot24);
        multiplePiePlot21.notifyListeners(plotChangeEvent25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        textTitle28.setExpandToFitSpace(true);
        java.lang.Object obj31 = textTitle28.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = textTitle28.getMargin();
        double double34 = rectangleInsets32.trimHeight((double) (byte) 100);
        double double35 = rectangleInsets32.getBottom();
        multiplePiePlot21.setInsets(rectangleInsets32, true);
        double double39 = rectangleInsets32.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str42 = textTitle41.getText();
        java.lang.Object obj43 = null;
        boolean boolean44 = textTitle41.equals(obj43);
        textTitle41.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle41.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets32.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType48, lengthAdjustmentType49);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets15.createInsetRectangle(rectangle2D47, false, true);
        piePlot1.drawBackgroundImage(graphics2D9, rectangle2D47);
        org.jfree.chart.entity.ChartEntity chartEntity56 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D47, "VerticalAlignment.TOP");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 32.0d + "'", double39 == 32.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }
}

