import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.PINK;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font1, (java.awt.Paint) color2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            textTitle1.setMargin(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        java.awt.Paint paint20 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = java.awt.Color.WHITE;
        float[] floatArray2 = new float[] { (-16698368) };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.block.Arrangement arrangement20 = null;
        org.jfree.chart.block.Arrangement arrangement21 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, arrangement20, arrangement21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            multiplePiePlot0.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType7, lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Color color2 = java.awt.Color.PINK;
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color2, color3, color4, color5, color6, color7 };
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color9, color10 };
        java.awt.Stroke stroke12 = null;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray8, paintArray11, strokeArray13, strokeArray14, shapeArray15);
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean19 = defaultDrawingSupplier16.equals((java.lang.Object) paint18);
        try {
            java.awt.Shape shape20 = defaultDrawingSupplier16.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = null;
        try {
            jFreeChart3.addLegend(legendTitle4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        try {
            java.awt.image.BufferedImage bufferedImage7 = jFreeChart3.createBufferedImage((int) '#', 0, chartRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (35) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Comparable comparable2 = null;
        try {
            int int3 = defaultKeyedValues2D1.getColumnIndex(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            textTitle1.setMargin(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        try {
            multiplePiePlot0.setBackgroundImageAlpha((float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        double double4 = rectangleInsets3.getTop();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets3.createInsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = flowArrangement11.arrange(blockContainer12, graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        org.junit.Assert.assertNotNull(tableOrder0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle1.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.lang.String str4 = projectInfo0.getName();
        java.lang.String str5 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue((int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str1 = color0.toString();
        java.awt.Color color2 = color0.brighter();
        java.awt.Color color3 = java.awt.Color.GRAY;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getRGBColorComponents(floatArray4);
        try {
            float[] floatArray6 = color0.getRGBComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        try {
            plot2.setForegroundAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            blockBorder9.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 10);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getColumnKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        try {
            jFreeChart3.draw(graphics2D4, rectangle2D5, chartRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        textTitle1.setID("TableOrder.BY_COLUMN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        jFreeChart3.removeLegend();
        try {
            org.jfree.chart.title.Title title7 = jFreeChart3.getSubtitle((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        try {
            jFreeChart3.draw(graphics2D5, rectangle2D6, point2D7, chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart3.getTitle();
        org.jfree.chart.event.ChartChangeListener chartChangeListener5 = null;
        try {
            jFreeChart3.removeChangeListener(chartChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(textTitle4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            multiplePiePlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) "TableOrder.BY_COLUMN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.data.UnknownKeyException: {0}", (int) '4');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        textTitle23.setExpandToFitSpace(true);
        double double26 = textTitle23.getWidth();
        java.awt.Font font27 = textTitle23.getFont();
        try {
            java.lang.Object obj28 = blockContainer12.draw(graphics2D20, rectangle2D21, (java.lang.Object) textTitle23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        try {
            jFreeChart3.handleClick((int) (short) 1, 15, chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        double double4 = rectangleInsets2.extendHeight((double) 100.0f);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 108.0d + "'", double4 == 108.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.lang.Object obj8 = jFreeChart3.clone();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.lang.Object obj13 = null;
        boolean boolean14 = textTitle11.equals(obj13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle11.getHorizontalAlignment();
        double double16 = textTitle11.getHeight();
        textTitle11.setWidth((double) (-1L));
        try {
            jFreeChart3.addSubtitle((int) 'a', (org.jfree.chart.title.Title) textTitle11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent4);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
//        java.lang.String str2 = projectInfo0.getInfo();
//        java.lang.String str3 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(libraryArray1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str3.equals("org.jfree.data.UnknownKeyException: {0}"));
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) "HorizontalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.lang.String str4 = projectInfo0.getInfo();
        java.lang.String str5 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.lang.Object obj5 = textTitle1.clone();
        java.lang.String str6 = textTitle1.getToolTipText();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = standardPieSectionLabelGenerator0.getAttributedLabel((int) (byte) 10);
        org.junit.Assert.assertNull(attributedString2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        java.lang.Comparable comparable13 = pieSectionEntity7.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", comparable13.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        try {
            defaultKeyedValues2D1.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart3.getTitle();
        jFreeChart3.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        try {
            jFreeChart3.handleClick(8, (int) (byte) -1, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(textTitle4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: a");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            textTitle1.setBounds(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        boolean boolean5 = jFreeChart3.getAntiAlias();
        org.jfree.chart.title.Title title7 = null;
        try {
            jFreeChart3.addSubtitle(100, title7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj16 = null;
        boolean boolean17 = defaultDrawingSupplier15.equals(obj16);
        boolean boolean18 = jFreeChart14.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart14.setBackgroundPaint(paint19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart14, chartChangeEventType26);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        textTitle30.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent33.setType(chartChangeEventType34);
        chartChangeEvent28.setType(chartChangeEventType34);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        double double6 = textTitle1.getHeight();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str8 = color7.toString();
        textTitle1.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            textTitle1.setBounds(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str8.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.Color color1 = java.awt.Color.YELLOW;
        java.awt.Color color2 = java.awt.Color.GRAY;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getRGBColorComponents(floatArray3);
        float[] floatArray5 = color1.getRGBColorComponents(floatArray4);
        try {
            float[] floatArray6 = color0.getComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        java.awt.Paint paint8 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart3.setBackgroundPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(paint8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            blockBorder10.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge1);
        try {
            double double4 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.calculateRightOutset((double) (short) -1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = blockContainer12.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets1.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color29 = java.awt.Color.getColor("HorizontalAlignment.CENTER", 1);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        multiplePiePlot0.setInsets(rectangleInsets7, true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 100L, 8.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.lang.Object obj9 = null;
        boolean boolean10 = textTitle7.equals(obj9);
        textTitle7.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle7.getBounds();
        try {
            multiplePiePlot0.drawOutline(graphics2D5, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int13 = chartColor12.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor12);
        java.awt.Color color15 = chartColor12.brighter();
        textTitle1.setPaint((java.awt.Paint) color15);
        textTitle1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-16698368) + "'", int13 == (-16698368));
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) chartColor3, stroke4, rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        try {
            piePlot0.setInteriorGap((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        pieSectionEntity7.setArea(shape9);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj11 = null;
        boolean boolean12 = defaultDrawingSupplier10.equals(obj11);
        boolean boolean13 = jFreeChart9.equals((java.lang.Object) defaultDrawingSupplier10);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart9.getTitle();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(textTitle15);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleAnchor.BOTTOM_RIGHT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.Comparable comparable8 = pieSectionEntity7.getSectionKey();
        boolean boolean10 = pieSectionEntity7.equals((java.lang.Object) "VerticalAlignment.TOP");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 8 + "'", comparable8.equals(8));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        multiplePiePlot0.setNoDataMessage("RectangleAnchor.BOTTOM_RIGHT");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        multiplePiePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot7);
        java.awt.Image image11 = jFreeChart10.getBackgroundImage();
        jFreeChart10.removeLegend();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        double double17 = textTitle14.getWidth();
        java.awt.Paint paint18 = textTitle14.getBackgroundPaint();
        double double19 = textTitle14.getContentYOffset();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle14);
        try {
            multiplePiePlot0.setPieChart(jFreeChart10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Color color3 = color2.darker();
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = java.awt.Color.GRAY;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        float[] floatArray8 = color4.getRGBColorComponents(floatArray7);
        float[] floatArray9 = color2.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray10 = color0.getComponents(colorSpace1, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.lang.String str4 = projectInfo0.getName();
        projectInfo0.setVersion("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle5.getMargin();
        java.awt.Paint paint8 = textTitle5.getPaint();
        jFreeChart3.setTitle(textTitle5);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart3.getLegend((int) (byte) 0);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendTitle11);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint4 = jFreeChart3.getBackgroundPaint();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = null;
        try {
            multiplePiePlot0.setInsets(rectangleInsets18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(tableOrder17);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) 10.0f);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) 0.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        multiplePiePlot0.handleClick((int) (byte) 10, (-16698368), plotRenderingInfo5);
        java.awt.Font font7 = multiplePiePlot0.getNoDataMessageFont();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent8);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        java.lang.Object obj9 = pieSectionEntity7.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = multiplePiePlot0.getAggregatedItemsPaint();
        double double4 = multiplePiePlot0.getLimit();
        multiplePiePlot0.zoom((double) (-1L));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        multiplePiePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot7);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list13);
        jFreeChart10.clearSubtitles();
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        float float17 = jFreeChart10.getBackgroundImageAlpha();
        try {
            multiplePiePlot0.setPieChart(jFreeChart10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        try {
            java.lang.Comparable comparable3 = defaultCategoryDataset0.getRowKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        java.lang.Object obj3 = objectList1.get(10);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) 10.0d, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: false");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 4.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        double double4 = rectangleInsets3.getTop();
        double double6 = rectangleInsets3.calculateBottomOutset((double) (byte) 10);
        double double8 = rectangleInsets3.calculateRightOutset((double) 100L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle3.getHorizontalAlignment();
        boolean boolean8 = pieLabelLinkStyle0.equals((java.lang.Object) horizontalAlignment7);
        java.lang.String str9 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str9.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        double double6 = textTitle1.getHeight();
        textTitle1.setWidth((double) (-1L));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        multiplePiePlot9.removeChangeListener(plotChangeListener10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot9);
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart12.getTitle();
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int18 = chartColor17.getRGB();
        jFreeChart12.setBackgroundPaint((java.awt.Paint) chartColor17);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart12);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.lang.Object obj25 = null;
        boolean boolean26 = textTitle23.equals(obj25);
        textTitle23.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle23.getBounds();
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        try {
            jFreeChart12.draw(graphics2D21, rectangle2D29, point2D30, chartRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(textTitle13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16698368) + "'", int18 == (-16698368));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        try {
            java.lang.Comparable comparable3 = defaultCategoryDataset0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Font font3 = multiplePiePlot0.getNoDataMessageFont();
        multiplePiePlot0.zoom(1.0d);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        multiplePiePlot0.drawBackgroundImage(graphics2D6, rectangle2D14);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library1 = null;
        try {
            projectInfo0.addLibrary(library1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "PieLabelLinkStyle.QUAD_CURVE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("PieLabelLinkStyle.QUAD_CURVE", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent4);
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color8, color9, color10, color11, color12, color13 };
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color15, color16 };
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray14, paintArray17, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        java.awt.Stroke stroke24 = defaultDrawingSupplier22.getNextOutlineStroke();
        multiplePiePlot0.setOutlineStroke(stroke24);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.clear();
        try {
            defaultCategoryDataset0.incrementValue((double) 255, (java.lang.Comparable) "PieSection: 52, -16698368(8)", (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo1);
        java.lang.String str3 = basicProjectInfo1.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = null;
        try {
            piePlot0.setLabelDistributor(abstractPieLabelDistributor4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Color color3 = color2.darker();
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = java.awt.Color.GRAY;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        float[] floatArray8 = color4.getRGBColorComponents(floatArray7);
        float[] floatArray9 = color2.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray10 = color1.getComponents(floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        double double4 = rectangleInsets3.getTop();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = color5.brighter();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets3.createInsetRectangle(rectangle2D9, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str6.equals("java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.addValue((double) (short) 0, (java.lang.Comparable) 100.0d, (java.lang.Comparable) 1.0f);
        defaultCategoryDataset0.removeRow((int) (short) 0);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) "org.jfree.data.UnknownKeyException: {0}");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle1.draw(graphics2D5, rectangle2D6);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle1.getPadding();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        multiplePiePlot15.removeChangeListener(plotChangeListener16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot15);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot15);
        java.awt.Font font20 = legendTitle19.getItemFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.lang.Object obj25 = null;
        boolean boolean26 = textTitle23.equals(obj25);
        textTitle23.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = textTitle23.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement32 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment21, verticalAlignment29, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement32);
        legendTitle19.setWrapper(blockContainer33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = null;
        try {
            org.jfree.chart.util.Size2D size2D37 = flowArrangement12.arrange(blockContainer33, graphics2D35, rectangleConstraint36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(verticalAlignment29);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset15, (java.lang.Comparable) '#');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle19.getMargin();
        boolean boolean22 = standardPieSectionLabelGenerator0.equals((java.lang.Object) textTitle19);
        java.lang.Object obj23 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        java.lang.String str26 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset24, (java.lang.Comparable) 0.08d);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("java.awt.Color[r=128,g=255,b=255]");
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("java.awt.Color[r=128,g=255,b=255]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.lang.String str4 = projectInfo0.getName();
        java.lang.String str5 = projectInfo0.getLicenceText();
        projectInfo0.setVersion("org.jfree.data.UnknownKeyException: {0}");
        java.util.List list8 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int3 = java.awt.Color.HSBtoRGB((float) (-16698368), (float) (short) -1, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent4.setType(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("java.awt.Color[r=128,g=255,b=255]");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        java.lang.Throwable[] throwableArray7 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]" + "'", str2.equals("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        jFreeChart3.removeLegend();
        boolean boolean6 = jFreeChart3.isNotify();
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        multiplePiePlot0.setNoDataMessage("RectangleAnchor.BOTTOM_RIGHT");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        double double12 = textTitle9.getWidth();
        java.awt.Paint paint13 = textTitle9.getBackgroundPaint();
        double double14 = textTitle9.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle9.getPadding();
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        java.lang.Object obj21 = null;
        boolean boolean22 = textTitle19.equals(obj21);
        textTitle19.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets15.createInsetRectangle(rectangle2D25, false, false);
        try {
            multiplePiePlot0.drawBackground(graphics2D7, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.addValue((double) (short) 0, (java.lang.Comparable) 100.0d, (java.lang.Comparable) 1.0f);
        defaultCategoryDataset0.removeRow((int) (short) 0);
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj16 = null;
        boolean boolean17 = defaultDrawingSupplier15.equals(obj16);
        boolean boolean18 = jFreeChart14.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart14.setBackgroundPaint(paint19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart14, chartChangeEventType26);
        float float29 = jFreeChart14.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 100, (float) 1L, 1.0f);
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color5 = color4.darker();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        java.awt.Color color7 = java.awt.Color.GRAY;
        float[] floatArray8 = null;
        float[] floatArray9 = color7.getRGBColorComponents(floatArray8);
        float[] floatArray10 = color6.getRGBColorComponents(floatArray9);
        float[] floatArray11 = color4.getRGBColorComponents(floatArray9);
        try {
            float[] floatArray12 = color3.getRGBComponents(floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        float float10 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        textTitle12.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent15.setType(chartChangeEventType16);
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        titleChangeEvent15.setChart(jFreeChart18);
        jFreeChart3.titleChanged(titleChangeEvent15);
        java.awt.Paint paint21 = jFreeChart3.getBackgroundPaint();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        double double12 = rectangleInsets10.calculateLeftOutset(0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color27 };
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color29, color30, color31, color32, color33, color34 };
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color36, color37 };
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray35, paintArray38, strokeArray40, strokeArray41, shapeArray42);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        multiplePiePlot0.setNoDataMessage("");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
//        projectInfo0.setName("");
//        java.lang.String str4 = projectInfo0.toString();
//        java.lang.String str5 = projectInfo0.getCopyright();
//        projectInfo0.setName("");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(libraryArray1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str5.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Paint paint10 = blockBorder9.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder9.getInsets();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("-4,-4,4,4", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.lang.String str4 = projectInfo0.getLicenceText();
        projectInfo0.setInfo("RectangleAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor1.sort();
        java.lang.String str3 = pieLabelDistributor1.toString();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TableOrder.BY_COLUMN", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart3.getTitle();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) (byte) 100, (float) 1L, 1.0f);
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        java.awt.geom.AffineTransform affineTransform20 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        multiplePiePlot21.removeChangeListener(plotChangeListener22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot21);
        java.awt.Image image25 = jFreeChart24.getBackgroundImage();
        jFreeChart24.removeLegend();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        textTitle28.setExpandToFitSpace(true);
        double double31 = textTitle28.getWidth();
        java.awt.Paint paint32 = textTitle28.getBackgroundPaint();
        double double33 = textTitle28.getContentYOffset();
        jFreeChart24.removeSubtitle((org.jfree.chart.title.Title) textTitle28);
        java.awt.RenderingHints renderingHints35 = jFreeChart24.getRenderingHints();
        java.awt.PaintContext paintContext36 = color9.createContext(colorModel10, rectangle11, rectangle2D19, affineTransform20, renderingHints35);
        java.awt.geom.Point2D point2D37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        try {
            jFreeChart3.draw(graphics2D5, rectangle2D19, point2D37, chartRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(textTitle4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNull(image25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(renderingHints35);
        org.junit.Assert.assertNotNull(paintContext36);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot0.getDataExtractOrder();
        int int18 = multiplePiePlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color8, color9, color10, color11, color12, color13 };
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color15, color16 };
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray14, paintArray17, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle26.getMargin();
        multiplePiePlot5.setInsets(rectangleInsets28);
        java.awt.Stroke stroke30 = null;
        multiplePiePlot5.setOutlineStroke(stroke30);
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color32 };
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Color color38 = java.awt.Color.PINK;
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color34, color35, color36, color37, color38, color39 };
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color41, color42 };
        java.awt.Stroke stroke44 = null;
        java.awt.Stroke[] strokeArray45 = new java.awt.Stroke[] { stroke44 };
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray40, paintArray43, strokeArray45, strokeArray46, shapeArray47);
        multiplePiePlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        multiplePiePlot0.setOutlineVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
        org.junit.Assert.assertNotNull(legendItemCollection53);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = multiplePiePlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = multiplePiePlot6.getInsets();
        boolean boolean9 = rectangleEdge5.equals((java.lang.Object) rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        double double8 = rectangleInsets5.getBottom();
        double double9 = rectangleInsets5.getTop();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape0, "HorizontalAlignment.CENTER", "");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) 100.0f);
        double double9 = rectangleInsets5.calculateTopOutset((double) 0L);
        double double11 = rectangleInsets5.calculateLeftInset((double) 0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.lang.Object obj12 = null;
        boolean boolean13 = textTitle10.equals(obj12);
        textTitle10.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            jFreeChart3.draw(graphics2D8, rectangle2D16, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        java.awt.Image image3 = null;
        multiplePiePlot0.setBackgroundImage(image3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent5);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 100, (float) 1L, 1.0f);
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.lang.Object obj9 = null;
        boolean boolean10 = textTitle7.equals(obj9);
        textTitle7.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle7.getBounds();
        java.awt.geom.AffineTransform affineTransform14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        multiplePiePlot15.removeChangeListener(plotChangeListener16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot15);
        java.awt.Image image19 = jFreeChart18.getBackgroundImage();
        jFreeChart18.removeLegend();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        double double25 = textTitle22.getWidth();
        java.awt.Paint paint26 = textTitle22.getBackgroundPaint();
        double double27 = textTitle22.getContentYOffset();
        jFreeChart18.removeSubtitle((org.jfree.chart.title.Title) textTitle22);
        java.awt.RenderingHints renderingHints29 = jFreeChart18.getRenderingHints();
        java.awt.PaintContext paintContext30 = color3.createContext(colorModel4, rectangle5, rectangle2D13, affineTransform14, renderingHints29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        textTitle32.setExpandToFitSpace(true);
        double double35 = textTitle32.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = textTitle32.getPosition();
        try {
            double double37 = org.jfree.chart.util.RectangleEdge.coordinate((java.awt.geom.Rectangle2D) rectangle5, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(renderingHints29);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color16, color17, color18, color19, color20, color21 };
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke stroke26 = null;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray22, paintArray25, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextOutlinePaint();
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str35 = textTitle34.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle34.getMargin();
        multiplePiePlot13.setInsets(rectangleInsets36);
        java.awt.Stroke stroke38 = null;
        multiplePiePlot13.setOutlineStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray41 = new java.awt.Paint[] { color40 };
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Color color43 = java.awt.Color.PINK;
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Color color45 = java.awt.Color.PINK;
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray48 = new java.awt.Paint[] { color42, color43, color44, color45, color46, color47 };
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { color49, color50 };
        java.awt.Stroke stroke52 = null;
        java.awt.Stroke[] strokeArray53 = new java.awt.Stroke[] { stroke52 };
        java.awt.Stroke[] strokeArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray41, paintArray48, paintArray51, strokeArray53, strokeArray54, shapeArray55);
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot13.setOutlineStroke(stroke58);
        boolean boolean60 = blockContainer12.equals((java.lang.Object) stroke58);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot62 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener63 = null;
        multiplePiePlot62.removeChangeListener(plotChangeListener63);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot65 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent66 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot65);
        multiplePiePlot62.notifyListeners(plotChangeEvent66);
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("");
        textTitle69.setExpandToFitSpace(true);
        java.lang.Object obj72 = textTitle69.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = textTitle69.getMargin();
        double double75 = rectangleInsets73.trimHeight((double) (byte) 100);
        double double76 = rectangleInsets73.getBottom();
        multiplePiePlot62.setInsets(rectangleInsets73, true);
        double double80 = rectangleInsets73.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle82 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str83 = textTitle82.getText();
        java.lang.Object obj84 = null;
        boolean boolean85 = textTitle82.equals(obj84);
        textTitle82.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D88 = textTitle82.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType89 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType90 = null;
        java.awt.geom.Rectangle2D rectangle2D91 = rectangleInsets73.createAdjustedRectangle(rectangle2D88, lengthAdjustmentType89, lengthAdjustmentType90);
        try {
            blockContainer12.draw(graphics2D61, rectangle2D88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintArray48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(strokeArray53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 100.0d + "'", double75 == 100.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 32.0d + "'", double80 == 32.0d);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "" + "'", str83.equals(""));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(rectangle2D88);
        org.junit.Assert.assertNotNull(rectangle2D91);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Font font5 = legendTitle4.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle4.getPosition();
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        java.text.NumberFormat numberFormat15 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        java.lang.String str18 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset16, (java.lang.Comparable) '#');
        java.lang.Object obj19 = standardPieSectionLabelGenerator0.clone();
        java.lang.Object obj20 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color27 };
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color29, color30, color31, color32, color33, color34 };
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color36, color37 };
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray35, paintArray38, strokeArray40, strokeArray41, shapeArray42);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot45 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset46 = multiplePiePlot45.getDataset();
        boolean boolean47 = multiplePiePlot0.equals((java.lang.Object) categoryDataset46);
        java.awt.Image image48 = multiplePiePlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(image48);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color7 };
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color9, color10, color11, color12, color13, color14 };
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color16, color17 };
        java.awt.Stroke stroke19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Stroke[] strokeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray15, paintArray18, strokeArray20, strokeArray21, shapeArray22);
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        multiplePiePlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str28 = textTitle27.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = textTitle27.getMargin();
        multiplePiePlot6.setInsets(rectangleInsets29);
        java.awt.Stroke stroke31 = null;
        multiplePiePlot6.setOutlineStroke(stroke31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str36 = textTitle35.getText();
        java.lang.Object obj37 = null;
        boolean boolean38 = textTitle35.equals(obj37);
        textTitle35.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle35.getBounds();
        multiplePiePlot6.drawBackgroundImage(graphics2D33, rectangle2D41);
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity49 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D41, pieDataset43, 0, (int) (short) -1, (java.lang.Comparable) "", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot51 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset50);
        try {
            java.lang.Object obj52 = legendTitle4.draw(graphics2D5, rectangle2D41, (java.lang.Object) multiplePiePlot51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Color color2 = java.awt.Color.PINK;
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color2, color3, color4, color5, color6, color7 };
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color9, color10 };
        java.awt.Stroke stroke12 = null;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray8, paintArray11, strokeArray13, strokeArray14, shapeArray15);
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean19 = defaultDrawingSupplier16.equals((java.lang.Object) paint18);
        java.lang.Object obj20 = defaultDrawingSupplier16.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int10 = chartColor9.getRGB();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = chartColor9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        legendTitle4.setBackgroundPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle4.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle4.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (byte) 100, (float) 1L, 1.0f);
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.lang.Object obj33 = null;
        boolean boolean34 = textTitle31.equals(obj33);
        textTitle31.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle31.getBounds();
        java.awt.geom.AffineTransform affineTransform38 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        multiplePiePlot39.removeChangeListener(plotChangeListener40);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot39);
        java.awt.Image image43 = jFreeChart42.getBackgroundImage();
        jFreeChart42.removeLegend();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        textTitle46.setExpandToFitSpace(true);
        double double49 = textTitle46.getWidth();
        java.awt.Paint paint50 = textTitle46.getBackgroundPaint();
        double double51 = textTitle46.getContentYOffset();
        jFreeChart42.removeSubtitle((org.jfree.chart.title.Title) textTitle46);
        java.awt.RenderingHints renderingHints53 = jFreeChart42.getRenderingHints();
        java.awt.PaintContext paintContext54 = color27.createContext(colorModel28, rectangle29, rectangle2D37, affineTransform38, renderingHints53);
        try {
            legendTitle4.draw(graphics2D23, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16698368) + "'", int10 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNull(image43);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(renderingHints53);
        org.junit.Assert.assertNotNull(paintContext54);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(2);
        java.lang.String str2 = pieLabelDistributor1.toString();
        int int3 = pieLabelDistributor1.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("TableOrder.BY_COLUMN");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 10L);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) 0.08d);
        paintMap0.clear();
        boolean boolean7 = paintMap0.containsKey((java.lang.Comparable) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.lang.String str4 = projectInfo0.getName();
        projectInfo0.addOptionalLibrary("org.jfree.data.UnknownKeyException: {0}");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.setBackgroundImageAlpha((float) (short) -1);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.lang.Object obj14 = null;
        boolean boolean15 = textTitle12.equals(obj14);
        textTitle12.setHeight((double) 2);
        java.lang.String str18 = textTitle12.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle12.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge20);
        boolean boolean22 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge20);
        textTitle12.setPosition(rectangleEdge20);
        try {
            jFreeChart3.addSubtitle((int) (byte) -1, (org.jfree.chart.title.Title) textTitle12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets5.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) (-16698368), 0.08d, 0.4d, 0.0d);
        double double14 = rectangleInsets13.getRight();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        jFreeChart3.removeLegend();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        double double10 = textTitle7.getWidth();
        java.awt.Paint paint11 = textTitle7.getBackgroundPaint();
        double double12 = textTitle7.getContentYOffset();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle7);
        java.awt.RenderingHints renderingHints14 = jFreeChart3.getRenderingHints();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color17 };
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color19, color20, color21, color22, color23, color24 };
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color26, color27 };
        java.awt.Stroke stroke29 = null;
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke29 };
        java.awt.Stroke[] strokeArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray25, paintArray28, strokeArray30, strokeArray31, shapeArray32);
        java.awt.Paint paint34 = defaultDrawingSupplier33.getNextOutlinePaint();
        multiplePiePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str38 = textTitle37.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = textTitle37.getMargin();
        multiplePiePlot16.setInsets(rectangleInsets39);
        java.awt.Stroke stroke41 = null;
        multiplePiePlot16.setOutlineStroke(stroke41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str46 = textTitle45.getText();
        java.lang.Object obj47 = null;
        boolean boolean48 = textTitle45.equals(obj47);
        textTitle45.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle45.getBounds();
        multiplePiePlot16.drawBackgroundImage(graphics2D43, rectangle2D51);
        try {
            jFreeChart3.draw(graphics2D15, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Font font5 = textTitle1.getFont();
        double double6 = textTitle1.getContentXOffset();
        textTitle1.setToolTipText("org.jfree.data.UnknownKeyException: {0}");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset15, (java.lang.Comparable) '#');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle19.getMargin();
        boolean boolean22 = standardPieSectionLabelGenerator0.equals((java.lang.Object) textTitle19);
        java.text.AttributedString attributedString24 = standardPieSectionLabelGenerator0.getAttributedLabel((int) (byte) 1);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(attributedString24);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        boolean boolean3 = strokeMap0.containsKey((java.lang.Comparable) 'a');
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 0.5f, stroke5);
        java.lang.Object obj7 = strokeMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            piePlot0.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor1.sort();
        java.lang.String str3 = pieLabelDistributor1.toString();
        pieLabelDistributor1.clear();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("PieSection: 52, -16698368(8)");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key PieSection: 52, -16698368(8)");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = legendTitle4.getVerticalAlignment();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        legendTitle4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        double double14 = textTitle11.getWidth();
        java.awt.Paint paint15 = textTitle11.getBackgroundPaint();
        double double16 = textTitle11.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle11.getPadding();
        double double19 = rectangleInsets17.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.lang.Object obj23 = null;
        boolean boolean24 = textTitle21.equals(obj23);
        textTitle21.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle21.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets17.createInsetRectangle(rectangle2D27, false, false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color32 };
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Color color38 = java.awt.Color.PINK;
        java.awt.Color color39 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color34, color35, color36, color37, color38, color39 };
        java.awt.Color color41 = java.awt.Color.PINK;
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color41, color42 };
        java.awt.Stroke stroke44 = null;
        java.awt.Stroke[] strokeArray45 = new java.awt.Stroke[] { stroke44 };
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray40, paintArray43, strokeArray45, strokeArray46, shapeArray47);
        boolean boolean49 = rectangleAnchor31.equals((java.lang.Object) paintArray43);
        try {
            java.lang.Object obj50 = legendTitle4.draw(graphics2D9, rectangle2D27, (java.lang.Object) paintArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        jFreeChart3.removeLegend();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        double double10 = textTitle7.getWidth();
        java.awt.Paint paint11 = textTitle7.getBackgroundPaint();
        double double12 = textTitle7.getContentYOffset();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle7);
        java.awt.RenderingHints renderingHints14 = jFreeChart3.getRenderingHints();
        org.jfree.chart.plot.Plot plot15 = jFreeChart3.getPlot();
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color16, color17, color18, color19, color20, color21 };
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke stroke26 = null;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray22, paintArray25, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextOutlinePaint();
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str35 = textTitle34.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle34.getMargin();
        multiplePiePlot13.setInsets(rectangleInsets36);
        java.awt.Stroke stroke38 = null;
        multiplePiePlot13.setOutlineStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray41 = new java.awt.Paint[] { color40 };
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Color color43 = java.awt.Color.PINK;
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Color color45 = java.awt.Color.PINK;
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray48 = new java.awt.Paint[] { color42, color43, color44, color45, color46, color47 };
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { color49, color50 };
        java.awt.Stroke stroke52 = null;
        java.awt.Stroke[] strokeArray53 = new java.awt.Stroke[] { stroke52 };
        java.awt.Stroke[] strokeArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray41, paintArray48, paintArray51, strokeArray53, strokeArray54, shapeArray55);
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot13.setOutlineStroke(stroke58);
        boolean boolean60 = blockContainer12.equals((java.lang.Object) stroke58);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = null;
        try {
            org.jfree.chart.util.Size2D size2D63 = blockContainer12.arrange(graphics2D61, rectangleConstraint62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintArray48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(strokeArray53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        java.awt.Shape shape13 = pieSectionEntity7.getArea();
        org.jfree.data.general.PieDataset pieDataset14 = pieSectionEntity7.getDataset();
        int int15 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(pieDataset14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor1.sort();
        int int3 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        double double25 = textTitle22.getWidth();
        java.awt.Paint paint26 = textTitle22.getBackgroundPaint();
        double double27 = textTitle22.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle22.getPadding();
        double double30 = rectangleInsets28.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str33 = textTitle32.getText();
        java.lang.Object obj34 = null;
        boolean boolean35 = textTitle32.equals(obj34);
        textTitle32.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets28.createInsetRectangle(rectangle2D38, false, false);
        try {
            blockContainer12.draw(graphics2D20, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.removeRow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
//        projectInfo0.setName("");
//        java.lang.String str4 = projectInfo0.getName();
//        java.lang.String str5 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(libraryArray1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str5.equals("ChartChangeEventType.NEW_DATASET"));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        pieSectionEntity7.setSectionIndex((-16698368));
        pieSectionEntity7.setPieIndex(2);
        java.lang.String str12 = pieSectionEntity7.getURLText();
        java.lang.String str13 = pieSectionEntity7.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "rect" + "'", str13.equals("rect"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.lang.Object obj20 = blockContainer12.clone();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        multiplePiePlot22.removeChangeListener(plotChangeListener23);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot25);
        multiplePiePlot22.notifyListeners(plotChangeEvent26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setExpandToFitSpace(true);
        java.lang.Object obj32 = textTitle29.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = textTitle29.getMargin();
        double double35 = rectangleInsets33.trimHeight((double) (byte) 100);
        double double36 = rectangleInsets33.getBottom();
        multiplePiePlot22.setInsets(rectangleInsets33, true);
        double double40 = rectangleInsets33.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str43 = textTitle42.getText();
        java.lang.Object obj44 = null;
        boolean boolean45 = textTitle42.equals(obj44);
        textTitle42.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D48 = textTitle42.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets33.createAdjustedRectangle(rectangle2D48, lengthAdjustmentType49, lengthAdjustmentType50);
        org.jfree.chart.PaintMap paintMap52 = new org.jfree.chart.PaintMap();
        boolean boolean54 = paintMap52.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color56 = java.awt.Color.cyan;
        paintMap52.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color56);
        try {
            java.lang.Object obj58 = blockContainer12.draw(graphics2D21, rectangle2D48, (java.lang.Object) paintMap52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 32.0d + "'", double40 == 32.0d);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("{0}");
        java.lang.String str2 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("java.awt.Color[r=128,g=255,b=255]");
        java.lang.String str5 = unknownKeyException4.toString();
        java.lang.Throwable[] throwableArray6 = unknownKeyException4.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException8 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException4.addSuppressed((java.lang.Throwable) unknownKeyException8);
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str2.equals("org.jfree.data.UnknownKeyException: {0}"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]" + "'", str5.equals("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Font font5 = legendTitle4.getItemFont();
        legendTitle4.setPadding((double) 0, (double) 8, (double) (short) 10, (double) (-16777216));
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_RIGHT", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Image image5 = jFreeChart4.getBackgroundImage();
        boolean boolean6 = jFreeChart4.getAntiAlias();
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot9.getParent();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle14.getMargin();
        java.awt.Paint paint17 = textTitle14.getPaint();
        jFreeChart12.setTitle(textTitle14);
        try {
            jFreeChart4.addSubtitle(10, (org.jfree.chart.title.Title) textTitle14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        double double6 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((java.lang.Comparable) "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        boolean boolean4 = multiplePiePlot0.isSubplot();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        pieSectionEntity7.setSectionIndex((-16698368));
        pieSectionEntity7.setPieIndex(2);
        java.lang.String str12 = pieSectionEntity7.getURLText();
        java.lang.String str13 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PieSection: 2, -16698368(8)" + "'", str13.equals("PieSection: 2, -16698368(8)"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Image image8 = jFreeChart3.getBackgroundImage();
        java.awt.Paint paint9 = null;
        jFreeChart3.setBackgroundPaint(paint9);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.lang.Object obj14 = null;
        boolean boolean15 = textTitle12.equals(obj14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle12.getHorizontalAlignment();
        textTitle12.setMargin((double) (-1L), (double) (short) 1, (double) 8, 0.0d);
        jFreeChart3.setTitle(textTitle12);
        textTitle12.setWidth(0.14d);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        int int8 = color6.getRed();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("RectangleAnchor.CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.CENTER");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.StrokeMap strokeMap4 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke6 = strokeMap4.getStroke((java.lang.Comparable) (short) -1);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) stroke6);
        multiplePiePlot0.setNoDataMessage("PieSection: 52, -16698368(8)");
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint4 = jFreeChart3.getBorderPaint();
        org.jfree.chart.plot.Plot plot5 = jFreeChart3.getPlot();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("-4,-4,4,4", "hi!", "RectangleAnchor.BOTTOM_RIGHT", "", "");
        basicProjectInfo5.setCopyright("VerticalAlignment.CENTER");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int13 = chartColor12.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor12);
        java.awt.Color color15 = chartColor12.brighter();
        textTitle1.setPaint((java.awt.Paint) color15);
        java.lang.Object obj17 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-16698368) + "'", int13 == (-16698368));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        textTitle3.setExpandToFitSpace(true);
        double double6 = textTitle3.getWidth();
        java.awt.Paint paint7 = textTitle3.getBackgroundPaint();
        double double8 = textTitle3.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle3.getPadding();
        double double11 = rectangleInsets9.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets9.createInsetRectangle(rectangle2D19, false, false);
        try {
            blockContainer0.draw(graphics2D1, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.Comparable comparable8 = pieSectionEntity7.getSectionKey();
        java.lang.String str9 = pieSectionEntity7.getShapeCoords();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape10, "");
        pieSectionEntity7.setArea(shape10);
        java.lang.String str21 = pieSectionEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 8 + "'", comparable8.equals(8));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-4,-4,4,4" + "'", str9.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        java.lang.String str3 = horizontalAlignment0.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment4, (double) 100, (double) (byte) 1);
        java.lang.Object obj8 = null;
        boolean boolean9 = verticalAlignment4.equals(obj8);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.lang.Comparable comparable2 = null;
        try {
            defaultCategoryDataset0.removeColumn(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setMargin((double) (short) 1, (double) (byte) 10, 0.0d, (double) 10.0f);
        textTitle1.setID("HorizontalAlignment.CENTER");
        java.awt.Color color12 = java.awt.Color.cyan;
        textTitle1.setPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        double double17 = piePlot16.getLabelGap();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot16);
        boolean boolean19 = textTitle1.equals((java.lang.Object) "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        java.lang.String str3 = horizontalAlignment0.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment4, (double) 100, (double) (byte) 1);
        java.lang.String str8 = verticalAlignment4.toString();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        textTitle10.setExpandToFitSpace(true);
        double double13 = textTitle10.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle10.getPosition();
        java.awt.Paint paint15 = textTitle10.getBackgroundPaint();
        boolean boolean16 = verticalAlignment4.equals((java.lang.Object) textTitle10);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "VerticalAlignment.TOP" + "'", str8.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        piePlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        textTitle3.setExpandToFitSpace(true);
        double double6 = textTitle3.getWidth();
        java.awt.Paint paint7 = textTitle3.getBackgroundPaint();
        double double8 = textTitle3.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle3.getPadding();
        double double11 = rectangleInsets9.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets9.createInsetRectangle(rectangle2D19, false, false);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getText();
        java.lang.Object obj26 = null;
        boolean boolean27 = textTitle24.equals(obj26);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textTitle24.getHorizontalAlignment();
        double double29 = textTitle24.getHeight();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str31 = color30.toString();
        textTitle24.setBackgroundPaint((java.awt.Paint) color30);
        try {
            java.lang.Object obj33 = blockContainer0.draw(graphics2D1, rectangle2D19, (java.lang.Object) color30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str31.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int7 = color6.getAlpha();
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getLabelOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.lang.String str4 = projectInfo0.getLicenceText();
        java.lang.String str5 = projectInfo0.toString();
        java.lang.String str6 = projectInfo0.getName();
        java.util.List list7 = projectInfo0.getContributors();
        projectInfo0.addOptionalLibrary("VerticalAlignment.TOP");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle1.getPadding();
        double double9 = rectangleInsets7.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.lang.Object obj13 = null;
        boolean boolean14 = textTitle11.equals(obj13);
        textTitle11.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets7.createInsetRectangle(rectangle2D17, false, false);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "RectangleAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        legendTitle4.setNotify(true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateTopInset((double) 100.0f);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 8);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot0.getLegendLabelGenerator();
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key (C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setName("");
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        projectInfo0.setVersion("ChartChangeEventType.NEW_DATASET");
        projectInfo0.setLicenceName("-4,-4,4,4");
        java.lang.String str10 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int9 = chartColor8.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        java.awt.Font font15 = multiplePiePlot12.getNoDataMessageFont();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = multiplePiePlot12.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = multiplePiePlot12.getInsets();
        boolean boolean18 = blockBorder10.equals((java.lang.Object) multiplePiePlot12);
        boolean boolean19 = color0.equals((java.lang.Object) multiplePiePlot12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16698368) + "'", int9 == (-16698368));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) (short) -1);
        strokeMap0.clear();
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color27 };
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color29, color30, color31, color32, color33, color34 };
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color36, color37 };
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray35, paintArray38, strokeArray40, strokeArray41, shapeArray42);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        java.awt.Paint paint45 = defaultDrawingSupplier43.getNextFillPaint();
        try {
            java.awt.Shape shape46 = defaultDrawingSupplier43.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.lang.Object obj20 = blockContainer12.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str22 = horizontalAlignment21.toString();
        java.lang.String str23 = horizontalAlignment21.toString();
        java.lang.String str24 = horizontalAlignment21.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment25, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        textTitle30.setExpandToFitSpace(true);
        java.lang.Object obj33 = textTitle30.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj35 = null;
        boolean boolean36 = defaultDrawingSupplier34.equals(obj35);
        columnArrangement28.add((org.jfree.chart.block.Block) textTitle30, (java.lang.Object) defaultDrawingSupplier34);
        blockContainer12.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement28);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = null;
        try {
            org.jfree.chart.util.Size2D size2D41 = blockContainer12.arrange(graphics2D39, rectangleConstraint40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.CENTER" + "'", str22.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "HorizontalAlignment.CENTER" + "'", str23.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "HorizontalAlignment.CENTER" + "'", str24.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getLabelGap();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        boolean boolean6 = piePlot1.isSubplot();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int15 = chartColor14.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor14);
        piePlot1.setLabelOutlinePaint((java.awt.Paint) chartColor14);
        int int18 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16698368) + "'", int15 == (-16698368));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot7);
        multiplePiePlot4.notifyListeners(plotChangeEvent8);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        double double18 = rectangleInsets15.getBottom();
        multiplePiePlot4.setInsets(rectangleInsets15, true);
        piePlot1.setSimpleLabelOffset(rectangleInsets15);
        java.lang.Object obj22 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        multiplePiePlot1.setOutlineVisible(false);
        multiplePiePlot1.setBackgroundImageAlignment((int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.lang.Comparable comparable5 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean12 = color10.equals((java.lang.Object) font11);
        java.awt.Color color13 = color10.darker();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        try {
            defaultCategoryDataset0.incrementValue(10.0d, (java.lang.Comparable) "HorizontalAlignment.CENTER", (java.lang.Comparable) "PieSection: 52, -16698368(8)");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: PieSection: 52, -16698368(8)");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        boolean boolean9 = jFreeChart3.getAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart3.getLegend();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.lang.Object obj15 = null;
        boolean boolean16 = textTitle13.equals(obj15);
        textTitle13.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            jFreeChart3.draw(graphics2D11, rectangle2D19, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("PieLabelLinkStyle.QUAD_CURVE", "PieSection: 52, 52(8)", "rect", "VerticalAlignment.CENTER");
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Other", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot1.getLabelLinkStyle();
        java.awt.Image image5 = piePlot1.getBackgroundImage();
        piePlot1.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(image5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.PaintMap paintMap1 = new org.jfree.chart.PaintMap();
        boolean boolean3 = paintMap1.containsKey((java.lang.Comparable) 10L);
        boolean boolean5 = paintMap1.containsKey((java.lang.Comparable) 1);
        boolean boolean6 = pieLabelLinkStyle0.equals((java.lang.Object) paintMap1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        piePlot0.setForegroundAlpha((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        boolean boolean6 = piePlot1.isCircular();
        java.awt.Color color7 = java.awt.Color.orange;
        java.awt.Color color8 = color7.darker();
        boolean boolean9 = piePlot1.equals((java.lang.Object) color8);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        java.awt.Shape shape13 = pieSectionEntity7.getArea();
        java.lang.Object obj14 = pieSectionEntity7.clone();
        pieSectionEntity7.setURLText("RectangleAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("ChartChangeEventType.NEW_DATASET");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ChartChangeEventType.NEW_DATASET");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        objectList0.clear();
        objectList0.clear();
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int10 = chartColor9.getRGB();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = chartColor9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        legendTitle4.setBackgroundPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle4.getItemContainer();
        boolean boolean19 = blockContainer18.isEmpty();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16698368) + "'", int10 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.Object obj1 = null;
        boolean boolean2 = verticalAlignment0.equals(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        multiplePiePlot3.removeChangeListener(plotChangeListener4);
        java.awt.Font font6 = multiplePiePlot3.getNoDataMessageFont();
        piePlot1.setLabelFont(font6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot1.setURLGenerator(pieURLGenerator8);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        jFreeChart3.clearSubtitles();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart3.getPadding();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot12 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        double double16 = rectangleInsets11.calculateTopInset((double) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        multiplePiePlot17.removeChangeListener(plotChangeListener18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot20);
        multiplePiePlot17.notifyListeners(plotChangeEvent21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setExpandToFitSpace(true);
        java.lang.Object obj27 = textTitle24.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle24.getMargin();
        double double30 = rectangleInsets28.trimHeight((double) (byte) 100);
        double double31 = rectangleInsets28.getBottom();
        multiplePiePlot17.setInsets(rectangleInsets28, true);
        double double35 = rectangleInsets28.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str38 = textTitle37.getText();
        java.lang.Object obj39 = null;
        boolean boolean40 = textTitle37.equals(obj39);
        textTitle37.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle37.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets28.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType44, lengthAdjustmentType45);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets11.createInsetRectangle(rectangle2D43, false, true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets5.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType50, lengthAdjustmentType51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        pieSectionEntity7.setSectionIndex((-16698368));
        java.lang.String str10 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 52, -16698368(8)" + "'", str10.equals("PieSection: 52, -16698368(8)"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.setBackgroundImageAlpha((float) (short) -1);
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage((-16698368), 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-16698368) and height (255) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int11 = chartColor10.getRGB();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = chartColor10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.block.BlockContainer blockContainer19 = legendTitle5.getItemContainer();
        boolean boolean20 = objectList0.equals((java.lang.Object) legendTitle5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle5.getLegendItemGraphicAnchor();
        java.lang.String str22 = rectangleAnchor21.toString();
        java.lang.String str23 = rectangleAnchor21.toString();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16698368) + "'", int11 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(blockContainer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleAnchor.CENTER" + "'", str22.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleAnchor.CENTER" + "'", str23.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str5 = horizontalAlignment4.toString();
        java.lang.String str6 = horizontalAlignment4.toString();
        java.lang.String str7 = horizontalAlignment4.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment8, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        java.lang.Object obj16 = textTitle13.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj18 = null;
        boolean boolean19 = defaultDrawingSupplier17.equals(obj18);
        columnArrangement11.add((org.jfree.chart.block.Block) textTitle13, (java.lang.Object) defaultDrawingSupplier17);
        java.awt.Stroke stroke21 = defaultDrawingSupplier17.getNextStroke();
        java.awt.Shape shape22 = defaultDrawingSupplier17.getNextShape();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        multiplePiePlot24.removeChangeListener(plotChangeListener25);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot24);
        java.awt.Image image28 = jFreeChart27.getBackgroundImage();
        jFreeChart27.removeLegend();
        multiplePiePlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart27);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        textTitle33.setExpandToFitSpace(true);
        double double36 = textTitle33.getWidth();
        java.awt.Paint paint37 = textTitle33.getBackgroundPaint();
        double double38 = textTitle33.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = textTitle33.getPadding();
        double double41 = rectangleInsets39.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str44 = textTitle43.getText();
        java.lang.Object obj45 = null;
        boolean boolean46 = textTitle43.equals(obj45);
        textTitle43.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets39.createInsetRectangle(rectangle2D49, false, false);
        java.awt.geom.Point2D point2D53 = null;
        org.jfree.chart.plot.PlotState plotState54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        try {
            multiplePiePlot0.draw(graphics2D31, rectangle2D52, point2D53, plotState54, plotRenderingInfo55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HorizontalAlignment.CENTER" + "'", str5.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HorizontalAlignment.CENTER" + "'", str6.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        int int13 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setURLText("java.awt.Color[r=128,g=255,b=255]");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot1.getInsets();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        double double5 = multiplePiePlot1.getLimit();
        java.awt.Font font6 = multiplePiePlot1.getNoDataMessageFont();
        java.awt.Paint paint7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean12 = rectangleEdge10.equals((java.lang.Object) rectangleInsets11);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str14 = pieLabelLinkStyle13.toString();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str17 = textTitle16.getText();
        java.lang.Object obj18 = null;
        boolean boolean19 = textTitle16.equals(obj18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle16.getHorizontalAlignment();
        boolean boolean21 = pieLabelLinkStyle13.equals((java.lang.Object) horizontalAlignment20);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setExpandToFitSpace(true);
        java.lang.Object obj27 = textTitle24.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle24.getMargin();
        double double30 = rectangleInsets28.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets28.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets(unitType31, (double) (-16698368), 0.08d, 0.4d, 0.0d);
        try {
            org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("", font6, paint7, rectangleEdge10, horizontalAlignment20, verticalAlignment22, rectangleInsets36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'paint' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str14.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(unitType31);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        java.text.NumberFormat numberFormat15 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString17 = null;
        try {
            standardPieSectionLabelGenerator0.setAttributedLabel((-16698368), attributedString17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberFormat15);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("PieSection: 52, -16698368(8)", "Other", "RectangleAnchor.CENTER", "TableOrder.BY_COLUMN", "rect");
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = defaultDrawingSupplier8.equals(obj9);
        boolean boolean11 = jFreeChart7.equals((java.lang.Object) defaultDrawingSupplier8);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        double double16 = textTitle13.getWidth();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        float float19 = multiplePiePlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.lang.Object obj31 = null;
        boolean boolean32 = textTitle29.equals(obj31);
        textTitle29.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle29.getBounds();
        multiplePiePlot0.drawBackgroundImage(graphics2D27, rectangle2D35);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity43 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D35, pieDataset37, 0, (int) (short) -1, (java.lang.Comparable) "", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER");
        pieSectionEntity43.setSectionIndex((int) (byte) 100);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        multiplePiePlot4.removeChangeListener(plotChangeListener5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot7);
        multiplePiePlot4.notifyListeners(plotChangeEvent8);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setExpandToFitSpace(true);
        java.lang.Object obj14 = textTitle11.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        double double17 = rectangleInsets15.trimHeight((double) (byte) 100);
        double double18 = rectangleInsets15.getBottom();
        multiplePiePlot4.setInsets(rectangleInsets15, true);
        piePlot1.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = piePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection22);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color16, color17, color18, color19, color20, color21 };
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke stroke26 = null;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray22, paintArray25, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextOutlinePaint();
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str35 = textTitle34.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle34.getMargin();
        multiplePiePlot13.setInsets(rectangleInsets36);
        java.awt.Stroke stroke38 = null;
        multiplePiePlot13.setOutlineStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray41 = new java.awt.Paint[] { color40 };
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Color color43 = java.awt.Color.PINK;
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Color color45 = java.awt.Color.PINK;
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray48 = new java.awt.Paint[] { color42, color43, color44, color45, color46, color47 };
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { color49, color50 };
        java.awt.Stroke stroke52 = null;
        java.awt.Stroke[] strokeArray53 = new java.awt.Stroke[] { stroke52 };
        java.awt.Stroke[] strokeArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray41, paintArray48, paintArray51, strokeArray53, strokeArray54, shapeArray55);
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot13.setOutlineStroke(stroke58);
        boolean boolean60 = blockContainer12.equals((java.lang.Object) stroke58);
        java.lang.String str61 = blockContainer12.getID();
        org.jfree.chart.block.Arrangement arrangement62 = blockContainer12.getArrangement();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintArray48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(strokeArray53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(arrangement62);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = null;
        boolean boolean2 = defaultDrawingSupplier0.equals(obj1);
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        java.lang.Object obj13 = blockContainer12.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart18 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint19 = multiplePiePlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertNotNull(jFreeChart18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.incrementValue(0.0d, comparable3, (java.lang.Comparable) 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.lang.Object obj31 = null;
        boolean boolean32 = textTitle29.equals(obj31);
        textTitle29.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle29.getBounds();
        multiplePiePlot0.drawBackgroundImage(graphics2D27, rectangle2D35);
        java.awt.Paint paint37 = multiplePiePlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, 0.4d, (double) (byte) 100, 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        double double9 = rectangleInsets5.calculateBottomOutset(0.0d);
        double double10 = rectangleInsets5.getBottom();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        double double4 = piePlot3.getLabelGap();
        double double5 = piePlot3.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot3.getLabelPadding();
        boolean boolean7 = piePlot3.getIgnoreZeroValues();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (short) 10, (int) '#', 8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        java.lang.Object obj16 = null;
        boolean boolean17 = textTitle14.equals(obj16);
        textTitle14.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = textTitle14.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment20, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement23);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color26 };
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] { color28, color29, color30, color31, color32, color33 };
        java.awt.Color color35 = java.awt.Color.PINK;
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray37 = new java.awt.Paint[] { color35, color36 };
        java.awt.Stroke stroke38 = null;
        java.awt.Stroke[] strokeArray39 = new java.awt.Stroke[] { stroke38 };
        java.awt.Stroke[] strokeArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray41 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray27, paintArray34, paintArray37, strokeArray39, strokeArray40, shapeArray41);
        java.awt.Paint paint43 = defaultDrawingSupplier42.getNextOutlinePaint();
        multiplePiePlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier42);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str47 = textTitle46.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = textTitle46.getMargin();
        multiplePiePlot25.setInsets(rectangleInsets48);
        java.awt.Stroke stroke50 = null;
        multiplePiePlot25.setOutlineStroke(stroke50);
        java.awt.Color color52 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray53 = new java.awt.Paint[] { color52 };
        java.awt.Color color54 = java.awt.Color.PINK;
        java.awt.Color color55 = java.awt.Color.PINK;
        java.awt.Color color56 = java.awt.Color.PINK;
        java.awt.Color color57 = java.awt.Color.PINK;
        java.awt.Color color58 = java.awt.Color.PINK;
        java.awt.Color color59 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray60 = new java.awt.Paint[] { color54, color55, color56, color57, color58, color59 };
        java.awt.Color color61 = java.awt.Color.PINK;
        java.awt.Color color62 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray63 = new java.awt.Paint[] { color61, color62 };
        java.awt.Stroke stroke64 = null;
        java.awt.Stroke[] strokeArray65 = new java.awt.Stroke[] { stroke64 };
        java.awt.Stroke[] strokeArray66 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray67 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier68 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray53, paintArray60, paintArray63, strokeArray65, strokeArray66, shapeArray67);
        multiplePiePlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier68);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot25.setOutlineStroke(stroke70);
        boolean boolean72 = blockContainer24.equals((java.lang.Object) stroke70);
        org.jfree.chart.title.TextTitle textTitle74 = new org.jfree.chart.title.TextTitle("");
        textTitle74.setExpandToFitSpace(true);
        java.lang.Object obj77 = textTitle74.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = textTitle74.getMargin();
        double double80 = rectangleInsets78.trimHeight((double) 100.0f);
        double double82 = rectangleInsets78.calculateBottomInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder83 = new org.jfree.chart.block.LineBorder((java.awt.Paint) chartColor11, stroke70, rectangleInsets78);
        piePlot3.setLabelLinkStroke(stroke70);
        piePlot0.setLabelLinkStroke(stroke70);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(shapeArray41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paintArray53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(paintArray60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(paintArray63);
        org.junit.Assert.assertNotNull(strokeArray65);
        org.junit.Assert.assertNotNull(strokeArray66);
        org.junit.Assert.assertNotNull(shapeArray67);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(obj77);
        org.junit.Assert.assertNotNull(rectangleInsets78);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 100.0d + "'", double80 == 100.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Other", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Color color2 = java.awt.Color.PINK;
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color2, color3, color4, color5, color6, color7 };
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color9, color10 };
        java.awt.Stroke stroke12 = null;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray8, paintArray11, strokeArray13, strokeArray14, shapeArray15);
        try {
            java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor1.sort();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        java.awt.Color color6 = java.awt.Color.gray;
        textTitle1.setBackgroundPaint((java.awt.Paint) color6);
        int int8 = color6.getBlue();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Font font5 = textTitle1.getFont();
        double double6 = textTitle1.getContentXOffset();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) 10.0f);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset4, (java.lang.Comparable) 0.025d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Image image8 = jFreeChart3.getBackgroundImage();
        jFreeChart3.setBackgroundImageAlpha((float) '4');
        jFreeChart3.setNotify(false);
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart3.createBufferedImage((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=255,b=255]", font6);
        textTitle7.setID("{0}");
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getLabelGap();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        multiplePiePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot7);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle11.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor16 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int17 = chartColor16.getRGB();
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = chartColor16.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        legendTitle11.setBackgroundPaint((java.awt.Paint) chartColor16);
        piePlot6.setBaseSectionPaint((java.awt.Paint) chartColor16);
        piePlot2.setLabelBackgroundPaint((java.awt.Paint) chartColor16);
        piePlot2.setLabelLinksVisible(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16698368) + "'", int17 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext23);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (short) 1);
        java.lang.String str3 = color2.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=0,b=1]" + "'", str3.equals("java.awt.Color[r=0,g=0,b=1]"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot0.setBaseSectionPaint((java.awt.Paint) color3);
        int int5 = piePlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        java.awt.Paint paint8 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart3.setBackgroundPaint(paint8);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot10 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setMargin((double) (short) 1, (double) (byte) 10, 0.0d, (double) 10.0f);
        textTitle1.setID("HorizontalAlignment.CENTER");
        java.awt.Graphics2D graphics2D12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = textTitle1.arrange(graphics2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        double double3 = rectangleInsets2.getLeft();
        double double5 = rectangleInsets2.calculateRightInset(0.0d);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.event.ChartChangeListener chartChangeListener4 = null;
        try {
            jFreeChart3.addChangeListener(chartChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.lang.Object obj5 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset15, (java.lang.Comparable) '#');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle19.getMargin();
        boolean boolean22 = standardPieSectionLabelGenerator0.equals((java.lang.Object) textTitle19);
        java.lang.Object obj23 = standardPieSectionLabelGenerator0.clone();
        java.text.AttributedString attributedString25 = standardPieSectionLabelGenerator0.getAttributedLabel(0);
        java.text.NumberFormat numberFormat26 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        try {
            java.text.AttributedString attributedString29 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset27, (java.lang.Comparable) "VerticalAlignment.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(attributedString25);
        org.junit.Assert.assertNotNull(numberFormat26);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset15, (java.lang.Comparable) '#');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle19.getMargin();
        boolean boolean22 = standardPieSectionLabelGenerator0.equals((java.lang.Object) textTitle19);
        java.lang.String str23 = textTitle19.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation2);
        java.lang.Object obj4 = piePlot1.clone();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        pieLabelDistributor1.sort();
        pieLabelDistributor1.clear();
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        java.awt.Paint paint6 = textTitle1.getBackgroundPaint();
        java.lang.Object obj7 = textTitle1.clone();
        textTitle1.setNotify(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        boolean boolean14 = blockContainer12.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        java.lang.String str15 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0}" + "'", str15.equals("{0}"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Rotation.CLOCKWISE");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        boolean boolean19 = blockContainer12.equals((java.lang.Object) textTitle14);
        java.lang.Object obj20 = blockContainer12.clone();
        blockContainer12.clear();
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color22 };
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color24, color25, color26, color27, color28, color29 };
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color31, color32 };
        java.awt.Stroke stroke34 = null;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] { stroke34 };
        java.awt.Stroke[] strokeArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray30, paintArray33, strokeArray35, strokeArray36, shapeArray37);
        java.awt.Color color39 = java.awt.Color.GRAY;
        float[] floatArray40 = null;
        float[] floatArray41 = color39.getRGBColorComponents(floatArray40);
        java.awt.Color color42 = java.awt.Color.white;
        java.awt.Color color43 = java.awt.Color.YELLOW;
        java.awt.Color color44 = java.awt.Color.WHITE;
        java.awt.Paint paint45 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray47 = new java.awt.Paint[] { color39, color42, color43, color44, paint45, color46 };
        java.awt.Stroke[] strokeArray48 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray49 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray47, strokeArray48, strokeArray49, shapeArray50);
        boolean boolean52 = blockContainer12.equals((java.lang.Object) strokeArray49);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(paintArray47);
        org.junit.Assert.assertNotNull(strokeArray48);
        org.junit.Assert.assertNotNull(strokeArray49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Other", "", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "rect");
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        int int4 = piePlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.lang.Object obj2 = objectList0.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.plot.Plot plot6 = multiplePiePlot4.getParent();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        objectList0.set(100, (java.lang.Object) multiplePiePlot4);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(jFreeChart7);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        float float8 = jFreeChart3.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        textTitle1.setURLText("TableOrder.BY_COLUMN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("PieSection: 52, 52(8)", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int7 = color6.getAlpha();
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Color color12 = java.awt.Color.blue;
        piePlot11.setBaseSectionOutlinePaint((java.awt.Paint) color12);
        piePlot11.setMaximumLabelWidth(100.0d);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot11.setBaseSectionPaint((java.awt.Paint) color16);
        double double18 = piePlot11.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setExpandToFitSpace(true);
        java.lang.Object obj24 = textTitle21.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle21.getMargin();
        double double27 = rectangleInsets25.trimHeight((double) (byte) 100);
        double double28 = rectangleInsets25.getBottom();
        double double30 = rectangleInsets25.calculateTopInset((double) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        multiplePiePlot31.removeChangeListener(plotChangeListener32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent35 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot34);
        multiplePiePlot31.notifyListeners(plotChangeEvent35);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        textTitle38.setExpandToFitSpace(true);
        java.lang.Object obj41 = textTitle38.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle38.getMargin();
        double double44 = rectangleInsets42.trimHeight((double) (byte) 100);
        double double45 = rectangleInsets42.getBottom();
        multiplePiePlot31.setInsets(rectangleInsets42, true);
        double double49 = rectangleInsets42.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str52 = textTitle51.getText();
        java.lang.Object obj53 = null;
        boolean boolean54 = textTitle51.equals(obj53);
        textTitle51.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D57 = textTitle51.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets42.createAdjustedRectangle(rectangle2D57, lengthAdjustmentType58, lengthAdjustmentType59);
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets25.createInsetRectangle(rectangle2D57, false, true);
        piePlot11.drawBackgroundImage(graphics2D19, rectangle2D57);
        try {
            piePlot0.drawOutline(graphics2D9, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 32.0d + "'", double49 == 32.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("java.awt.Color[r=128,g=255,b=255]");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        java.lang.String str7 = unknownKeyException5.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]" + "'", str2.equals("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str7.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setExpandToFitSpace(true);
        double double5 = textTitle2.getWidth();
        java.awt.Paint paint6 = textTitle2.getBackgroundPaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.lang.Object obj10 = textTitle2.draw(graphics2D7, rectangle2D8, (java.lang.Object) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle2.getPosition();
        java.awt.Font font12 = textTitle2.getFont();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("VerticalAlignment.TOP", font12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle13.arrange(graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        objectList0.clear();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle1.getPadding();
        double double9 = rectangleInsets7.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.lang.Object obj13 = null;
        boolean boolean14 = textTitle11.equals(obj13);
        textTitle11.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets7.createInsetRectangle(rectangle2D17, false, false);
        double double22 = rectangleInsets7.calculateBottomOutset((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        java.util.List list4 = defaultKeyedValues2D1.getColumnKeys();
        int int5 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        int int13 = pieSectionEntity7.getPieIndex();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity21 = new org.jfree.chart.entity.PieSectionEntity(shape14, pieDataset15, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        pieSectionEntity7.setArea(shape14);
        int int23 = pieSectionEntity7.getPieIndex();
        java.lang.Object obj24 = pieSectionEntity7.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        boolean boolean6 = piePlot1.isSubplot();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int15 = chartColor14.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor14);
        piePlot1.setLabelOutlinePaint((java.awt.Paint) chartColor14);
        boolean boolean18 = piePlot1.getIgnoreZeroValues();
        boolean boolean19 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint20 = null;
        try {
            piePlot1.setLabelPaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16698368) + "'", int15 == (-16698368));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setURLGenerator(pieURLGenerator1);
        double double3 = piePlot0.getLabelGap();
        try {
            piePlot0.setBackgroundImageAlpha(100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        int int8 = pieSectionEntity7.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart3.getLegend(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(legendTitle9);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        double double8 = rectangleInsets5.getBottom();
        double double10 = rectangleInsets5.calculateLeftInset((double) 0.5f);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue(comparable1, (java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Color color1 = java.awt.Color.getColor("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle5.getMargin();
        java.awt.Paint paint8 = textTitle5.getPaint();
        jFreeChart3.setTitle(textTitle5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart3.getPadding();
        boolean boolean11 = jFreeChart3.isBorderVisible();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle1.getFrame();
        textTitle1.setID("VerticalAlignment.TOP");
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        double double7 = rectangleInsets5.trimHeight((double) (byte) 100);
        double double8 = rectangleInsets5.getTop();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color13, color14, color15, color16, color17 };
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color19, color20 };
        java.awt.Stroke stroke22 = null;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke22 };
        java.awt.Stroke[] strokeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray25 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, paintArray21, strokeArray23, strokeArray24, shapeArray25);
        java.awt.Paint paint27 = defaultDrawingSupplier26.getNextOutlinePaint();
        multiplePiePlot9.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = textTitle30.getMargin();
        multiplePiePlot9.setInsets(rectangleInsets32);
        java.awt.Color color37 = java.awt.Color.getHSBColor((float) (byte) 100, (float) 1L, 1.0f);
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str42 = textTitle41.getText();
        java.lang.Object obj43 = null;
        boolean boolean44 = textTitle41.equals(obj43);
        textTitle41.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle41.getBounds();
        java.awt.geom.AffineTransform affineTransform48 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener50 = null;
        multiplePiePlot49.removeChangeListener(plotChangeListener50);
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot49);
        java.awt.Image image53 = jFreeChart52.getBackgroundImage();
        jFreeChart52.removeLegend();
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("");
        textTitle56.setExpandToFitSpace(true);
        double double59 = textTitle56.getWidth();
        java.awt.Paint paint60 = textTitle56.getBackgroundPaint();
        double double61 = textTitle56.getContentYOffset();
        jFreeChart52.removeSubtitle((org.jfree.chart.title.Title) textTitle56);
        java.awt.RenderingHints renderingHints63 = jFreeChart52.getRenderingHints();
        java.awt.PaintContext paintContext64 = color37.createContext(colorModel38, rectangle39, rectangle2D47, affineTransform48, renderingHints63);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets32.createInsetRectangle(rectangle2D47, false, true);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets5.createOutsetRectangle(rectangle2D47, false, false);
        double double72 = rectangleInsets5.calculateTopOutset(0.14d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shapeArray25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNull(image53);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNull(paint60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
        org.junit.Assert.assertNotNull(renderingHints63);
        org.junit.Assert.assertNotNull(paintContext64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0.5f);
        try {
            java.lang.Number number5 = defaultKeyedValues2D0.getValue((int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.5f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        java.lang.Object obj9 = pieSectionEntity7.clone();
        pieSectionEntity7.setSectionIndex((-16777216));
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        boolean boolean5 = jFreeChart3.getAntiAlias();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage((int) (byte) -1, (int) '#', (double) 'a', (double) ' ', chartRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (35) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        piePlot0.markerChanged(markerChangeEvent5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.lang.Object obj11 = null;
        boolean boolean12 = textTitle9.equals(obj11);
        textTitle9.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle9.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment15, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str21 = horizontalAlignment20.toString();
        java.lang.String str22 = horizontalAlignment20.toString();
        java.lang.String str23 = horizontalAlignment20.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment20, verticalAlignment24, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setExpandToFitSpace(true);
        java.lang.Object obj32 = textTitle29.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj34 = null;
        boolean boolean35 = defaultDrawingSupplier33.equals(obj34);
        columnArrangement27.add((org.jfree.chart.block.Block) textTitle29, (java.lang.Object) defaultDrawingSupplier33);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement18, (org.jfree.chart.block.Arrangement) columnArrangement27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "HorizontalAlignment.CENTER" + "'", str21.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "HorizontalAlignment.CENTER" + "'", str22.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "HorizontalAlignment.CENTER" + "'", str23.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Other", "PieSection: 52, 52(8)", "Other", "VerticalAlignment.CENTER");
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        double double12 = textTitle9.getWidth();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        textTitle15.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle15);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int27 = chartColor26.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor26);
        java.awt.Color color29 = chartColor26.brighter();
        textTitle15.setPaint((java.awt.Paint) color29);
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16698368) + "'", int27 == (-16698368));
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setExpandToFitSpace(true);
        java.lang.Object obj9 = textTitle6.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle6.getMargin();
        double double12 = rectangleInsets10.trimHeight((double) (byte) 100);
        double double13 = rectangleInsets10.getBottom();
        double double15 = rectangleInsets10.calculateTopInset((double) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        multiplePiePlot16.removeChangeListener(plotChangeListener17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot19);
        multiplePiePlot16.notifyListeners(plotChangeEvent20);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        textTitle23.setExpandToFitSpace(true);
        java.lang.Object obj26 = textTitle23.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle23.getMargin();
        double double29 = rectangleInsets27.trimHeight((double) (byte) 100);
        double double30 = rectangleInsets27.getBottom();
        multiplePiePlot16.setInsets(rectangleInsets27, true);
        double double34 = rectangleInsets27.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.lang.Object obj38 = null;
        boolean boolean39 = textTitle36.equals(obj38);
        textTitle36.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle36.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets27.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType43, lengthAdjustmentType44);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets10.createInsetRectangle(rectangle2D42, false, true);
        textTitle1.draw(graphics2D4, rectangle2D42);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 32.0d + "'", double34 == 32.0d);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        boolean boolean6 = piePlot1.isSubplot();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int15 = chartColor14.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor14);
        piePlot1.setLabelOutlinePaint((java.awt.Paint) chartColor14);
        double double18 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16698368) + "'", int15 == (-16698368));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 90.0d + "'", double18 == 90.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.clear();
        java.lang.Comparable comparable5 = null;
        try {
            defaultCategoryDataset0.setValue(4.0d, (java.lang.Comparable) 0.0f, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int10 = chartColor9.getRGB();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = chartColor9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        legendTitle4.setBackgroundPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle4.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle4.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor21);
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int31 = chartColor30.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor30);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = blockBorder32.getInsets();
        java.awt.Paint paint34 = blockBorder32.getPaint();
        legendTitle4.setBackgroundPaint(paint34);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16698368) + "'", int10 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-16698368) + "'", int31 == (-16698368));
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1L, 0.5f, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle1.getMargin();
        boolean boolean6 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color10, color11, color12, color13, color14, color15 };
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color17, color18 };
        java.awt.Stroke stroke20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray23 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray16, paintArray19, strokeArray21, strokeArray22, shapeArray23);
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        multiplePiePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle28.getMargin();
        multiplePiePlot7.setInsets(rectangleInsets30);
        java.awt.Stroke stroke32 = null;
        multiplePiePlot7.setOutlineStroke(stroke32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.lang.Object obj38 = null;
        boolean boolean39 = textTitle36.equals(obj38);
        textTitle36.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle36.getBounds();
        multiplePiePlot7.drawBackgroundImage(graphics2D34, rectangle2D42);
        textTitle1.setBounds(rectangle2D42);
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42, "Other");
        chartEntity46.setToolTipText("RectangleAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        double double4 = multiplePiePlot0.getLimit();
        java.awt.Font font5 = multiplePiePlot0.getNoDataMessageFont();
        java.lang.Comparable comparable6 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setBackgroundAlpha((float) (-1L));
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "Other" + "'", comparable6.equals("Other"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.lang.Object obj12 = null;
        boolean boolean13 = textTitle10.equals(obj12);
        textTitle10.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle10.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment16, (-1.0d), (double) 0.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.lang.Object obj24 = null;
        boolean boolean25 = textTitle22.equals(obj24);
        textTitle22.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = textTitle22.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment28, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.chart.block.Arrangement) flowArrangement31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        multiplePiePlot34.removeChangeListener(plotChangeListener35);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot34);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj39 = null;
        boolean boolean40 = defaultDrawingSupplier38.equals(obj39);
        boolean boolean41 = jFreeChart37.equals((java.lang.Object) defaultDrawingSupplier38);
        boolean boolean42 = jFreeChart37.isNotify();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) flowArrangement19, jFreeChart37);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        jFreeChart3.removeLegend();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        double double10 = textTitle7.getWidth();
        java.awt.Paint paint11 = textTitle7.getBackgroundPaint();
        double double12 = textTitle7.getContentYOffset();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle7);
        int int14 = jFreeChart3.getBackgroundImageAlignment();
        jFreeChart3.setAntiAlias(true);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 1, (java.lang.Comparable) "-4,-4,4,4");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -4,-4,4,4");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Stroke stroke4 = null;
        jFreeChart3.setBorderStroke(stroke4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage(128, 0, 108.0d, 0.0d, chartRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (128) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getLabelPadding();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot0.getLabelLinkStyle();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot0.setURLGenerator(pieURLGenerator5);
        java.lang.Comparable comparable7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        java.lang.Object obj12 = textTitle9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getMargin();
        java.awt.Color color14 = java.awt.Color.gray;
        textTitle9.setBackgroundPaint((java.awt.Paint) color14);
        try {
            piePlot0.setSectionOutlinePaint(comparable7, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        double double9 = piePlot1.getShadowYOffset();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle12.getMargin();
        java.lang.String str15 = textTitle12.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle12.getMargin();
        boolean boolean17 = textTitle12.getExpandToFitSpace();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color19 };
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Color color26 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color21, color22, color23, color24, color25, color26 };
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color28, color29 };
        java.awt.Stroke stroke31 = null;
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Stroke[] strokeArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray20, paintArray27, paintArray30, strokeArray32, strokeArray33, shapeArray34);
        java.awt.Paint paint36 = defaultDrawingSupplier35.getNextOutlinePaint();
        multiplePiePlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str40 = textTitle39.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = textTitle39.getMargin();
        multiplePiePlot18.setInsets(rectangleInsets41);
        java.awt.Stroke stroke43 = null;
        multiplePiePlot18.setOutlineStroke(stroke43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str48 = textTitle47.getText();
        java.lang.Object obj49 = null;
        boolean boolean50 = textTitle47.equals(obj49);
        textTitle47.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle47.getBounds();
        multiplePiePlot18.drawBackgroundImage(graphics2D45, rectangle2D53);
        textTitle12.setBounds(rectangle2D53);
        org.jfree.data.general.PieDataset pieDataset56 = null;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot(pieDataset56);
        java.awt.Color color58 = java.awt.Color.blue;
        piePlot57.setBaseSectionOutlinePaint((java.awt.Paint) color58);
        piePlot57.setMaximumLabelWidth(100.0d);
        java.awt.Paint paint63 = piePlot57.getSectionPaint((java.lang.Comparable) (-1L));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        org.jfree.chart.plot.PiePlotState piePlotState66 = piePlot1.initialise(graphics2D10, rectangle2D53, piePlot57, (java.lang.Integer) 2, plotRenderingInfo65);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNotNull(piePlotState66);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.lang.Object obj31 = null;
        boolean boolean32 = textTitle29.equals(obj31);
        textTitle29.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle29.getBounds();
        multiplePiePlot0.drawBackgroundImage(graphics2D27, rectangle2D35);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity43 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D35, pieDataset37, 0, (int) (short) -1, (java.lang.Comparable) "", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER");
        java.lang.String str44 = pieSectionEntity43.getShapeType();
        pieSectionEntity43.setSectionIndex(128);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "rect" + "'", str44.equals("rect"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart3.getTitle();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int9 = chartColor8.getRGB();
        jFreeChart3.setBackgroundPaint((java.awt.Paint) chartColor8);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getLabelGap();
        double double13 = piePlot11.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot11.getLabelPadding();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        piePlot11.setLegendLabelURLGenerator(pieURLGenerator15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot11);
        java.lang.Object obj18 = plotChangeEvent17.getSource();
        jFreeChart3.plotChanged(plotChangeEvent17);
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        boolean boolean22 = paintMap20.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Color color24 = java.awt.Color.cyan;
        paintMap20.put((java.lang.Comparable) (short) 0, (java.awt.Paint) color24);
        java.awt.Paint paint27 = paintMap20.getPaint((java.lang.Comparable) 0.08d);
        org.jfree.chart.ChartColor chartColor32 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        paintMap20.put((java.lang.Comparable) (-1.0f), (java.awt.Paint) chartColor32);
        try {
            jFreeChart3.setTextAntiAlias((java.lang.Object) chartColor32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.ChartColor[r=1,g=52,b=0] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(textTitle4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16698368) + "'", int9 == (-16698368));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        java.awt.Font font4 = multiplePiePlot0.getNoDataMessageFont();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(2);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int11 = chartColor10.getRGB();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = chartColor10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor10);
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) chartColor10);
        org.jfree.chart.util.TableOrder tableOrder20 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder20);
        java.lang.String str22 = tableOrder20.toString();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16698368) + "'", int11 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(tableOrder20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TableOrder.BY_COLUMN" + "'", str22.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        java.awt.Paint paint2 = null;
        multiplePiePlot0.setOutlinePaint(paint2);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "HorizontalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        multiplePiePlot0.setDataset(categoryDataset6);
        org.jfree.chart.JFreeChart jFreeChart8 = multiplePiePlot0.getPieChart();
        java.lang.Comparable comparable9 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(jFreeChart8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "HorizontalAlignment.CENTER" + "'", comparable9.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int11 = chartColor10.getRGB();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = chartColor10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.block.BlockContainer blockContainer19 = legendTitle5.getItemContainer();
        boolean boolean20 = objectList0.equals((java.lang.Object) legendTitle5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle5.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendTitle5.getLegendItemGraphicLocation();
        double double23 = legendTitle5.getHeight();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16698368) + "'", int11 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(blockContainer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int11 = chartColor10.getRGB();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = chartColor10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.block.BlockContainer blockContainer19 = legendTitle5.getItemContainer();
        boolean boolean20 = objectList0.equals((java.lang.Object) legendTitle5);
        java.awt.Color color24 = java.awt.Color.getColor("{0}", (int) (short) 10);
        objectList0.set((int) (short) 10, (java.lang.Object) "{0}");
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16698368) + "'", int11 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(blockContainer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.util.List list2 = defaultCategoryDataset0.getColumnKeys();
        java.lang.Object obj3 = defaultCategoryDataset0.clone();
        int int5 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 8);
        try {
            java.lang.Comparable comparable7 = defaultCategoryDataset0.getColumnKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        boolean boolean8 = jFreeChart3.isNotify();
        java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage(128, (int) (short) 1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str13 = horizontalAlignment12.toString();
        java.lang.String str14 = horizontalAlignment12.toString();
        java.lang.String str15 = horizontalAlignment12.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment16, (double) 100, (double) (byte) 1);
        try {
            jFreeChart3.setTextAntiAlias((java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 100 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(bufferedImage11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "HorizontalAlignment.CENTER" + "'", str13.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "HorizontalAlignment.CENTER" + "'", str14.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "HorizontalAlignment.CENTER" + "'", str15.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment16);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset1.getGroup();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        multiplePiePlot3.removeChangeListener(plotChangeListener4);
        defaultCategoryDataset1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot3);
        org.jfree.data.general.DatasetGroup datasetGroup7 = multiplePiePlot3.getDatasetGroup();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: hi!", (org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNull(datasetGroup7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        piePlot1.setLabelLinksVisible(true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        java.lang.Object obj16 = null;
        boolean boolean17 = textTitle14.equals(obj16);
        textTitle14.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = textTitle14.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment20, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement23);
        boolean boolean25 = standardPieSectionLabelGenerator11.equals((java.lang.Object) flowArrangement23);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        java.lang.String str28 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset26, (java.lang.Comparable) '#');
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = textTitle30.getMargin();
        boolean boolean33 = standardPieSectionLabelGenerator11.equals((java.lang.Object) textTitle30);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        java.lang.String str37 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset35, (java.lang.Comparable) 52.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.lang.Object obj31 = null;
        boolean boolean32 = textTitle29.equals(obj31);
        textTitle29.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle29.getBounds();
        multiplePiePlot0.drawBackgroundImage(graphics2D27, rectangle2D35);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity43 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D35, pieDataset37, 0, (int) (short) -1, (java.lang.Comparable) "", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER");
        java.awt.Shape shape44 = pieSectionEntity43.getArea();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape44);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.util.List list1 = projectInfo0.getContributors();
//        java.lang.String str2 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(list1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: {0}" + "'", str2.equals("org.jfree.data.UnknownKeyException: {0}"));
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) 15, (java.lang.Comparable) 108.0d, (java.lang.Comparable) (-16698368));
        defaultCategoryDataset0.removeRow((int) (short) 0);
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle1.draw(graphics2D5, rectangle2D6);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.title.Title title9 = titleChangeEvent8.getTitle();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(title9);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            piePlot1.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color27 };
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color29, color30, color31, color32, color33, color34 };
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color36, color37 };
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray35, paintArray38, strokeArray40, strokeArray41, shapeArray42);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        java.awt.Paint paint45 = defaultDrawingSupplier43.getNextFillPaint();
        java.lang.Object obj46 = defaultDrawingSupplier43.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        java.awt.Shape shape13 = pieSectionEntity7.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape13, "");
        java.lang.String str16 = chartEntity15.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.lang.Object obj3 = piePlot1.clone();
        piePlot1.setLabelGap(0.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 15);
        java.lang.String str11 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 52, 52(8)" + "'", str8.equals("PieSection: 52, 52(8)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: 52, 52(15)" + "'", str11.equals("PieSection: 52, 52(15)"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot2.removeChangeListener(plotChangeListener3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int12 = chartColor11.getRGB();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = chartColor11.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        legendTitle6.setBackgroundPaint((java.awt.Paint) chartColor11);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = null;
        piePlot21.setURLGenerator(pieURLGenerator22);
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        piePlot21.setLabelPaint((java.awt.Paint) chartColor27);
        java.awt.Paint paint29 = piePlot21.getLabelShadowPaint();
        piePlot1.setShadowPaint(paint29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str32 = color31.toString();
        piePlot1.setLabelShadowPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16698368) + "'", int12 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str32.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo1.getOptionalLibraries();
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo4.getOptionalLibraries();
        projectInfo4.setInfo("hi!");
        java.lang.String str8 = projectInfo4.getName();
        java.lang.String str9 = projectInfo4.getLicenceText();
        projectInfo4.setVersion("org.jfree.data.UnknownKeyException: {0}");
        projectInfo4.setInfo("");
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo4);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Other", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo1.getOptionalLibraries();
//        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        java.lang.String str4 = projectInfo1.getCopyright();
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str4.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color0 = java.awt.Color.CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        multiplePiePlot1.setOutlineVisible(false);
        java.lang.Object obj5 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = multiplePiePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        jFreeChart3.setBorderVisible(true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        java.awt.Color color4 = java.awt.Color.pink;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        java.lang.String str3 = horizontalAlignment0.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment4, (double) 100, (double) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        java.lang.Object obj12 = textTitle9.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj14 = null;
        boolean boolean15 = defaultDrawingSupplier13.equals(obj14);
        columnArrangement7.add((org.jfree.chart.block.Block) textTitle9, (java.lang.Object) defaultDrawingSupplier13);
        java.awt.Stroke stroke17 = defaultDrawingSupplier13.getNextStroke();
        java.awt.Shape shape18 = defaultDrawingSupplier13.getNextShape();
        java.awt.Paint paint19 = defaultDrawingSupplier13.getNextFillPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        java.awt.Stroke stroke3 = strokeMap0.getStroke((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        float float10 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        textTitle12.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent15.setType(chartChangeEventType16);
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        titleChangeEvent15.setChart(jFreeChart18);
        jFreeChart3.titleChanged(titleChangeEvent15);
        jFreeChart3.setTitle("RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        java.awt.Paint paint11 = blockBorder9.getPaint();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setExpandToFitSpace(true);
        java.lang.Object obj17 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle14.getMargin();
        double double20 = rectangleInsets18.trimHeight((double) 100.0f);
        double double22 = rectangleInsets18.calculateTopOutset((double) 0L);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setExpandToFitSpace(true);
        double double27 = textTitle24.getWidth();
        java.awt.Paint paint28 = textTitle24.getBackgroundPaint();
        double double29 = textTitle24.getContentYOffset();
        double double30 = textTitle24.getContentYOffset();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets18.createInsetRectangle(rectangle2D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double34 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D32, rectangleEdge33);
        try {
            blockBorder9.draw(graphics2D12, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("org.jfree.data.UnknownKeyException: hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        flowArrangement11.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot0.getParent();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str6 = textTitle5.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle5.getMargin();
        java.awt.Paint paint8 = textTitle5.getPaint();
        jFreeChart3.setTitle(textTitle5);
        java.awt.Image image10 = null;
        jFreeChart3.setBackgroundImage(image10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart3.createBufferedImage(0, 10, (double) 100.0f, 10.0d, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj16 = null;
        boolean boolean17 = defaultDrawingSupplier15.equals(obj16);
        boolean boolean18 = jFreeChart14.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart14.setBackgroundPaint(paint19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart14, chartChangeEventType26);
        org.jfree.chart.JFreeChart jFreeChart29 = chartChangeEvent28.getChart();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        textTitle32.setExpandToFitSpace(true);
        double double35 = textTitle32.getWidth();
        java.awt.Paint paint36 = textTitle32.getBackgroundPaint();
        double double37 = textTitle32.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = textTitle32.getPadding();
        double double40 = rectangleInsets38.calculateLeftOutset((double) 10.0f);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str43 = textTitle42.getText();
        java.lang.Object obj44 = null;
        boolean boolean45 = textTitle42.equals(obj44);
        textTitle42.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D48 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets38.createInsetRectangle(rectangle2D48, false, false);
        try {
            jFreeChart29.draw(graphics2D30, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertNotNull(jFreeChart29);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = legendTitle4.getVerticalAlignment();
        java.awt.Paint paint7 = legendTitle4.getBackgroundPaint();
        java.awt.Paint paint8 = legendTitle4.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = null;
        boolean boolean6 = defaultDrawingSupplier4.equals(obj5);
        boolean boolean7 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier4);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        double double12 = textTitle9.getWidth();
        jFreeChart3.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        textTitle16.setExpandToFitSpace(true);
        java.lang.Object obj19 = textTitle16.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle16.getMargin();
        double double22 = rectangleInsets20.trimHeight((double) 100.0f);
        double double24 = rectangleInsets20.calculateTopOutset((double) 0L);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        textTitle26.setExpandToFitSpace(true);
        double double29 = textTitle26.getWidth();
        java.awt.Paint paint30 = textTitle26.getBackgroundPaint();
        double double31 = textTitle26.getContentYOffset();
        double double32 = textTitle26.getContentYOffset();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets20.createInsetRectangle(rectangle2D33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double36 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D34, rectangleEdge35);
        java.awt.geom.Point2D point2D37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        try {
            jFreeChart3.draw(graphics2D14, rectangle2D34, point2D37, chartRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        double double12 = rectangleInsets10.calculateTopInset((double) 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Multiple Pie Plot", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        textTitle1.setPadding((double) 'a', (double) 2, 10.0d, 0.0d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        try {
            org.jfree.chart.title.Title title18 = jFreeChart14.getSubtitle(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNull(textTitle15);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.data.UnknownKeyException: hi!");
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = piePlot1.getLabelLinkStyle();
        boolean boolean5 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint6 = piePlot1.getOutlinePaint();
        boolean boolean7 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle2.equals(obj4);
        textTitle2.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment8, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.Color color17 = java.awt.Color.PINK;
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Color color19 = java.awt.Color.PINK;
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color16, color17, color18, color19, color20, color21 };
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke stroke26 = null;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray22, paintArray25, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextOutlinePaint();
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str35 = textTitle34.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle34.getMargin();
        multiplePiePlot13.setInsets(rectangleInsets36);
        java.awt.Stroke stroke38 = null;
        multiplePiePlot13.setOutlineStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray41 = new java.awt.Paint[] { color40 };
        java.awt.Color color42 = java.awt.Color.PINK;
        java.awt.Color color43 = java.awt.Color.PINK;
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Color color45 = java.awt.Color.PINK;
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray48 = new java.awt.Paint[] { color42, color43, color44, color45, color46, color47 };
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { color49, color50 };
        java.awt.Stroke stroke52 = null;
        java.awt.Stroke[] strokeArray53 = new java.awt.Stroke[] { stroke52 };
        java.awt.Stroke[] strokeArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray41, paintArray48, paintArray51, strokeArray53, strokeArray54, shapeArray55);
        multiplePiePlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot13.setOutlineStroke(stroke58);
        boolean boolean60 = blockContainer12.equals((java.lang.Object) stroke58);
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str63 = textTitle62.getText();
        java.lang.Object obj64 = null;
        boolean boolean65 = textTitle62.equals(obj64);
        textTitle62.setHeight((double) 2);
        double double68 = textTitle62.getContentXOffset();
        blockContainer12.add((org.jfree.chart.block.Block) textTitle62, (java.lang.Object) "PieSection: 52, 52(8)");
        java.lang.Object obj71 = blockContainer12.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintArray48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(strokeArray53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertNotNull(obj71);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Color color3 = java.awt.Color.PINK;
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color3, color4, color5, color6, color7, color8 };
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color10, color11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, paintArray12, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle21.getMargin();
        multiplePiePlot0.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = null;
        multiplePiePlot0.setOutlineStroke(stroke25);
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color27 };
        java.awt.Color color29 = java.awt.Color.PINK;
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = java.awt.Color.PINK;
        java.awt.Color color32 = java.awt.Color.PINK;
        java.awt.Color color33 = java.awt.Color.PINK;
        java.awt.Color color34 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color29, color30, color31, color32, color33, color34 };
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color36, color37 };
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray35, paintArray38, strokeArray40, strokeArray41, shapeArray42);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        java.lang.Class<?> wildcardClass45 = multiplePiePlot0.getClass();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent46);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.TOP", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "org.jfree.data.UnknownKeyException: hi!", "", "VerticalAlignment.TOP");
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = multiplePiePlot0.getInsets();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo4.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo6.getOptionalLibraries();
        projectInfo6.setInfo("hi!");
        java.lang.String str10 = projectInfo6.getName();
        java.awt.Image image11 = projectInfo6.getLogo();
        projectInfo4.setLogo(image11);
        jFreeChart3.setBackgroundImage(image11);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(image11);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        try {
            java.lang.Object obj5 = jFreeChartResources0.getObject("RectangleAnchor.BOTTOM_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.BOTTOM_RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        boolean boolean9 = jFreeChart3.getAntiAlias();
        java.lang.Class<?> wildcardClass10 = jFreeChart3.getClass();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        double double4 = textTitle1.getWidth();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle1.getPadding();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setExpandToFitSpace(true);
        java.lang.Object obj12 = textTitle9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getMargin();
        double double15 = rectangleInsets13.trimHeight((double) (byte) 100);
        double double16 = rectangleInsets13.getBottom();
        double double18 = rectangleInsets13.calculateTopInset((double) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        multiplePiePlot19.removeChangeListener(plotChangeListener20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot22);
        multiplePiePlot19.notifyListeners(plotChangeEvent23);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        textTitle26.setExpandToFitSpace(true);
        java.lang.Object obj29 = textTitle26.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle26.getMargin();
        double double32 = rectangleInsets30.trimHeight((double) (byte) 100);
        double double33 = rectangleInsets30.getBottom();
        multiplePiePlot19.setInsets(rectangleInsets30, true);
        double double37 = rectangleInsets30.trimHeight((double) ' ');
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str40 = textTitle39.getText();
        java.lang.Object obj41 = null;
        boolean boolean42 = textTitle39.equals(obj41);
        textTitle39.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle39.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets30.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType46, lengthAdjustmentType47);
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets13.createInsetRectangle(rectangle2D45, false, true);
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets7.createInsetRectangle(rectangle2D51, false, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 32.0d + "'", double37 == 32.0d);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.lang.Object obj3 = piePlot1.clone();
        java.awt.Image image4 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) '#', 8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.lang.Object obj8 = null;
        boolean boolean9 = textTitle6.equals(obj8);
        textTitle6.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle6.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment12, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color18 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color18 };
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = java.awt.Color.PINK;
        java.awt.Color color23 = java.awt.Color.PINK;
        java.awt.Color color24 = java.awt.Color.PINK;
        java.awt.Color color25 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color20, color21, color22, color23, color24, color25 };
        java.awt.Color color27 = java.awt.Color.PINK;
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color27, color28 };
        java.awt.Stroke stroke30 = null;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke30 };
        java.awt.Stroke[] strokeArray32 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray26, paintArray29, strokeArray31, strokeArray32, shapeArray33);
        java.awt.Paint paint35 = defaultDrawingSupplier34.getNextOutlinePaint();
        multiplePiePlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str39 = textTitle38.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle38.getMargin();
        multiplePiePlot17.setInsets(rectangleInsets40);
        java.awt.Stroke stroke42 = null;
        multiplePiePlot17.setOutlineStroke(stroke42);
        java.awt.Color color44 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray45 = new java.awt.Paint[] { color44 };
        java.awt.Color color46 = java.awt.Color.PINK;
        java.awt.Color color47 = java.awt.Color.PINK;
        java.awt.Color color48 = java.awt.Color.PINK;
        java.awt.Color color49 = java.awt.Color.PINK;
        java.awt.Color color50 = java.awt.Color.PINK;
        java.awt.Color color51 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray52 = new java.awt.Paint[] { color46, color47, color48, color49, color50, color51 };
        java.awt.Color color53 = java.awt.Color.PINK;
        java.awt.Color color54 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray55 = new java.awt.Paint[] { color53, color54 };
        java.awt.Stroke stroke56 = null;
        java.awt.Stroke[] strokeArray57 = new java.awt.Stroke[] { stroke56 };
        java.awt.Stroke[] strokeArray58 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray45, paintArray52, paintArray55, strokeArray57, strokeArray58, shapeArray59);
        multiplePiePlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        java.awt.Stroke stroke62 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        multiplePiePlot17.setOutlineStroke(stroke62);
        boolean boolean64 = blockContainer16.equals((java.lang.Object) stroke62);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("");
        textTitle66.setExpandToFitSpace(true);
        java.lang.Object obj69 = textTitle66.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = textTitle66.getMargin();
        double double72 = rectangleInsets70.trimHeight((double) 100.0f);
        double double74 = rectangleInsets70.calculateBottomInset(0.0d);
        org.jfree.chart.block.LineBorder lineBorder75 = new org.jfree.chart.block.LineBorder((java.awt.Paint) chartColor3, stroke62, rectangleInsets70);
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = lineBorder75.getInsets();
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D78 = rectangleInsets76.createInsetRectangle(rectangle2D77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(paintArray55);
        org.junit.Assert.assertNotNull(strokeArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 100.0d + "'", double72 == 100.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets76);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(10, attributedString2);
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int11 = chartColor10.getRGB();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = chartColor10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        legendTitle5.setBackgroundPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.block.BlockContainer blockContainer19 = legendTitle5.getItemContainer();
        boolean boolean20 = objectList0.equals((java.lang.Object) legendTitle5);
        java.lang.Object obj21 = legendTitle5.clone();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16698368) + "'", int11 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(blockContainer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        multiplePiePlot3.removeChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultDrawingSupplier7.equals(obj8);
        boolean boolean10 = jFreeChart6.equals((java.lang.Object) defaultDrawingSupplier7);
        boolean boolean11 = jFreeChart6.isNotify();
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart6.createBufferedImage(128, (int) (short) 1);
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("org.jfree.data.UnknownKeyException: java.awt.Color[r=128,g=255,b=255]", "TableOrder.BY_COLUMN", "HorizontalAlignment.CENTER", (java.awt.Image) bufferedImage14, "hi!", "RectangleAnchor.BOTTOM", "RectangleAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(bufferedImage14);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean12 = color10.equals((java.lang.Object) font11);
        java.awt.Color color13 = color10.brighter();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("{0}");
        boolean boolean7 = jFreeChartResources0.containsKey("TableOrder.BY_COLUMN");
        java.util.Enumeration<java.lang.String> strEnumeration8 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strEnumeration8);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("hi!");
        java.lang.String str4 = projectInfo0.getName();
        java.lang.String str5 = projectInfo0.getLicenceText();
        projectInfo0.setCopyright("org.jfree.data.UnknownKeyException: {0}");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        double double2 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        piePlot0.setLabelLinkStyle(pieLabelLinkStyle3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        java.awt.Font font3 = multiplePiePlot0.getNoDataMessageFont();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = multiplePiePlot0.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = multiplePiePlot0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            multiplePiePlot0.setInsets(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Paint paint8 = piePlot1.getLabelOutlinePaint();
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setCircular(false, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle8.equals(obj10);
        textTitle8.setHeight((double) 2);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        try {
            piePlot1.drawOutline(graphics2D6, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getLabelGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        piePlot0.notifyListeners(plotChangeEvent2);
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color4 };
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color6, color7, color8, color9, color10, color11 };
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color13, color14 };
        java.awt.Stroke stroke16 = null;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke16 };
        java.awt.Stroke[] strokeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray19 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray12, paintArray15, strokeArray17, strokeArray18, shapeArray19);
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextOutlinePaint();
        java.awt.Stroke stroke22 = defaultDrawingSupplier20.getNextOutlineStroke();
        piePlot0.setBaseSectionOutlineStroke(stroke22);
        java.awt.Paint paint25 = piePlot0.getSectionPaint((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = chartColor7.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj16 = null;
        boolean boolean17 = defaultDrawingSupplier15.equals(obj16);
        boolean boolean18 = jFreeChart14.equals((java.lang.Object) defaultDrawingSupplier15);
        java.awt.Paint paint19 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart14.setBackgroundPaint(paint19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart14, chartChangeEventType26);
        java.lang.String str29 = chartChangeEventType26.toString();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Color color3 = java.awt.Color.getColor("PieSection: 52, 52(8)", (int) (short) 1);
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean7 = rectangleEdge5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle8.setTextAlignment(horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        java.lang.Object obj16 = textTitle13.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle13.getMargin();
        double double19 = rectangleInsets17.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets17.getUnitType();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color2, rectangleEdge5, horizontalAlignment9, verticalAlignment11, rectangleInsets17);
        double double22 = rectangleInsets17.getTop();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int8 = chartColor7.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor7);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        java.awt.Color color12 = java.awt.Color.orange;
        java.awt.Color color13 = color12.darker();
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Color color15 = java.awt.Color.GRAY;
        float[] floatArray16 = null;
        float[] floatArray17 = color15.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color14.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color12.getRGBColorComponents(floatArray17);
        try {
            float[] floatArray20 = chartColor7.getComponents(colorSpace11, floatArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-16698368) + "'", int8 == (-16698368));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle1.getFrame();
        java.lang.Object obj6 = null;
        boolean boolean7 = textTitle1.equals(obj6);
        org.junit.Assert.assertNotNull(blockFrame5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        piePlot1.setStartAngle((double) 8);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup2 = null;
        try {
            defaultCategoryDataset0.setGroup(datasetGroup2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color2 };
        java.awt.Color color4 = java.awt.Color.PINK;
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.Color color6 = java.awt.Color.PINK;
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Color color9 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color4, color5, color6, color7, color8, color9 };
        java.awt.Color color11 = java.awt.Color.PINK;
        java.awt.Color color12 = java.awt.Color.PINK;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color11, color12 };
        java.awt.Stroke stroke14 = null;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke14 };
        java.awt.Stroke[] strokeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray10, paintArray13, strokeArray15, strokeArray16, shapeArray17);
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextOutlinePaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean21 = defaultDrawingSupplier18.equals((java.lang.Object) paint20);
        piePlot1.setLabelBackgroundPaint(paint20);
        boolean boolean23 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.5f);
        java.awt.Paint paint5 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.14d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        piePlot1.handleClick(3, 0, plotRenderingInfo8);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int10 = chartColor9.getRGB();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = chartColor9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        legendTitle4.setBackgroundPaint((java.awt.Paint) chartColor9);
        java.awt.Font font18 = legendTitle4.getItemFont();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16698368) + "'", int10 == (-16698368));
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.awt.Color color2 = java.awt.Color.PINK;
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) color2);
        int int4 = defaultKeyedValues2D1.getRowCount();
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 1L);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 1, (java.lang.Comparable) 32.0d);
        try {
            defaultKeyedValues2D1.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setExpandToFitSpace(true);
        java.lang.Object obj4 = textTitle1.clone();
        java.awt.Font font5 = textTitle1.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str7 = horizontalAlignment6.toString();
        java.lang.String str8 = horizontalAlignment6.toString();
        textTitle1.setTextAlignment(horizontalAlignment6);
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(1, (int) '4', (int) (byte) 0);
        int int18 = chartColor17.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (byte) -1, (double) (byte) 10, (double) 3, (java.awt.Paint) chartColor17);
        java.awt.Color color20 = chartColor17.brighter();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        multiplePiePlot21.removeChangeListener(plotChangeListener22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot21);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj26 = null;
        boolean boolean27 = defaultDrawingSupplier25.equals(obj26);
        boolean boolean28 = jFreeChart24.equals((java.lang.Object) defaultDrawingSupplier25);
        java.awt.Paint paint29 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        jFreeChart24.setBackgroundPaint(paint29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        textTitle32.setExpandToFitSpace(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent35.setType(chartChangeEventType36);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart24, chartChangeEventType36);
        textTitle1.setPaint((java.awt.Paint) color20);
        java.awt.Color color42 = java.awt.Color.getColor("PieSection: 52, 52(8)", (int) (short) 1);
        textTitle1.setBackgroundPaint((java.awt.Paint) color42);
        java.awt.Color color44 = java.awt.Color.orange;
        java.awt.Color color45 = color44.darker();
        java.awt.Color color46 = java.awt.Color.YELLOW;
        java.awt.Color color47 = java.awt.Color.GRAY;
        float[] floatArray48 = null;
        float[] floatArray49 = color47.getRGBColorComponents(floatArray48);
        float[] floatArray50 = color46.getRGBColorComponents(floatArray49);
        float[] floatArray51 = color44.getRGBColorComponents(floatArray49);
        try {
            float[] floatArray52 = color42.getRGBComponents(floatArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HorizontalAlignment.CENTER" + "'", str8.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16698368) + "'", int18 == (-16698368));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot3.getParent();
        java.lang.String str6 = multiplePiePlot3.getPlotType();
        boolean boolean7 = multiplePiePlot3.isOutlineVisible();
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) boolean7);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        piePlot1.setMaximumLabelWidth(100.0d);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setOutlineStroke(stroke8);
        double double10 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', (int) '4', (java.lang.Comparable) 8, "hi!", "");
        java.lang.Comparable comparable8 = pieSectionEntity7.getSectionKey();
        java.lang.String str9 = pieSectionEntity7.getShapeCoords();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        pieSectionEntity7.setDataset(pieDataset10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 8 + "'", comparable8.equals(8));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-4,-4,4,4" + "'", str9.equals("-4,-4,4,4"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.lang.Object obj5 = null;
        boolean boolean6 = textTitle3.equals(obj5);
        textTitle3.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment9, (-1.0d), (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) flowArrangement12);
        java.text.NumberFormat numberFormat15 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        try {
            java.text.AttributedString attributedString18 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset16, (java.lang.Comparable) "HorizontalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberFormat15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean7 = rectangleEdge5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle8.setTextAlignment(horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setExpandToFitSpace(true);
        java.lang.Object obj16 = textTitle13.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle13.getMargin();
        double double19 = rectangleInsets17.trimHeight(1.0d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets17.getUnitType();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color2, rectangleEdge5, horizontalAlignment9, verticalAlignment11, rectangleInsets17);
        java.lang.String str22 = textTitle21.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str22.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("PieSection: 52, -16698368(8)", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        jFreeChart3.clearSubtitles();
        java.awt.RenderingHints renderingHints9 = jFreeChart3.getRenderingHints();
        float float10 = jFreeChart3.getBackgroundImageAlpha();
        try {
            java.awt.image.BufferedImage bufferedImage13 = jFreeChart3.createBufferedImage((int) (byte) 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (3) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) blockBorder1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = legendTitle4.getSources();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot7.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = multiplePiePlot7.getInsets();
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot7.getPieChart();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.calculateTopInset((double) 100.0f);
        double double15 = rectangleInsets11.calculateBottomOutset((double) 8);
        jFreeChart10.setPadding(rectangleInsets11);
        legendTitle4.setLegendItemGraphicPadding(rectangleInsets11);
        double double18 = rectangleInsets11.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(legendItemSourceArray6);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(jFreeChart10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = legendTitle4.getVerticalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer7 = legendTitle4.getItemContainer();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        try {
            legendTitle4.setLegendItemGraphicEdge(rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(blockContainer7);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle1.equals(obj3);
        textTitle1.setHeight((double) 2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        java.lang.Object obj8 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getLegendItemGraphicPadding();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = legendTitle4.getSources();
        legendTitle4.setWidth((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(legendItemSourceArray6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) (-1));
        java.awt.Color color4 = java.awt.Color.pink;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        int int6 = color4.getGreen();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 175 + "'", int6 == 175);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setExpandToFitSpace(true);
        java.lang.Object obj10 = textTitle7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle7.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (byte) 100);
        double double14 = rectangleInsets11.getBottom();
        multiplePiePlot0.setInsets(rectangleInsets11, true);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart18 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setExpandToFitSpace(true);
        java.lang.Object obj24 = textTitle21.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = textTitle21.getMargin();
        double double27 = rectangleInsets25.trimHeight((double) 100.0f);
        double double29 = rectangleInsets25.calculateTopOutset((double) 0L);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        textTitle31.setExpandToFitSpace(true);
        double double34 = textTitle31.getWidth();
        java.awt.Paint paint35 = textTitle31.getBackgroundPaint();
        double double36 = textTitle31.getContentYOffset();
        double double37 = textTitle31.getContentYOffset();
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle31.getBounds();
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets25.createInsetRectangle(rectangle2D38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double41 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D39, rectangleEdge40);
        try {
            jFreeChart18.draw(graphics2D19, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertNotNull(jFreeChart18);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }
}

