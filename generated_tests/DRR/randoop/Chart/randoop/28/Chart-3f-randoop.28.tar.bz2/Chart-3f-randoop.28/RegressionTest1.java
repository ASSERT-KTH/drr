import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1L));
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries2);
//        int int15 = timeSeries2.getItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185806465L + "'", long1 == 1560185806465L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 100.0d);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        int int8 = month6.getMonth();
//        org.jfree.data.time.Year year9 = month6.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond10.getLastMillisecond(calendar13);
//        long long15 = fixedMillisecond10.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10);
//        int int18 = month6.compareTo((java.lang.Object) timeSeriesDataItem17);
//        long long19 = month6.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long19, "", "10-June-2019");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        int int27 = month25.getMonth();
//        long long28 = month25.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 2);
//        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) (byte) 1);
//        boolean boolean33 = fixedMillisecond0.equals((java.lang.Object) timeSeries22);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener34);
//        timeSeries22.setRangeDescription("Mon Jun 10 00:00:00 PDT 2019");
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185806521L + "'", long3 == 1560185806521L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185806522L + "'", long14 == 1560185806522L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185806522L + "'", long15 == 1560185806522L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62112153600001L) + "'", long19 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62112153600001L) + "'", long28 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener12);
//        int int14 = timeSeries2.getItemCount();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getMonth();
//        org.jfree.data.time.Year year20 = month17.getYear();
//        java.lang.String str21 = month17.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 1560185732223L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries2.addChangeListener(seriesChangeListener24);
//        timeSeries2.setRangeDescription("");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185806599L + "'", long1 == 1560185806599L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "September 0" + "'", str21.equals("September 0"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        long long13 = timeSeries2.getMaximumItemAge();
//        java.lang.Class class14 = timeSeries2.getTimePeriodClass();
//        timeSeries2.fireSeriesChanged();
//        try {
//            timeSeries2.delete(1, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185806651L + "'", long1 == 1560185806651L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class14);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        java.lang.String str13 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14);
//        timeSeries16.setDomainDescription("10-June-2019");
//        java.lang.Object obj19 = timeSeries16.clone();
//        timeSeries16.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int24 = day22.compareTo((java.lang.Object) 9);
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day22.previous();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) year27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond30);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        int int37 = month35.getMonth();
//        long long38 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 2);
//        timeSeries32.add(timeSeriesDataItem40);
//        timeSeries29.add(timeSeriesDataItem40);
//        timeSeries2.add(timeSeriesDataItem40);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries46 = timeSeries2.createCopy(2147483647, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185806691L + "'", long1 == 1560185806691L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185806692L + "'", long9 == 1560185806692L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185806693L + "'", long15 == 1560185806693L);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185806696L + "'", long31 == 1560185806696L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62112153600001L) + "'", long38 == (-62112153600001L));
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getLastMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem22.getPeriod();
//        timeSeries2.delete(regularTimePeriod23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        int int26 = month25.getMonth();
//        java.util.Date date27 = month25.getEnd();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 1560185736955L);
//        double double30 = timeSeries2.getMinY();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185806723L + "'", long1 == 1560185806723L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560185806726L + "'", long19 == 1560185806726L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560185806726L + "'", long20 == 1560185806726L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.560185736955E12d + "'", double30 == 1.560185736955E12d);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(9);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 1560185730188L);
//        timeSeries15.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22);
//        timeSeries24.setDomainDescription("10-June-2019");
//        java.lang.Object obj27 = timeSeries24.clone();
//        timeSeries24.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 9);
//        long long33 = day30.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day30.previous();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) year35);
//        java.util.Collection collection38 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass41 = timePeriodFormatException40.getClass();
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int45 = day43.compareTo((java.lang.Object) 9);
//        long long46 = day43.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate47 = day43.getSerialDate();
//        java.util.Date date48 = day43.getStart();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date48, timeZone50);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        long long54 = fixedMillisecond53.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond53);
//        timeSeries55.setDomainDescription("10-June-2019");
//        java.lang.Object obj58 = timeSeries55.clone();
//        timeSeries55.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        long long62 = fixedMillisecond61.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year52, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        int int65 = timeSeries64.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185806828L + "'", long1 == 1560185806828L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560185806831L + "'", long23 == 1560185806831L);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560185806835L + "'", long54 == 1560185806835L);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560185806836L + "'", long62 == 1560185806836L);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2147483647 + "'", int65 == 2147483647);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        long long25 = fixedMillisecond21.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
//        long long32 = fixedMillisecond28.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1560185749314L);
//        int int35 = timeSeries2.getItemCount();
//        java.util.List list36 = timeSeries2.getItems();
//        java.lang.String str37 = timeSeries2.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807262L + "'", long1 == 1560185807262L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185807266L + "'", long22 == 1560185807266L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185807266L + "'", long24 == 1560185807266L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185807266L + "'", long25 == 1560185807266L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185807267L + "'", long29 == 1560185807267L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185807267L + "'", long31 == 1560185807267L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185807267L + "'", long32 == 1560185807267L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(list36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNull(seriesChangeInfo2);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) -1 + "'", obj3.equals((short) -1));
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.lang.Comparable comparable13 = timeSeries2.getKey();
//        java.lang.String str14 = timeSeries2.getDescription();
//        timeSeries2.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807613L + "'", long1 == 1560185807613L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertNull(str14);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        int int21 = month19.getMonth();
//        long long22 = month19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 2);
//        timeSeries16.add(timeSeriesDataItem24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries16.getNextTimePeriod();
//        java.util.List list27 = timeSeries16.getItems();
//        java.lang.String str28 = timeSeries16.getDomainDescription();
//        timeSeries16.setKey((java.lang.Comparable) 1560185736734L);
//        long long31 = timeSeries16.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries2.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass35 = timePeriodFormatException34.getClass();
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int39 = day37.compareTo((java.lang.Object) 9);
//        long long40 = day37.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate41 = day37.getSerialDate();
//        java.util.Date date42 = day37.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date42, timeZone44);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries49 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year46, regularTimePeriod48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807655L + "'", long1 == 1560185807655L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185807657L + "'", long15 == 1560185807657L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62112153600001L) + "'", long22 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(list27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43626L + "'", long40 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        int int15 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Comparable comparable18 = null;
//        try {
//            timeSeries2.setKey(comparable18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807699L + "'", long1 == 1560185807699L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185807700L + "'", long9 == 1560185807700L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        long long25 = fixedMillisecond21.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
//        long long32 = fixedMillisecond28.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1560185749314L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond28.next();
//        long long36 = fixedMillisecond28.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807714L + "'", long1 == 1560185807714L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185807718L + "'", long22 == 1560185807718L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185807718L + "'", long24 == 1560185807718L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185807718L + "'", long25 == 1560185807718L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185807740L + "'", long29 == 1560185807740L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185807740L + "'", long31 == 1560185807740L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185807740L + "'", long32 == 1560185807740L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560185807740L + "'", long36 == 1560185807740L);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.lang.Comparable comparable13 = timeSeries2.getKey();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 1560185729661L);
//        try {
//            timeSeries2.add(timeSeriesDataItem20, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807800L + "'", long1 == 1560185807800L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16);
//        timeSeries18.setDomainDescription("10-June-2019");
//        java.lang.Object obj21 = timeSeries18.clone();
//        java.util.Collection collection22 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        double double23 = timeSeries2.getMinY();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807816L + "'", long1 == 1560185807816L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560185807818L + "'", long17 == 1560185807818L);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        timeSeries2.setNotify(true);
//        double double15 = timeSeries2.getMaxY();
//        timeSeries2.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807874L + "'", long1 == 1560185807874L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185807876L + "'", long9 == 1560185807876L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        java.lang.String str12 = timeSeries2.getDescription();
//        try {
//            timeSeries2.delete(2, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807893L + "'", long1 == 1560185807893L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185807916L + "'", long9 == 1560185807916L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNull(str12);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        int int13 = month11.getMonth();
//        long long14 = month11.getLastMillisecond();
//        int int15 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
//        double double16 = timeSeries2.getMaxY();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807930L + "'", long1 == 1560185807930L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185807930L + "'", long4 == 1560185807930L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185807930L + "'", long6 == 1560185807930L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185807930L + "'", long7 == 1560185807930L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62112153600001L) + "'", long14 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        int int19 = day16.getMonth();
//        long long20 = day16.getMiddleMillisecond();
//        int int21 = day16.getDayOfMonth();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries2.addAndOrUpdate(timeSeries26);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries2.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
//        int int34 = month32.getMonth();
//        org.jfree.data.time.Year year35 = month32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month32.previous();
//        org.jfree.data.time.Year year37 = month32.getYear();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year37, (double) 1560185753888L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        long long41 = fixedMillisecond40.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond40.previous();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond40.getMiddleMillisecond(calendar43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int47 = day45.compareTo((java.lang.Object) 9);
//        int int48 = day45.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day45.previous();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, regularTimePeriod49);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass53 = timePeriodFormatException52.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int57 = day55.compareTo((java.lang.Object) 9);
//        long long58 = day55.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate59 = day55.getSerialDate();
//        java.util.Date date60 = day55.getStart();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
//        java.util.TimeZone timeZone62 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date60, timeZone62);
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date60);
//        int int65 = month64.getYearValue();
//        int int66 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) month64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        long long68 = fixedMillisecond67.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond67.previous();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getFirstMillisecond(calendar70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = fixedMillisecond67.next();
//        timeSeries50.delete(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185807955L + "'", long1 == 1560185807955L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560185807962L + "'", long41 == 1560185807962L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560185807962L + "'", long44 == 1560185807962L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 43626L + "'", long58 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560185807990L + "'", long68 == 1560185807990L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560185807990L + "'", long71 == 1560185807990L);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 9);
//        long long9 = day6.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate10 = day6.getSerialDate();
//        java.util.Date date11 = day6.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date11, timeZone13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11);
//        boolean boolean16 = year0.equals((java.lang.Object) month15);
//        int int17 = month15.getMonth();
//        int int18 = month15.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        org.jfree.data.time.Year year11 = month8.getYear();
//        java.lang.String str12 = month8.toString();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) month8);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond0.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond0.getTime();
//        long long17 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185808818L + "'", long1 == 1560185808818L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185808818L + "'", long2 == 1560185808818L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185808818L + "'", long4 == 1560185808818L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185808818L + "'", long5 == 1560185808818L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "September 0" + "'", str12.equals("September 0"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185808818L + "'", long15 == 1560185808818L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560185808818L + "'", long17 == 1560185808818L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 100.0d);
        timeSeriesDataItem2.setSelected(true);
        boolean boolean5 = timeSeriesDataItem2.isSelected();
        timeSeriesDataItem2.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        timeSeries2.setKey((java.lang.Comparable) 1560185736734L);
//        timeSeries2.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185809519L + "'", long1 == 1560185809519L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 100.0d);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.lang.String str6 = year5.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185809581L + "'", long3 == 1560185809581L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        long long11 = fixedMillisecond8.getSerialIndex();
//        long long12 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        long long14 = fixedMillisecond8.getFirstMillisecond();
//        long long15 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond8.previous();
//        timeSeries2.add(regularTimePeriod16, (java.lang.Number) 1560185751309L);
//        java.util.Date date19 = regularTimePeriod16.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185809606L + "'", long1 == 1560185809606L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185809607L + "'", long6 == 1560185809607L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185809607L + "'", long9 == 1560185809607L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560185809607L + "'", long11 == 1560185809607L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560185809607L + "'", long12 == 1560185809607L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185809607L + "'", long14 == 1560185809607L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185809607L + "'", long15 == 1560185809607L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date19);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries2.setMaximumItemCount((int) (short) 10);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo22);
//        boolean boolean24 = timeSeries2.equals((java.lang.Object) seriesChangeEvent21);
//        timeSeries2.removeAgedItems(true);
//        java.lang.Object obj27 = timeSeries2.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getLastMillisecond(calendar31);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1560185771901L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185809650L + "'", long1 == 1560185809650L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185809650L + "'", long4 == 1560185809650L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185809650L + "'", long6 == 1560185809650L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185809650L + "'", long7 == 1560185809650L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185809654L + "'", long32 == 1560185809654L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date9, timeZone12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        int int14 = month13.getYearValue();
//        java.lang.String str15 = month13.toString();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = month13.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        timeSeries2.setNotify(false);
//        boolean boolean18 = timeSeries2.equals((java.lang.Object) 1560185754849L);
//        timeSeries2.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        long long25 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.previous();
//        long long27 = fixedMillisecond24.getSerialIndex();
//        long long28 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        long long30 = timeSeries23.getMaximumItemAge();
//        java.lang.Object obj31 = timeSeries23.clone();
//        boolean boolean32 = timeSeries2.equals((java.lang.Object) timeSeries23);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810053L + "'", long1 == 1560185810053L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185810056L + "'", long22 == 1560185810056L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185810056L + "'", long25 == 1560185810056L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560185810056L + "'", long27 == 1560185810056L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560185810056L + "'", long28 == 1560185810056L);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        int int19 = day16.getMonth();
//        long long20 = day16.getMiddleMillisecond();
//        int int21 = day16.getDayOfMonth();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries2.addAndOrUpdate(timeSeries26);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries2.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
//        int int34 = month32.getMonth();
//        org.jfree.data.time.Year year35 = month32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month32.previous();
//        org.jfree.data.time.Year year37 = month32.getYear();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year37, (double) 1560185753888L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        long long41 = fixedMillisecond40.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond40.previous();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond40.getMiddleMillisecond(calendar43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int47 = day45.compareTo((java.lang.Object) 9);
//        int int48 = day45.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day45.previous();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, regularTimePeriod49);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass53 = timePeriodFormatException52.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int57 = day55.compareTo((java.lang.Object) 9);
//        long long58 = day55.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate59 = day55.getSerialDate();
//        java.util.Date date60 = day55.getStart();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
//        java.util.TimeZone timeZone62 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date60, timeZone62);
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date60);
//        int int65 = month64.getYearValue();
//        int int66 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) month64);
//        timeSeries50.setMaximumItemAge(1560185780897L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810156L + "'", long1 == 1560185810156L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560185810162L + "'", long41 == 1560185810162L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560185810162L + "'", long44 == 1560185810162L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 43626L + "'", long58 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810526L + "'", long1 == 1560185810526L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, 0.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        int int7 = fixedMillisecond0.compareTo((java.lang.Object) day5);
//        long long8 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810635L + "'", long1 == 1560185810635L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185810635L + "'", long3 == 1560185810635L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185810635L + "'", long4 == 1560185810635L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560185810635L + "'", long8 == 1560185810635L);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        java.lang.String str12 = timeSeries2.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond13);
//        timeSeries15.setDomainDescription("10-June-2019");
//        java.lang.Object obj18 = timeSeries15.clone();
//        timeSeries15.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        int int24 = timeSeries15.getItemCount();
//        double double25 = timeSeries15.getMinY();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(2019);
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) year27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries2.addAndOrUpdate(timeSeries15);
//        java.lang.Comparable comparable30 = null;
//        try {
//            timeSeries29.setKey(comparable30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810648L + "'", long1 == 1560185810648L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185810649L + "'", long9 == 1560185810649L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185810650L + "'", long14 == 1560185810650L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185810651L + "'", long22 == 1560185810651L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries29);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getMonth();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int7 = day5.compareTo((java.lang.Object) 9);
//        long long8 = day5.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
//        java.util.Date date10 = day5.getStart();
//        long long11 = day5.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        boolean boolean13 = day0.equals((java.lang.Object) regularTimePeriod12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.previous();
//        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193199999L + "'", long4 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193199999L + "'", long11 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = fixedMillisecond13.equals(obj14);
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond13.peg(calendar16);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.lang.Object obj10 = timeSeries2.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
//        int int18 = month16.getMonth();
//        long long19 = month16.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 2);
//        timeSeries13.add(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries13.getNextTimePeriod();
//        boolean boolean24 = timeSeries13.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean26 = timeSeries13.equals((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int29 = day27.compareTo((java.lang.Object) 9);
//        int int30 = day27.getMonth();
//        long long31 = day27.getMiddleMillisecond();
//        int int32 = day27.getDayOfMonth();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        int int34 = day27.getMonth();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day27, (double) 1560185754923L);
//        timeSeries2.setNotify(false);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810757L + "'", long1 == 1560185810757L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185810758L + "'", long4 == 1560185810758L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185810758L + "'", long6 == 1560185810758L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185810758L + "'", long7 == 1560185810758L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560185810759L + "'", long12 == 1560185810759L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62112153600001L) + "'", long19 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.String str7 = year6.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year6.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries2.setMaximumItemCount((int) (short) 10);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo22);
//        boolean boolean24 = timeSeries2.equals((java.lang.Object) seriesChangeEvent21);
//        timeSeries2.removeAgedItems(true);
//        java.lang.String str27 = timeSeries2.getRangeDescription();
//        int int28 = timeSeries2.getItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810910L + "'", long1 == 1560185810910L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185810911L + "'", long4 == 1560185810911L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185810911L + "'", long6 == 1560185810911L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185810911L + "'", long7 == 1560185810911L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 100.0d);
        timeSeriesDataItem2.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "September 0", "9");
        try {
            timeSeries8.update(6, (java.lang.Number) 1560185794528L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560185750309L, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.event.SeriesChangeEvent[source=September 0]");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        int int7 = fixedMillisecond0.compareTo((java.lang.Object) day5);
//        java.util.Date date8 = day5.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185810995L + "'", long1 == 1560185810995L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185810995L + "'", long3 == 1560185810995L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185810995L + "'", long4 == 1560185810995L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        long long13 = timeSeries2.getMaximumItemAge();
//        java.lang.Class class14 = timeSeries2.getTimePeriodClass();
//        timeSeries2.fireSeriesChanged();
//        try {
//            timeSeries2.delete(1, (int) (short) 10, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185811012L + "'", long1 == 1560185811012L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class14);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9);
//        java.util.Date date16 = month15.getEnd();
//        java.lang.String str17 = month15.toString();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries2.setMaximumItemCount((int) (short) 10);
//        timeSeries2.removeAgedItems(1560185741815L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        long long27 = fixedMillisecond26.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond26);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.next();
//        int int33 = month31.getMonth();
//        long long34 = month31.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 2);
//        timeSeries28.add(timeSeriesDataItem36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeries28.getNextTimePeriod();
//        boolean boolean39 = timeSeries28.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean41 = timeSeries28.equals((java.lang.Object) fixedMillisecond40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        int int44 = day42.compareTo((java.lang.Object) 9);
//        int int45 = day42.getMonth();
//        long long46 = day42.getMiddleMillisecond();
//        int int47 = day42.getDayOfMonth();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries28.addAndOrUpdate(timeSeries52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries25.addAndOrUpdate(timeSeries53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        long long56 = fixedMillisecond55.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond55);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
//        int int62 = month60.getMonth();
//        long long63 = month60.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month60, (java.lang.Number) 2);
//        timeSeries57.add(timeSeriesDataItem65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = timeSeries57.getNextTimePeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        long long69 = fixedMillisecond68.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond68);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month73.next();
//        int int75 = month73.getMonth();
//        long long76 = month73.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month73, (java.lang.Number) 2);
//        timeSeries70.add(timeSeriesDataItem78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = timeSeries70.getNextTimePeriod();
//        boolean boolean81 = timeSeries70.isEmpty();
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        int int84 = day82.compareTo((java.lang.Object) 9);
//        int int85 = day82.getMonth();
//        long long86 = day82.getMiddleMillisecond();
//        int int87 = day82.getDayOfMonth();
//        java.lang.Number number88 = timeSeries70.getValue((org.jfree.data.time.RegularTimePeriod) day82);
//        boolean boolean89 = timeSeries57.equals((java.lang.Object) number88);
//        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day();
//        int int92 = day90.compareTo((java.lang.Object) 9);
//        int int93 = day90.getMonth();
//        long long94 = day90.getLastMillisecond();
//        java.lang.Number number95 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) day90);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem97 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day90, (double) 1560185750777L);
//        org.jfree.data.time.TimeSeries timeSeries98 = timeSeries2.addAndOrUpdate(timeSeries54);
//        double double99 = timeSeries2.getMinY();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185811084L + "'", long1 == 1560185811084L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185811085L + "'", long4 == 1560185811085L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185811085L + "'", long6 == 1560185811085L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185811085L + "'", long7 == 1560185811085L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185811108L + "'", long24 == 1560185811108L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560185811108L + "'", long27 == 1560185811108L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62112153600001L) + "'", long34 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560193199999L + "'", long46 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560185811113L + "'", long56 == 1560185811113L);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 9 + "'", int62 == 9);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-62112153600001L) + "'", long63 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560185811115L + "'", long69 == 1560185811115L);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 9 + "'", int75 == 9);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-62112153600001L) + "'", long76 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 6 + "'", int85 == 6);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560193199999L + "'", long86 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 10 + "'", int87 == 10);
//        org.junit.Assert.assertTrue("'" + number88 + "' != '" + 2 + "'", number88.equals(2));
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 6 + "'", int93 == 6);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1560236399999L + "'", long94 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + number95 + "' != '" + 2 + "'", number95.equals(2));
//        org.junit.Assert.assertNull(timeSeriesDataItem97);
//        org.junit.Assert.assertNotNull(timeSeries98);
//        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 1.560185750777E12d + "'", double99 == 1.560185750777E12d);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone15 = null;
//        try {
//            org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date9, timeZone15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14);
//        timeSeries16.setDomainDescription("10-June-2019");
//        java.lang.Object obj19 = timeSeries16.clone();
//        timeSeries16.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond22.getMiddleMillisecond(calendar25);
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass31 = timePeriodFormatException30.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int35 = day33.compareTo((java.lang.Object) 9);
//        long long36 = day33.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate37 = day33.getSerialDate();
//        java.util.Date date38 = day33.getStart();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date38, timeZone40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date38);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date38);
//        java.util.Date date45 = month44.getEnd();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month44, (double) 1560185743828L);
//        java.util.Calendar calendar48 = null;
//        try {
//            long long49 = month44.getFirstMillisecond(calendar48);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185811611L + "'", long1 == 1560185811611L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185811613L + "'", long15 == 1560185811613L);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560185811615L + "'", long23 == 1560185811615L);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560185811615L + "'", long26 == 1560185811615L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43626L + "'", long36 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date45);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener12);
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 100.0d);
//        timeSeries2.setKey((java.lang.Comparable) fixedMillisecond15);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185811650L + "'", long1 == 1560185811650L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = day0.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.String str7 = year6.toString();
//        long long8 = year6.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9);
//        timeSeries11.setDomainDescription("10-June-2019");
//        int int14 = year6.compareTo((java.lang.Object) "10-June-2019");
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = year6.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185811699L + "'", long10 == 1560185811699L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.addOrUpdate(regularTimePeriod19, (double) 1560185737482L);
//        try {
//            timeSeries2.update(2019, (java.lang.Number) 1560185766595L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185811713L + "'", long1 == 1560185811713L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185811714L + "'", long4 == 1560185811714L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185811714L + "'", long6 == 1560185811714L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185811714L + "'", long7 == 1560185811714L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(9);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 1560185730188L);
//        timeSeries15.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22);
//        timeSeries24.setDomainDescription("10-June-2019");
//        java.lang.Object obj27 = timeSeries24.clone();
//        timeSeries24.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 9);
//        long long33 = day30.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day30.previous();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) year35);
//        java.util.Collection collection38 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass41 = timePeriodFormatException40.getClass();
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int45 = day43.compareTo((java.lang.Object) 9);
//        long long46 = day43.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate47 = day43.getSerialDate();
//        java.util.Date date48 = day43.getStart();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date48, timeZone50);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        long long54 = fixedMillisecond53.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond53);
//        timeSeries55.setDomainDescription("10-June-2019");
//        java.lang.Object obj58 = timeSeries55.clone();
//        timeSeries55.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        long long62 = fixedMillisecond61.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year52, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener65 = null;
//        timeSeries64.removeChangeListener(seriesChangeListener65);
//        int int67 = timeSeries64.getItemCount();
//        int int68 = timeSeries64.getItemCount();
//        java.util.List list69 = timeSeries64.getItems();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185811730L + "'", long1 == 1560185811730L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560185811755L + "'", long23 == 1560185811755L);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560185811760L + "'", long54 == 1560185811760L);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560185811761L + "'", long62 == 1560185811761L);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertNotNull(list69);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, 5, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560185763825L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2);
//        timeSeries4.setDomainDescription("10-June-2019");
//        java.lang.Object obj7 = timeSeries4.clone();
//        timeSeries4.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 9);
//        long long13 = day10.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries21.setDomainDescription("10-June-2019");
//        timeSeries21.removeAgedItems(true);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int28 = day26.compareTo((java.lang.Object) 9);
//        long long29 = day26.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate30 = day26.getSerialDate();
//        java.util.Date date31 = day26.getStart();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, 0.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 1560185745363L);
//        timeSeries21.add(timeSeriesDataItem36, false);
//        boolean boolean39 = timeSeriesDataItem36.isSelected();
//        java.lang.Number number40 = timeSeriesDataItem36.getValue();
//        timeSeries4.add(timeSeriesDataItem36, true);
//        boolean boolean43 = timeSeriesDataItem36.isSelected();
//        timeSeries1.add(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185812441L + "'", long3 == 1560185812441L);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 1560185745363L + "'", number40.equals(1560185745363L));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 9);
//        long long9 = day6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day6, (double) 1560185733359L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 9);
//        long long16 = day13.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        java.util.Date date18 = day13.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, 0.0d);
//        timeSeries3.setKey((java.lang.Comparable) 0.0d);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries3.addChangeListener(seriesChangeListener23);
//        timeSeries3.setNotify(false);
//        java.lang.String str27 = timeSeries3.getDescription();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(str27);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        int int14 = month13.getYearValue();
//        java.lang.String str15 = month13.toString();
//        org.jfree.data.time.Year year16 = month13.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        int int27 = month25.getMonth();
//        long long28 = month25.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 2);
//        timeSeries22.add(timeSeriesDataItem30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries22.getNextTimePeriod();
//        boolean boolean33 = timeSeries22.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean35 = timeSeries22.equals((java.lang.Object) fixedMillisecond34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int38 = day36.compareTo((java.lang.Object) 9);
//        int int39 = day36.getMonth();
//        long long40 = day36.getMiddleMillisecond();
//        int int41 = day36.getDayOfMonth();
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day36);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries22.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries19.addAndOrUpdate(timeSeries47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        long long50 = fixedMillisecond49.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond49);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
//        int int56 = month54.getMonth();
//        long long57 = month54.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month54, (java.lang.Number) 2);
//        timeSeries51.add(timeSeriesDataItem59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = timeSeries51.getNextTimePeriod();
//        boolean boolean62 = timeSeries51.isEmpty();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        int int65 = day63.compareTo((java.lang.Object) 9);
//        int int66 = day63.getMonth();
//        long long67 = day63.getMiddleMillisecond();
//        int int68 = day63.getDayOfMonth();
//        java.lang.Number number69 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) day63);
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) day63, (java.lang.Number) 1560185744532L);
//        boolean boolean72 = year16.equals((java.lang.Object) 1560185744532L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year16.next();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560185812672L + "'", long18 == 1560185812672L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560185812672L + "'", long21 == 1560185812672L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62112153600001L) + "'", long28 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560193199999L + "'", long40 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560185812677L + "'", long50 == 1560185812677L);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-62112153600001L) + "'", long57 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560193199999L + "'", long67 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 10 + "'", int68 == 10);
//        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 2 + "'", number69.equals(2));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        java.lang.Comparable comparable9 = timeSeries2.getKey();
//        java.lang.String str10 = timeSeries2.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185813322L + "'", long1 == 1560185813322L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185813323L + "'", long4 == 1560185813323L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185813323L + "'", long6 == 1560185813323L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185813323L + "'", long7 == 1560185813323L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(comparable9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int20 = day18.compareTo((java.lang.Object) 9);
//        long long21 = day18.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate22 = day18.getSerialDate();
//        java.util.Date date23 = day18.getStart();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date23, timeZone25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date23);
//        int int28 = month27.getYearValue();
//        java.lang.String str29 = month27.toString();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month27);
//        long long31 = month27.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32);
//        java.lang.Comparable comparable35 = timeSeries34.getKey();
//        java.lang.Object obj36 = timeSeries34.clone();
//        java.lang.Class class37 = timeSeries34.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond38);
//        timeSeries40.setDomainDescription("10-June-2019");
//        java.lang.Object obj43 = timeSeries40.clone();
//        timeSeries40.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int48 = day46.compareTo((java.lang.Object) 9);
//        long long49 = day46.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day46.previous();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year51.next();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) year51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        long long55 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond54);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = month59.next();
//        int int61 = month59.getMonth();
//        long long62 = month59.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month59, (java.lang.Number) 2);
//        timeSeries56.add(timeSeriesDataItem64);
//        timeSeries53.add(timeSeriesDataItem64);
//        java.lang.Class<?> wildcardClass67 = timeSeriesDataItem64.getClass();
//        timeSeriesDataItem64.setValue((java.lang.Number) (byte) -1);
//        boolean boolean70 = timeSeriesDataItem64.isSelected();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = timeSeriesDataItem64.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries34.addOrUpdate(regularTimePeriod71, (double) (-1L));
//        int int74 = timeSeries34.getMaximumItemCount();
//        boolean boolean75 = month27.equals((java.lang.Object) int74);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185813342L + "'", long1 == 1560185813342L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560185813347L + "'", long33 == 1560185813347L);
//        org.junit.Assert.assertNotNull(comparable35);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560185813348L + "'", long39 == 1560185813348L);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560185813350L + "'", long55 == 1560185813350L);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 9 + "'", int61 == 9);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-62112153600001L) + "'", long62 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(timeSeriesDataItem73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2147483647 + "'", int74 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
//        int int9 = month7.getMonth();
//        long long10 = month7.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 2);
//        timeSeries4.add(timeSeriesDataItem12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries4.getNextTimePeriod();
//        boolean boolean15 = timeSeries4.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean17 = timeSeries4.equals((java.lang.Object) fixedMillisecond16);
//        boolean boolean18 = fixedMillisecond0.equals((java.lang.Object) timeSeries4);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int21 = day19.compareTo((java.lang.Object) 9);
//        long long22 = day19.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate23 = day19.getSerialDate();
//        java.util.Date date24 = day19.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getLastMillisecond();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560185805106L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185813788L + "'", long1 == 1560185813788L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185813789L + "'", long3 == 1560185813789L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62112153600001L) + "'", long10 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        long long25 = fixedMillisecond21.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.next();
//        int int32 = month30.getMonth();
//        org.jfree.data.time.Year year33 = month30.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month30.next();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) 9223372036854775807L);
//        double double37 = timeSeries2.getMaxY();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeries2.getTimePeriod((int) (byte) 0);
//        double double40 = timeSeries2.getMinY();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185813808L + "'", long1 == 1560185813808L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185813815L + "'", long22 == 1560185813815L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185813815L + "'", long24 == 1560185813815L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185813815L + "'", long25 == 1560185813815L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 9.223372036854776E18d + "'", double37 == 9.223372036854776E18d);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.223372036854776E18d + "'", double40 == 9.223372036854776E18d);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = day0.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        java.util.Date date17 = day12.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date17);
//        java.util.Date date22 = fixedMillisecond21.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date22, timeZone24);
//        java.util.TimeZone timeZone26 = null;
//        try {
//            org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        timeSeries2.setNotify(false);
//        boolean boolean18 = timeSeries2.equals((java.lang.Object) 1560185754849L);
//        long long19 = timeSeries2.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185814011L + "'", long1 == 1560185814011L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getLastMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem22.getPeriod();
//        timeSeries2.delete(regularTimePeriod23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        int int26 = month25.getMonth();
//        java.util.Date date27 = month25.getEnd();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 1560185736955L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond30);
//        timeSeries32.setDomainDescription("10-June-2019");
//        java.lang.Object obj35 = timeSeries32.clone();
//        timeSeries32.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        int int41 = timeSeries32.getItemCount();
//        double double42 = timeSeries32.getMinY();
//        java.lang.String str43 = timeSeries32.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        long long45 = fixedMillisecond44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond44);
//        timeSeries46.setDomainDescription("10-June-2019");
//        java.lang.Object obj49 = timeSeries46.clone();
//        timeSeries46.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        int int54 = day52.compareTo((java.lang.Object) 9);
//        long long55 = day52.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day52.previous();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.next();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) day52, (org.jfree.data.time.RegularTimePeriod) year57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        long long61 = fixedMillisecond60.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond60);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
//        int int67 = month65.getMonth();
//        long long68 = month65.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) 2);
//        timeSeries62.add(timeSeriesDataItem70);
//        timeSeries59.add(timeSeriesDataItem70);
//        timeSeries32.add(timeSeriesDataItem70);
//        timeSeries2.add(timeSeriesDataItem70);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185814042L + "'", long1 == 1560185814042L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560185814067L + "'", long19 == 1560185814067L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560185814067L + "'", long20 == 1560185814067L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185814070L + "'", long31 == 1560185814070L);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560185814071L + "'", long39 == 1560185814071L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560185814072L + "'", long45 == 1560185814072L);
//        org.junit.Assert.assertNotNull(obj49);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43626L + "'", long55 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560185814075L + "'", long61 == 1560185814075L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62112153600001L) + "'", long68 == (-62112153600001L));
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        long long11 = month8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 2);
//        timeSeries5.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        boolean boolean16 = timeSeries5.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean18 = timeSeries5.equals((java.lang.Object) fixedMillisecond17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int21 = day19.compareTo((java.lang.Object) 9);
//        int int22 = day19.getMonth();
//        long long23 = day19.getMiddleMillisecond();
//        int int24 = day19.getDayOfMonth();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.addAndOrUpdate(timeSeries29);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
//        int int39 = month37.getMonth();
//        long long40 = month37.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) 2);
//        timeSeries34.add(timeSeriesDataItem42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries34.getNextTimePeriod();
//        boolean boolean45 = timeSeries34.isEmpty();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int48 = day46.compareTo((java.lang.Object) 9);
//        int int49 = day46.getMonth();
//        long long50 = day46.getMiddleMillisecond();
//        int int51 = day46.getDayOfMonth();
//        java.lang.Number number52 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries2.addAndOrUpdate(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185814587L + "'", long1 == 1560185814587L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185814587L + "'", long4 == 1560185814587L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600001L) + "'", long11 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560193199999L + "'", long23 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560185814612L + "'", long33 == 1560185814612L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62112153600001L) + "'", long40 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560193199999L + "'", long50 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 2 + "'", number52.equals(2));
//        org.junit.Assert.assertNotNull(timeSeries53);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 9);
//        long long9 = day6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day6, (double) 1560185733359L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 9);
//        long long16 = day13.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        java.util.Date date18 = day13.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, 0.0d);
//        timeSeries3.setKey((java.lang.Comparable) 0.0d);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries3.addChangeListener(seriesChangeListener23);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries3.getDataItem((int) (short) 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date9, timeZone12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 100.0d);
//        long long17 = fixedMillisecond14.getFirstMillisecond();
//        java.util.Date date18 = fixedMillisecond14.getTime();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date18);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560185815090L + "'", long17 == 1560185815090L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries3.setDomainDescription("10-June-2019");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate12 = day8.getSerialDate();
//        java.util.Date date13 = day8.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, 0.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 1560185745363L);
//        timeSeries3.add(timeSeriesDataItem18, false);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener21);
//        int int23 = timeSeries3.getItemCount();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = null;
//        try {
//            java.lang.Number number25 = timeSeries3.getValue(regularTimePeriod24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond13);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        int int20 = month18.getMonth();
//        long long21 = month18.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 2);
//        timeSeries15.add(timeSeriesDataItem23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener25);
//        int int27 = timeSeries15.getItemCount();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.next();
//        int int32 = month30.getMonth();
//        org.jfree.data.time.Year year33 = month30.getYear();
//        java.lang.String str34 = month30.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (double) 1560185732223L);
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month30);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185815222L + "'", long1 == 1560185815222L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185815223L + "'", long9 == 1560185815223L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185815224L + "'", long14 == 1560185815224L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62112153600001L) + "'", long21 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "September 0" + "'", str34.equals("September 0"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        int int13 = month11.getMonth();
//        long long14 = month11.getLastMillisecond();
//        int int15 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.String str16 = timeSeries2.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185815394L + "'", long1 == 1560185815394L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185815394L + "'", long4 == 1560185815394L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185815394L + "'", long6 == 1560185815394L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185815394L + "'", long7 == 1560185815394L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62112153600001L) + "'", long14 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        timeSeries2.setNotify(false);
//        long long17 = timeSeries2.getMaximumItemAge();
//        java.lang.String str18 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        long long20 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
//        int int29 = month27.getMonth();
//        long long30 = month27.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 2);
//        timeSeries24.add(timeSeriesDataItem32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries24.getNextTimePeriod();
//        int int35 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod34);
//        java.lang.Number number36 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185815416L + "'", long1 == 1560185815416L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560185815419L + "'", long20 == 1560185815419L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560185815420L + "'", long23 == 1560185815420L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62112153600001L) + "'", long30 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 2 + "'", number36.equals(2));
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185815580L + "'", long1 == 1560185815580L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185815580L + "'", long3 == 1560185815580L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185815580L + "'", long4 == 1560185815580L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185815580L + "'", long6 == 1560185815580L);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        int int4 = month2.getMonth();
//        org.jfree.data.time.Year year5 = month2.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getLastMillisecond(calendar9);
//        long long11 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 10);
//        int int14 = month2.compareTo((java.lang.Object) timeSeriesDataItem13);
//        long long15 = month2.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long15, "", "10-June-2019");
//        java.util.Collection collection19 = timeSeries18.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        int int27 = month25.getMonth();
//        long long28 = month25.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 2);
//        timeSeries22.add(timeSeriesDataItem30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries22.getNextTimePeriod();
//        boolean boolean33 = timeSeries22.isEmpty();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int36 = day34.compareTo((java.lang.Object) 9);
//        int int37 = day34.getMonth();
//        long long38 = day34.getMiddleMillisecond();
//        int int39 = day34.getDayOfMonth();
//        java.lang.Number number40 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        long long42 = fixedMillisecond41.getLastMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond41.getMiddleMillisecond(calendar43);
//        long long45 = fixedMillisecond41.getSerialIndex();
//        timeSeries22.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        long long49 = fixedMillisecond48.getLastMillisecond();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond48.getMiddleMillisecond(calendar50);
//        long long52 = fixedMillisecond48.getSerialIndex();
//        timeSeries22.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 1560185749314L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond48.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond48.next();
//        try {
//            timeSeries18.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 1560185801324L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185815611L + "'", long10 == 1560185815611L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560185815611L + "'", long11 == 1560185815611L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62112153600001L) + "'", long15 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560185815613L + "'", long21 == 1560185815613L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62112153600001L) + "'", long28 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560193199999L + "'", long38 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 2 + "'", number40.equals(2));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560185815616L + "'", long42 == 1560185815616L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560185815616L + "'", long44 == 1560185815616L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560185815616L + "'", long45 == 1560185815616L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560185815617L + "'", long49 == 1560185815617L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560185815617L + "'", long51 == 1560185815617L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560185815617L + "'", long52 == 1560185815617L);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
//        long long16 = fixedMillisecond14.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.addOrUpdate(regularTimePeriod19, (double) 1560185737482L);
//        java.util.Date date22 = regularTimePeriod19.getEnd();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185815679L + "'", long1 == 1560185815679L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185815680L + "'", long4 == 1560185815680L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185815680L + "'", long6 == 1560185815680L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185815680L + "'", long7 == 1560185815680L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date22);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        long long4 = year3.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185815770L + "'", long1 == 1560185815770L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        int int2 = month0.compareTo(obj1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185798887L);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9);
//        java.lang.String str15 = year14.toString();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 2);
        long long8 = month2.getSerialIndex();
        int int9 = month2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62112153600001L) + "'", long5 == (-62112153600001L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(9);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 1560185730188L);
//        timeSeries15.removeAgedItems(false);
//        timeSeries15.removeAgedItems(1560185809745L, false);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185816282L + "'", long1 == 1560185816282L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.lang.Comparable comparable13 = timeSeries2.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 100.0d);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem16.getPeriod();
//        try {
//            timeSeries2.add(timeSeriesDataItem16, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185816318L + "'", long1 == 1560185816318L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        int int8 = month6.getMonth();
//        long long9 = month6.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2);
//        timeSeries3.add(timeSeriesDataItem11);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener13);
//        int int15 = timeSeries3.getItemCount();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        int int20 = month18.getMonth();
//        org.jfree.data.time.Year year21 = month18.getYear();
//        java.lang.String str22 = month18.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) 1560185732223L);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        int int26 = year25.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        long long28 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond27);
//        timeSeries29.setDomainDescription("10-June-2019");
//        java.lang.Object obj32 = timeSeries29.clone();
//        timeSeries29.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        long long36 = fixedMillisecond35.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(4, year25);
//        java.util.Calendar calendar40 = null;
//        try {
//            long long41 = year25.getLastMillisecond(calendar40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185816331L + "'", long2 == 1560185816331L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62112153600001L) + "'", long9 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "September 0" + "'", str22.equals("September 0"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560185816355L + "'", long28 == 1560185816355L);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560185816356L + "'", long36 == 1560185816356L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        long long11 = month8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 2);
//        timeSeries5.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        boolean boolean16 = timeSeries5.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean18 = timeSeries5.equals((java.lang.Object) fixedMillisecond17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int21 = day19.compareTo((java.lang.Object) 9);
//        int int22 = day19.getMonth();
//        long long23 = day19.getMiddleMillisecond();
//        int int24 = day19.getDayOfMonth();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.addAndOrUpdate(timeSeries29);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
//        int int39 = month37.getMonth();
//        long long40 = month37.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) 2);
//        timeSeries34.add(timeSeriesDataItem42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries34.getNextTimePeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        long long46 = fixedMillisecond45.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond45);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        int int52 = month50.getMonth();
//        long long53 = month50.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 2);
//        timeSeries47.add(timeSeriesDataItem55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = timeSeries47.getNextTimePeriod();
//        boolean boolean58 = timeSeries47.isEmpty();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        int int61 = day59.compareTo((java.lang.Object) 9);
//        int int62 = day59.getMonth();
//        long long63 = day59.getMiddleMillisecond();
//        int int64 = day59.getDayOfMonth();
//        java.lang.Number number65 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day59);
//        boolean boolean66 = timeSeries34.equals((java.lang.Object) number65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        int int69 = day67.compareTo((java.lang.Object) 9);
//        int int70 = day67.getMonth();
//        long long71 = day67.getLastMillisecond();
//        java.lang.Number number72 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day67);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day67, (double) 1560185750777L);
//        org.jfree.data.time.SerialDate serialDate75 = day67.getSerialDate();
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(serialDate75);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185816370L + "'", long1 == 1560185816370L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185816371L + "'", long4 == 1560185816371L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600001L) + "'", long11 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560193199999L + "'", long23 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560185816375L + "'", long33 == 1560185816375L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62112153600001L) + "'", long40 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560185816376L + "'", long46 == 1560185816376L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 9 + "'", int52 == 9);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62112153600001L) + "'", long53 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560193199999L + "'", long63 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
//        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 2 + "'", number65.equals(2));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560236399999L + "'", long71 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 2 + "'", number72.equals(2));
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(serialDate75);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries2.setMaximumItemCount((int) (short) 10);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo22);
//        boolean boolean24 = timeSeries2.equals((java.lang.Object) seriesChangeEvent21);
//        timeSeries2.removeAgedItems(true);
//        java.lang.Object obj27 = timeSeries2.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getLastMillisecond(calendar31);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond28.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185816960L + "'", long1 == 1560185816960L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185816961L + "'", long4 == 1560185816961L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185816961L + "'", long6 == 1560185816961L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185816961L + "'", long7 == 1560185816961L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185816964L + "'", long32 == 1560185816964L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.jfree.data.time.Year year7 = month2.getYear();
        int int9 = year7.compareTo((java.lang.Object) 1560185750526L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date9);
//        java.lang.Object obj15 = null;
//        int int16 = day14.compareTo(obj15);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        long long16 = timeSeries2.getMaximumItemAge();
//        timeSeries2.setDomainDescription("September 0");
//        timeSeries2.setRangeDescription("Mon Jun 10 09:56:20 PDT 2019");
//        java.lang.Comparable comparable21 = timeSeries2.getKey();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185817148L + "'", long1 == 1560185817148L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560185732869L + "'", long16 == 1560185732869L);
//        org.junit.Assert.assertNotNull(comparable21);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int7 = day5.compareTo((java.lang.Object) 9);
//        long long8 = day5.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
//        java.util.Date date10 = day5.getStart();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date10, timeZone12);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.addOrUpdate(regularTimePeriod19, (double) 1560185737482L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener22);
//        double double24 = timeSeries2.getMinY();
//        timeSeries2.setDescription("org.jfree.data.event.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        long long28 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond27);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
//        int int34 = month32.getMonth();
//        long long35 = month32.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 2);
//        timeSeries29.add(timeSeriesDataItem37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeries29.getNextTimePeriod();
//        boolean boolean40 = timeSeries29.isEmpty();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int43 = day41.compareTo((java.lang.Object) 9);
//        int int44 = day41.getMonth();
//        long long45 = day41.getMiddleMillisecond();
//        int int46 = day41.getDayOfMonth();
//        java.lang.Number number47 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        long long49 = fixedMillisecond48.getLastMillisecond();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond48.getMiddleMillisecond(calendar50);
//        long long52 = fixedMillisecond48.getSerialIndex();
//        timeSeries29.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
//        int int59 = month57.getMonth();
//        org.jfree.data.time.Year year60 = month57.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month57.next();
//        timeSeries29.update((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 9223372036854775807L);
//        double double64 = timeSeries29.getMaxY();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = timeSeries29.getTimePeriod((int) (byte) 0);
//        java.lang.Number number67 = timeSeries2.getValue(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185817301L + "'", long1 == 1560185817301L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185817301L + "'", long4 == 1560185817301L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185817301L + "'", long6 == 1560185817301L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185817301L + "'", long7 == 1560185817301L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.560185737482E12d + "'", double24 == 1.560185737482E12d);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560185817325L + "'", long28 == 1560185817325L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112153600001L) + "'", long35 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560193199999L + "'", long45 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 2 + "'", number47.equals(2));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560185817328L + "'", long49 == 1560185817328L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560185817328L + "'", long51 == 1560185817328L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560185817328L + "'", long52 == 1560185817328L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 9 + "'", int59 == 9);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 9.223372036854776E18d + "'", double64 == 9.223372036854776E18d);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 1.560185737482E12d + "'", number67.equals(1.560185737482E12d));
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.String str7 = year6.toString();
//        long long8 = year6.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "10-June-2019", "");
//        timeSeries8.setMaximumItemCount(2147483647);
//        boolean boolean11 = timeSeries8.getNotify();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185817774L + "'", long1 == 1560185817774L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185817774L + "'", long4 == 1560185817774L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.Date date14 = fixedMillisecond13.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
//        int int18 = month16.compareTo((java.lang.Object) 1560185737735L);
//        long long19 = month16.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener12);
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        int int15 = timeSeries2.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185817860L + "'", long1 == 1560185817860L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        boolean boolean4 = timeSeriesDataItem2.isSelected();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.TimeZone timeZone8 = null;
//        try {
//            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5, timeZone8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener12);
//        int int14 = timeSeries2.getItemCount();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getMonth();
//        org.jfree.data.time.Year year20 = month17.getYear();
//        java.lang.String str21 = month17.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 1560185732223L);
//        long long24 = month17.getSerialIndex();
//        long long25 = month17.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185817921L + "'", long1 == 1560185817921L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "September 0" + "'", str21.equals("September 0"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9L + "'", long24 == 9L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62112153600001L) + "'", long25 == (-62112153600001L));
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.lang.Object obj10 = timeSeries2.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
//        int int18 = month16.getMonth();
//        long long19 = month16.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 2);
//        timeSeries13.add(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries13.getNextTimePeriod();
//        boolean boolean24 = timeSeries13.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean26 = timeSeries13.equals((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int29 = day27.compareTo((java.lang.Object) 9);
//        int int30 = day27.getMonth();
//        long long31 = day27.getMiddleMillisecond();
//        int int32 = day27.getDayOfMonth();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        int int34 = day27.getMonth();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day27, (double) 1560185754923L);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        long long41 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond40);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month45.next();
//        int int47 = month45.getMonth();
//        long long48 = month45.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (java.lang.Number) 2);
//        timeSeries42.add(timeSeriesDataItem50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeries42.getNextTimePeriod();
//        boolean boolean53 = timeSeries42.isEmpty();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        int int56 = day54.compareTo((java.lang.Object) 9);
//        int int57 = day54.getMonth();
//        long long58 = day54.getMiddleMillisecond();
//        int int59 = day54.getDayOfMonth();
//        java.lang.Number number60 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) day54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        long long62 = fixedMillisecond61.getLastMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond61.getMiddleMillisecond(calendar63);
//        long long65 = fixedMillisecond61.getSerialIndex();
//        timeSeries42.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        long long69 = fixedMillisecond68.getLastMillisecond();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond68.getMiddleMillisecond(calendar70);
//        long long72 = fixedMillisecond68.getSerialIndex();
//        timeSeries42.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560185749314L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond68.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond68.next();
//        int int77 = day37.compareTo((java.lang.Object) regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818017L + "'", long1 == 1560185818017L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185818018L + "'", long4 == 1560185818018L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185818018L + "'", long6 == 1560185818018L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185818018L + "'", long7 == 1560185818018L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560185818020L + "'", long12 == 1560185818020L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62112153600001L) + "'", long19 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560185818025L + "'", long41 == 1560185818025L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62112153600001L) + "'", long48 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560193199999L + "'", long58 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 2 + "'", number60.equals(2));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560185818049L + "'", long62 == 1560185818049L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560185818049L + "'", long64 == 1560185818049L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560185818049L + "'", long65 == 1560185818049L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560185818050L + "'", long69 == 1560185818050L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560185818050L + "'", long71 == 1560185818050L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560185818050L + "'", long72 == 1560185818050L);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        timeSeries2.removeAgedItems(1560185786798L, true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        int int15 = month13.getMonth();
//        org.jfree.data.time.Year year16 = month13.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
//        long long22 = fixedMillisecond17.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 10);
//        int int25 = month13.compareTo((java.lang.Object) timeSeriesDataItem24);
//        long long26 = month13.getLastMillisecond();
//        int int27 = month13.getYearValue();
//        org.jfree.data.time.Year year28 = month13.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year28, (double) 1560185794023L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818445L + "'", long1 == 1560185818445L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560185818447L + "'", long21 == 1560185818447L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185818447L + "'", long22 == 1560185818447L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62112153600001L) + "'", long26 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "September 0", seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=September 0]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=September 0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=September 0]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=September 0]"));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries2.setMaximumItemCount((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond23.previous();
//        long long26 = fixedMillisecond23.getSerialIndex();
//        long long27 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.next();
//        int int33 = month31.getMonth();
//        long long34 = month31.getLastMillisecond();
//        int int35 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month31);
//        java.lang.Number number36 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) month31);
//        int int37 = month31.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818507L + "'", long1 == 1560185818507L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185818508L + "'", long4 == 1560185818508L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185818508L + "'", long6 == 1560185818508L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185818508L + "'", long7 == 1560185818508L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560185818510L + "'", long21 == 1560185818510L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185818531L + "'", long24 == 1560185818531L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560185818531L + "'", long26 == 1560185818531L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560185818531L + "'", long27 == 1560185818531L);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62112153600001L) + "'", long34 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        int int19 = day16.getMonth();
//        long long20 = day16.getMiddleMillisecond();
//        int int21 = day16.getDayOfMonth();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int25 = day23.compareTo((java.lang.Object) 9);
//        int int26 = day23.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day23);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day23.getLastMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818594L + "'", long1 == 1560185818594L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        long long25 = fixedMillisecond21.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
//        long long32 = fixedMillisecond28.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1560185749314L);
//        int int35 = timeSeries2.getItemCount();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int38 = day36.compareTo((java.lang.Object) 9);
//        int int39 = day36.getMonth();
//        long long40 = day36.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day36.previous();
//        timeSeries2.update(regularTimePeriod41, (java.lang.Number) 1560185736538L);
//        timeSeries2.setDomainDescription("Value");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries2.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818610L + "'", long1 == 1560185818610L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185818614L + "'", long22 == 1560185818614L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185818614L + "'", long24 == 1560185818614L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185818614L + "'", long25 == 1560185818614L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185818634L + "'", long29 == 1560185818634L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185818634L + "'", long31 == 1560185818634L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185818634L + "'", long32 == 1560185818634L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 100.0d);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185818730L + "'", long3 == 1560185818730L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185818730L + "'", long4 == 1560185818730L);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(2019);
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) year14);
//        java.lang.Object obj16 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185734796L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818739L + "'", long1 == 1560185818739L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185818741L + "'", long9 == 1560185818741L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj16);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 09:56:20 PDT 2019");
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        long long5 = day0.getFirstMillisecond();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = year6.equals((java.lang.Object) day9);
//        java.util.Date date11 = day9.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = year6.equals((java.lang.Object) day9);
//        long long11 = year6.getFirstMillisecond();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = year6.equals(obj12);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        java.lang.String str13 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14);
//        timeSeries16.setDomainDescription("10-June-2019");
//        java.lang.Object obj19 = timeSeries16.clone();
//        timeSeries16.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int24 = day22.compareTo((java.lang.Object) 9);
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day22.previous();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) year27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond30);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        int int37 = month35.getMonth();
//        long long38 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 2);
//        timeSeries32.add(timeSeriesDataItem40);
//        timeSeries29.add(timeSeriesDataItem40);
//        timeSeries2.add(timeSeriesDataItem40);
//        timeSeriesDataItem40.setSelected(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818876L + "'", long1 == 1560185818876L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185818877L + "'", long9 == 1560185818877L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185818878L + "'", long15 == 1560185818878L);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185818881L + "'", long31 == 1560185818881L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62112153600001L) + "'", long38 == (-62112153600001L));
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int22 = day20.compareTo((java.lang.Object) 9);
//        long long23 = day20.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
//        java.util.Date date25 = day20.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date25);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 1560185742933L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond29.previous();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond29);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int37 = day35.compareTo((java.lang.Object) 9);
//        long long38 = day35.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day35.previous();
//        long long40 = day35.getLastMillisecond();
//        long long41 = day35.getLastMillisecond();
//        java.lang.Number number42 = null;
//        try {
//            timeSeries34.update((org.jfree.data.time.RegularTimePeriod) day35, number42);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185818992L + "'", long1 == 1560185818992L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.Year year14 = month13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getMiddleMillisecond(calendar11);
//        long long13 = fixedMillisecond8.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185819097L + "'", long1 == 1560185819097L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185819098L + "'", long9 == 1560185819098L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560185819098L + "'", long12 == 1560185819098L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185819098L + "'", long13 == 1560185819098L);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9);
//        java.util.Date date16 = month15.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
//        int int24 = month22.getMonth();
//        long long25 = month22.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 2);
//        timeSeries19.add(timeSeriesDataItem27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries19.getNextTimePeriod();
//        boolean boolean30 = timeSeries19.isEmpty();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int33 = day31.compareTo((java.lang.Object) 9);
//        int int34 = day31.getMonth();
//        long long35 = day31.getMiddleMillisecond();
//        int int36 = day31.getDayOfMonth();
//        java.lang.Number number37 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getLastMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond38.getMiddleMillisecond(calendar40);
//        long long42 = fixedMillisecond38.getSerialIndex();
//        timeSeries19.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.next();
//        int int49 = month47.getMonth();
//        org.jfree.data.time.Year year50 = month47.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month47.next();
//        timeSeries19.update((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) 9223372036854775807L);
//        double double54 = timeSeries19.getMaxY();
//        int int55 = month15.compareTo((java.lang.Object) timeSeries19);
//        long long56 = month15.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560185819146L + "'", long18 == 1560185819146L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62112153600001L) + "'", long25 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560193199999L + "'", long35 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 2 + "'", number37.equals(2));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560185819149L + "'", long39 == 1560185819149L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560185819149L + "'", long41 == 1560185819149L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560185819149L + "'", long42 == 1560185819149L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 9 + "'", int49 == 9);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 9.223372036854776E18d + "'", double54 == 9.223372036854776E18d);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1561964399999L + "'", long56 == 1561964399999L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = month2.equals((java.lang.Object) timeSeries9);
        timeSeries9.removeAgedItems(1560185792637L, false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62112153600001L) + "'", long5 == (-62112153600001L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        int int23 = month21.getMonth();
//        long long24 = month21.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 2);
//        timeSeries18.add(timeSeriesDataItem26);
//        timeSeries15.add(timeSeriesDataItem26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        long long30 = fixedMillisecond29.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond29);
//        timeSeries31.setDomainDescription("10-June-2019");
//        java.lang.Object obj34 = timeSeries31.clone();
//        timeSeries31.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int39 = day37.compareTo((java.lang.Object) 9);
//        long long40 = day37.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day37.previous();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day37, (org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        long long46 = fixedMillisecond45.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond45);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        int int52 = month50.getMonth();
//        long long53 = month50.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 2);
//        timeSeries47.add(timeSeriesDataItem55);
//        timeSeries44.add(timeSeriesDataItem55);
//        boolean boolean59 = timeSeriesDataItem55.equals((java.lang.Object) 1560185738184L);
//        java.lang.Object obj60 = timeSeriesDataItem55.clone();
//        int int61 = timeSeriesDataItem26.compareTo(obj60);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185819408L + "'", long1 == 1560185819408L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560185819410L + "'", long17 == 1560185819410L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62112153600001L) + "'", long24 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560185819433L + "'", long30 == 1560185819433L);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43626L + "'", long40 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560185819435L + "'", long46 == 1560185819435L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 9 + "'", int52 == 9);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62112153600001L) + "'", long53 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(obj60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        double double14 = timeSeries2.getMinY();
//        boolean boolean15 = timeSeries2.isEmpty();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185819878L + "'", long1 == 1560185819878L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries2.setMaximumItemCount((int) (short) 10);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo22);
//        boolean boolean24 = timeSeries2.equals((java.lang.Object) seriesChangeEvent21);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo25);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo27);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = seriesChangeEvent21.getSummary();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = seriesChangeEvent21.getSummary();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185819905L + "'", long1 == 1560185819905L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185819905L + "'", long4 == 1560185819905L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185819905L + "'", long6 == 1560185819905L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185819905L + "'", long7 == 1560185819905L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNull(seriesChangeInfo29);
//        org.junit.Assert.assertNull(seriesChangeInfo30);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        timeSeries2.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185819958L + "'", long1 == 1560185819958L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        long long25 = fixedMillisecond21.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
//        long long32 = fixedMillisecond28.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1560185749314L);
//        int int35 = timeSeries2.getItemCount();
//        java.lang.Class class36 = timeSeries2.getTimePeriodClass();
//        java.lang.String str37 = timeSeries2.getDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185820032L + "'", long1 == 1560185820032L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185820035L + "'", long22 == 1560185820035L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185820035L + "'", long24 == 1560185820035L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185820035L + "'", long25 == 1560185820035L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185820035L + "'", long29 == 1560185820035L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185820035L + "'", long31 == 1560185820035L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185820035L + "'", long32 == 1560185820035L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNull(str37);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185820160L + "'", long1 == 1560185820160L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185820160L + "'", long2 == 1560185820160L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185820160L + "'", long4 == 1560185820160L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185820160L + "'", long5 == 1560185820160L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.String str7 = year6.toString();
//        long long8 = year6.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9);
//        timeSeries11.setDomainDescription("10-June-2019");
//        int int14 = year6.compareTo((java.lang.Object) "10-June-2019");
//        long long15 = year6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year6.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185820176L + "'", long10 == 1560185820176L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getNextTimePeriod();
//        java.lang.Comparable comparable14 = timeSeries2.getKey();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
//        java.lang.String str17 = month15.toString();
//        java.lang.Number number18 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(1560185806831L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185820208L + "'", long1 == 1560185820208L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185806831L + "'", long22 == 1560185806831L);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        long long16 = timeSeries2.getMaximumItemAge();
//        timeSeries2.setDomainDescription("September 0");
//        timeSeries2.clear();
//        double double20 = timeSeries2.getMinY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 100.0d);
//        timeSeriesDataItem23.setSelected(true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem23.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (java.lang.Number) 1560185750115L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries2.addOrUpdate(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185820282L + "'", long1 == 1560185820282L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560185732869L + "'", long16 == 1560185732869L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1560185730157L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5);
//        timeSeries7.setDomainDescription("10-June-2019");
//        java.lang.Object obj10 = timeSeries7.clone();
//        timeSeries7.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        int int16 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeriesDataItem15);
//        java.lang.Object obj17 = timeSeriesDataItem4.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem4.getPeriod();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185820385L + "'", long6 == 1560185820385L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185820386L + "'", long14 == 1560185820386L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9);
//        java.util.Date date16 = month15.getEnd();
//        java.util.TimeZone timeZone17 = null;
//        try {
//            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.lang.Object obj10 = timeSeries2.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
//        int int18 = month16.getMonth();
//        long long19 = month16.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 2);
//        timeSeries13.add(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries13.getNextTimePeriod();
//        boolean boolean24 = timeSeries13.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean26 = timeSeries13.equals((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int29 = day27.compareTo((java.lang.Object) 9);
//        int int30 = day27.getMonth();
//        long long31 = day27.getMiddleMillisecond();
//        int int32 = day27.getDayOfMonth();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        int int34 = day27.getMonth();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day27, (double) 1560185754923L);
//        timeSeries2.setMaximumItemAge(0L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        long long40 = fixedMillisecond39.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond39);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
//        int int46 = month44.getMonth();
//        long long47 = month44.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 2);
//        timeSeries41.add(timeSeriesDataItem49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeries41.getNextTimePeriod();
//        boolean boolean52 = timeSeries41.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean54 = timeSeries41.equals((java.lang.Object) fixedMillisecond53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int57 = day55.compareTo((java.lang.Object) 9);
//        int int58 = day55.getMonth();
//        long long59 = day55.getMiddleMillisecond();
//        int int60 = day55.getDayOfMonth();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries41.addAndOrUpdate(timeSeries65);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
//        timeSeries41.addChangeListener(seriesChangeListener67);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries2.addAndOrUpdate(timeSeries41);
//        java.lang.String str70 = timeSeries69.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185820436L + "'", long1 == 1560185820436L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185820437L + "'", long4 == 1560185820437L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185820437L + "'", long6 == 1560185820437L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185820437L + "'", long7 == 1560185820437L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560185820438L + "'", long12 == 1560185820438L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62112153600001L) + "'", long19 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560185820463L + "'", long40 == 1560185820463L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62112153600001L) + "'", long47 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560193199999L + "'", long59 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Value" + "'", str70.equals("Value"));
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getMonth();
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193199999L + "'", long4 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int20 = day18.compareTo((java.lang.Object) 9);
//        long long21 = day18.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate22 = day18.getSerialDate();
//        java.util.Date date23 = day18.getStart();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date23, timeZone25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date23);
//        int int28 = month27.getYearValue();
//        java.lang.String str29 = month27.toString();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month27);
//        long long31 = month27.getSerialIndex();
//        java.util.Calendar calendar32 = null;
//        try {
//            month27.peg(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185820736L + "'", long1 == 1560185820736L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        long long6 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        long long8 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193199999L + "'", long6 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
//        timeSeriesDataItem8.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
//        int int16 = timeSeriesDataItem8.compareTo((java.lang.Object) calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        boolean boolean23 = timeSeriesDataItem8.equals((java.lang.Object) timePeriodFormatException18);
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException18.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass27 = timePeriodFormatException26.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
//        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
//        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
//        java.lang.Throwable[] throwableArray35 = timePeriodFormatException26.getSuppressed();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185820792L + "'", long15 == 1560185820792L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(throwableArray35);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        long long25 = fixedMillisecond21.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
//        long long32 = fixedMillisecond28.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1560185749314L);
//        int int35 = timeSeries2.getItemCount();
//        java.lang.Class class36 = timeSeries2.getTimePeriodClass();
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185820910L + "'", long1 == 1560185820910L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185820933L + "'", long22 == 1560185820933L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185820933L + "'", long24 == 1560185820933L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185820933L + "'", long25 == 1560185820933L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185820934L + "'", long29 == 1560185820934L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185820934L + "'", long31 == 1560185820934L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185820934L + "'", long32 == 1560185820934L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        int int4 = month2.getMonth();
//        long long5 = month2.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 2);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day8);
//        boolean boolean14 = month2.equals((java.lang.Object) day8);
//        long long15 = month2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62112153600001L) + "'", long5 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62112153600001L) + "'", long15 == (-62112153600001L));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.util.List list13 = timeSeries2.getItems();
//        java.lang.String str14 = timeSeries2.getDomainDescription();
//        timeSeries2.setKey((java.lang.Comparable) 1560185736734L);
//        long long17 = timeSeries2.getMaximumItemAge();
//        timeSeries2.fireSeriesChanged();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        int int20 = year19.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass23 = timePeriodFormatException22.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int27 = day25.compareTo((java.lang.Object) 9);
//        long long28 = day25.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
//        java.util.Date date30 = day25.getStart();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30);
//        boolean boolean35 = year19.equals((java.lang.Object) month34);
//        long long36 = year19.getFirstMillisecond();
//        try {
//            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 1560185818634L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185821012L + "'", long1 == 1560185821012L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries2.getKey();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
//        int int17 = month15.getMonth();
//        org.jfree.data.time.Year year18 = month15.getYear();
//        int int19 = year18.getYear();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
//        boolean boolean22 = year18.equals((java.lang.Object) year20);
//        long long23 = year18.getFirstMillisecond();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 100.0d);
//        long long28 = fixedMillisecond25.getFirstMillisecond();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.next();
//        int int33 = month31.getMonth();
//        org.jfree.data.time.Year year34 = month31.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond35.getLastMillisecond(calendar38);
//        long long40 = fixedMillisecond35.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 10);
//        int int43 = month31.compareTo((java.lang.Object) timeSeriesDataItem42);
//        long long44 = month31.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long44, "", "10-June-2019");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        int int52 = month50.getMonth();
//        long long53 = month50.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 2);
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) (byte) 1);
//        boolean boolean58 = fixedMillisecond25.equals((java.lang.Object) timeSeries47);
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries47.addPropertyChangeListener(propertyChangeListener59);
//        boolean boolean61 = year18.equals((java.lang.Object) propertyChangeListener59);
//        java.util.Date date62 = year18.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185821078L + "'", long1 == 1560185821078L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185821079L + "'", long4 == 1560185821079L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185821079L + "'", long6 == 1560185821079L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185821079L + "'", long7 == 1560185821079L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(comparable12);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62167363200000L) + "'", long23 == (-62167363200000L));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560185821083L + "'", long28 == 1560185821083L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560185821084L + "'", long39 == 1560185821084L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560185821084L + "'", long40 == 1560185821084L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62112153600001L) + "'", long44 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 9 + "'", int52 == 9);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62112153600001L) + "'", long53 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(date62);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
//        timeSeriesDataItem8.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
//        int int16 = timeSeriesDataItem8.compareTo((java.lang.Object) calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        boolean boolean23 = timeSeriesDataItem8.equals((java.lang.Object) timePeriodFormatException18);
//        int int25 = timeSeriesDataItem8.compareTo((java.lang.Object) 1560185761656L);
//        boolean boolean27 = timeSeriesDataItem8.equals((java.lang.Object) 1.560185750777E12d);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185821627L + "'", long15 == 1560185821627L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date9, timeZone12);
//        java.util.TimeZone timeZone14 = null;
//        try {
//            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9, timeZone14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=September 0]");
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) -1);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 9);
//        long long9 = day6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day6, (double) 1560185733359L);
//        timeSeries3.setMaximumItemAge(1560185748992L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond15);
//        java.lang.Comparable comparable18 = timeSeries17.getKey();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.addAndOrUpdate(timeSeries17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        long long23 = fixedMillisecond20.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 100.0d);
//        boolean boolean27 = fixedMillisecond20.equals((java.lang.Object) timeSeriesDataItem26);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond20);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560185821755L + "'", long16 == 1560185821755L);
//        org.junit.Assert.assertNotNull(comparable18);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560185821756L + "'", long21 == 1560185821756L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560185821756L + "'", long23 == 1560185821756L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
//        int int24 = month22.getMonth();
//        long long25 = month22.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 2);
//        timeSeries19.add(timeSeriesDataItem27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries19.getNextTimePeriod();
//        boolean boolean30 = timeSeries19.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean32 = timeSeries19.equals((java.lang.Object) fixedMillisecond31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int35 = day33.compareTo((java.lang.Object) 9);
//        int int36 = day33.getMonth();
//        long long37 = day33.getMiddleMillisecond();
//        int int38 = day33.getDayOfMonth();
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries19.addAndOrUpdate(timeSeries43);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries16.addAndOrUpdate(timeSeries44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        long long47 = fixedMillisecond46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond46);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month51.next();
//        int int53 = month51.getMonth();
//        long long54 = month51.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 2);
//        timeSeries48.add(timeSeriesDataItem56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeries48.getNextTimePeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        long long60 = fixedMillisecond59.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond59);
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month64.next();
//        int int66 = month64.getMonth();
//        long long67 = month64.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) 2);
//        timeSeries61.add(timeSeriesDataItem69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = timeSeries61.getNextTimePeriod();
//        boolean boolean72 = timeSeries61.isEmpty();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        int int75 = day73.compareTo((java.lang.Object) 9);
//        int int76 = day73.getMonth();
//        long long77 = day73.getMiddleMillisecond();
//        int int78 = day73.getDayOfMonth();
//        java.lang.Number number79 = timeSeries61.getValue((org.jfree.data.time.RegularTimePeriod) day73);
//        boolean boolean80 = timeSeries48.equals((java.lang.Object) number79);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        int int83 = day81.compareTo((java.lang.Object) 9);
//        int int84 = day81.getMonth();
//        long long85 = day81.getLastMillisecond();
//        java.lang.Number number86 = timeSeries48.getValue((org.jfree.data.time.RegularTimePeriod) day81);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day81, (double) 1560185750777L);
//        org.jfree.data.time.SerialDate serialDate89 = day81.getSerialDate();
//        java.util.Date date90 = day81.getStart();
//        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date90);
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date90);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem94 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year92, (java.lang.Number) 1560185793540L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185821816L + "'", long1 == 1560185821816L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185821817L + "'", long4 == 1560185821817L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185821817L + "'", long6 == 1560185821817L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185821817L + "'", long7 == 1560185821817L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185821819L + "'", long15 == 1560185821819L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560185821819L + "'", long18 == 1560185821819L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62112153600001L) + "'", long25 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560193199999L + "'", long37 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560185821823L + "'", long47 == 1560185821823L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 9 + "'", int53 == 9);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62112153600001L) + "'", long54 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560185821845L + "'", long60 == 1560185821845L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 9 + "'", int66 == 9);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-62112153600001L) + "'", long67 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 6 + "'", int76 == 6);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560193199999L + "'", long77 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 10 + "'", int78 == 10);
//        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 2 + "'", number79.equals(2));
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 6 + "'", int84 == 6);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560236399999L + "'", long85 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 2 + "'", number86.equals(2));
//        org.junit.Assert.assertNull(timeSeriesDataItem88);
//        org.junit.Assert.assertNotNull(serialDate89);
//        org.junit.Assert.assertNotNull(date90);
//        org.junit.Assert.assertNull(timeSeriesDataItem94);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) -1 + "'", obj3.equals((short) -1));
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(9);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 1560185730188L);
//        timeSeries15.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22);
//        timeSeries24.setDomainDescription("10-June-2019");
//        java.lang.Object obj27 = timeSeries24.clone();
//        timeSeries24.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 9);
//        long long33 = day30.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day30.previous();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) year35);
//        java.util.Collection collection38 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        boolean boolean39 = timeSeries37.getNotify();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeries37.getTimePeriod((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822612L + "'", long1 == 1560185822612L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560185822634L + "'", long23 == 1560185822634L);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.lang.String str3 = fixedMillisecond0.toString();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822649L + "'", long1 == 1560185822649L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185822649L + "'", long2 == 1560185822649L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mon Jun 10 09:57:02 PDT 2019" + "'", str3.equals("Mon Jun 10 09:57:02 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185822649L + "'", long6 == 1560185822649L);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        boolean boolean16 = timeSeries2.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy(0, 0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822658L + "'", long1 == 1560185822658L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        long long11 = month8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 2);
//        timeSeries5.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        int int16 = fixedMillisecond0.compareTo((java.lang.Object) regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int16);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries17.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822695L + "'", long1 == 1560185822695L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185822695L + "'", long4 == 1560185822695L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600001L) + "'", long11 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener11);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822709L + "'", long1 == 1560185822709L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185822710L + "'", long9 == 1560185822710L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.lang.String str3 = fixedMillisecond0.toString();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822724L + "'", long1 == 1560185822724L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185822724L + "'", long2 == 1560185822724L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mon Jun 10 09:57:02 PDT 2019" + "'", str3.equals("Mon Jun 10 09:57:02 PDT 2019"));
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries2.createCopy(0, (int) (short) 100);
//        java.lang.Comparable comparable6 = timeSeries5.getKey();
//        timeSeries5.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822753L + "'", long1 == 1560185822753L);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(comparable6);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 8, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        int int5 = year3.compareTo((java.lang.Object) 1560185821817L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822775L + "'", long1 == 1560185822775L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        int int21 = day14.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822788L + "'", long1 == 1560185822788L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        boolean boolean12 = timeSeries2.getNotify();
//        timeSeries2.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=September 0]");
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
//        java.lang.Number number18 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year15);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822865L + "'", long1 == 1560185822865L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185822865L + "'", long4 == 1560185822865L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185822865L + "'", long6 == 1560185822865L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185822865L + "'", long7 == 1560185822865L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62112153600001L) + "'", long5 == (-62112153600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=-1]"));
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.lang.Object obj10 = timeSeries2.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
//        int int18 = month16.getMonth();
//        long long19 = month16.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 2);
//        timeSeries13.add(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries13.getNextTimePeriod();
//        boolean boolean24 = timeSeries13.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean26 = timeSeries13.equals((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int29 = day27.compareTo((java.lang.Object) 9);
//        int int30 = day27.getMonth();
//        long long31 = day27.getMiddleMillisecond();
//        int int32 = day27.getDayOfMonth();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        int int34 = day27.getMonth();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day27, (double) 1560185754923L);
//        long long37 = day27.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185822940L + "'", long1 == 1560185822940L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185822941L + "'", long4 == 1560185822941L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185822941L + "'", long6 == 1560185822941L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185822941L + "'", long7 == 1560185822941L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560185822942L + "'", long12 == 1560185822942L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62112153600001L) + "'", long19 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 9);
//        long long9 = day6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        long long11 = day6.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day6.getSerialDate();
//        int int13 = day0.compareTo((java.lang.Object) serialDate12);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = month2.equals((java.lang.Object) timeSeries9);
        java.lang.String str13 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62112153600001L) + "'", long5 == (-62112153600001L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "September 0" + "'", str13.equals("September 0"));
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        int int19 = day16.getMonth();
//        long long20 = day16.getMiddleMillisecond();
//        int int21 = day16.getDayOfMonth();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int25 = day23.compareTo((java.lang.Object) 9);
//        int int26 = day23.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.next();
//        int int32 = month30.getMonth();
//        org.jfree.data.time.Year year33 = month30.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond34.getLastMillisecond(calendar37);
//        long long39 = fixedMillisecond34.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 10);
//        int int42 = month30.compareTo((java.lang.Object) timeSeriesDataItem41);
//        timeSeriesDataItem41.setSelected(false);
//        timeSeries2.add(timeSeriesDataItem41, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        long long48 = fixedMillisecond47.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond47);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month52.next();
//        int int54 = month52.getMonth();
//        long long55 = month52.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month52, (java.lang.Number) 2);
//        timeSeries49.add(timeSeriesDataItem57);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener59);
//        int int61 = timeSeries49.getItemCount();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month64.next();
//        int int66 = month64.getMonth();
//        org.jfree.data.time.Year year67 = month64.getYear();
//        java.lang.String str68 = month64.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month64, (double) 1560185732223L);
//        boolean boolean71 = timeSeriesDataItem70.isSelected();
//        try {
//            timeSeries2.add(timeSeriesDataItem70, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823077L + "'", long1 == 1560185823077L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560185823082L + "'", long38 == 1560185823082L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560185823082L + "'", long39 == 1560185823082L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560185823083L + "'", long48 == 1560185823083L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 9 + "'", int54 == 9);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62112153600001L) + "'", long55 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 9 + "'", int66 == 9);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "September 0" + "'", str68.equals("September 0"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        long long11 = month8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 2);
//        timeSeries5.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        java.lang.Comparable comparable16 = timeSeries5.getKey();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries5.addChangeListener(seriesChangeListener17);
//        boolean boolean19 = timeSeries5.isEmpty();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries5);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185823166L + "'", long4 == 1560185823166L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600001L) + "'", long11 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(comparable16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        long long11 = month8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 2);
//        timeSeries5.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        int int16 = fixedMillisecond0.compareTo((java.lang.Object) regularTimePeriod15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823201L + "'", long1 == 1560185823201L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185823201L + "'", long4 == 1560185823201L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600001L) + "'", long11 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener13);
//        double double15 = timeSeries2.getMinY();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823243L + "'", long1 == 1560185823243L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185823263L + "'", long9 == 1560185823263L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 9);
//        long long9 = day6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day6, (double) 1560185733359L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 9);
//        long long16 = day13.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        java.util.Date date18 = day13.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, 0.0d);
//        timeSeries3.setKey((java.lang.Comparable) 0.0d);
//        boolean boolean23 = timeSeries3.getNotify();
//        timeSeries3.setRangeDescription("Mon Jun 10 09:57:02 PDT 2019");
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1L));
//        int int6 = year3.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        boolean boolean12 = year3.equals((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod11, (java.lang.Number) 0);
//        boolean boolean15 = timeSeriesDataItem14.isSelected();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823330L + "'", long1 == 1560185823330L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        int int19 = day16.getMonth();
//        long long20 = day16.getMiddleMillisecond();
//        int int21 = day16.getDayOfMonth();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries2.addAndOrUpdate(timeSeries26);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries2.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
//        int int34 = month32.getMonth();
//        org.jfree.data.time.Year year35 = month32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month32.previous();
//        org.jfree.data.time.Year year37 = month32.getYear();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year37, (double) 1560185753888L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        long long41 = fixedMillisecond40.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond40.previous();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond40.getMiddleMillisecond(calendar43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int47 = day45.compareTo((java.lang.Object) 9);
//        int int48 = day45.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day45.previous();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, regularTimePeriod49);
//        try {
//            java.lang.Number number52 = timeSeries50.getValue(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823363L + "'", long1 == 1560185823363L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560185823389L + "'", long41 == 1560185823389L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560185823389L + "'", long44 == 1560185823389L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = month2.toString();
        java.lang.Class<?> wildcardClass7 = month2.getClass();
        java.lang.String str8 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "September 0" + "'", str6.equals("September 0"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "September 0" + "'", str8.equals("September 0"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62112153600001L) + "'", long5 == (-62112153600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries2.setMaximumItemCount((int) (short) 10);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo22);
//        boolean boolean24 = timeSeries2.equals((java.lang.Object) seriesChangeEvent21);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int27 = day25.compareTo((java.lang.Object) 9);
//        int int28 = day25.getMonth();
//        long long29 = day25.getMiddleMillisecond();
//        int int30 = day25.getYear();
//        java.lang.Number number31 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        java.util.Collection collection32 = timeSeries2.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823440L + "'", long1 == 1560185823440L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185823440L + "'", long4 == 1560185823440L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185823440L + "'", long6 == 1560185823440L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185823440L + "'", long7 == 1560185823440L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560193199999L + "'", long29 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertNotNull(collection32);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        int int6 = month4.getMonth();
        long long7 = month4.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month4.previous();
        long long11 = month4.getSerialIndex();
        boolean boolean12 = year1.equals((java.lang.Object) long11);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62112153600001L) + "'", long7 == (-62112153600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
//        try {
//            timeSeries2.add(regularTimePeriod10, (java.lang.Number) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823535L + "'", long1 == 1560185823535L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185823536L + "'", long4 == 1560185823536L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185823536L + "'", long6 == 1560185823536L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185823536L + "'", long7 == 1560185823536L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560185791577L, seriesChangeInfo1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        int int23 = month21.getMonth();
//        long long24 = month21.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 2);
//        timeSeries18.add(timeSeriesDataItem26);
//        timeSeries15.add(timeSeriesDataItem26);
//        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem26.getClass();
//        timeSeriesDataItem26.setValue((java.lang.Number) (byte) -1);
//        boolean boolean32 = timeSeriesDataItem26.isSelected();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem26.getPeriod();
//        java.lang.Number number34 = timeSeriesDataItem26.getValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823564L + "'", long1 == 1560185823564L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560185823567L + "'", long17 == 1560185823567L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62112153600001L) + "'", long24 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (byte) -1 + "'", number34.equals((byte) -1));
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        timeSeries2.setNotify(true);
//        timeSeries2.setRangeDescription("Mon Jun 10 09:56:03 PDT 2019");
//        timeSeries2.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823737L + "'", long1 == 1560185823737L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185823738L + "'", long9 == 1560185823738L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        long long11 = month8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 2);
//        timeSeries5.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        int int16 = fixedMillisecond0.compareTo((java.lang.Object) regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.previous();
//        long long24 = fixedMillisecond21.getSerialIndex();
//        long long25 = fixedMillisecond21.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        long long27 = timeSeries20.getMaximumItemAge();
//        java.lang.Object obj28 = timeSeries20.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        long long30 = fixedMillisecond29.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond29);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
//        int int36 = month34.getMonth();
//        long long37 = month34.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 2);
//        timeSeries31.add(timeSeriesDataItem39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeries31.getNextTimePeriod();
//        boolean boolean42 = timeSeries31.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean44 = timeSeries31.equals((java.lang.Object) fixedMillisecond43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int47 = day45.compareTo((java.lang.Object) 9);
//        int int48 = day45.getMonth();
//        long long49 = day45.getMiddleMillisecond();
//        int int50 = day45.getDayOfMonth();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day45);
//        int int52 = day45.getMonth();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day45, (double) 1560185754923L);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries61.removeAgedItems(false);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        int int66 = day64.compareTo((java.lang.Object) 9);
//        long long67 = day64.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day64.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day64, (double) 1560185733359L);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        int int73 = day71.compareTo((java.lang.Object) 9);
//        long long74 = day71.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate75 = day71.getSerialDate();
//        java.util.Date date76 = day71.getStart();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year77, 0.0d);
//        timeSeries61.setKey((java.lang.Comparable) 0.0d);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
//        timeSeries61.addChangeListener(seriesChangeListener81);
//        java.util.Collection collection83 = timeSeries61.getTimePeriods();
//        int int84 = day55.compareTo((java.lang.Object) collection83);
//        timeSeries17.setKey((java.lang.Comparable) int84);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185823754L + "'", long1 == 1560185823754L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185823754L + "'", long4 == 1560185823754L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600001L) + "'", long11 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560185823756L + "'", long19 == 1560185823756L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185823757L + "'", long22 == 1560185823757L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185823757L + "'", long24 == 1560185823757L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185823757L + "'", long25 == 1560185823757L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560185823758L + "'", long30 == 1560185823758L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 9 + "'", int36 == 9);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62112153600001L) + "'", long37 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560193199999L + "'", long49 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 43626L + "'", long67 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 43626L + "'", long74 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(collection83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560185799458L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        org.jfree.data.time.Year year9 = month2.getYear();
        int int10 = month2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62112153600001L) + "'", long5 == (-62112153600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 00:00:00 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        long long11 = month8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 2);
//        timeSeries5.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        boolean boolean16 = timeSeries5.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean18 = timeSeries5.equals((java.lang.Object) fixedMillisecond17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int21 = day19.compareTo((java.lang.Object) 9);
//        int int22 = day19.getMonth();
//        long long23 = day19.getMiddleMillisecond();
//        int int24 = day19.getDayOfMonth();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.addAndOrUpdate(timeSeries29);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
//        int int39 = month37.getMonth();
//        long long40 = month37.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) 2);
//        timeSeries34.add(timeSeriesDataItem42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries34.getNextTimePeriod();
//        boolean boolean45 = timeSeries34.isEmpty();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int48 = day46.compareTo((java.lang.Object) 9);
//        int int49 = day46.getMonth();
//        long long50 = day46.getMiddleMillisecond();
//        int int51 = day46.getDayOfMonth();
//        java.lang.Number number52 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 1560185744532L);
//        int int55 = timeSeries30.getItemCount();
//        try {
//            timeSeries30.update(5, (java.lang.Number) 1560185753973L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185824247L + "'", long1 == 1560185824247L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185824247L + "'", long4 == 1560185824247L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600001L) + "'", long11 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560193199999L + "'", long23 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560185824251L + "'", long33 == 1560185824251L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62112153600001L) + "'", long40 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560193199999L + "'", long50 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 2 + "'", number52.equals(2));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.lang.Comparable comparable13 = timeSeries2.getKey();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries2.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185824292L + "'", long1 == 1560185824292L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        java.lang.String str12 = timeSeries2.getDescription();
//        java.lang.String str13 = timeSeries2.getDescription();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries2.getDataItem((int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185824317L + "'", long1 == 1560185824317L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185824318L + "'", long9 == 1560185824318L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNull(str13);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
        timeSeries3.setDomainDescription("10-June-2019");
        timeSeries3.removeAgedItems(true);
        boolean boolean8 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 100.0d);
        timeSeriesDataItem2.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod5, (java.lang.Number) 1560185750115L);
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod5, number8);
        java.lang.Number number10 = timeSeriesDataItem9.getValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        int int15 = month13.getMonth();
        org.jfree.data.time.Year year16 = month13.getYear();
        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) year16);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        java.lang.Comparable comparable3 = timeSeries2.getKey();
//        java.lang.Object obj4 = timeSeries2.clone();
//        java.lang.Class<?> wildcardClass5 = timeSeries2.getClass();
//        int int6 = timeSeries2.getItemCount();
//        timeSeries2.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185824378L + "'", long1 == 1560185824378L);
//        org.junit.Assert.assertNotNull(comparable3);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int22 = day20.compareTo((java.lang.Object) 9);
//        long long23 = day20.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
//        java.util.Date date25 = day20.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date25);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 1560185742933L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond29.previous();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        long long36 = fixedMillisecond35.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35);
//        timeSeries37.setDomainDescription("10-June-2019");
//        java.lang.Object obj40 = timeSeries37.clone();
//        timeSeries37.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int45 = day43.compareTo((java.lang.Object) 9);
//        long long46 = day43.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day43.previous();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.next();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) year48);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(9);
//        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 1560185730188L);
//        timeSeries50.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        long long58 = fixedMillisecond57.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond57);
//        timeSeries59.setDomainDescription("10-June-2019");
//        java.lang.Object obj62 = timeSeries59.clone();
//        timeSeries59.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int67 = day65.compareTo((java.lang.Object) 9);
//        long long68 = day65.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day65.previous();
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year70.next();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries59.createCopy((org.jfree.data.time.RegularTimePeriod) day65, (org.jfree.data.time.RegularTimePeriod) year70);
//        java.util.Collection collection73 = timeSeries50.getTimePeriodsUniqueToOtherSeries(timeSeries72);
//        int int74 = fixedMillisecond29.compareTo((java.lang.Object) collection73);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185824416L + "'", long1 == 1560185824416L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560185824422L + "'", long36 == 1560185824422L);
//        org.junit.Assert.assertNotNull(obj40);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560185824424L + "'", long58 == 1560185824424L);
//        org.junit.Assert.assertNotNull(obj62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 43626L + "'", long68 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertNotNull(collection73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 1);
        long long3 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        int int19 = day16.getMonth();
//        long long20 = day16.getMiddleMillisecond();
//        int int21 = day16.getDayOfMonth();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries2.addAndOrUpdate(timeSeries26);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries2.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
//        int int34 = month32.getMonth();
//        org.jfree.data.time.Year year35 = month32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month32.previous();
//        org.jfree.data.time.Year year37 = month32.getYear();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year37, (double) 1560185753888L);
//        long long40 = year37.getMiddleMillisecond();
//        int int42 = year37.compareTo((java.lang.Object) 1560185768724L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185825986L + "'", long1 == 1560185825986L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62135784000001L) + "'", long40 == (-62135784000001L));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = month2.toString();
        java.lang.Class<?> wildcardClass7 = month2.getClass();
        boolean boolean9 = month2.equals((java.lang.Object) 1560185762533L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "September 0" + "'", str6.equals("September 0"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 9);
//        int int17 = day14.getMonth();
//        long long18 = day14.getMiddleMillisecond();
//        int int19 = day14.getDayOfMonth();
//        java.lang.Number number20 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        long long25 = fixedMillisecond21.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560185734158L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
//        long long32 = fixedMillisecond28.getSerialIndex();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1560185749314L);
//        int int35 = timeSeries2.getItemCount();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int38 = day36.compareTo((java.lang.Object) 9);
//        int int39 = day36.getMonth();
//        long long40 = day36.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day36.previous();
//        timeSeries2.update(regularTimePeriod41, (java.lang.Number) 1560185736538L);
//        timeSeries2.setDomainDescription("Value");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        long long47 = fixedMillisecond46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond46);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month51.next();
//        int int53 = month51.getMonth();
//        long long54 = month51.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 2);
//        timeSeries48.add(timeSeriesDataItem56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeries48.getNextTimePeriod();
//        boolean boolean59 = timeSeries48.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean61 = timeSeries48.equals((java.lang.Object) fixedMillisecond60);
//        java.util.Collection collection62 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185826130L + "'", long1 == 1560185826130L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2 + "'", number20.equals(2));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185826137L + "'", long22 == 1560185826137L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560185826137L + "'", long24 == 1560185826137L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560185826137L + "'", long25 == 1560185826137L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185826138L + "'", long29 == 1560185826138L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185826138L + "'", long31 == 1560185826138L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560185826138L + "'", long32 == 1560185826138L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560185826140L + "'", long47 == 1560185826140L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 9 + "'", int53 == 9);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62112153600001L) + "'", long54 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(collection62);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        java.lang.Comparable comparable13 = timeSeries2.getKey();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries2.createCopy((int) (short) 1, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185826417L + "'", long1 == 1560185826417L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(comparable13);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 100.0d);
        timeSeriesDataItem6.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem6.getPeriod();
        timeSeries3.add(timeSeriesDataItem6, false);
        java.lang.Object obj12 = timeSeriesDataItem6.clone();
        java.lang.Number number13 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0d + "'", number13.equals(100.0d));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener12);
//        int int14 = timeSeries2.getItemCount();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getMonth();
//        org.jfree.data.time.Year year20 = month17.getYear();
//        java.lang.String str21 = month17.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 1560185732223L);
//        long long24 = month17.getSerialIndex();
//        long long25 = month17.getFirstMillisecond();
//        long long26 = month17.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185826470L + "'", long1 == 1560185826470L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "September 0" + "'", str21.equals("September 0"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9L + "'", long24 == 9L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62146281600000L) + "'", long25 == (-62146281600000L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9L + "'", long26 == 9L);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 9);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        java.util.Date date9 = day4.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.TimeZone timeZone15 = null;
//        try {
//            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date9, timeZone15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        boolean boolean13 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean15 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int18 = day16.compareTo((java.lang.Object) 9);
//        int int19 = day16.getMonth();
//        long long20 = day16.getMiddleMillisecond();
//        int int21 = day16.getDayOfMonth();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries2.addAndOrUpdate(timeSeries26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int30 = day28.compareTo((java.lang.Object) 9);
//        long long31 = day28.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day28);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day28.equals(obj34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 1560185737545L);
//        java.lang.Number number38 = null;
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day28, number38, true);
//        java.util.Calendar calendar41 = null;
//        try {
//            long long42 = day28.getLastMillisecond(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185826543L + "'", long1 == 1560185826543L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        int int4 = month2.getMonth();
//        org.jfree.data.time.Year year5 = month2.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 100.0d);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getLastMillisecond(calendar9);
//        long long11 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 10);
//        int int14 = month2.compareTo((java.lang.Object) timeSeriesDataItem13);
//        timeSeriesDataItem13.setValue((java.lang.Number) 1560185728937L);
//        timeSeriesDataItem13.setSelected(false);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185826570L + "'", long10 == 1560185826570L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560185826570L + "'", long11 == 1560185826570L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.String str7 = year6.toString();
//        java.lang.String str8 = year6.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = year6.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        boolean boolean18 = timeSeries2.getNotify();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        int int23 = month21.getMonth();
//        long long24 = month21.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 2);
//        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) 1560185735798L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries2.addOrUpdate(timeSeriesDataItem26);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries33.setDomainDescription("10-June-2019");
//        timeSeries33.removeAgedItems(true);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        int int40 = day38.compareTo((java.lang.Object) 9);
//        long long41 = day38.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate42 = day38.getSerialDate();
//        java.util.Date date43 = day38.getStart();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, 0.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 1560185745363L);
//        timeSeries33.add(timeSeriesDataItem48, false);
//        java.beans.PropertyChangeListener propertyChangeListener51 = null;
//        timeSeries33.removePropertyChangeListener(propertyChangeListener51);
//        int int53 = timeSeriesDataItem26.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener54);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185826616L + "'", long1 == 1560185826616L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185826616L + "'", long4 == 1560185826616L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185826616L + "'", long6 == 1560185826616L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185826616L + "'", long7 == 1560185826616L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62112153600001L) + "'", long24 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int22 = day20.compareTo((java.lang.Object) 9);
//        long long23 = day20.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
//        java.util.Date date25 = day20.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date25);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 1560185742933L, false);
//        long long33 = fixedMillisecond29.getLastMillisecond();
//        long long34 = fixedMillisecond29.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185826743L + "'", long1 == 1560185826743L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        org.jfree.data.time.Year year11 = month8.getYear();
//        java.lang.String str12 = month8.toString();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) month8);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond0.getMiddleMillisecond(calendar14);
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond0.peg(calendar16);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185826850L + "'", long1 == 1560185826850L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185826850L + "'", long2 == 1560185826850L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185826850L + "'", long4 == 1560185826850L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185826850L + "'", long5 == 1560185826850L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "September 0" + "'", str12.equals("September 0"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185826850L + "'", long15 == 1560185826850L);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 9);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
//        int int12 = month10.getMonth();
//        long long13 = month10.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 2);
//        timeSeries7.add(timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getNextTimePeriod();
//        boolean boolean18 = timeSeries7.isEmpty();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int21 = day19.compareTo((java.lang.Object) 9);
//        int int22 = day19.getMonth();
//        long long23 = day19.getMiddleMillisecond();
//        int int24 = day19.getDayOfMonth();
//        java.lang.Number number25 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
//        int int30 = month28.getMonth();
//        long long31 = month28.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 2);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries7.addOrUpdate(timeSeriesDataItem33);
//        boolean boolean35 = day0.equals((java.lang.Object) timeSeries7);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185826867L + "'", long6 == 1560185826867L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62112153600001L) + "'", long13 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560193199999L + "'", long23 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2 + "'", number25.equals(2));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62112153600001L) + "'", long31 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        timeSeries3.setDomainDescription("10-June-2019");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate12 = day8.getSerialDate();
//        java.util.Date date13 = day8.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, 0.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 1560185745363L);
//        timeSeries3.add(timeSeriesDataItem18, false);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener21);
//        java.lang.Class class23 = timeSeries3.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(class23);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        int int7 = month5.getMonth();
//        long long8 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2);
//        timeSeries2.add(timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getNextTimePeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getNextTimePeriod();
//        int int14 = timeSeries2.getMaximumItemCount();
//        timeSeries2.removeAgedItems(1560185812441L, false);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185827008L + "'", long1 == 1560185827008L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112153600001L) + "'", long8 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
        timeSeries3.setDomainDescription("10-June-2019");
        java.lang.String str6 = timeSeries3.getRangeDescription();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 1.0f + "'", comparable7.equals(1.0f));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        long long7 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        long long9 = timeSeries2.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 9);
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.String str18 = day12.toString();
//        int int20 = day12.compareTo((java.lang.Object) 1560185759100L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185827051L + "'", long1 == 1560185827051L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185827052L + "'", long4 == 1560185827052L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185827052L + "'", long6 == 1560185827052L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185827052L + "'", long7 == 1560185827052L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int11 = timeSeries2.getItemCount();
//        double double12 = timeSeries2.getMinY();
//        java.lang.String str13 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14);
//        timeSeries16.setDomainDescription("10-June-2019");
//        java.lang.Object obj19 = timeSeries16.clone();
//        timeSeries16.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int24 = day22.compareTo((java.lang.Object) 9);
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day22.previous();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) year27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond30);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        int int37 = month35.getMonth();
//        long long38 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 2);
//        timeSeries32.add(timeSeriesDataItem40);
//        timeSeries29.add(timeSeriesDataItem40);
//        timeSeries2.add(timeSeriesDataItem40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        long long45 = fixedMillisecond44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond44);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month49.next();
//        int int51 = month49.getMonth();
//        long long52 = month49.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 2);
//        timeSeries46.add(timeSeriesDataItem54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries46.getNextTimePeriod();
//        long long57 = timeSeries46.getMaximumItemAge();
//        java.lang.Class class58 = timeSeries46.getTimePeriodClass();
//        timeSeries46.setRangeDescription("9");
//        int int61 = timeSeriesDataItem40.compareTo((java.lang.Object) timeSeries46);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185827082L + "'", long1 == 1560185827082L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185827083L + "'", long9 == 1560185827083L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185827084L + "'", long15 == 1560185827084L);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560185827087L + "'", long31 == 1560185827087L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62112153600001L) + "'", long38 == (-62112153600001L));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560185827088L + "'", long45 == 1560185827088L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 9 + "'", int51 == 9);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-62112153600001L) + "'", long52 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries2.setDomainDescription("10-June-2019");
//        java.lang.Object obj5 = timeSeries2.clone();
//        timeSeries2.setMaximumItemAge(1560185732869L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 9);
//        long long11 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) year13);
//        long long16 = year13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        long long20 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(9, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        int int26 = month24.getMonth();
//        long long27 = month24.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 2);
//        timeSeries21.add(timeSeriesDataItem29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries21.getNextTimePeriod();
//        boolean boolean32 = timeSeries21.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean34 = timeSeries21.equals((java.lang.Object) fixedMillisecond33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int37 = day35.compareTo((java.lang.Object) 9);
//        int int38 = day35.getMonth();
//        long long39 = day35.getMiddleMillisecond();
//        int int40 = day35.getDayOfMonth();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries21.addAndOrUpdate(timeSeries45);
//        timeSeries46.setKey((java.lang.Comparable) 1560185729540L);
//        int int49 = timeSeriesDataItem18.compareTo((java.lang.Object) timeSeries46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem18.getPeriod();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185827467L + "'", long1 == 1560185827467L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560185827474L + "'", long20 == 1560185827474L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62112153600001L) + "'", long27 == (-62112153600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560193199999L + "'", long39 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//    }
//}

