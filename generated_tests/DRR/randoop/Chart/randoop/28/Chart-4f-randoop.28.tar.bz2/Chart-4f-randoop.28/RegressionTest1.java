import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "January");
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class9 = periodAxis8.getAutoRangeTimePeriodClass();
        float float10 = periodAxis8.getMinorTickMarkOutsideLength();
        java.lang.Class class11 = periodAxis8.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class20 = periodAxis19.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = periodAxis19.getLast();
        java.util.Date date22 = regularTimePeriod21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone24);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone24);
        java.util.List list28 = timeSeriesCollection27.getSeries();
        org.jfree.chart.entity.XYItemEntity xYItemEntity33 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) timeSeriesCollection27, (int) (short) 0, (int) (byte) 10, "LegendItemEntity: seriesKey=null, dataset=null", "{0}");
        try {
            int int37 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection27, 0, 0.05d, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        chartRenderingInfo1.clear();
        org.jfree.chart.RenderingSource renderingSource3 = null;
        chartRenderingInfo1.setRenderingSource(renderingSource3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        chartRenderingInfo1.setRenderingSource(renderingSource6);
        org.junit.Assert.assertNotNull(plotRenderingInfo5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer0.setSeriesShape(12, shape4, false);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = null;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint9);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot7.getLabelDistributor();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator12 = piePlot7.getToolTipGenerator();
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) piePlot7, "LegendItemEntity: seriesKey=null, dataset=null", "MINOR");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer16.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = null;
        xYLineAndShapeRenderer16.setBaseToolTipGenerator(xYToolTipGenerator20, true);
        xYLineAndShapeRenderer16.setDrawOutlines(false);
        xYLineAndShapeRenderer16.setBaseShapesVisible(true);
        java.awt.Font font28 = null;
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer32 = null;
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("", font28, paint29, (float) 0L, 0, textMeasurer32);
        xYLineAndShapeRenderer16.setBaseItemLabelPaint(paint29, true);
        piePlot7.setLabelLinkPaint(paint29);
        java.awt.Paint paint38 = piePlot7.getSectionPaint((java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertNull(pieToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textBlock33);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.lookupLegendShape((int) (short) 1);
        boolean boolean16 = xYLineAndShapeRenderer0.isItemLabelVisible(12, (-16777216), true);
        java.awt.Paint paint20 = xYLineAndShapeRenderer0.getItemPaint(5, 2147483647, true);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range4, 2.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range4, (double) (byte) 10);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "NOID", "java.awt.Color[r=255,g=175,b=175]");
        java.lang.Object obj8 = timeSeries7.clone();
        java.lang.Class class9 = timeSeries7.getTimePeriodClass();
        timeSeries7.removeAgedItems((long) 1900, true);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYLineAndShapeRenderer11.setBaseToolTipGenerator(xYToolTipGenerator15, true);
        xYLineAndShapeRenderer11.setDrawOutlines(false);
        java.awt.Font font21 = xYLineAndShapeRenderer11.getSeriesItemLabelFont(10);
        java.awt.Paint paint22 = xYLineAndShapeRenderer11.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes(1.0d, plotRenderingInfo25, point2D26, false);
        xYLineAndShapeRenderer11.setPlot(xYPlot23);
        java.awt.Stroke stroke30 = xYPlot23.getDomainZeroBaselineStroke();
        org.jfree.data.time.TimeSeries timeSeries31 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis33 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class34 = periodAxis33.getAutoRangeTimePeriodClass();
        float float35 = periodAxis33.getMinorTickMarkOutsideLength();
        java.lang.Class class36 = periodAxis33.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class39 = periodAxis38.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = periodAxis38.getLast();
        java.util.Date date41 = regularTimePeriod40.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class45 = periodAxis44.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = periodAxis44.getLast();
        java.util.Date date47 = regularTimePeriod46.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        java.util.TimeZone timeZone49 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date47, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date41, timeZone49);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection52 = new org.jfree.data.time.TimeSeriesCollection(timeSeries31, timeZone49);
        timeSeriesCollection52.clearSelection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        try {
            org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState55 = xYBarRenderer0.initialise(graphics2D9, rectangle2D10, xYPlot23, (org.jfree.data.xy.XYDataset) timeSeriesCollection52, plotRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 2.0f + "'", float35 == 2.0f);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder36 = null;
        try {
            categoryPlot34.setColumnRenderingOrder(sortOrder36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNull(legendItemCollection35);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setOutlinePaint(paint4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.plot.CrosshairState crosshairState7 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setStartAngle((double) 1);
        java.awt.Paint paint12 = piePlot9.getLabelPaint();
        java.awt.Paint paint13 = piePlot9.getLabelLinkPaint();
        java.awt.Stroke stroke14 = null;
        piePlot9.setLabelOutlineStroke(stroke14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot9);
        jFreeChart16.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState7, jFreeChart16);
        org.jfree.chart.JFreeChart jFreeChart20 = chartChangeEvent19.getChart();
        java.awt.RenderingHints renderingHints21 = jFreeChart20.getRenderingHints();
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart20.createBufferedImage((int) (byte) 10, 2019);
        projectInfo6.setLogo((java.awt.Image) bufferedImage24);
        piePlot0.setBackgroundImage((java.awt.Image) bufferedImage24);
        boolean boolean27 = piePlot0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.removeAnnotations();
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        periodAxis1.setRangeAboutValue((double) (short) 10, (double) 0.0f);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setStartAngle((double) 1);
        java.awt.Paint paint10 = piePlot7.getLabelPaint();
        java.awt.Paint paint11 = piePlot7.getLabelLinkPaint();
        periodAxis1.setTickLabelPaint(paint11);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        periodAxis1.setLeftArrow(shape13);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        piePlot3D0.setNoDataMessage("RectangleEdge.RIGHT");
        float float8 = piePlot3D0.getBackgroundAlpha();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection9.getSeries(comparable10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) float8, (org.jfree.data.general.Dataset) timeSeriesCollection9);
        try {
            timeSeriesCollection9.setSelected(12, (int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (12).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(timeSeries11);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection21);
        org.jfree.data.time.TimeSeries timeSeries23 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class26 = periodAxis25.getAutoRangeTimePeriodClass();
        float float27 = periodAxis25.getMinorTickMarkOutsideLength();
        java.lang.Class class28 = periodAxis25.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class31 = periodAxis30.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = periodAxis30.getLast();
        java.util.Date date33 = regularTimePeriod32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class37 = periodAxis36.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = periodAxis36.getLast();
        java.util.Date date39 = regularTimePeriod38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.util.TimeZone timeZone41 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date39, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date33, timeZone41);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection44 = new org.jfree.data.time.TimeSeriesCollection(timeSeries23, timeZone41);
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection44);
        timeSeriesCollection21.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection44);
        try {
            java.lang.Number number49 = timeSeriesCollection44.getStartY(5, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertEquals((double) number22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertEquals((double) number45, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = null;
        piePlot10.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint12);
        boolean boolean14 = piePlot3D9.equals((java.lang.Object) (-1L));
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis20.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font23 = periodAxis20.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer24.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint29 = xYLineAndShapeRenderer24.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        piePlot31.setStartAngle((double) 1);
        java.awt.Paint paint34 = piePlot31.getLabelPaint();
        xYLineAndShapeRenderer24.setSeriesFillPaint(100, paint34);
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("hi!", font23, paint34, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("NOID", font23);
        org.jfree.chart.entity.EntityCollection entityCollection41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo(entityCollection41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = chartRenderingInfo42.getPlotInfo();
        int int44 = plotRenderingInfo43.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D45 = plotRenderingInfo43.getDataArea();
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D45);
        labelBlock38.setBounds(rectangle2D45);
        boolean boolean48 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D45);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("Range[0.0,1.0]");
        java.lang.String str51 = textTitle50.getID();
        java.lang.Object obj52 = textTitle50.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = textTitle50.getPosition();
        org.jfree.chart.axis.AxisSpace axisSpace54 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace54.ensureAtLeast((double) 1, rectangleEdge56);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) piePlot3D9, rectangle2D45, rectangleEdge53, axisSpace54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotRenderingInfo43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge56);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        boolean boolean2 = blockBorder0.equals((java.lang.Object) '#');
        java.awt.Paint paint3 = blockBorder0.getPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class5 = periodAxis4.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = periodAxis4.getLast();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = null;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot7.setBaseSectionPaint(paint11);
        periodAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis4);
        periodAxis4.setMinorTickMarkOutsideLength((float) (byte) 1);
        org.jfree.data.Range range17 = periodAxis4.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            barRenderer3D2.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.removeAnnotations();
        double double3 = xYBarRenderer1.getMargin();
        xYBarRenderer1.setUseYInterval(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        xYBarRenderer6.setNegativeItemLabelPositionFallback(itemLabelPosition8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYBarRenderer6.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition11, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = itemLabelPosition11.getItemLabelAnchor();
        boolean boolean15 = textBlockAnchor0.equals((java.lang.Object) itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        spreadsheetDate1.setDescription("{0}");
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        boolean boolean7 = xYSeries3.getNotify();
        org.jfree.data.xy.XYSeries xYSeries10 = xYSeries3.createCopy((int) (short) 1, 2019);
        double double11 = xYSeries10.getMinX();
        xYSeries10.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.xy.XYDataItem xYDataItem16 = xYSeries10.addOrUpdate(2.0d, 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(xYSeries10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem16);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = null;
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot4.setBaseSectionPaint(paint8);
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        java.awt.Font font13 = null;
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 0L, 0, textMeasurer17);
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) 0.0d, paint14);
        org.jfree.chart.util.Rotation rotation20 = piePlot4.getDirection();
        piePlot4.setMaximumLabelWidth((double) 5);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(rotation20);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(100.0d, numberFormat1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        java.awt.Paint paint12 = xYLineAndShapeRenderer1.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot13.zoomDomainAxes(1.0d, plotRenderingInfo15, point2D16, false);
        xYLineAndShapeRenderer1.setPlot(xYPlot13);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = null;
        piePlot21.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint23);
        boolean boolean25 = piePlot3D20.equals((java.lang.Object) (-1L));
        double double26 = piePlot3D20.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis30.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font33 = periodAxis30.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer34.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint39 = xYLineAndShapeRenderer34.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        piePlot41.setStartAngle((double) 1);
        java.awt.Paint paint44 = piePlot41.getLabelPaint();
        xYLineAndShapeRenderer34.setSeriesFillPaint(100, paint44);
        org.jfree.chart.text.TextFragment textFragment47 = new org.jfree.chart.text.TextFragment("hi!", font33, paint44, (-1.0f));
        java.awt.Color color48 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("hi!", font33, (java.awt.Paint) color48);
        piePlot3D20.setLabelFont(font33);
        xYPlot13.setNoDataMessageFont(font33);
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint55 = null;
        piePlot53.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint55);
        java.awt.Paint paint57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot53.setBaseSectionPaint(paint57);
        java.awt.Paint paint59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot53.setBackgroundPaint(paint59);
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(1.0d, paint59, stroke61);
        xYPlot13.setDomainZeroBaselineStroke(stroke61);
        combinedRangeXYPlot0.add(xYPlot13, (int) '#');
        double double66 = xYPlot13.getDomainCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot13.getDomainAxisForDataset((int) (short) 0);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNull(valueAxis68);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '#', 4, (-65281));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        double double2 = xYBarRenderer0.getMargin();
        xYBarRenderer0.setUseYInterval(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer5.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        xYBarRenderer5.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYBarRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer0.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(itemLabelPosition15);
        org.junit.Assert.assertNull(itemLabelPosition16);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        java.awt.Paint paint12 = xYLineAndShapeRenderer1.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot13.zoomDomainAxes(1.0d, plotRenderingInfo15, point2D16, false);
        xYLineAndShapeRenderer1.setPlot(xYPlot13);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = null;
        piePlot21.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint23);
        boolean boolean25 = piePlot3D20.equals((java.lang.Object) (-1L));
        double double26 = piePlot3D20.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis30.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font33 = periodAxis30.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer34.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint39 = xYLineAndShapeRenderer34.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        piePlot41.setStartAngle((double) 1);
        java.awt.Paint paint44 = piePlot41.getLabelPaint();
        xYLineAndShapeRenderer34.setSeriesFillPaint(100, paint44);
        org.jfree.chart.text.TextFragment textFragment47 = new org.jfree.chart.text.TextFragment("hi!", font33, paint44, (-1.0f));
        java.awt.Color color48 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("hi!", font33, (java.awt.Paint) color48);
        piePlot3D20.setLabelFont(font33);
        xYPlot13.setNoDataMessageFont(font33);
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint55 = null;
        piePlot53.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint55);
        java.awt.Paint paint57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot53.setBaseSectionPaint(paint57);
        java.awt.Paint paint59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot53.setBackgroundPaint(paint59);
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(1.0d, paint59, stroke61);
        xYPlot13.setDomainZeroBaselineStroke(stroke61);
        combinedRangeXYPlot0.add(xYPlot13, (int) '#');
        double double66 = xYPlot13.getDomainCrosshairValue();
        org.jfree.chart.axis.PeriodAxis periodAxis68 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis68.setMinorTickMarkOutsideLength((float) 0);
        periodAxis68.setUpperBound((double) (-1));
        java.awt.Color color73 = java.awt.Color.black;
        periodAxis68.setMinorTickMarkPaint((java.awt.Paint) color73);
        xYPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis68);
        org.jfree.chart.axis.PeriodAxis periodAxis77 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class78 = periodAxis77.getAutoRangeTimePeriodClass();
        float float79 = periodAxis77.getMinorTickMarkOutsideLength();
        java.lang.Class class80 = periodAxis77.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis82 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class83 = periodAxis82.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = periodAxis82.getLast();
        java.util.Date date85 = regularTimePeriod84.getStart();
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date85);
        org.jfree.chart.axis.PeriodAxis periodAxis88 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class89 = periodAxis88.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = periodAxis88.getLast();
        java.util.Date date91 = regularTimePeriod90.getStart();
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date91);
        java.util.TimeZone timeZone93 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date91, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date85, timeZone93);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem97 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod95, (java.lang.Number) (-1.0f));
        java.util.Date date98 = regularTimePeriod95.getStart();
        periodAxis68.setLast(regularTimePeriod95);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(class78);
        org.junit.Assert.assertTrue("'" + float79 + "' != '" + 2.0f + "'", float79 == 2.0f);
        org.junit.Assert.assertNotNull(class80);
        org.junit.Assert.assertNotNull(class83);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(class89);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(timeZone93);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertNotNull(date98);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setStartAngle((double) 1);
        java.awt.Paint paint6 = piePlot3.getLabelPaint();
        java.awt.Paint paint7 = piePlot3.getLabelLinkPaint();
        java.awt.Stroke stroke8 = null;
        piePlot3.setLabelOutlineStroke(stroke8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart10.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState1, jFreeChart10);
        org.jfree.chart.JFreeChart jFreeChart14 = chartChangeEvent13.getChart();
        java.awt.RenderingHints renderingHints15 = jFreeChart14.getRenderingHints();
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage((int) (byte) 10, 2019);
        projectInfo0.setLogo((java.awt.Image) bufferedImage18);
        java.lang.String str20 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(jFreeChart14);
        org.junit.Assert.assertNotNull(renderingHints15);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getUseFillPaint();
        java.awt.Paint paint2 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.LegendItem legendItem6 = xYAreaRenderer3.getLegendItem(7, (-1));
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = xYAreaRenderer3.getGradientTransformer();
        xYAreaRenderer0.setGradientTransformer(gradientPaintTransformer7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        java.util.List list22 = timeSeriesCollection21.getSeries();
        try {
            int[] intArray25 = timeSeriesCollection21.getSurroundingItems((int) (short) 0, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setURLText("MINOR");
        java.awt.Stroke stroke17 = legendItem14.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        boolean boolean7 = xYSeries3.getNotify();
        int int9 = xYSeries3.indexOf((java.lang.Number) 100);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean(0, (java.lang.Boolean) true);
        booleanList0.setBoolean(2, (java.lang.Boolean) true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint22 = null;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint22);
        boolean boolean24 = piePlot3D19.equals((java.lang.Object) (-1L));
        double double25 = piePlot3D19.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis29.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font32 = periodAxis29.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint38 = xYLineAndShapeRenderer33.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        piePlot40.setStartAngle((double) 1);
        java.awt.Paint paint43 = piePlot40.getLabelPaint();
        xYLineAndShapeRenderer33.setSeriesFillPaint(100, paint43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font32, paint43, (-1.0f));
        java.awt.Color color47 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!", font32, (java.awt.Paint) color47);
        piePlot3D19.setLabelFont(font32);
        xYPlot12.setNoDataMessageFont(font32);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint53 = null;
        piePlot51.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint53);
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot51.setBaseSectionPaint(paint55);
        java.awt.Stroke stroke57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot51.setLabelOutlineStroke(stroke57);
        xYPlot12.setRangeMinorGridlineStroke(stroke57);
        org.jfree.chart.plot.Marker marker61 = null;
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean63 = xYPlot12.removeDomainMarker((int) (short) 0, marker61, layer62);
        boolean boolean64 = xYPlot12.isRangeZoomable();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        xYPlot12.setRangeCrosshairPaint((java.awt.Paint) color65);
        org.jfree.data.general.DatasetGroup datasetGroup67 = xYPlot12.getDatasetGroup();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer68 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer68.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator72 = null;
        xYLineAndShapeRenderer68.setBaseToolTipGenerator(xYToolTipGenerator72, true);
        xYLineAndShapeRenderer68.setDrawOutlines(false);
        java.awt.Font font78 = xYLineAndShapeRenderer68.getSeriesItemLabelFont(10);
        java.awt.Paint paint79 = xYLineAndShapeRenderer68.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot80 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        java.awt.geom.Point2D point2D83 = null;
        xYPlot80.zoomDomainAxes(1.0d, plotRenderingInfo82, point2D83, false);
        xYLineAndShapeRenderer68.setPlot(xYPlot80);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder87 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot80.setDatasetRenderingOrder(datasetRenderingOrder87);
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder87);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNull(datasetGroup67);
        org.junit.Assert.assertNull(font78);
        org.junit.Assert.assertNull(paint79);
        org.junit.Assert.assertNotNull(datasetRenderingOrder87);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis3.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font6 = periodAxis3.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint12 = xYLineAndShapeRenderer7.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        piePlot14.setStartAngle((double) 1);
        java.awt.Paint paint17 = piePlot14.getLabelPaint();
        xYLineAndShapeRenderer7.setSeriesFillPaint(100, paint17);
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!", font6, paint17, (-1.0f));
        java.awt.Color color21 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font6, (java.awt.Paint) color21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer26.removeAnnotations();
        double double28 = xYBarRenderer26.getMargin();
        xYBarRenderer26.setUseYInterval(true);
        boolean boolean31 = xYBarRenderer26.isDrawBarOutline();
        xYBarRenderer26.setShadowXOffset((double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = xYBarRenderer26.getSeriesPositiveItemLabelPosition((int) '#');
        org.jfree.chart.text.TextAnchor textAnchor36 = itemLabelPosition35.getTextAnchor();
        try {
            textFragment22.draw(graphics2D23, (float) (byte) -1, (float) 22801L, textAnchor36, (float) 'a', (float) 6, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(textAnchor36);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        piePlot0.setLabelGap((double) 0L);
        double double13 = piePlot0.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot0.getLabelPadding();
        double double16 = rectangleInsets14.extendHeight((double) ' ');
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 90.0d + "'", double13 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 36.0d + "'", double16 == 36.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("NOID", "NOID", "hi!");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) ' ', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        xYStepAreaRenderer6.setShapesVisible(true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        piePlot4.setStartAngle((double) 1);
        java.awt.Paint paint7 = piePlot4.getLabelPaint();
        java.awt.Paint paint8 = piePlot4.getLabelLinkPaint();
        java.awt.Stroke stroke9 = null;
        piePlot4.setLabelOutlineStroke(stroke9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer12.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        xYBarRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYBarRenderer12.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        boolean boolean18 = jFreeChart11.equals((java.lang.Object) (byte) 100);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart11);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        double double2 = xYBarRenderer0.getMargin();
        xYBarRenderer0.setUseYInterval(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer5.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        xYBarRenderer5.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYBarRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
        org.jfree.chart.LegendItem legendItem15 = xYBarRenderer0.getLegendItem((-16777216), (-16777216));
        java.awt.Paint paint16 = xYBarRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint22 = null;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint22);
        boolean boolean24 = piePlot3D19.equals((java.lang.Object) (-1L));
        double double25 = piePlot3D19.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis29.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font32 = periodAxis29.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint38 = xYLineAndShapeRenderer33.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        piePlot40.setStartAngle((double) 1);
        java.awt.Paint paint43 = piePlot40.getLabelPaint();
        xYLineAndShapeRenderer33.setSeriesFillPaint(100, paint43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font32, paint43, (-1.0f));
        java.awt.Color color47 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!", font32, (java.awt.Paint) color47);
        piePlot3D19.setLabelFont(font32);
        xYPlot12.setNoDataMessageFont(font32);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint53 = null;
        piePlot51.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint53);
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot51.setBaseSectionPaint(paint55);
        java.awt.Stroke stroke57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot51.setLabelOutlineStroke(stroke57);
        xYPlot12.setRangeMinorGridlineStroke(stroke57);
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection62 = xYPlot12.getRangeMarkers(2147483647, layer61);
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis69 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis69.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font72 = periodAxis69.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer73 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer73.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint78 = xYLineAndShapeRenderer73.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot80 = new org.jfree.chart.plot.PiePlot();
        piePlot80.setStartAngle((double) 1);
        java.awt.Paint paint83 = piePlot80.getLabelPaint();
        xYLineAndShapeRenderer73.setSeriesFillPaint(100, paint83);
        org.jfree.chart.text.TextFragment textFragment86 = new org.jfree.chart.text.TextFragment("hi!", font72, paint83, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock87 = new org.jfree.chart.block.LabelBlock("NOID", font72);
        org.jfree.chart.entity.EntityCollection entityCollection90 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo91 = new org.jfree.chart.ChartRenderingInfo(entityCollection90);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = chartRenderingInfo91.getPlotInfo();
        int int93 = plotRenderingInfo92.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D94 = plotRenderingInfo92.getDataArea();
        boolean boolean95 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D94);
        labelBlock87.setBounds(rectangle2D94);
        boolean boolean97 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D94);
        try {
            xYPlot12.drawBackground(graphics2D63, rectangle2D94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertNull(paint78);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(plotRenderingInfo92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(rectangle2D94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font7 = periodAxis4.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = xYLineAndShapeRenderer8.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        xYLineAndShapeRenderer8.setSeriesFillPaint(100, paint18);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font7, paint18, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("NOID", font7);
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = chartRenderingInfo26.getPlotInfo();
        int int28 = plotRenderingInfo27.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo27.getDataArea();
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D29);
        labelBlock22.setBounds(rectangle2D29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis33, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font38);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font50 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis45, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font50);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis33, (double) ' ', (double) (byte) -1, (double) (short) 10, (double) 'a', font50);
        labelBlock22.setFont(font50);
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle("MINOR", font50);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment56 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment57 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement60 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment56, verticalAlignment57, (double) 2, (-65285.0d));
        org.jfree.chart.block.ColumnArrangement columnArrangement63 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment55, verticalAlignment57, (double) (-1L), (double) 10L);
        textTitle54.setTextAlignment(horizontalAlignment55);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(plotRenderingInfo27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertNotNull(horizontalAlignment56);
        org.junit.Assert.assertNotNull(verticalAlignment57);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint22 = null;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint22);
        boolean boolean24 = piePlot3D19.equals((java.lang.Object) (-1L));
        double double25 = piePlot3D19.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis29.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font32 = periodAxis29.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint38 = xYLineAndShapeRenderer33.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        piePlot40.setStartAngle((double) 1);
        java.awt.Paint paint43 = piePlot40.getLabelPaint();
        xYLineAndShapeRenderer33.setSeriesFillPaint(100, paint43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font32, paint43, (-1.0f));
        java.awt.Color color47 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!", font32, (java.awt.Paint) color47);
        piePlot3D19.setLabelFont(font32);
        xYPlot12.setNoDataMessageFont(font32);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint53 = null;
        piePlot51.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint53);
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot51.setBaseSectionPaint(paint55);
        java.awt.Stroke stroke57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot51.setLabelOutlineStroke(stroke57);
        xYPlot12.setRangeMinorGridlineStroke(stroke57);
        org.jfree.chart.plot.Marker marker61 = null;
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean63 = xYPlot12.removeDomainMarker((int) (short) 0, marker61, layer62);
        boolean boolean64 = xYPlot12.isRangeZoomable();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        xYPlot12.setRangeCrosshairPaint((java.awt.Paint) color65);
        org.jfree.data.general.DatasetGroup datasetGroup67 = xYPlot12.getDatasetGroup();
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Point2D point2D72 = null;
        xYPlot69.zoomDomainAxes(1.0d, plotRenderingInfo71, point2D72, false);
        org.jfree.chart.plot.PiePlot piePlot77 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint79 = null;
        piePlot77.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint79);
        java.awt.Paint paint81 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot77.setBaseSectionPaint(paint81);
        java.awt.Paint paint83 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot77.setBackgroundPaint(paint83);
        java.awt.Stroke stroke85 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker86 = new org.jfree.chart.plot.ValueMarker(1.0d, paint83, stroke85);
        org.jfree.chart.axis.PeriodAxis periodAxis88 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class89 = periodAxis88.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = periodAxis88.getLast();
        org.jfree.data.Range range91 = periodAxis88.getDefaultAutoRange();
        java.awt.Stroke stroke92 = periodAxis88.getTickMarkStroke();
        valueMarker86.setOutlineStroke(stroke92);
        org.jfree.chart.util.Layer layer94 = null;
        boolean boolean95 = xYPlot69.removeDomainMarker(100, (org.jfree.chart.plot.Marker) valueMarker86, layer94);
        java.awt.Stroke stroke96 = valueMarker86.getOutlineStroke();
        org.jfree.chart.util.Layer layer97 = null;
        try {
            xYPlot12.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker86, layer97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNull(datasetGroup67);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(class89);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(range91);
        org.junit.Assert.assertNotNull(stroke92);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(stroke96);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        xYBarRenderer0.setShadowXOffset(0.0d);
        boolean boolean4 = xYBarRenderer0.getUseYInterval();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        boolean boolean12 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        try {
            java.util.Date date14 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint10);
        boolean boolean12 = xYPlot0.canSelectByRegion();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot0.getRenderer();
        boolean boolean14 = xYPlot0.isDomainPannable();
        java.awt.Stroke stroke15 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.Comparable comparable4 = legendItemEntity3.getSeriesKey();
        java.lang.Object obj5 = legendItemEntity3.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer0.setSeriesShape(12, shape4, false);
        xYBarRenderer0.setShadowXOffset((double) (byte) 100);
        java.awt.Paint paint10 = xYBarRenderer0.getLegendTextPaint(9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer12.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer12.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke19 = xYLineAndShapeRenderer12.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        xYLineAndShapeRenderer12.drawAnnotations(graphics2D20, rectangle2D21, valueAxis22, valueAxis23, layer24, plotRenderingInfo25);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer28.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer28.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font35 = xYLineAndShapeRenderer28.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer28.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape40 = xYLineAndShapeRenderer28.lookupLegendShape((int) (short) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape40, rectangleAnchor41, (double) (byte) -1, 1.0d);
        xYLineAndShapeRenderer12.setSeriesShape(12, shape40);
        xYBarRenderer0.setLegendShape(9999, shape40);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer47 = xYBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNull(font35);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(gradientPaintTransformer47);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint5 = xYLineAndShapeRenderer0.getSeriesPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.lang.Object obj5 = intervalXYDelegate4.clone();
        intervalXYDelegate4.setIntervalPositionFactor(1.0E-8d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer37.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = null;
        xYLineAndShapeRenderer37.setBaseToolTipGenerator(xYToolTipGenerator41, true);
        xYLineAndShapeRenderer37.setDrawOutlines(false);
        java.awt.Font font47 = xYLineAndShapeRenderer37.getSeriesItemLabelFont(10);
        java.awt.Paint paint48 = xYLineAndShapeRenderer37.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        xYPlot49.zoomDomainAxes(1.0d, plotRenderingInfo51, point2D52, false);
        xYLineAndShapeRenderer37.setPlot(xYPlot49);
        org.jfree.chart.plot.PiePlot3D piePlot3D56 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint59 = null;
        piePlot57.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint59);
        boolean boolean61 = piePlot3D56.equals((java.lang.Object) (-1L));
        double double62 = piePlot3D56.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis66 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis66.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font69 = periodAxis66.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer70 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer70.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint75 = xYLineAndShapeRenderer70.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot77 = new org.jfree.chart.plot.PiePlot();
        piePlot77.setStartAngle((double) 1);
        java.awt.Paint paint80 = piePlot77.getLabelPaint();
        xYLineAndShapeRenderer70.setSeriesFillPaint(100, paint80);
        org.jfree.chart.text.TextFragment textFragment83 = new org.jfree.chart.text.TextFragment("hi!", font69, paint80, (-1.0f));
        java.awt.Color color84 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment85 = new org.jfree.chart.text.TextFragment("hi!", font69, (java.awt.Paint) color84);
        piePlot3D56.setLabelFont(font69);
        xYPlot49.setNoDataMessageFont(font69);
        org.jfree.chart.plot.PiePlot piePlot88 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint90 = null;
        piePlot88.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint90);
        java.awt.Paint paint92 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot88.setBaseSectionPaint(paint92);
        java.awt.Stroke stroke94 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot88.setLabelOutlineStroke(stroke94);
        xYPlot49.setRangeMinorGridlineStroke(stroke94);
        org.jfree.chart.axis.AxisLocation axisLocation97 = xYPlot49.getDomainAxisLocation();
        try {
            categoryPlot34.setRangeAxisLocation((-1), axisLocation97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertNull(font47);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 4.0d + "'", double62 == 4.0d);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNotNull(paint92);
        org.junit.Assert.assertNotNull(stroke94);
        org.junit.Assert.assertNotNull(axisLocation97);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder19);
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis22.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font25 = periodAxis22.getLabelFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list30 = periodAxis22.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis32.setVisible(false);
        java.awt.Stroke stroke35 = periodAxis32.getMinorTickMarkStroke();
        periodAxis22.setMinorTickMarkStroke(stroke35);
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class39 = periodAxis38.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = periodAxis38.getLast();
        java.util.Date date41 = regularTimePeriod40.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        java.util.TimeZone timeZone43 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date41, timeZone43);
        java.lang.Number number45 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, number45);
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot();
        piePlot48.setStartAngle((double) 1);
        java.awt.Paint paint51 = piePlot48.getLabelPaint();
        java.awt.Paint paint52 = piePlot48.getLabelLinkPaint();
        java.awt.Stroke stroke53 = null;
        piePlot48.setLabelOutlineStroke(stroke53);
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot48);
        jFreeChart55.setTitle("NOID");
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent60 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) year44, jFreeChart55, (int) (byte) 0, 0);
        boolean boolean61 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) periodAxis22, (java.lang.Object) chartProgressEvent60);
        periodAxis22.setFixedDimension((double) 9);
        int int64 = xYPlot12.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis22);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo39.getPlotInfo();
        int int41 = plotRenderingInfo40.getSubplotCount();
        org.jfree.chart.renderer.RendererState rendererState42 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo40);
        categoryPlot34.handleClick(1, 0, plotRenderingInfo40);
        org.jfree.chart.axis.AxisState axisState45 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis47.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font50 = periodAxis47.getLabelFont();
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.axis.AxisState axisState52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list55 = periodAxis47.refreshTicks(graphics2D51, axisState52, rectangle2D53, rectangleEdge54);
        axisState45.setTicks(list55);
        try {
            categoryPlot34.mapDatasetToDomainAxes((int) '#', list55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(list55);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke7 = xYLineAndShapeRenderer0.lookupSeriesStroke(4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYLineAndShapeRenderer0.getSeriesToolTipGenerator((-1));
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible(9999, false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        barRenderer3D2.setItemMargin((-1.0d));
        java.awt.Graphics2D graphics2D5 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray11, numberArray15, numberArray19, numberArray23, numberArray27, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = dateAxis37.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot40.getFixedLegendItems();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer42.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator46 = null;
        xYLineAndShapeRenderer42.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator46, false);
        java.awt.Paint paint50 = null;
        xYLineAndShapeRenderer42.setSeriesOutlinePaint(1, paint50);
        boolean boolean53 = xYLineAndShapeRenderer42.isSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer55 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        xYLineAndShapeRenderer55.setSeriesNegativeItemLabelPosition(0, itemLabelPosition57);
        int int59 = xYLineAndShapeRenderer55.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis65.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font68 = periodAxis65.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer69 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer69.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint74 = xYLineAndShapeRenderer69.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot76 = new org.jfree.chart.plot.PiePlot();
        piePlot76.setStartAngle((double) 1);
        java.awt.Paint paint79 = piePlot76.getLabelPaint();
        xYLineAndShapeRenderer69.setSeriesFillPaint(100, paint79);
        org.jfree.chart.text.TextFragment textFragment82 = new org.jfree.chart.text.TextFragment("hi!", font68, paint79, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock83 = new org.jfree.chart.block.LabelBlock("NOID", font68);
        org.jfree.chart.entity.EntityCollection entityCollection86 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo87 = new org.jfree.chart.ChartRenderingInfo(entityCollection86);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = chartRenderingInfo87.getPlotInfo();
        int int89 = plotRenderingInfo88.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D90 = plotRenderingInfo88.getDataArea();
        boolean boolean91 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D90);
        labelBlock83.setBounds(rectangle2D90);
        boolean boolean93 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D90);
        xYLineAndShapeRenderer55.setLegendLine((java.awt.Shape) rectangle2D90);
        xYLineAndShapeRenderer42.setSeriesShape(2, (java.awt.Shape) rectangle2D90);
        try {
            barRenderer3D2.drawBackground(graphics2D5, categoryPlot40, rectangle2D90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertNull(legendItemCollection41);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNull(paint74);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(plotRenderingInfo88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(rectangle2D90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setForegroundAlpha(1.0f);
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.awt.Paint paint5 = piePlot0.getSectionPaint((java.lang.Comparable) serialDate4);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.lang.Object obj35 = null;
        boolean boolean36 = dateAxis31.equals(obj35);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Font font4 = piePlot0.getNoDataMessageFont();
        java.lang.String str5 = piePlot0.getPlotType();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis13.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font16 = periodAxis13.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint22 = xYLineAndShapeRenderer17.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        piePlot24.setStartAngle((double) 1);
        java.awt.Paint paint27 = piePlot24.getLabelPaint();
        xYLineAndShapeRenderer17.setSeriesFillPaint(100, paint27);
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("hi!", font16, paint27, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("NOID", font16);
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo(entityCollection34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = chartRenderingInfo35.getPlotInfo();
        int int37 = plotRenderingInfo36.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo36.getDataArea();
        boolean boolean39 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D38);
        labelBlock31.setBounds(rectangle2D38);
        java.awt.geom.AffineTransform affineTransform41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        piePlot44.setStartAngle((double) 1);
        java.awt.Paint paint47 = piePlot44.getLabelPaint();
        java.awt.Paint paint48 = piePlot44.getLabelLinkPaint();
        java.awt.Stroke stroke49 = null;
        piePlot44.setLabelOutlineStroke(stroke49);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot44);
        jFreeChart51.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState42, jFreeChart51);
        org.jfree.chart.JFreeChart jFreeChart55 = chartChangeEvent54.getChart();
        java.awt.RenderingHints renderingHints56 = jFreeChart55.getRenderingHints();
        java.awt.PaintContext paintContext57 = color7.createContext(colorModel8, rectangle9, rectangle2D38, affineTransform41, renderingHints56);
        piePlot0.drawBackgroundImage(graphics2D6, (java.awt.geom.Rectangle2D) rectangle9);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotRenderingInfo36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(jFreeChart55);
        org.junit.Assert.assertNotNull(renderingHints56);
        org.junit.Assert.assertNotNull(paintContext57);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart8.setTitle("NOID");
        boolean boolean11 = jFreeChart8.isBorderVisible();
        try {
            java.awt.image.BufferedImage bufferedImage14 = jFreeChart8.createBufferedImage((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBackgroundPaint(paint6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot0.getDrawingSupplier();
        java.lang.Object obj9 = piePlot0.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis12.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font15 = periodAxis12.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer16.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = xYLineAndShapeRenderer16.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        piePlot23.setStartAngle((double) 1);
        java.awt.Paint paint26 = piePlot23.getLabelPaint();
        xYLineAndShapeRenderer16.setSeriesFillPaint(100, paint26);
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font15, paint26, (-1.0f));
        piePlot0.setShadowPaint(paint26);
        piePlot0.setIgnoreZeroValues(false);
        org.jfree.data.general.PieDataset pieDataset33 = null;
        piePlot0.setDataset(pieDataset33);
        java.awt.Paint paint35 = piePlot0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setDatasetIndex(4);
        double double3 = crosshairState0.getCrosshairDistance();
        double double4 = crosshairState0.getAnchorX();
        int int5 = crosshairState0.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.Object obj2 = null;
//        int int3 = day1.compareTo(obj2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day1.previous();
//        long long5 = day1.getLastMillisecond();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Object obj7 = null;
//        int int8 = day6.compareTo(obj7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.previous();
//        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
//        java.lang.Class class12 = periodAxis11.getAutoRangeTimePeriodClass();
//        float float13 = periodAxis11.getMinorTickMarkOutsideLength();
//        java.lang.Class class14 = periodAxis11.getMajorTickTimePeriodClass();
//        org.jfree.chart.axis.PeriodAxis periodAxis16 = new org.jfree.chart.axis.PeriodAxis("");
//        java.lang.Class class17 = periodAxis16.getAutoRangeTimePeriodClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = periodAxis16.getLast();
//        java.util.Date date19 = regularTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
//        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = periodAxis22.getLast();
//        java.util.Date date25 = regularTimePeriod24.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        java.util.TimeZone timeZone27 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone27);
//        java.util.Locale locale30 = null;
//        try {
//            org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day6, timeZone27, locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("NOID");
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = logAxis0.equals((java.lang.Object) textBlockAnchor1);
        double double3 = logAxis0.getSmallestValue();
        org.jfree.chart.ChartTheme chartTheme4 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        boolean boolean5 = logAxis0.equals((java.lang.Object) chartTheme4);
        double double6 = logAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-100d + "'", double3 == 1.0E-100d);
        org.junit.Assert.assertNotNull(chartTheme4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        boolean boolean4 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setAutoTickUnitSelection(false);
        boolean boolean7 = dateAxis1.isMinorTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        java.awt.Stroke stroke5 = periodAxis1.getTickMarkStroke();
        periodAxis1.setAutoRangeMinimumSize((double) 9999, true);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setStartAngle((double) 1);
        java.awt.Paint paint12 = piePlot9.getLabelPaint();
        piePlot9.setBackgroundAlpha((float) (short) 1);
        periodAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot9);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list9 = periodAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = periodAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        int int15 = legendItem14.getDatasetIndex();
        org.jfree.data.general.Dataset dataset16 = legendItem14.getDataset();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(dataset16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        boolean boolean12 = dateAxis1.isAxisLineVisible();
        java.util.Date date13 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat16 = null;
        dateAxis15.setDateFormatOverride(dateFormat16);
        java.awt.Font font19 = null;
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font19, paint20, (float) 0L, 0, textMeasurer23);
        boolean boolean25 = dateAxis15.equals((java.lang.Object) paint20);
        boolean boolean26 = dateAxis15.isAxisLineVisible();
        java.util.Date date27 = dateAxis15.getMinimumDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, serialDate36, (-65281));
        java.util.Date date39 = spreadsheetDate31.toDate();
        try {
            dateAxis1.setRange(date27, date39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer12.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer12.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font19 = xYLineAndShapeRenderer12.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer12.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape24 = xYLineAndShapeRenderer12.lookupLegendShape((int) (short) 1);
        dateAxis1.setUpArrow(shape24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis1.setTickMarkStroke(stroke26);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis3.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font6 = periodAxis3.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint12 = xYLineAndShapeRenderer7.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        piePlot14.setStartAngle((double) 1);
        java.awt.Paint paint17 = piePlot14.getLabelPaint();
        xYLineAndShapeRenderer7.setSeriesFillPaint(100, paint17);
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!", font6, paint17, (-1.0f));
        java.awt.Color color21 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font6, (java.awt.Paint) color21);
        java.awt.Graphics2D graphics2D23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = textFragment22.calculateDimensions(graphics2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline1.setStartTime((long) 2);
        long long4 = segmentedTimeline1.getStartTime();
        boolean boolean5 = seriesRenderingOrder0.equals((java.lang.Object) segmentedTimeline1);
        boolean boolean8 = segmentedTimeline1.containsDomainRange(0L, (long) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline9.setAdjustForDaylightSaving(true);
        java.util.List list12 = segmentedTimeline9.getExceptionSegments();
        segmentedTimeline1.addExceptions(list12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2L + "'", long4 == 2L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.data.Range range5 = xYLineAndShapeRenderer0.findRangeBounds(xYDataset4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer6.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer6.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font13 = xYLineAndShapeRenderer6.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer6.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape18 = xYLineAndShapeRenderer6.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        xYLineAndShapeRenderer0.setBaseShape(shape18);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator21 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYLineAndShapeRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator21);
        java.lang.Object obj23 = standardXYSeriesLabelGenerator21.clone();
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection();
        int int26 = xYPlot24.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection25);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate28 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection25, true);
        java.util.List list29 = timeSeriesCollection25.getSeries();
        try {
            java.lang.String str31 = standardXYSeriesLabelGenerator21.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection25, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setShapeVisible(false);
        boolean boolean17 = legendItem14.isLineVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 1900);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer3.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYLineAndShapeRenderer3.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator7, false);
        java.awt.Paint paint11 = null;
        xYLineAndShapeRenderer3.setSeriesOutlinePaint(1, paint11);
        boolean boolean14 = xYLineAndShapeRenderer3.isSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        xYLineAndShapeRenderer16.setSeriesNegativeItemLabelPosition(0, itemLabelPosition18);
        int int20 = xYLineAndShapeRenderer16.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis26.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font29 = periodAxis26.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer30.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint35 = xYLineAndShapeRenderer30.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        piePlot37.setStartAngle((double) 1);
        java.awt.Paint paint40 = piePlot37.getLabelPaint();
        xYLineAndShapeRenderer30.setSeriesFillPaint(100, paint40);
        org.jfree.chart.text.TextFragment textFragment43 = new org.jfree.chart.text.TextFragment("hi!", font29, paint40, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("NOID", font29);
        org.jfree.chart.entity.EntityCollection entityCollection47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo(entityCollection47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo48.getPlotInfo();
        int int50 = plotRenderingInfo49.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo49.getDataArea();
        boolean boolean52 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D51);
        labelBlock44.setBounds(rectangle2D51);
        boolean boolean54 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D51);
        xYLineAndShapeRenderer16.setLegendLine((java.awt.Shape) rectangle2D51);
        xYLineAndShapeRenderer3.setSeriesShape(2, (java.awt.Shape) rectangle2D51);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets0.createInsetRectangle(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangle2D57);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        java.lang.String str12 = basicProjectInfo10.getCopyright();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str18 = basicProjectInfo17.getVersion();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo17.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo29 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str30 = basicProjectInfo29.getVersion();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo35 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo29.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo35);
        basicProjectInfo23.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo35);
        basicProjectInfo23.setLicenceName("");
        basicProjectInfo10.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo45 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str46 = basicProjectInfo45.getVersion();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo51 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo45.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo51);
        basicProjectInfo23.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo51);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis3.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font6 = periodAxis3.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint12 = xYLineAndShapeRenderer7.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        piePlot14.setStartAngle((double) 1);
        java.awt.Paint paint17 = piePlot14.getLabelPaint();
        xYLineAndShapeRenderer7.setSeriesFillPaint(100, paint17);
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!", font6, paint17, (-1.0f));
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("http://www.jfree.org/jfreechart/index.html", font6);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        java.lang.Comparable comparable29 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset27, comparable29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart8.createBufferedImage(0, 10, 1.0E-8d, (double) 100.0f, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("{0}: ({1}, {2})");
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        java.awt.Stroke stroke3 = piePlot0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setStartAngle((double) 1);
        java.awt.Paint paint8 = piePlot5.getLabelPaint();
        java.awt.Paint paint9 = piePlot5.getLabelLinkPaint();
        java.awt.Stroke stroke10 = null;
        piePlot5.setLabelOutlineStroke(stroke10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity15 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart12, "RectangleEdge.RIGHT", "Rotation.CLOCKWISE");
        boolean boolean17 = jFreeChartEntity15.equals((java.lang.Object) "{0}: ({1}, {2})");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str1.equals("TextBlockAnchor.TOP_LEFT"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) (short) 10);
        java.lang.String str3 = size2D2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=10.0]" + "'", str3.equals("Size2D[width=0.0, height=10.0]"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        boolean boolean5 = dateAxis2.isTickLabelsVisible();
        java.awt.Paint paint6 = dateAxis2.getLabelPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis8.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font11 = periodAxis8.getLabelFont();
        dateAxis2.setTickLabelFont(font11);
        java.awt.Color color14 = org.jfree.chart.util.PaintUtilities.stringToColor("LegendItemEntity: seriesKey=null, dataset=null");
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        xYPlot0.mapDatasetToRangeAxis(0, (int) 'a');
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        boolean boolean11 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("-3,-3,3,3", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.CrosshairState crosshairState3 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setStartAngle((double) 1);
        java.awt.Paint paint8 = piePlot5.getLabelPaint();
        java.awt.Paint paint9 = piePlot5.getLabelLinkPaint();
        java.awt.Stroke stroke10 = null;
        piePlot5.setLabelOutlineStroke(stroke10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot5);
        jFreeChart12.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState3, jFreeChart12);
        org.jfree.chart.JFreeChart jFreeChart16 = chartChangeEvent15.getChart();
        java.awt.RenderingHints renderingHints17 = jFreeChart16.getRenderingHints();
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart16.createBufferedImage((int) (byte) 10, 2019);
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "ThreadContext", (java.awt.Image) bufferedImage20, "RectangleEdge.RIGHT", "MINOR", "TextBlockAnchor.TOP_LEFT");
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(renderingHints17);
        org.junit.Assert.assertNotNull(bufferedImage20);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo39.getPlotInfo();
        int int41 = plotRenderingInfo40.getSubplotCount();
        org.jfree.chart.renderer.RendererState rendererState42 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo40);
        categoryPlot34.handleClick(1, 0, plotRenderingInfo40);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot34.setDomainAxis(categoryAxis44);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation46 = null;
        try {
            boolean boolean48 = categoryPlot34.removeAnnotation(categoryAnnotation46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) '4', xYURLGenerator2, true);
        java.awt.Shape shape5 = xYLineAndShapeRenderer0.getLegendLine();
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        piePlot1.setMinimumArcAngleToDraw((double) 9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        boolean boolean7 = xYSeries3.getNotify();
        org.jfree.data.xy.XYSeries xYSeries10 = xYSeries3.createCopy((int) (short) 1, 2019);
        double double11 = xYSeries10.getMinX();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder();
        boolean boolean13 = xYSeries10.equals((java.lang.Object) blockBorder12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder12.getInsets();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(xYSeries10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo39.getPlotInfo();
        int int41 = plotRenderingInfo40.getSubplotCount();
        org.jfree.chart.renderer.RendererState rendererState42 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo40);
        categoryPlot34.handleClick(1, 0, plotRenderingInfo40);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot34.setDomainAxis(categoryAxis44);
        categoryPlot34.mapDatasetToRangeAxis(9, (int) (short) -1);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate8, (-65281));
        java.util.Date date11 = spreadsheetDate3.toDate();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
        float float24 = periodAxis22.getMinorTickMarkOutsideLength();
        java.lang.Class class25 = periodAxis22.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class28 = periodAxis27.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = periodAxis27.getLast();
        java.util.Date date30 = regularTimePeriod29.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.axis.PeriodAxis periodAxis33 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class34 = periodAxis33.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = periodAxis33.getLast();
        java.util.Date date36 = regularTimePeriod35.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        java.util.TimeZone timeZone38 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone38);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection41 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date16, timeZone38);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date11, timeZone38);
        java.util.Calendar calendar44 = null;
        try {
            month43.peg(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5, textAnchor6, (double) (-1));
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType0, 0.2d, "RectangleEdge.RIGHT", textAnchor5, textAnchor9, (double) (-16777216));
        double double12 = numberTick11.getAngle();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.6777216E7d) + "'", double12 == (-1.6777216E7d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        float float3 = periodAxis1.getMinorTickMarkOutsideLength();
        java.lang.Class class4 = periodAxis1.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        java.util.Date date9 = regularTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class13 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis12.getLast();
        java.util.Date date15 = regularTimePeriod14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date9, timeZone17);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class6 = periodAxis5.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = periodAxis5.getLast();
        org.jfree.data.Range range8 = periodAxis5.getDefaultAutoRange();
        dateAxis1.setRange(range8);
        float float10 = dateAxis1.getTickMarkOutsideLength();
        java.awt.Stroke stroke11 = dateAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setNotify(true);
        double double4 = textTitle1.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        jFreeChart9.setBorderVisible(true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        double double5 = intervalXYDelegate4.getFixedIntervalWidth();
        double double7 = intervalXYDelegate4.getDomainUpperBound(false);
        java.lang.Object obj8 = null;
        boolean boolean9 = intervalXYDelegate4.equals(obj8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot5 = periodAxis1.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets6.getTop();
        periodAxis1.setLabelInsets(rectangleInsets6, false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = periodAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNull(tickUnitSource10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list9 = periodAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        float float10 = periodAxis1.getMinorTickMarkOutsideLength();
        java.awt.Shape shape11 = periodAxis1.getRightArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightOutset((double) 0.0f);
        periodAxis1.setLabelInsets(rectangleInsets12);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        periodAxis1.setUpperBound((double) (-1));
        java.awt.Color color6 = java.awt.Color.black;
        periodAxis1.setMinorTickMarkPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis17.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font20 = periodAxis17.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer21.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint26 = xYLineAndShapeRenderer21.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        piePlot28.setStartAngle((double) 1);
        java.awt.Paint paint31 = piePlot28.getLabelPaint();
        xYLineAndShapeRenderer21.setSeriesFillPaint(100, paint31);
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("hi!", font20, paint31, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("NOID", font20);
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo39.getPlotInfo();
        int int41 = plotRenderingInfo40.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D42 = plotRenderingInfo40.getDataArea();
        boolean boolean43 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D42);
        labelBlock35.setBounds(rectangle2D42);
        boolean boolean45 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D42);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        xYPlot46.zoomDomainAxes(1.0d, plotRenderingInfo48, point2D49, false);
        int int52 = xYPlot46.getSeriesCount();
        java.awt.Font font54 = null;
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer58 = null;
        org.jfree.chart.text.TextBlock textBlock59 = org.jfree.chart.text.TextUtilities.createTextBlock("", font54, paint55, (float) 0L, 0, textMeasurer58);
        xYPlot46.setDomainCrosshairPaint(paint55);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = xYPlot46.getDomainAxisEdge(0);
        double double63 = numberAxis10.java2DToValue((double) 7, rectangle2D42, rectangleEdge62);
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("Range[0.0,1.0]");
        java.lang.String str66 = textTitle65.getID();
        java.lang.Object obj67 = textTitle65.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = textTitle65.getPosition();
        double double69 = periodAxis1.java2DToValue((double) 2L, rectangle2D42, rectangleEdge68);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(textBlock59);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.POSITIVE_INFINITY + "'", double63 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.POSITIVE_INFINITY + "'", double69 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        piePlot0.setLabelGap((double) 0L);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = piePlot0.getLabelLinkStyle();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot0.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        java.lang.String str6 = basicProjectInfo4.getVersion();
        java.lang.String str7 = basicProjectInfo4.getCopyright();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str13 = basicProjectInfo12.getVersion();
        java.lang.String str14 = basicProjectInfo12.getVersion();
        basicProjectInfo12.setCopyright("-3,-3,3,3");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo12);
        basicProjectInfo4.setLicenceName("Pie Plot");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        double double2 = xYBarRenderer0.getMargin();
        xYBarRenderer0.setUseYInterval(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer5.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        xYBarRenderer5.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYBarRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = itemLabelPosition10.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition10.getTextAnchor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis5.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font8 = periodAxis5.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer9.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = xYLineAndShapeRenderer9.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        piePlot16.setStartAngle((double) 1);
        java.awt.Paint paint19 = piePlot16.getLabelPaint();
        xYLineAndShapeRenderer9.setSeriesFillPaint(100, paint19);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font8, paint19, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("NOID", font8);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie Plot", font8, (java.awt.Paint) color24);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint30 = xYAreaRenderer26.getItemOutlinePaint((int) ' ', 8, false);
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("NOID", font8, paint30);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(0.0d);
        double double4 = rectangleInsets0.trimHeight((double) (-65281));
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-65285.0d) + "'", double4 == (-65285.0d));
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        double double6 = piePlot3D0.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis10.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font13 = periodAxis10.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint19 = xYLineAndShapeRenderer14.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        piePlot21.setStartAngle((double) 1);
        java.awt.Paint paint24 = piePlot21.getLabelPaint();
        xYLineAndShapeRenderer14.setSeriesFillPaint(100, paint24);
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("hi!", font13, paint24, (-1.0f));
        java.awt.Color color28 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font13, (java.awt.Paint) color28);
        piePlot3D0.setLabelFont(font13);
        org.jfree.data.xy.XYSeries xYSeries34 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int36 = xYSeries34.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray37 = xYSeries34.toArray();
        boolean boolean38 = piePlot3D0.equals((java.lang.Object) doubleArray37);
        piePlot3D0.setStartAngle((double) 10.0f);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int42 = color41.getTransparency();
        piePlot3D0.setShadowPaint((java.awt.Paint) color41);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.util.List list5 = timeSeriesCollection1.getSeries();
        try {
            timeSeriesCollection1.setSelected((int) (byte) 100, 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean11 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate9, (-65281));
        int int12 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        abstractPieLabelDistributor4.clear();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord6 = null;
        try {
            abstractPieLabelDistributor4.addPieLabelRecord(pieLabelRecord6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        boolean boolean4 = periodAxis1.isMinorTickMarksVisible();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getMonth();
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) day5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot34.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot34.getDataset((-1));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer40.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator44 = null;
        xYLineAndShapeRenderer40.setBaseToolTipGenerator(xYToolTipGenerator44, true);
        xYLineAndShapeRenderer40.setDrawOutlines(false);
        java.awt.Font font50 = xYLineAndShapeRenderer40.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator51 = null;
        xYLineAndShapeRenderer40.setBaseItemLabelGenerator(xYItemLabelGenerator51, false);
        xYLineAndShapeRenderer40.setBaseCreateEntities(false, true);
        combinedRangeXYPlot39.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer40);
        org.jfree.chart.axis.PeriodAxis periodAxis60 = new org.jfree.chart.axis.PeriodAxis("");
        double double61 = periodAxis60.getLowerBound();
        combinedRangeXYPlot39.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) periodAxis60, false);
        java.util.List list64 = combinedRangeXYPlot39.getSubplots();
        try {
            categoryPlot34.mapDatasetToDomainAxes(2147483647, list64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertNull(categoryDataset37);
        org.junit.Assert.assertNull(font50);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(list64);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        java.awt.Paint paint7 = xYLineAndShapeRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        xYSeries3.add((java.lang.Number) 10L, (java.lang.Number) 100.0f, true);
        xYSeries3.add(4.0d, 0.2d, false);
        xYSeries3.add((double) 1546329600000L, (java.lang.Number) 7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str17 = basicProjectInfo16.getVersion();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo22 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo16.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo22);
        basicProjectInfo10.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo22);
        basicProjectInfo10.setLicenceName("DateTickUnitType.HOUR");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        barRenderer3D2.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer3D2.getItemLabelGenerator((-16777216), (-65281), false);
        barRenderer3D2.setShadowYOffset((-1.0d));
        java.awt.Graphics2D graphics2D14 = null;
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray20, numberArray24, numberArray28, numberArray32, numberArray36, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray41);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot43 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource47 = dateAxis46.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer48);
        org.jfree.chart.axis.PeriodAxis periodAxis51 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis51.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font54 = periodAxis51.getLabelFont();
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.axis.AxisState axisState56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list59 = periodAxis51.refreshTicks(graphics2D55, axisState56, rectangle2D57, rectangleEdge58);
        float float60 = periodAxis51.getMinorTickMarkOutsideLength();
        java.awt.Shape shape61 = periodAxis51.getRightArrow();
        periodAxis51.setUpperBound((double) (byte) 100);
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Point2D point2D67 = null;
        xYPlot64.zoomDomainAxes(1.0d, plotRenderingInfo66, point2D67, false);
        org.jfree.chart.plot.PiePlot piePlot72 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint74 = null;
        piePlot72.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint74);
        java.awt.Paint paint76 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot72.setBaseSectionPaint(paint76);
        java.awt.Paint paint78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot72.setBackgroundPaint(paint78);
        java.awt.Stroke stroke80 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker81 = new org.jfree.chart.plot.ValueMarker(1.0d, paint78, stroke80);
        org.jfree.chart.axis.PeriodAxis periodAxis83 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class84 = periodAxis83.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = periodAxis83.getLast();
        org.jfree.data.Range range86 = periodAxis83.getDefaultAutoRange();
        java.awt.Stroke stroke87 = periodAxis83.getTickMarkStroke();
        valueMarker81.setOutlineStroke(stroke87);
        org.jfree.chart.util.Layer layer89 = null;
        boolean boolean90 = xYPlot64.removeDomainMarker(100, (org.jfree.chart.plot.Marker) valueMarker81, layer89);
        org.jfree.chart.entity.EntityCollection entityCollection91 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo92 = new org.jfree.chart.ChartRenderingInfo(entityCollection91);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = chartRenderingInfo92.getPlotInfo();
        int int94 = plotRenderingInfo93.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D95 = plotRenderingInfo93.getDataArea();
        try {
            barRenderer3D2.drawRangeMarker(graphics2D14, categoryPlot49, (org.jfree.chart.axis.ValueAxis) periodAxis51, (org.jfree.chart.plot.Marker) valueMarker81, rectangle2D95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(tickUnitSource47);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.0f + "'", float60 == 0.0f);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(class84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(range86);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertNotNull(rectangle2D95);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        int int7 = plotRenderingInfo6.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double11 = logAxis0.java2DToValue((double) 0L, rectangle2D8, rectangleEdge10);
        double double13 = logAxis0.calculateLog((double) 4);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.6020599913279623d + "'", double13 == 0.6020599913279623d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        int int6 = xYSeries3.getMaximumItemCount();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        int int9 = xYPlot7.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection8, true);
        java.util.List list12 = timeSeriesCollection8.getSeries();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeriesCollection13.getSeries(comparable14);
        java.util.List list16 = timeSeriesCollection13.getSeries();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = timeSeriesCollection8.getRangeBounds(list16, range17, true);
        xYSeries3.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        double double21 = xYSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(timeSeries15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator4, false);
        java.awt.Shape shape8 = xYLineAndShapeRenderer0.lookupSeriesShape((int) (byte) 10);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(0.0d);
        double double4 = rectangleInsets0.trimHeight((double) (byte) 1);
        double double6 = rectangleInsets0.extendHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.0d) + "'", double4 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) itemLabelAnchor0, jFreeChart1, chartChangeEventType2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset27, false);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset27);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 'a');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis2.getLast();
        org.jfree.data.Range range5 = periodAxis2.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot6 = periodAxis2.getPlot();
        boolean boolean7 = color0.equals((java.lang.Object) periodAxis2);
        try {
            periodAxis2.setRangeWithMargins((double) 7, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (7.0) <= upper (0.05).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        java.lang.String str14 = chartEntity13.getShapeCoords();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = chartEntity13.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-3,-3,3,3" + "'", str14.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class11 = periodAxis10.getAutoRangeTimePeriodClass();
        float float12 = periodAxis10.getMinorTickMarkOutsideLength();
        java.lang.Class class13 = periodAxis10.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class16 = periodAxis15.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = periodAxis15.getLast();
        java.util.Date date18 = regularTimePeriod17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class22 = periodAxis21.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = periodAxis21.getLast();
        java.util.Date date24 = regularTimePeriod23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone26);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8, timeZone26);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date7, timeZone26);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        double double22 = periodAxis21.getLowerBound();
        combinedRangeXYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) periodAxis21, false);
        boolean boolean25 = combinedRangeXYPlot0.isDomainZoomable();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("RectangleEdge.RIGHT");
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = chartRenderingInfo32.getPlotInfo();
        int int34 = plotRenderingInfo33.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        boolean boolean36 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D35, rectangleEdge37);
        logAxis28.setUpArrow((java.awt.Shape) rectangle2D35);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline40 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline40.setAdjustForDaylightSaving(true);
        java.util.List list43 = segmentedTimeline40.getExceptionSegments();
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D26, rectangle2D35, list43);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline40);
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) (short) 0, (float) (-1L));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        xYSeries3.add((java.lang.Number) 10L, (java.lang.Number) 100.0f, true);
        xYSeries3.add(4.0d, 0.2d, false);
        xYSeries3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer0.getBaseStroke();
        boolean boolean12 = xYLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.lang.Object obj13 = xYLineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = logAxis1.equals((java.lang.Object) textBlockAnchor2);
        double double4 = logAxis1.getSmallestValue();
        org.jfree.chart.ChartTheme chartTheme5 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        boolean boolean6 = logAxis1.equals((java.lang.Object) chartTheme5);
        logAxis1.zoomRange(1.0E-100d, 4.0d);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis1, polarItemRenderer10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = logAxis1.getTickUnit();
        java.text.NumberFormat numberFormat13 = null;
        logAxis1.setNumberFormatOverride(numberFormat13);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-100d + "'", double4 == 1.0E-100d);
        org.junit.Assert.assertNotNull(chartTheme5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        org.jfree.data.xy.XYSeries xYSeries7 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int9 = xYSeries7.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray10 = xYSeries7.toArray();
        try {
            org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray1, (java.lang.Comparable[]) strArray3, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.Object obj4 = legendItemEntity3.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        double double22 = periodAxis21.getLowerBound();
        combinedRangeXYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) periodAxis21, false);
        boolean boolean25 = combinedRangeXYPlot0.isDomainZoomable();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        boolean boolean12 = jFreeChart9.isBorderVisible();
        multiplePiePlot0.setPieChart(jFreeChart9);
        java.lang.Object obj14 = null;
        boolean boolean15 = jFreeChart9.equals(obj14);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoRange(true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        dateAxis1.zoomRange((double) (-65281), (double) 100.0f);
        java.text.DateFormat dateFormat15 = dateAxis1.getDateFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = chartRenderingInfo23.getPlotInfo();
        int int25 = plotRenderingInfo24.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo24.getDataArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double29 = logAxis18.java2DToValue((double) 0L, rectangle2D26, rectangleEdge28);
        try {
            double double30 = dateAxis1.java2DToValue((double) 2019L, rectangle2D17, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(plotRenderingInfo24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class5 = periodAxis4.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = periodAxis4.getLast();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = null;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot7.setBaseSectionPaint(paint11);
        periodAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis4);
        float float15 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator22 = null;
        xYLineAndShapeRenderer18.setBaseToolTipGenerator(xYToolTipGenerator22, true);
        xYLineAndShapeRenderer18.setDrawOutlines(false);
        java.awt.Font font28 = xYLineAndShapeRenderer18.getSeriesItemLabelFont(10);
        java.awt.Paint paint29 = xYLineAndShapeRenderer18.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot30.zoomDomainAxes(1.0d, plotRenderingInfo32, point2D33, false);
        xYLineAndShapeRenderer18.setPlot(xYPlot30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot30.setDatasetRenderingOrder(datasetRenderingOrder37);
        org.jfree.chart.entity.EntityCollection entityCollection40 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo(entityCollection40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = chartRenderingInfo41.getPlotInfo();
        int int43 = plotRenderingInfo42.getSubplotCount();
        java.awt.geom.Point2D point2D44 = null;
        xYPlot30.zoomRangeAxes((double) 2147483647, plotRenderingInfo42, point2D44, true);
        xYPlot0.handleClick(9, 4, plotRenderingInfo42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNull(font28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(plotRenderingInfo42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        barRenderer3D2.setItemMargin((-1.0d));
        double double5 = barRenderer3D2.getXOffset();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        double double7 = xYSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot();
        piePlot36.setStartAngle((double) 1);
        java.awt.Paint paint39 = piePlot36.getLabelPaint();
        java.awt.Paint paint40 = piePlot36.getLabelLinkPaint();
        java.awt.Shape shape45 = null;
        java.awt.Paint paint46 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot47.zoomDomainAxes(1.0d, plotRenderingInfo49, point2D50, false);
        java.awt.Stroke stroke53 = xYPlot47.getDomainGridlineStroke();
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape45, paint46, stroke53, (java.awt.Paint) color54);
        piePlot36.setBaseSectionOutlinePaint(paint46);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat60 = null;
        dateAxis59.setDateFormatOverride(dateFormat60);
        boolean boolean62 = dateAxis59.isTickLabelsVisible();
        java.awt.Paint paint63 = dateAxis59.getLabelPaint();
        piePlot36.setSectionOutlinePaint((java.lang.Comparable) 0, paint63);
        categoryPlot34.setDomainCrosshairPaint(paint63);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart9.getPadding();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        double double13 = crosshairState0.getAnchorX();
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        crosshairState0.updateCrosshairPoint((double) 7, (double) 0.0f, (double) 8, (double) (short) 1, plotOrientation18);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation18);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder19);
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = chartRenderingInfo23.getPlotInfo();
        int int25 = plotRenderingInfo24.getSubplotCount();
        java.awt.geom.Point2D point2D26 = null;
        xYPlot12.zoomRangeAxes((double) 2147483647, plotRenderingInfo24, point2D26, true);
        boolean boolean29 = xYPlot12.isDomainZoomable();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation30 = null;
        try {
            xYPlot12.addAnnotation(xYAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(plotRenderingInfo24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.util.List list5 = timeSeriesCollection1.getSeries();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeriesCollection6.getSeries(comparable7);
        java.util.List list9 = timeSeriesCollection6.getSeries();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = timeSeriesCollection1.getRangeBounds(list9, range10, true);
        try {
            timeSeriesCollection1.removeSeries(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (7).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(timeSeries8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        double double6 = piePlot3D0.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis10.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font13 = periodAxis10.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint19 = xYLineAndShapeRenderer14.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        piePlot21.setStartAngle((double) 1);
        java.awt.Paint paint24 = piePlot21.getLabelPaint();
        xYLineAndShapeRenderer14.setSeriesFillPaint(100, paint24);
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("hi!", font13, paint24, (-1.0f));
        java.awt.Color color28 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font13, (java.awt.Paint) color28);
        piePlot3D0.setLabelFont(font13);
        piePlot3D0.setMaximumLabelWidth((double) ' ');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            xYLineAndShapeRenderer0.setSeriesPaint((-16777216), paint4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 2, (-65285.0d));
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) 2.0f);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment9, Double.POSITIVE_INFINITY, (double) '4');
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        piePlot3D0.setNoDataMessage("RectangleEdge.RIGHT");
        float float8 = piePlot3D0.getBackgroundAlpha();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection9.getSeries(comparable10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) float8, (org.jfree.data.general.Dataset) timeSeriesCollection9);
        try {
            double double15 = timeSeriesCollection9.getXValue(0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(timeSeries11);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBackgroundPaint(paint6);
        java.awt.Paint paint8 = piePlot0.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getLastTextFragment();
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis5.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font8 = periodAxis5.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer9.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = xYLineAndShapeRenderer9.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        piePlot16.setStartAngle((double) 1);
        java.awt.Paint paint19 = piePlot16.getLabelPaint();
        xYLineAndShapeRenderer9.setSeriesFillPaint(100, paint19);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font8, paint19, (-1.0f));
        java.awt.Color color23 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color23);
        textLine0.removeFragment(textFragment24);
        org.junit.Assert.assertNull(textFragment1);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(4.0d);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = multiplePiePlot0.getDrawingSupplier();
        multiplePiePlot0.setLimit((double) 1.0f);
        float float6 = multiplePiePlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font8);
        numberAxis1.setMarkerBand(markerAxisBand9);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        org.jfree.chart.axis.Timeline timeline12 = dateAxis1.getTimeline();
        dateAxis1.setRange((-3.0d), 36.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timeline12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer0.setSeriesShape(12, shape4, false);
        xYBarRenderer0.setShadowXOffset((double) (byte) 100);
        java.awt.Paint paint10 = xYBarRenderer0.getLegendTextPaint(9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer12.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer12.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke19 = xYLineAndShapeRenderer12.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        xYLineAndShapeRenderer12.drawAnnotations(graphics2D20, rectangle2D21, valueAxis22, valueAxis23, layer24, plotRenderingInfo25);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer28.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer28.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font35 = xYLineAndShapeRenderer28.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer28.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape40 = xYLineAndShapeRenderer28.lookupLegendShape((int) (short) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape40, rectangleAnchor41, (double) (byte) -1, 1.0d);
        xYLineAndShapeRenderer12.setSeriesShape(12, shape40);
        xYBarRenderer0.setLegendShape(9999, shape40);
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection48 = new org.jfree.data.time.TimeSeriesCollection();
        int int49 = xYPlot47.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection48);
        org.jfree.chart.axis.PeriodAxis periodAxis51 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class52 = periodAxis51.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = periodAxis51.getLast();
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint56 = null;
        piePlot54.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint56);
        java.awt.Paint paint58 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot54.setBaseSectionPaint(paint58);
        periodAxis51.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot54);
        xYPlot47.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis51);
        org.jfree.chart.entity.AxisEntity axisEntity62 = new org.jfree.chart.entity.AxisEntity(shape40, (org.jfree.chart.axis.Axis) periodAxis51);
        java.lang.String str63 = axisEntity62.toString();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNull(font35);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(class52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "AxisEntity: tooltip = null" + "'", str63.equals("AxisEntity: tooltip = null"));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        segmentedTimeline0.setStartTime((long) 2);
//        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
//        java.lang.Class class5 = periodAxis4.getAutoRangeTimePeriodClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = periodAxis4.getLast();
//        java.util.Date date7 = regularTimePeriod6.getStart();
//        long long8 = segmentedTimeline0.getTime(date7);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setURLText("MINOR");
        legendItem14.setShapeVisible(false);
        boolean boolean19 = legendItem14.isShapeVisible();
        boolean boolean20 = legendItem14.isLineVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
        timeSeries7.removeAgedItems(0L, true);
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, number20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) horizontalAlignment22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.addOrUpdate(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        boolean boolean33 = xYPlot12.isRangePannable();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat36 = null;
        dateAxis35.setDateFormatOverride(dateFormat36);
        java.awt.Font font39 = null;
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer43 = null;
        org.jfree.chart.text.TextBlock textBlock44 = org.jfree.chart.text.TextUtilities.createTextBlock("", font39, paint40, (float) 0L, 0, textMeasurer43);
        boolean boolean45 = dateAxis35.equals((java.lang.Object) paint40);
        dateAxis35.setLabelToolTip("hi!");
        xYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(textBlock44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(true);
        int int3 = segmentedTimeline0.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Range[0.0,1.0]");
        java.lang.Object obj2 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        boolean boolean4 = dateAxis1.isTickLabelsVisible();
        java.awt.Paint paint5 = dateAxis1.getLabelPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis7.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font10 = periodAxis7.getLabelFont();
        dateAxis1.setTickLabelFont(font10);
        dateAxis1.configure();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo39.getPlotInfo();
        int int41 = plotRenderingInfo40.getSubplotCount();
        org.jfree.chart.renderer.RendererState rendererState42 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo40);
        categoryPlot34.handleClick(1, 0, plotRenderingInfo40);
        categoryPlot34.setNoDataMessage("-3,-3,3,3");
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        boolean boolean2 = strokeList0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = logAxis1.equals((java.lang.Object) textBlockAnchor2);
        double double4 = logAxis1.getSmallestValue();
        org.jfree.chart.ChartTheme chartTheme5 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        boolean boolean6 = logAxis1.equals((java.lang.Object) chartTheme5);
        logAxis1.zoomRange(1.0E-100d, 4.0d);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis1, polarItemRenderer10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = logAxis1.getTickUnit();
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = chartRenderingInfo17.getPlotInfo();
        int int19 = plotRenderingInfo18.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D20, rectangleEdge22);
        org.jfree.chart.axis.AxisSpace axisSpace24 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace24.ensureAtLeast((double) 1, rectangleEdge26);
        double double28 = logAxis1.valueToJava2D((double) ' ', rectangle2D20, rectangleEdge26);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-100d + "'", double4 == 1.0E-100d);
        org.junit.Assert.assertNotNull(chartTheme5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("RectangleEdge.RIGHT");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        int int7 = plotRenderingInfo6.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D8, rectangleEdge10);
        logAxis1.setUpArrow((java.awt.Shape) rectangle2D8);
        logAxis1.setSmallestValue((double) 100L);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setDatasetIndex(4);
        double double3 = crosshairState0.getCrosshairDistance();
        double double4 = crosshairState0.getAnchorX();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        crosshairState0.updateCrosshairPoint((double) 1560409200000L, (double) (byte) 100, 10, (int) ' ', 0.0d, Double.NaN, plotOrientation11);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        dateAxis1.zoomRange((double) (-65281), (double) 100.0f);
        java.text.DateFormat dateFormat15 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLowerBound((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat21 = null;
        dateAxis20.setDateFormatOverride(dateFormat21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class25 = periodAxis24.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = periodAxis24.getLast();
        org.jfree.data.Range range27 = periodAxis24.getDefaultAutoRange();
        dateAxis20.setRange(range27);
        double double29 = range27.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) 4, (double) (-1L));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint32.getHeightConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat37 = null;
        dateAxis36.setDateFormatOverride(dateFormat37);
        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class41 = periodAxis40.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = periodAxis40.getLast();
        org.jfree.data.Range range43 = periodAxis40.getDefaultAutoRange();
        dateAxis36.setRange(range43);
        double double45 = range43.getLowerBound();
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class48 = periodAxis47.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = periodAxis47.getLast();
        org.jfree.data.Range range50 = periodAxis47.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat53 = null;
        dateAxis52.setDateFormatOverride(dateFormat53);
        org.jfree.chart.axis.PeriodAxis periodAxis56 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class57 = periodAxis56.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = periodAxis56.getLast();
        org.jfree.data.Range range59 = periodAxis56.getDefaultAutoRange();
        dateAxis52.setRange(range59);
        org.jfree.data.Range range61 = org.jfree.data.Range.combine(range50, range59);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat64 = null;
        dateAxis63.setDateFormatOverride(dateFormat64);
        org.jfree.chart.axis.PeriodAxis periodAxis67 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class68 = periodAxis67.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = periodAxis67.getLast();
        org.jfree.data.Range range70 = periodAxis67.getDefaultAutoRange();
        dateAxis63.setRange(range70);
        double double72 = range70.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint73 = new org.jfree.chart.block.RectangleConstraint(range59, range70);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType74 = rectangleConstraint73.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint75 = new org.jfree.chart.block.RectangleConstraint(0.0d, range27, lengthConstraintType33, (double) 1900, range43, lengthConstraintType74);
        double double76 = range43.getUpperBound();
        dateAxis1.setRangeWithMargins(range43);
        org.jfree.chart.axis.PeriodAxis periodAxis79 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class80 = periodAxis79.getAutoRangeTimePeriodClass();
        float float81 = periodAxis79.getMinorTickMarkOutsideLength();
        java.lang.Class class82 = periodAxis79.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis84 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class85 = periodAxis84.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = periodAxis84.getLast();
        java.util.Date date87 = regularTimePeriod86.getStart();
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date87);
        org.jfree.chart.axis.PeriodAxis periodAxis90 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class91 = periodAxis90.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = periodAxis90.getLast();
        java.util.Date date93 = regularTimePeriod92.getStart();
        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date93);
        java.util.TimeZone timeZone95 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year96 = new org.jfree.data.time.Year(date93, timeZone95);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date87, timeZone95);
        dateAxis1.setTimeZone(timeZone95);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertNotNull(class80);
        org.junit.Assert.assertTrue("'" + float81 + "' != '" + 2.0f + "'", float81 == 2.0f);
        org.junit.Assert.assertNotNull(class82);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(class91);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(timeZone95);
        org.junit.Assert.assertNotNull(regularTimePeriod97);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        categoryPlot34.configureDomainAxes();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart8.setTitle("NOID");
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart8.getTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle11);
        org.jfree.chart.title.Title title13 = titleChangeEvent12.getTitle();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(title13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("RectangleEdge.RIGHT");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(12, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator3);
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        float float9 = periodAxis7.getMinorTickMarkOutsideLength();
        java.lang.Class class10 = periodAxis7.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class13 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis12.getLast();
        java.util.Date date15 = regularTimePeriod14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class19 = periodAxis18.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = periodAxis18.getLast();
        java.util.Date date21 = regularTimePeriod20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone23);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone23);
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection26);
        org.jfree.data.time.TimeSeries timeSeries28 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class31 = periodAxis30.getAutoRangeTimePeriodClass();
        float float32 = periodAxis30.getMinorTickMarkOutsideLength();
        java.lang.Class class33 = periodAxis30.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class36 = periodAxis35.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = periodAxis35.getLast();
        java.util.Date date38 = regularTimePeriod37.getStart();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class42 = periodAxis41.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = periodAxis41.getLast();
        java.util.Date date44 = regularTimePeriod43.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        java.util.TimeZone timeZone46 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date38, timeZone46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries28, timeZone46);
        java.lang.Number number50 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        timeSeriesCollection26.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection49);
        try {
            java.lang.String str54 = standardXYToolTipGenerator1.generateToolTip((org.jfree.data.xy.XYDataset) timeSeriesCollection49, 2019, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2019).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertEquals((double) number27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertEquals((double) number50, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = xYLineAndShapeRenderer0.getBaseURLGenerator();
        boolean boolean22 = xYLineAndShapeRenderer0.getItemShapeVisible((int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(xYURLGenerator19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 12, (float) 10L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "Time", "NOID");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = logAxis0.equals((java.lang.Object) textBlockAnchor1);
        double double3 = logAxis0.getSmallestValue();
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        logAxis0.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.Color color6 = color4.brighter();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-100d + "'", double3 == 1.0E-100d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5, textAnchor6, (double) (-1));
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType0, 0.2d, "RectangleEdge.RIGHT", textAnchor5, textAnchor9, (double) (-16777216));
        java.lang.String str12 = numberTick11.getText();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.RIGHT" + "'", str12.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "NOID", "java.awt.Color[r=255,g=175,b=175]");
        java.lang.Object obj8 = timeSeries7.clone();
        long long9 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYLineAndShapeRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis3.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font6 = periodAxis3.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint12 = xYLineAndShapeRenderer7.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        piePlot14.setStartAngle((double) 1);
        java.awt.Paint paint17 = piePlot14.getLabelPaint();
        xYLineAndShapeRenderer7.setSeriesFillPaint(100, paint17);
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!", font6, paint17, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("NOID", font6);
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = chartRenderingInfo25.getPlotInfo();
        int int27 = plotRenderingInfo26.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo26.getDataArea();
        boolean boolean29 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D28);
        labelBlock21.setBounds(rectangle2D28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font37 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis32, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font37);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font49 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis44, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font49);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis32, (double) ' ', (double) (byte) -1, (double) (short) 10, (double) 'a', font49);
        labelBlock21.setFont(font49);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis55 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class56 = periodAxis55.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = periodAxis55.getLast();
        org.jfree.data.Range range58 = periodAxis55.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat61 = null;
        dateAxis60.setDateFormatOverride(dateFormat61);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class65 = periodAxis64.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = periodAxis64.getLast();
        org.jfree.data.Range range67 = periodAxis64.getDefaultAutoRange();
        dateAxis60.setRange(range67);
        org.jfree.data.Range range69 = org.jfree.data.Range.combine(range58, range67);
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat72 = null;
        dateAxis71.setDateFormatOverride(dateFormat72);
        org.jfree.chart.axis.PeriodAxis periodAxis75 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class76 = periodAxis75.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = periodAxis75.getLast();
        org.jfree.data.Range range78 = periodAxis75.getDefaultAutoRange();
        dateAxis71.setRange(range78);
        double double80 = range78.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint81 = new org.jfree.chart.block.RectangleConstraint(range67, range78);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType82 = rectangleConstraint81.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D83 = labelBlock21.arrange(graphics2D53, rectangleConstraint81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(plotRenderingInfo26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(class76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType82);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        org.jfree.data.Range range9 = periodAxis6.getDefaultAutoRange();
        dateAxis2.setRange(range9);
        double double11 = range9.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 4, (double) (-1L));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getHeightConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat19 = null;
        dateAxis18.setDateFormatOverride(dateFormat19);
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = periodAxis22.getLast();
        org.jfree.data.Range range25 = periodAxis22.getDefaultAutoRange();
        dateAxis18.setRange(range25);
        double double27 = range25.getLowerBound();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class30 = periodAxis29.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = periodAxis29.getLast();
        org.jfree.data.Range range32 = periodAxis29.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class39 = periodAxis38.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = periodAxis38.getLast();
        org.jfree.data.Range range41 = periodAxis38.getDefaultAutoRange();
        dateAxis34.setRange(range41);
        org.jfree.data.Range range43 = org.jfree.data.Range.combine(range32, range41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat46 = null;
        dateAxis45.setDateFormatOverride(dateFormat46);
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class50 = periodAxis49.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = periodAxis49.getLast();
        org.jfree.data.Range range52 = periodAxis49.getDefaultAutoRange();
        dateAxis45.setRange(range52);
        double double54 = range52.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range41, range52);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType56 = rectangleConstraint55.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(0.0d, range9, lengthConstraintType15, (double) 1900, range25, lengthConstraintType56);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat60 = null;
        dateAxis59.setDateFormatOverride(dateFormat60);
        org.jfree.chart.axis.PeriodAxis periodAxis63 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class64 = periodAxis63.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = periodAxis63.getLast();
        org.jfree.data.Range range66 = periodAxis63.getDefaultAutoRange();
        dateAxis59.setRange(range66);
        java.lang.String str68 = range66.toString();
        double double69 = range66.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint70 = rectangleConstraint57.toRangeWidth(range66);
        org.jfree.data.Range range72 = org.jfree.data.Range.scale(range66, 0.1d);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType56);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Range[0.0,1.0]" + "'", str68.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint70);
        org.junit.Assert.assertNotNull(range72);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        boolean boolean2 = xYAreaRenderer1.isOutline();
        java.lang.Object obj3 = xYAreaRenderer1.clone();
        xYAreaRenderer1.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBackgroundPaint(paint6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot0.getDrawingSupplier();
        java.lang.Object obj9 = piePlot0.clone();
        piePlot0.clearSectionOutlineStrokes(false);
        piePlot0.setBackgroundAlpha((float) (-16777216));
        double double14 = piePlot0.getInteriorGap();
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint18 = null;
        piePlot16.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint18);
        boolean boolean20 = piePlot3D15.equals((java.lang.Object) (-1L));
        piePlot3D15.setNoDataMessage("RectangleEdge.RIGHT");
        float float23 = piePlot3D15.getBackgroundAlpha();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeriesCollection24.getSeries(comparable25);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) float23, (org.jfree.data.general.Dataset) timeSeriesCollection24);
        piePlot0.datasetChanged(datasetChangeEvent27);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.08d + "'", double14 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(timeSeries26);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer0.setSeriesShape(12, shape4, false);
        xYBarRenderer0.setShadowXOffset((double) (byte) 100);
        double double9 = xYBarRenderer0.getBase();
        boolean boolean10 = xYBarRenderer0.getAutoPopulateSeriesStroke();
        boolean boolean11 = xYBarRenderer0.getShadowsVisible();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape14);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape14, "January");
        org.jfree.data.time.TimeSeries timeSeries18 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class21 = periodAxis20.getAutoRangeTimePeriodClass();
        float float22 = periodAxis20.getMinorTickMarkOutsideLength();
        java.lang.Class class23 = periodAxis20.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class26 = periodAxis25.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = periodAxis25.getLast();
        java.util.Date date28 = regularTimePeriod27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class32 = periodAxis31.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = periodAxis31.getLast();
        java.util.Date date34 = regularTimePeriod33.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        java.util.TimeZone timeZone36 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date28, timeZone36);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeSeries18, timeZone36);
        java.util.List list40 = timeSeriesCollection39.getSeries();
        org.jfree.chart.entity.XYItemEntity xYItemEntity45 = new org.jfree.chart.entity.XYItemEntity(shape14, (org.jfree.data.xy.XYDataset) timeSeriesCollection39, (int) (short) 0, (int) (byte) 10, "LegendItemEntity: seriesKey=null, dataset=null", "{0}");
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        org.jfree.data.Range range47 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertEquals((double) number46, Double.NaN, 0);
        org.junit.Assert.assertNull(range47);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        int int6 = xYPlot0.getSeriesCount();
        java.awt.Font font8 = null;
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, paint9, (float) 0L, 0, textMeasurer12);
        xYPlot0.setDomainCrosshairPaint(paint9);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = xYPlot0.getDataRange(valueAxis15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        axisSpace6.setRight((double) 1L);
        double double12 = axisSpace6.getTop();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class6 = periodAxis5.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = periodAxis5.getLast();
        org.jfree.data.Range range8 = periodAxis5.getDefaultAutoRange();
        dateAxis1.setRange(range8);
        float float10 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis1.setTickUnit(dateTickUnit11);
        java.text.DateFormat dateFormat13 = null;
        dateAxis1.setDateFormatOverride(dateFormat13);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        int int6 = xYSeries3.getMaximumItemCount();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        int int9 = xYPlot7.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection8, true);
        java.util.List list12 = timeSeriesCollection8.getSeries();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeriesCollection13.getSeries(comparable14);
        java.util.List list16 = timeSeriesCollection13.getSeries();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = timeSeriesCollection8.getRangeBounds(list16, range17, true);
        xYSeries3.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        double double21 = xYSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(timeSeries15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        int int1 = booleanList0.size();
        java.lang.Boolean boolean3 = booleanList0.getBoolean((int) (short) 0);
        java.lang.Boolean boolean5 = booleanList0.getBoolean(2019);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        barRenderer3D2.setItemMargin((-1.0d));
        double double5 = barRenderer3D2.getMinimumBarLength();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer3D2.getSeriesToolTipGenerator(7);
        org.jfree.chart.LegendItem legendItem10 = barRenderer3D2.getLegendItem(0, 8);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNull(legendItem10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setBaseShapesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        xYLineAndShapeRenderer0.setBasePaint(paint11);
        java.awt.Paint paint14 = xYLineAndShapeRenderer0.lookupLegendTextPaint(9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.util.List list5 = timeSeriesCollection1.getSeries();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10);
        timeSeriesCollection1.addSeries(timeSeries13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        boolean boolean2 = xYAreaRenderer1.isOutline();
        java.awt.Paint paint6 = xYAreaRenderer1.getItemPaint((int) (short) 100, 1, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        boolean boolean33 = xYPlot12.isRangePannable();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot36.zoomDomainAxes(1.0d, plotRenderingInfo38, point2D39, false);
        org.jfree.chart.entity.EntityCollection entityCollection44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = new org.jfree.chart.ChartRenderingInfo(entityCollection44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo45.getPlotInfo();
        int int47 = plotRenderingInfo46.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D48 = plotRenderingInfo46.getDataArea();
        java.awt.geom.Point2D point2D49 = null;
        xYPlot36.zoomDomainAxes((double) (short) 10, 0.025d, plotRenderingInfo46, point2D49);
        xYPlot12.handleClick((-16777216), (int) (byte) -1, plotRenderingInfo46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection53 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot12.setDataset(3, (org.jfree.data.xy.XYDataset) timeSeriesCollection53);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setShapeVisible(false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer17.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font24 = xYLineAndShapeRenderer17.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer17.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape29 = xYLineAndShapeRenderer17.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape29, "January");
        legendItem14.setShape(shape29);
        legendItem14.setSeriesKey((java.lang.Comparable) 22801L);
        java.awt.Stroke stroke36 = legendItem14.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(font24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBackgroundPaint(paint6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot0.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = piePlot0.getLabelLinkStyle();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer10.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYLineAndShapeRenderer10.setBaseToolTipGenerator(xYToolTipGenerator14, true);
        xYLineAndShapeRenderer10.setDrawOutlines(false);
        java.awt.Font font20 = xYLineAndShapeRenderer10.getSeriesItemLabelFont(10);
        java.awt.Paint paint21 = xYLineAndShapeRenderer10.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot22.zoomDomainAxes(1.0d, plotRenderingInfo24, point2D25, false);
        xYLineAndShapeRenderer10.setPlot(xYPlot22);
        java.awt.Stroke stroke29 = xYPlot22.getDomainZeroBaselineStroke();
        boolean boolean30 = pieLabelLinkStyle9.equals((java.lang.Object) xYPlot22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = xYPlot22.getRenderer();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(xYItemRenderer31);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        boolean boolean3 = barRenderer3D2.isDrawBarOutline();
        boolean boolean4 = barRenderer3D2.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        java.awt.Paint paint4 = piePlot0.getLabelLinkPaint();
        piePlot0.setInteriorGap(1.0E-100d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "NOID", "java.awt.Color[r=255,g=175,b=175]");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, serialDate17, (-65281));
        java.util.Date date20 = spreadsheetDate12.toDate();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = periodAxis22.getLast();
        java.util.Date date25 = regularTimePeriod24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone27 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class32 = periodAxis31.getAutoRangeTimePeriodClass();
        float float33 = periodAxis31.getMinorTickMarkOutsideLength();
        java.lang.Class class34 = periodAxis31.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class37 = periodAxis36.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = periodAxis36.getLast();
        java.util.Date date39 = regularTimePeriod38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.chart.axis.PeriodAxis periodAxis42 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class43 = periodAxis42.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = periodAxis42.getLast();
        java.util.Date date45 = regularTimePeriod44.getStart();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        java.util.TimeZone timeZone47 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date45, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date39, timeZone47);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection50 = new org.jfree.data.time.TimeSeriesCollection(timeSeries29, timeZone47);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date25, timeZone47);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date20, timeZone47);
        int int53 = month52.getYearValue();
        org.jfree.data.time.Year year54 = month52.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year54, (double) 2L);
        org.jfree.data.xy.XYDataItem xYDataItem60 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 4);
        java.lang.Number number61 = xYDataItem60.getX();
        java.lang.Number number62 = xYDataItem60.getY();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem60);
        long long64 = timeSeries63.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries7.addAndOrUpdate(timeSeries63);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1900 + "'", int53 == 1900);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + 2.0d + "'", number61.equals(2.0d));
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 4 + "'", number62.equals(4));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 9223372036854775807L + "'", long64 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries65);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font7 = periodAxis4.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = xYLineAndShapeRenderer8.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        xYLineAndShapeRenderer8.setSeriesFillPaint(100, paint18);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font7, paint18, (-1.0f));
        java.awt.Paint paint22 = textFragment21.getPaint();
        textTitle1.setPaint(paint22);
        java.lang.String str24 = textTitle1.getText();
        textTitle1.setText("DateTickUnitType.HOUR");
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer5.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font12 = xYLineAndShapeRenderer5.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer5.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape17 = xYLineAndShapeRenderer5.lookupLegendShape((int) (short) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape17, rectangleAnchor18, (double) (byte) -1, 1.0d);
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) 9223372036854775807L, 10.0d, rectangleAnchor18);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        float float3 = periodAxis1.getMinorTickMarkOutsideLength();
        periodAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        java.awt.Stroke stroke5 = periodAxis1.getTickMarkStroke();
        boolean boolean6 = periodAxis1.isAutoTickUnitSelection();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis10.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font13 = periodAxis10.getLabelFont();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list18 = periodAxis10.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        axisState8.setTicks(list18);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline20.setAdjustForDaylightSaving(true);
        java.util.List list23 = segmentedTimeline20.getExceptionSegments();
        axisState8.setTicks(list23);
        axisState8.cursorDown((double) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double28 = rectangleInsets27.getTop();
        double double30 = rectangleInsets27.calculateTopInset(0.0d);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        xYLineAndShapeRenderer31.setSeriesNegativeItemLabelPosition(0, itemLabelPosition33);
        int int35 = xYLineAndShapeRenderer31.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis41.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font44 = periodAxis41.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer45.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint50 = xYLineAndShapeRenderer45.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot();
        piePlot52.setStartAngle((double) 1);
        java.awt.Paint paint55 = piePlot52.getLabelPaint();
        xYLineAndShapeRenderer45.setSeriesFillPaint(100, paint55);
        org.jfree.chart.text.TextFragment textFragment58 = new org.jfree.chart.text.TextFragment("hi!", font44, paint55, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock59 = new org.jfree.chart.block.LabelBlock("NOID", font44);
        org.jfree.chart.entity.EntityCollection entityCollection62 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo63 = new org.jfree.chart.ChartRenderingInfo(entityCollection62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = chartRenderingInfo63.getPlotInfo();
        int int65 = plotRenderingInfo64.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D66 = plotRenderingInfo64.getDataArea();
        boolean boolean67 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D66);
        labelBlock59.setBounds(rectangle2D66);
        boolean boolean69 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D66);
        xYLineAndShapeRenderer31.setLegendLine((java.awt.Shape) rectangle2D66);
        java.awt.geom.Rectangle2D rectangle2D71 = rectangleInsets27.createOutsetRectangle(rectangle2D66);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("Range[0.0,1.0]");
        java.lang.String str74 = textTitle73.getID();
        java.lang.Object obj75 = textTitle73.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = textTitle73.getPosition();
        java.util.List list77 = periodAxis1.refreshTicks(graphics2D7, axisState8, rectangle2D71, rectangleEdge76);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(segmentedTimeline20);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(plotRenderingInfo64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(list77);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = logAxis1.equals((java.lang.Object) textBlockAnchor2);
        double double4 = logAxis1.getSmallestValue();
        org.jfree.chart.ChartTheme chartTheme5 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        boolean boolean6 = logAxis1.equals((java.lang.Object) chartTheme5);
        logAxis1.zoomRange(1.0E-100d, 4.0d);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis1, polarItemRenderer10);
        polarPlot11.setAngleGridlinesVisible(true);
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = chartRenderingInfo17.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        plotRenderingInfo18.setPlotArea(rectangle2D19);
        java.awt.geom.Point2D point2D21 = null;
        polarPlot11.zoomRangeAxes(100.0d, (double) '4', plotRenderingInfo18, point2D21);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-100d + "'", double4 == 1.0E-100d);
        org.junit.Assert.assertNotNull(chartTheme5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "TextBlockAnchor.TOP_LEFT", false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        try {
            java.lang.Number number24 = timeSeriesCollection21.getEndY(6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.TickType tickType4 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str5 = tickType4.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor9, textAnchor10, (double) (-1));
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick(tickType4, 0.2d, "RectangleEdge.RIGHT", textAnchor9, textAnchor13, (double) (-16777216));
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.text.TextUtilities.drawAlignedString("{0}", graphics2D1, (float) (-65281), (float) 100, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "MINOR" + "'", str5.equals("MINOR"));
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        java.awt.Font font6 = null;
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7, (float) 0L, 0, textMeasurer10);
        boolean boolean12 = dateAxis2.equals((java.lang.Object) paint7);
        dateAxis2.zoomRange((double) (-65281), (double) 100.0f);
        java.text.DateFormat dateFormat16 = dateAxis2.getDateFormatOverride();
        dateAxis2.setAutoRangeMinimumSize((double) 1L, false);
        dateAxis2.resizeRange((double) '4', 1.0E-8d);
        boolean boolean23 = lengthAdjustmentType0.equals((java.lang.Object) 1.0E-8d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(dateFormat16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        periodAxis1.setRangeAboutValue((double) (short) 10, (double) 0.0f);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setStartAngle((double) 1);
        java.awt.Paint paint10 = piePlot7.getLabelPaint();
        java.awt.Paint paint11 = piePlot7.getLabelLinkPaint();
        periodAxis1.setTickLabelPaint(paint11);
        float float13 = periodAxis1.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint10);
        boolean boolean12 = xYPlot0.canSelectByRegion();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot0.getDatasetRenderingOrder();
        java.lang.String str14 = datasetRenderingOrder13.toString();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str14.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D(0.0d, (double) (short) 10);
        double double4 = size2D3.width;
        org.jfree.chart.util.Size2D size2D5 = rectangleConstraint0.calculateConstrainedSize(size2D3);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(size2D5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint10);
        boolean boolean12 = xYPlot0.canSelectByRegion();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot0.getRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke7 = xYLineAndShapeRenderer0.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYLineAndShapeRenderer0.drawAnnotations(graphics2D8, rectangle2D9, valueAxis10, valueAxis11, layer12, plotRenderingInfo13);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer0.getSeriesCreateEntities(1900);
        xYLineAndShapeRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.RenderingSource renderingSource2 = null;
        chartRenderingInfo1.setRenderingSource(renderingSource2);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = chartRenderingInfo9.getPlotInfo();
        int int11 = plotRenderingInfo10.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        boolean boolean13 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double15 = logAxis4.java2DToValue((double) 0L, rectangle2D12, rectangleEdge14);
        chartRenderingInfo1.setChartArea(rectangle2D12);
        org.junit.Assert.assertNotNull(plotRenderingInfo10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder19);
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = chartRenderingInfo23.getPlotInfo();
        int int25 = plotRenderingInfo24.getSubplotCount();
        java.awt.geom.Point2D point2D26 = null;
        xYPlot12.zoomRangeAxes((double) 2147483647, plotRenderingInfo24, point2D26, true);
        boolean boolean29 = xYPlot12.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double32 = rectangleInsets30.calculateLeftOutset(0.0d);
        double double34 = rectangleInsets30.trimHeight((double) (byte) 1);
        xYPlot12.setAxisOffset(rectangleInsets30);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(plotRenderingInfo24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + (-3.0d) + "'", double34 == (-3.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = xYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        double double6 = piePlot3D0.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis10.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font13 = periodAxis10.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint19 = xYLineAndShapeRenderer14.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        piePlot21.setStartAngle((double) 1);
        java.awt.Paint paint24 = piePlot21.getLabelPaint();
        xYLineAndShapeRenderer14.setSeriesFillPaint(100, paint24);
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("hi!", font13, paint24, (-1.0f));
        java.awt.Color color28 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font13, (java.awt.Paint) color28);
        piePlot3D0.setLabelFont(font13);
        piePlot3D0.setDepthFactor((double) (short) -1);
        piePlot3D0.setAutoPopulateSectionPaint(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D0.setLabelPadding(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock0.setLineAlignment(horizontalAlignment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        org.jfree.chart.text.TextLine textLine9 = textBlock6.getLastLine();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock6.draw(graphics2D10, (float) ' ', 0.0f, textBlockAnchor13);
        textBlock0.draw(graphics2D3, (float) 100, 0.0f, textBlockAnchor13, (float) 1900, (float) 1560409200000L, (double) 0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNull(textLine9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer9.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        xYBarRenderer9.setNegativeItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYBarRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        boolean boolean15 = jFreeChart8.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        double double18 = periodAxis17.getLowerBound();
        boolean boolean19 = periodAxis17.isAutoTickUnitSelection();
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) boolean19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: true incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        barRenderer3D2.setItemMargin((-1.0d));
        double double5 = barRenderer3D2.getMinimumBarLength();
        barRenderer3D2.removeAnnotations();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setNotify(true);
        columnArrangement2.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) 0.08d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType35 = numberAxis34.getRangeType();
        java.awt.Font font40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis34, 0.0d, (-3.0d), (double) (short) 100, (double) 2019, font40);
        int int42 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rangeType35);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = java.awt.Color.getColor("Pie 3D Plot", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("RectangleEdge.RIGHT");
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class5 = periodAxis4.getAutoRangeTimePeriodClass();
        float float6 = periodAxis4.getMinorTickMarkOutsideLength();
        java.lang.Class class7 = periodAxis4.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class10 = periodAxis9.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis9.getLast();
        java.util.Date date12 = regularTimePeriod11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class16 = periodAxis15.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = periodAxis15.getLast();
        java.util.Date date18 = regularTimePeriod17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.TimeZone timeZone20 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date12, timeZone20);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone20);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.data.time.TimeSeries timeSeries25 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class28 = periodAxis27.getAutoRangeTimePeriodClass();
        float float29 = periodAxis27.getMinorTickMarkOutsideLength();
        java.lang.Class class30 = periodAxis27.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class33 = periodAxis32.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = periodAxis32.getLast();
        java.util.Date date35 = regularTimePeriod34.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class39 = periodAxis38.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = periodAxis38.getLast();
        java.util.Date date41 = regularTimePeriod40.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        java.util.TimeZone timeZone43 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date41, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date35, timeZone43);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection46 = new org.jfree.data.time.TimeSeriesCollection(timeSeries25, timeZone43);
        java.lang.Number number47 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection46);
        timeSeriesCollection23.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection46);
        java.lang.String str51 = standardXYURLGenerator1.generateURL((org.jfree.data.xy.XYDataset) timeSeriesCollection46, 1900, 0);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertEquals((double) number24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertEquals((double) number47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "RectangleEdge.RIGHT?series=1900&amp;item=0" + "'", str51.equals("RectangleEdge.RIGHT?series=1900&amp;item=0"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("LegendItemEntity: seriesKey=null, dataset=null");
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis5.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font8 = periodAxis5.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer9.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = xYLineAndShapeRenderer9.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        piePlot16.setStartAngle((double) 1);
        java.awt.Paint paint19 = piePlot16.getLabelPaint();
        xYLineAndShapeRenderer9.setSeriesFillPaint(100, paint19);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font8, paint19, (-1.0f));
        java.awt.Paint paint23 = textFragment22.getPaint();
        textTitle2.setPaint(paint23);
        textTitle2.setText("LegendItemEntity: seriesKey=null, dataset=null");
        try {
            org.jfree.chart.entity.TitleEntity titleEntity27 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) textTitle2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.data.Range range5 = xYLineAndShapeRenderer0.findRangeBounds(xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        int int9 = xYPlot7.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class12 = periodAxis11.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = periodAxis11.getLast();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint16 = null;
        piePlot14.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot14.setBaseSectionPaint(paint18);
        periodAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot14);
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis11);
        float float22 = xYPlot7.getForegroundAlpha();
        java.awt.Stroke stroke23 = xYPlot7.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat26 = null;
        dateAxis25.setDateFormatOverride(dateFormat26);
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class30 = periodAxis29.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = periodAxis29.getLast();
        org.jfree.data.Range range32 = periodAxis29.getDefaultAutoRange();
        dateAxis25.setRange(range32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer34.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator38 = null;
        xYLineAndShapeRenderer34.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator38, false);
        java.awt.Paint paint42 = null;
        xYLineAndShapeRenderer34.setSeriesOutlinePaint(1, paint42);
        boolean boolean45 = xYLineAndShapeRenderer34.isSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = null;
        xYLineAndShapeRenderer47.setSeriesNegativeItemLabelPosition(0, itemLabelPosition49);
        int int51 = xYLineAndShapeRenderer47.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis57.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font60 = periodAxis57.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer61 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer61.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint66 = xYLineAndShapeRenderer61.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        piePlot68.setStartAngle((double) 1);
        java.awt.Paint paint71 = piePlot68.getLabelPaint();
        xYLineAndShapeRenderer61.setSeriesFillPaint(100, paint71);
        org.jfree.chart.text.TextFragment textFragment74 = new org.jfree.chart.text.TextFragment("hi!", font60, paint71, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock75 = new org.jfree.chart.block.LabelBlock("NOID", font60);
        org.jfree.chart.entity.EntityCollection entityCollection78 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo79 = new org.jfree.chart.ChartRenderingInfo(entityCollection78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = chartRenderingInfo79.getPlotInfo();
        int int81 = plotRenderingInfo80.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D82 = plotRenderingInfo80.getDataArea();
        boolean boolean83 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D82);
        labelBlock75.setBounds(rectangle2D82);
        boolean boolean85 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D82);
        xYLineAndShapeRenderer47.setLegendLine((java.awt.Shape) rectangle2D82);
        xYLineAndShapeRenderer34.setSeriesShape(2, (java.awt.Shape) rectangle2D82);
        xYLineAndShapeRenderer0.fillRangeGridBand(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D82, (double) 9, (double) (short) -1);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(plotRenderingInfo80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer3.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYLineAndShapeRenderer3.setBaseToolTipGenerator(xYToolTipGenerator7, true);
        xYLineAndShapeRenderer3.setDrawOutlines(false);
        java.awt.Font font13 = xYLineAndShapeRenderer3.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator14, false);
        xYLineAndShapeRenderer3.setBaseCreateEntities(false, true);
        combinedRangeXYPlot2.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.Range range22 = combinedRangeXYPlot2.getDataRange(valueAxis21);
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] { numberArray28, numberArray32, numberArray36, numberArray40, numberArray44, numberArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray49);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot51 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource55 = dateAxis54.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis54, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getRangeMinorGridlineStroke();
        combinedRangeXYPlot2.setRangeGridlineStroke(stroke58);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(tickUnitSource55);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint10);
        boolean boolean12 = xYPlot0.canSelectByRegion();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot14.zoomDomainAxes(1.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = new org.jfree.chart.axis.AxisSpace();
        double double21 = axisSpace20.getBottom();
        xYPlot14.setFixedRangeAxisSpace(axisSpace20, true);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot14.setDomainCrosshairPaint(paint24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace26.ensureAtLeast((double) 1, rectangleEdge28);
        xYPlot14.setFixedRangeAxisSpace(axisSpace26);
        xYPlot0.setFixedDomainAxisSpace(axisSpace26);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot0.setLabelOutlineStroke(stroke6);
        org.jfree.chart.plot.Plot plot8 = piePlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot0.addChangeListener(plotChangeListener9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        barRenderer3D2.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer3D2.getItemLabelGenerator((-16777216), (-65281), false);
        barRenderer3D2.setShadowYOffset((-1.0d));
        barRenderer3D2.setIncludeBaseInRange(false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        org.jfree.data.Range range9 = periodAxis6.getDefaultAutoRange();
        dateAxis2.setRange(range9);
        double double11 = range9.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 4, (double) (-1L));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getHeightConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat19 = null;
        dateAxis18.setDateFormatOverride(dateFormat19);
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = periodAxis22.getLast();
        org.jfree.data.Range range25 = periodAxis22.getDefaultAutoRange();
        dateAxis18.setRange(range25);
        double double27 = range25.getLowerBound();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class30 = periodAxis29.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = periodAxis29.getLast();
        org.jfree.data.Range range32 = periodAxis29.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class39 = periodAxis38.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = periodAxis38.getLast();
        org.jfree.data.Range range41 = periodAxis38.getDefaultAutoRange();
        dateAxis34.setRange(range41);
        org.jfree.data.Range range43 = org.jfree.data.Range.combine(range32, range41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat46 = null;
        dateAxis45.setDateFormatOverride(dateFormat46);
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class50 = periodAxis49.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = periodAxis49.getLast();
        org.jfree.data.Range range52 = periodAxis49.getDefaultAutoRange();
        dateAxis45.setRange(range52);
        double double54 = range52.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range41, range52);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType56 = rectangleConstraint55.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(0.0d, range9, lengthConstraintType15, (double) 1900, range25, lengthConstraintType56);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType58 = rectangleConstraint57.getWidthConstraintType();
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType56);
        org.junit.Assert.assertNotNull(lengthConstraintType58);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = null;
        xYLineAndShapeRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator11, false);
        java.awt.Paint paint17 = xYLineAndShapeRenderer0.getItemLabelPaint(9, 0, false);
        java.awt.Stroke stroke19 = xYLineAndShapeRenderer0.getSeriesStroke(0);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(stroke19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        piePlot0.setLabelGap((double) 0L);
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class15 = periodAxis14.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = periodAxis14.getLast();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint19 = null;
        piePlot17.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint19);
        java.awt.Paint paint21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot17.setBaseSectionPaint(paint21);
        periodAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot17);
        java.awt.Font font26 = null;
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, paint27, (float) 0L, 0, textMeasurer30);
        piePlot17.setSectionOutlinePaint((java.lang.Comparable) 0.0d, paint27);
        org.jfree.chart.util.Rotation rotation33 = piePlot17.getDirection();
        piePlot0.setDirection(rotation33);
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis36.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font39 = periodAxis36.getLabelFont();
        piePlot0.setLabelFont(font39);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNotNull(rotation33);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = null;
        piePlot34.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint36);
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBaseSectionPaint(paint38);
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBackgroundPaint(paint40);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(1.0d, paint40, stroke42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean45 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker43, layer44);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer46 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer46.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer46.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke53 = xYLineAndShapeRenderer46.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        xYLineAndShapeRenderer46.drawAnnotations(graphics2D54, rectangle2D55, valueAxis56, valueAxis57, layer58, plotRenderingInfo59);
        java.util.Collection collection61 = xYPlot12.getRangeMarkers(layer58);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.axis.LogAxis logAxis63 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.entity.EntityCollection entityCollection67 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = new org.jfree.chart.ChartRenderingInfo(entityCollection67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = chartRenderingInfo68.getPlotInfo();
        int int70 = plotRenderingInfo69.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D71 = plotRenderingInfo69.getDataArea();
        boolean boolean72 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D71);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double74 = logAxis63.java2DToValue((double) 0L, rectangle2D71, rectangleEdge73);
        try {
            xYPlot12.drawBackground(graphics2D62, rectangle2D71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNotNull(plotRenderingInfo69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertEquals((double) double74, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        java.awt.Graphics2D graphics2D3 = null;
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17, numberArray21, numberArray25, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray30);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis35.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        java.awt.Stroke stroke39 = categoryPlot38.getRangeMinorGridlineStroke();
        categoryPlot38.mapDatasetToRangeAxis(100, (int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double44 = rectangleInsets43.getTop();
        double double46 = rectangleInsets43.calculateTopInset(0.0d);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = null;
        xYLineAndShapeRenderer47.setSeriesNegativeItemLabelPosition(0, itemLabelPosition49);
        int int51 = xYLineAndShapeRenderer47.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis57.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font60 = periodAxis57.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer61 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer61.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint66 = xYLineAndShapeRenderer61.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        piePlot68.setStartAngle((double) 1);
        java.awt.Paint paint71 = piePlot68.getLabelPaint();
        xYLineAndShapeRenderer61.setSeriesFillPaint(100, paint71);
        org.jfree.chart.text.TextFragment textFragment74 = new org.jfree.chart.text.TextFragment("hi!", font60, paint71, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock75 = new org.jfree.chart.block.LabelBlock("NOID", font60);
        org.jfree.chart.entity.EntityCollection entityCollection78 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo79 = new org.jfree.chart.ChartRenderingInfo(entityCollection78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = chartRenderingInfo79.getPlotInfo();
        int int81 = plotRenderingInfo80.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D82 = plotRenderingInfo80.getDataArea();
        boolean boolean83 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D82);
        labelBlock75.setBounds(rectangle2D82);
        boolean boolean85 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D82);
        xYLineAndShapeRenderer47.setLegendLine((java.awt.Shape) rectangle2D82);
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets43.createOutsetRectangle(rectangle2D82);
        try {
            barRenderer3D2.drawOutline(graphics2D3, categoryPlot38, rectangle2D87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.0d + "'", double46 == 2.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(plotRenderingInfo80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(rectangle2D87);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) (-16777216));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot1.zoomDomainAxes(1.0d, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = chartRenderingInfo10.getPlotInfo();
        int int12 = plotRenderingInfo11.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.geom.Point2D point2D14 = null;
        xYPlot1.zoomDomainAxes((double) (short) 10, 0.025d, plotRenderingInfo11, point2D14);
        combinedRangeXYPlot0.remove(xYPlot1);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot0.setDomainAxisLocation(0, axisLocation18, false);
        org.junit.Assert.assertNotNull(plotRenderingInfo11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        int int1 = dateTickUnitType0.getCalendarField();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis1.getStandardTickUnits();
        java.text.DateFormat dateFormat3 = null;
        dateAxis1.setDateFormatOverride(dateFormat3);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition5.getTextAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D40 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        categoryPlot34.setRenderer(6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = categoryPlot34.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(axisSpace42);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = xYBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setShapeVisible(false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer17.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font24 = xYLineAndShapeRenderer17.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer17.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape29 = xYLineAndShapeRenderer17.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape29, "January");
        legendItem14.setShape(shape29);
        legendItem14.setSeriesKey((java.lang.Comparable) 22801L);
        java.awt.Shape shape36 = legendItem14.getLine();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(font24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 10.0f);
        boolean boolean3 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.RenderingSource renderingSource20 = null;
        chartRenderingInfo19.setRenderingSource(renderingSource20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean23 = chartRenderingInfo19.equals((java.lang.Object) rectangleInsets22);
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart13.createBufferedImage((int) (short) 1, (int) (byte) -1, 1.0d, (double) 7, chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, serialDate11, (-65281));
        int int14 = spreadsheetDate6.getYYYY();
        boolean boolean15 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer0.getBaseStroke();
        boolean boolean12 = xYLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation37 = null;
        try {
            boolean boolean38 = categoryPlot34.removeAnnotation(categoryAnnotation37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1L), (double) (-1.0f));
        barRenderer3D2.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator5, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer3D2.getItemLabelGenerator((-16777216), (-65281), false);
        barRenderer3D2.setShadowYOffset((-1.0d));
        java.awt.Paint paint14 = barRenderer3D2.getWallPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer3D2.getBaseURLGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryURLGenerator15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        xYPlot0.mapDatasetToRangeAxis(0, (int) 'a');
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        xYPlot0.setDomainZeroBaselineVisible(false);
        xYPlot0.setRangeCrosshairVisible(true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) true, false);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean10 = xYLineAndShapeRenderer7.getItemLineVisible((-16777216), (int) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator11 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj12 = standardXYSeriesLabelGenerator11.clone();
        xYLineAndShapeRenderer7.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator11);
        xYLineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator11);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        double double2 = xYBarRenderer0.getMargin();
        xYBarRenderer0.setUseYInterval(true);
        boolean boolean5 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setShadowXOffset((double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYBarRenderer0.getSeriesNegativeItemLabelPosition(2019);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYBarRenderer0.getNegativeItemLabelPosition(9999, 4, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setURLText("MINOR");
        legendItem14.setShapeVisible(false);
        legendItem14.setURLText("-3,-3,3,3");
        java.lang.String str21 = legendItem14.getDescription();
        java.awt.Font font23 = null;
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, paint24, (float) 0L, 0, textMeasurer27);
        legendItem14.setLabelPaint(paint24);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "item" + "'", str21.equals("item"));
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textBlock28);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 4);
        java.lang.Number number3 = xYDataItem2.getX();
        xYDataItem2.setSelected(true);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        piePlot11.setStartAngle((double) 1);
        java.awt.Paint paint14 = piePlot11.getLabelPaint();
        java.awt.Paint paint15 = piePlot11.getLabelLinkPaint();
        java.awt.Stroke stroke16 = null;
        piePlot11.setLabelOutlineStroke(stroke16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot11);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity21 = new org.jfree.chart.entity.JFreeChartEntity(shape8, jFreeChart18, "RectangleEdge.RIGHT", "Rotation.CLOCKWISE");
        int int22 = xYDataItem2.compareTo((java.lang.Object) jFreeChart18);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 2.0d + "'", number3.equals(2.0d));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) (byte) 10);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint22 = null;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint22);
        boolean boolean24 = piePlot3D19.equals((java.lang.Object) (-1L));
        double double25 = piePlot3D19.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis29.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font32 = periodAxis29.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint38 = xYLineAndShapeRenderer33.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        piePlot40.setStartAngle((double) 1);
        java.awt.Paint paint43 = piePlot40.getLabelPaint();
        xYLineAndShapeRenderer33.setSeriesFillPaint(100, paint43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font32, paint43, (-1.0f));
        java.awt.Color color47 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!", font32, (java.awt.Paint) color47);
        piePlot3D19.setLabelFont(font32);
        xYPlot12.setNoDataMessageFont(font32);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint53 = null;
        piePlot51.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint53);
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot51.setBaseSectionPaint(paint55);
        java.awt.Stroke stroke57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot51.setLabelOutlineStroke(stroke57);
        xYPlot12.setRangeMinorGridlineStroke(stroke57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = xYPlot12.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation61 = axisLocation60.getOpposite();
        org.jfree.data.xy.XYDataItem xYDataItem64 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 4);
        java.lang.Number number65 = xYDataItem64.getX();
        boolean boolean66 = axisLocation61.equals((java.lang.Object) xYDataItem64);
        java.lang.String str67 = axisLocation61.toString();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 2.0d + "'", number65.equals(2.0d));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str67.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(true);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) (byte) 0);
        long long5 = segmentedTimeline0.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 172800000L + "'", long5 == 172800000L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        int int6 = xYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYLineAndShapeRenderer8.setBaseToolTipGenerator(xYToolTipGenerator12, true);
        xYLineAndShapeRenderer8.setDrawOutlines(false);
        java.awt.Font font18 = xYLineAndShapeRenderer8.getSeriesItemLabelFont(10);
        java.awt.Paint paint19 = xYLineAndShapeRenderer8.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot20.zoomDomainAxes(1.0d, plotRenderingInfo22, point2D23, false);
        xYLineAndShapeRenderer8.setPlot(xYPlot20);
        java.awt.Stroke stroke27 = xYPlot20.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer28.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = null;
        xYLineAndShapeRenderer28.setBaseToolTipGenerator(xYToolTipGenerator32, true);
        xYLineAndShapeRenderer28.setDrawOutlines(false);
        java.awt.Font font38 = xYLineAndShapeRenderer28.getSeriesItemLabelFont(10);
        java.awt.Paint paint39 = xYLineAndShapeRenderer28.getBaseLegendTextPaint();
        xYPlot20.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer28);
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint44 = null;
        piePlot42.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint44);
        java.awt.Paint paint46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot42.setBaseSectionPaint(paint46);
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot42.setBackgroundPaint(paint48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(1.0d, paint48, stroke50);
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean53 = xYPlot20.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker51, layer52);
        java.awt.Stroke stroke54 = valueMarker51.getOutlineStroke();
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean56 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker51, layer55);
        xYPlot0.clearSelection();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(font18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 2, (-65285.0d));
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) (-1L), (double) 10L);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer11.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYLineAndShapeRenderer11.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator15, false);
        java.awt.Paint paint19 = null;
        xYLineAndShapeRenderer11.setSeriesOutlinePaint(1, paint19);
        boolean boolean22 = xYLineAndShapeRenderer11.isSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        xYLineAndShapeRenderer24.setSeriesNegativeItemLabelPosition(0, itemLabelPosition26);
        int int28 = xYLineAndShapeRenderer24.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis34.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font37 = periodAxis34.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer38.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint43 = xYLineAndShapeRenderer38.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        piePlot45.setStartAngle((double) 1);
        java.awt.Paint paint48 = piePlot45.getLabelPaint();
        xYLineAndShapeRenderer38.setSeriesFillPaint(100, paint48);
        org.jfree.chart.text.TextFragment textFragment51 = new org.jfree.chart.text.TextFragment("hi!", font37, paint48, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("NOID", font37);
        org.jfree.chart.entity.EntityCollection entityCollection55 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo(entityCollection55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = chartRenderingInfo56.getPlotInfo();
        int int58 = plotRenderingInfo57.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D59 = plotRenderingInfo57.getDataArea();
        boolean boolean60 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D59);
        labelBlock52.setBounds(rectangle2D59);
        boolean boolean62 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D59);
        xYLineAndShapeRenderer24.setLegendLine((java.awt.Shape) rectangle2D59);
        xYLineAndShapeRenderer11.setSeriesShape(2, (java.awt.Shape) rectangle2D59);
        try {
            blockContainer9.draw(graphics2D10, rectangle2D59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(plotRenderingInfo57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot0.getLegendItems();
        piePlot0.setBackgroundAlpha((float) 1L);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        int int2 = spreadsheetDate1.getMonth();
        java.lang.String str3 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-January-1900" + "'", str3.equals("31-January-1900"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate8, (-65281));
        java.util.Date date11 = spreadsheetDate3.toDate();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
        float float24 = periodAxis22.getMinorTickMarkOutsideLength();
        java.lang.Class class25 = periodAxis22.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class28 = periodAxis27.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = periodAxis27.getLast();
        java.util.Date date30 = regularTimePeriod29.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.axis.PeriodAxis periodAxis33 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class34 = periodAxis33.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = periodAxis33.getLast();
        java.util.Date date36 = regularTimePeriod35.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        java.util.TimeZone timeZone38 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone38);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection41 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date16, timeZone38);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date11, timeZone38);
        int int44 = month43.getYearValue();
        org.jfree.data.time.Year year45 = month43.getYear();
        long long46 = month43.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertNotNull(year45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2207620800001L) + "'", long46 == (-2207620800001L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        piePlot0.setLabelGap((double) 0L);
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class15 = periodAxis14.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = periodAxis14.getLast();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint19 = null;
        piePlot17.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint19);
        java.awt.Paint paint21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot17.setBaseSectionPaint(paint21);
        periodAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot17);
        java.awt.Font font26 = null;
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, paint27, (float) 0L, 0, textMeasurer30);
        piePlot17.setSectionOutlinePaint((java.lang.Comparable) 0.0d, paint27);
        org.jfree.chart.util.Rotation rotation33 = piePlot17.getDirection();
        piePlot0.setDirection(rotation33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis39.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font42 = periodAxis39.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer43.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint48 = xYLineAndShapeRenderer43.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot();
        piePlot50.setStartAngle((double) 1);
        java.awt.Paint paint53 = piePlot50.getLabelPaint();
        xYLineAndShapeRenderer43.setSeriesFillPaint(100, paint53);
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("hi!", font42, paint53, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("NOID", font42);
        org.jfree.chart.entity.EntityCollection entityCollection60 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo(entityCollection60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = chartRenderingInfo61.getPlotInfo();
        int int63 = plotRenderingInfo62.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D64 = plotRenderingInfo62.getDataArea();
        boolean boolean65 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D64);
        labelBlock57.setBounds(rectangle2D64);
        java.awt.geom.Point2D point2D67 = null;
        org.jfree.chart.plot.PlotState plotState68 = null;
        org.jfree.chart.entity.EntityCollection entityCollection69 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = new org.jfree.chart.ChartRenderingInfo(entityCollection69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = chartRenderingInfo70.getPlotInfo();
        try {
            piePlot0.draw(graphics2D35, rectangle2D64, point2D67, plotState68, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNotNull(rotation33);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(plotRenderingInfo62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo71);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 4);
        java.lang.Number number3 = xYDataItem2.getX();
        java.lang.Number number4 = xYDataItem2.getY();
        java.lang.Number number5 = xYDataItem2.getX();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 2.0d + "'", number3.equals(2.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4 + "'", number4.equals(4));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.0d + "'", number5.equals(2.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list9 = periodAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis11.setVisible(false);
        java.awt.Stroke stroke14 = periodAxis11.getMinorTickMarkStroke();
        periodAxis1.setMinorTickMarkStroke(stroke14);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class18 = periodAxis17.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = periodAxis17.getLast();
        java.util.Date date20 = regularTimePeriod19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone22);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, number24);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        piePlot27.setStartAngle((double) 1);
        java.awt.Paint paint30 = piePlot27.getLabelPaint();
        java.awt.Paint paint31 = piePlot27.getLabelLinkPaint();
        java.awt.Stroke stroke32 = null;
        piePlot27.setLabelOutlineStroke(stroke32);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot27);
        jFreeChart34.setTitle("NOID");
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) year23, jFreeChart34, (int) (byte) 0, 0);
        boolean boolean40 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) periodAxis1, (java.lang.Object) chartProgressEvent39);
        java.awt.Stroke stroke41 = periodAxis1.getTickMarkStroke();
        int int42 = periodAxis1.getMinorTickCount();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        int int6 = xYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYLineAndShapeRenderer8.setBaseToolTipGenerator(xYToolTipGenerator12, true);
        xYLineAndShapeRenderer8.setDrawOutlines(false);
        java.awt.Font font18 = xYLineAndShapeRenderer8.getSeriesItemLabelFont(10);
        java.awt.Paint paint19 = xYLineAndShapeRenderer8.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot20.zoomDomainAxes(1.0d, plotRenderingInfo22, point2D23, false);
        xYLineAndShapeRenderer8.setPlot(xYPlot20);
        java.awt.Stroke stroke27 = xYPlot20.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer28.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = null;
        xYLineAndShapeRenderer28.setBaseToolTipGenerator(xYToolTipGenerator32, true);
        xYLineAndShapeRenderer28.setDrawOutlines(false);
        java.awt.Font font38 = xYLineAndShapeRenderer28.getSeriesItemLabelFont(10);
        java.awt.Paint paint39 = xYLineAndShapeRenderer28.getBaseLegendTextPaint();
        xYPlot20.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer28);
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint44 = null;
        piePlot42.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint44);
        java.awt.Paint paint46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot42.setBaseSectionPaint(paint46);
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot42.setBackgroundPaint(paint48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(1.0d, paint48, stroke50);
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean53 = xYPlot20.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker51, layer52);
        java.awt.Stroke stroke54 = valueMarker51.getOutlineStroke();
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean56 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker51, layer55);
        double double57 = valueMarker51.getValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(font18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = combinedRangeXYPlot0.getDataRange(valueAxis19);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray26, numberArray30, numberArray34, numberArray38, numberArray42, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray47);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource53 = dateAxis52.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis52, categoryItemRenderer54);
        java.awt.Stroke stroke56 = categoryPlot55.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.setRangeGridlineStroke(stroke56);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer58 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer58.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator62 = null;
        xYLineAndShapeRenderer58.setBaseToolTipGenerator(xYToolTipGenerator62, true);
        xYLineAndShapeRenderer58.setDrawOutlines(false);
        java.awt.Font font68 = xYLineAndShapeRenderer58.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator69 = null;
        xYLineAndShapeRenderer58.setBaseItemLabelGenerator(xYItemLabelGenerator69, false);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer58);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(tickUnitSource53);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNull(font68);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        categoryPlot34.setDomainAxis(12, categoryAxis38, false);
        java.awt.Image image41 = categoryPlot34.getBackgroundImage();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(image41);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot32.zoomDomainAxes(1.0d, plotRenderingInfo34, point2D35, false);
        xYLineAndShapeRenderer20.setPlot(xYPlot32);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = xYLineAndShapeRenderer20.getBaseURLGenerator();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        xYLineAndShapeRenderer20.notifyListeners(rendererChangeEvent40);
        combinedRangeXYPlot0.setRenderer((int) (short) 1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        int int43 = combinedRangeXYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNull(xYURLGenerator39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = chartRenderingInfo3.getPlotInfo();
        int int5 = plotRenderingInfo4.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getDataArea();
        boolean boolean7 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat10 = null;
        dateAxis9.setDateFormatOverride(dateFormat10);
        java.awt.Font font13 = null;
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 0L, 0, textMeasurer17);
        boolean boolean19 = dateAxis9.equals((java.lang.Object) paint14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer20.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font27 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer20.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape32 = xYLineAndShapeRenderer20.lookupLegendShape((int) (short) 1);
        dateAxis9.setUpArrow(shape32);
        boolean boolean34 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D6, shape32);
        org.junit.Assert.assertNotNull(plotRenderingInfo4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        org.jfree.data.Range range9 = periodAxis6.getDefaultAutoRange();
        dateAxis2.setRange(range9);
        double double11 = range9.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 4, (double) (-1L));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getHeightConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat19 = null;
        dateAxis18.setDateFormatOverride(dateFormat19);
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = periodAxis22.getLast();
        org.jfree.data.Range range25 = periodAxis22.getDefaultAutoRange();
        dateAxis18.setRange(range25);
        double double27 = range25.getLowerBound();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class30 = periodAxis29.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = periodAxis29.getLast();
        org.jfree.data.Range range32 = periodAxis29.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class39 = periodAxis38.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = periodAxis38.getLast();
        org.jfree.data.Range range41 = periodAxis38.getDefaultAutoRange();
        dateAxis34.setRange(range41);
        org.jfree.data.Range range43 = org.jfree.data.Range.combine(range32, range41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat46 = null;
        dateAxis45.setDateFormatOverride(dateFormat46);
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class50 = periodAxis49.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = periodAxis49.getLast();
        org.jfree.data.Range range52 = periodAxis49.getDefaultAutoRange();
        dateAxis45.setRange(range52);
        double double54 = range52.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range41, range52);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType56 = rectangleConstraint55.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(0.0d, range9, lengthConstraintType15, (double) 1900, range25, lengthConstraintType56);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat60 = null;
        dateAxis59.setDateFormatOverride(dateFormat60);
        org.jfree.chart.axis.PeriodAxis periodAxis63 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class64 = periodAxis63.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = periodAxis63.getLast();
        org.jfree.data.Range range66 = periodAxis63.getDefaultAutoRange();
        dateAxis59.setRange(range66);
        java.lang.String str68 = range66.toString();
        double double69 = range66.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint70 = rectangleConstraint57.toRangeWidth(range66);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = rectangleConstraint57.toFixedHeight((double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint73 = rectangleConstraint57.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType56);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Range[0.0,1.0]" + "'", str68.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint70);
        org.junit.Assert.assertNotNull(rectangleConstraint72);
        org.junit.Assert.assertNotNull(rectangleConstraint73);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        xYBarRenderer0.setShadowXOffset(0.0d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = xYBarRenderer0.getGradientPaintTransformer();
        xYBarRenderer0.setSeriesVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 1560495599999L, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray11);
        java.awt.Paint paint13 = xYPlot0.getDomainMinorGridlinePaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = null;
        xYLineAndShapeRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator11, false);
        xYLineAndShapeRenderer0.setBaseCreateEntities(false, true);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint20 = null;
        piePlot18.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint20);
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot18.setBaseSectionPaint(paint22);
        xYLineAndShapeRenderer0.setSeriesFillPaint(15, paint22, false);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        categoryPlot34.mapDatasetToRangeAxis(100, (int) (short) 100);
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray65 = new java.lang.Number[][] { numberArray44, numberArray48, numberArray52, numberArray56, numberArray60, numberArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray65);
        categoryPlot34.setDataset(categoryDataset66);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation68 = null;
        try {
            boolean boolean70 = categoryPlot34.removeAnnotation(categoryAnnotation68, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        java.lang.String str6 = basicProjectInfo4.getVersion();
        basicProjectInfo4.setCopyright("-3,-3,3,3");
        java.lang.String str9 = basicProjectInfo4.getVersion();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate6, "NOID", "java.awt.Color[r=255,g=175,b=175]");
        boolean boolean13 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int14 = spreadsheetDate6.getYYYY();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        categoryPlot34.mapDatasetToRangeAxis(100, (int) (short) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot34.getRenderer((int) (short) -1);
        org.jfree.chart.axis.AxisSpace axisSpace41 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace41.ensureAtLeast((double) 1, rectangleEdge43);
        categoryPlot34.setFixedDomainAxisSpace(axisSpace41, false);
        org.jfree.chart.axis.AxisSpace axisSpace47 = categoryPlot34.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(axisSpace47);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        double double6 = piePlot3D0.getShadowYOffset();
        piePlot3D0.setShadowXOffset((double) '4');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) (short) 10);
        double double3 = size2D2.width;
        double double4 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        float float3 = periodAxis1.getMinorTickMarkOutsideLength();
        java.lang.Class class4 = periodAxis1.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        java.util.Date date9 = regularTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class13 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis12.getLast();
        java.util.Date date15 = regularTimePeriod14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date9, timeZone17);
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class4);
        java.util.ResourceBundle.clearCache(classLoader20);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(classLoader20);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) ' ');
        java.lang.Number number3 = null;
        org.jfree.data.xy.XYDataItem xYDataItem4 = xYSeries1.addOrUpdate((java.lang.Number) 36.0d, number3);
        int int5 = xYSeries1.getItemCount();
        org.junit.Assert.assertNull(xYDataItem4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.util.List list5 = timeSeriesCollection1.getSeries();
        org.jfree.data.DomainOrder domainOrder6 = timeSeriesCollection1.getDomainOrder();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(domainOrder6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("January", graphics2D1, (float) (short) 100, (float) 1L, textAnchor4, (double) 5, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class6 = periodAxis5.getAutoRangeTimePeriodClass();
        float float7 = periodAxis5.getMinorTickMarkOutsideLength();
        java.lang.Class class8 = periodAxis5.getMajorTickTimePeriodClass();
        periodAxis5.setAutoTickUnitSelection(false, true);
        xYPlot0.setRangeAxis(9, (org.jfree.chart.axis.ValueAxis) periodAxis5, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYLineAndShapeRenderer14.setBaseToolTipGenerator(xYToolTipGenerator18, true);
        xYLineAndShapeRenderer14.setDrawOutlines(false);
        java.awt.Font font24 = xYLineAndShapeRenderer14.getSeriesItemLabelFont(10);
        java.awt.Paint paint25 = xYLineAndShapeRenderer14.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot26.zoomDomainAxes(1.0d, plotRenderingInfo28, point2D29, false);
        xYLineAndShapeRenderer14.setPlot(xYPlot26);
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = null;
        piePlot34.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint36);
        boolean boolean38 = piePlot3D33.equals((java.lang.Object) (-1L));
        double double39 = piePlot3D33.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis43.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font46 = periodAxis43.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer47.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint52 = xYLineAndShapeRenderer47.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        piePlot54.setStartAngle((double) 1);
        java.awt.Paint paint57 = piePlot54.getLabelPaint();
        xYLineAndShapeRenderer47.setSeriesFillPaint(100, paint57);
        org.jfree.chart.text.TextFragment textFragment60 = new org.jfree.chart.text.TextFragment("hi!", font46, paint57, (-1.0f));
        java.awt.Color color61 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment62 = new org.jfree.chart.text.TextFragment("hi!", font46, (java.awt.Paint) color61);
        piePlot3D33.setLabelFont(font46);
        xYPlot26.setNoDataMessageFont(font46);
        org.jfree.chart.plot.PiePlot piePlot65 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint67 = null;
        piePlot65.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint67);
        java.awt.Paint paint69 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot65.setBaseSectionPaint(paint69);
        java.awt.Stroke stroke71 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot65.setLabelOutlineStroke(stroke71);
        xYPlot26.setRangeMinorGridlineStroke(stroke71);
        xYPlot0.setRangeZeroBaselineStroke(stroke71);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNull(font24);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("VerticalAlignment.CENTER", "MINOR", "SerialDate.weekInMonthToString(): invalid code.", "Time");
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        double double22 = periodAxis21.getLowerBound();
        combinedRangeXYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) periodAxis21, false);
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        chartRenderingInfo27.clear();
        org.jfree.chart.RenderingSource renderingSource29 = null;
        chartRenderingInfo27.setRenderingSource(renderingSource29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo27.getPlotInfo();
        java.awt.geom.Point2D point2D32 = null;
        combinedRangeXYPlot0.panDomainAxes((double) 1L, plotRenderingInfo31, point2D32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer35.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator39 = null;
        xYLineAndShapeRenderer35.setBaseToolTipGenerator(xYToolTipGenerator39, true);
        xYLineAndShapeRenderer35.setDrawOutlines(false);
        java.awt.Font font45 = xYLineAndShapeRenderer35.getSeriesItemLabelFont(10);
        java.awt.Paint paint46 = xYLineAndShapeRenderer35.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot47.zoomDomainAxes(1.0d, plotRenderingInfo49, point2D50, false);
        xYLineAndShapeRenderer35.setPlot(xYPlot47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot47.setDatasetRenderingOrder(datasetRenderingOrder54);
        org.jfree.chart.entity.EntityCollection entityCollection57 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo(entityCollection57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = chartRenderingInfo58.getPlotInfo();
        int int60 = plotRenderingInfo59.getSubplotCount();
        java.awt.geom.Point2D point2D61 = null;
        xYPlot47.zoomRangeAxes((double) 2147483647, plotRenderingInfo59, point2D61, true);
        java.awt.geom.Point2D point2D64 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 172800000L, plotRenderingInfo59, point2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNull(font45);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertNotNull(plotRenderingInfo59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot1.getLabelDistributor();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot1.axisChanged(axisChangeEvent9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        piePlot1.setLabelGap((double) 0L);
        double double14 = piePlot1.getStartAngle();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", (org.jfree.chart.plot.Plot) piePlot1);
        piePlot1.setLabelGap(3.0d);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class20 = periodAxis19.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = periodAxis19.getLast();
        java.util.Date date22 = regularTimePeriod21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, number26);
        long long28 = year25.getSerialIndex();
        double double29 = piePlot1.getExplodePercent((java.lang.Comparable) year25);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 90.0d + "'", double14 == 90.0d);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean11 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate9, (-65281));
        java.util.Date date12 = spreadsheetDate4.toDate();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class15 = periodAxis14.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = periodAxis14.getLast();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis23 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class24 = periodAxis23.getAutoRangeTimePeriodClass();
        float float25 = periodAxis23.getMinorTickMarkOutsideLength();
        java.lang.Class class26 = periodAxis23.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class29 = periodAxis28.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = periodAxis28.getLast();
        java.util.Date date31 = regularTimePeriod30.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class35 = periodAxis34.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = periodAxis34.getLast();
        java.util.Date date37 = regularTimePeriod36.getStart();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        java.util.TimeZone timeZone39 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date37, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date31, timeZone39);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection(timeSeries21, timeZone39);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date17, timeZone39);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date12, timeZone39);
        long long45 = month44.getFirstMillisecond();
        long long46 = month44.getSerialIndex();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        int int48 = day47.getMonth();
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("DateTickUnitType.HOUR", (org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) day47);
        java.util.Calendar calendar50 = null;
        try {
            long long51 = month44.getLastMillisecond(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-2208960000000L) + "'", long45 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 22801L + "'", long46 == 22801L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        java.awt.Paint paint29 = multiplePiePlot28.getAggregatedItemsPaint();
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        piePlot31.setStartAngle((double) 1);
        java.awt.Paint paint34 = piePlot31.getLabelPaint();
        java.awt.Paint paint35 = piePlot31.getLabelLinkPaint();
        java.awt.Stroke stroke36 = null;
        piePlot31.setLabelOutlineStroke(stroke36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot31);
        jFreeChart38.setTitle("NOID");
        boolean boolean41 = jFreeChart38.isBorderVisible();
        multiplePiePlot28.setPieChart(jFreeChart38);
        org.jfree.chart.plot.Plot plot43 = multiplePiePlot28.getParent();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(plot43);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator4, false);
        java.awt.Paint paint8 = null;
        xYLineAndShapeRenderer0.setSeriesOutlinePaint(1, paint8);
        xYLineAndShapeRenderer0.setDrawOutlines(true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setBaseShapesVisible(true);
        java.awt.Font font12 = null;
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, (float) 0L, 0, textMeasurer16);
        xYLineAndShapeRenderer0.setBaseItemLabelPaint(paint13, true);
        java.awt.Shape shape21 = xYLineAndShapeRenderer0.lookupSeriesShape(1);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis26.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font29 = periodAxis26.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer30.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint35 = xYLineAndShapeRenderer30.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        piePlot37.setStartAngle((double) 1);
        java.awt.Paint paint40 = piePlot37.getLabelPaint();
        xYLineAndShapeRenderer30.setSeriesFillPaint(100, paint40);
        org.jfree.chart.text.TextFragment textFragment43 = new org.jfree.chart.text.TextFragment("hi!", font29, paint40, (-1.0f));
        java.awt.Paint paint44 = textFragment43.getPaint();
        textTitle23.setPaint(paint44);
        java.lang.String str46 = textTitle23.getText();
        org.jfree.chart.entity.TitleEntity titleEntity48 = new org.jfree.chart.entity.TitleEntity(shape21, (org.jfree.chart.title.Title) textTitle23, "http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType10 = numberAxis9.getRangeType();
        java.lang.Object obj11 = null;
        boolean boolean12 = rangeType10.equals(obj11);
        numberAxis1.setRangeType(rangeType10);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        categoryPlot34.mapDatasetToRangeAxis(100, (int) (short) 100);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot34.getDomainMarkers((-1), layer40);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        categoryPlot34.setDataset(1900, categoryDataset43);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(collection41);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, serialDate10, (-65281));
        java.util.Date date13 = spreadsheetDate5.toDate();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class16 = periodAxis15.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = periodAxis15.getLast();
        java.util.Date date18 = regularTimePeriod17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.TimeZone timeZone20 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class25 = periodAxis24.getAutoRangeTimePeriodClass();
        float float26 = periodAxis24.getMinorTickMarkOutsideLength();
        java.lang.Class class27 = periodAxis24.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class30 = periodAxis29.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = periodAxis29.getLast();
        java.util.Date date32 = regularTimePeriod31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class36 = periodAxis35.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = periodAxis35.getLast();
        java.util.Date date38 = regularTimePeriod37.getStart();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        java.util.TimeZone timeZone40 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone40);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection43 = new org.jfree.data.time.TimeSeriesCollection(timeSeries22, timeZone40);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date18, timeZone40);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date13, timeZone40);
        long long46 = month45.getFirstMillisecond();
        long long47 = month45.getSerialIndex();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        int int49 = day48.getMonth();
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("DateTickUnitType.HOUR", (org.jfree.data.time.RegularTimePeriod) month45, (org.jfree.data.time.RegularTimePeriod) day48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeriesDataItem52.getPeriod();
        try {
            org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) regularTimePeriod53, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2208960000000L) + "'", long46 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 22801L + "'", long47 == 22801L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        xYBarRenderer0.clearSeriesPaints(true);
        xYBarRenderer0.setShadowYOffset((double) 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        timeSeriesCollection21.clearSelection();
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class25 = periodAxis24.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = periodAxis24.getLast();
        java.util.Date date27 = regularTimePeriod26.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date27);
        timeSeries30.removeAgedItems(0L, true);
        java.lang.String str34 = timeSeries30.getDomainDescription();
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class37 = periodAxis36.getAutoRangeTimePeriodClass();
        float float38 = periodAxis36.getMinorTickMarkOutsideLength();
        java.lang.Class class39 = periodAxis36.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class42 = periodAxis41.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = periodAxis41.getLast();
        java.util.Date date44 = regularTimePeriod43.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class48 = periodAxis47.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = periodAxis47.getLast();
        java.util.Date date50 = regularTimePeriod49.getStart();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        java.util.TimeZone timeZone52 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date50, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date44, timeZone52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod54, (java.lang.Number) (-1.0f));
        timeSeries30.add(timeSeriesDataItem56);
        timeSeriesCollection21.addSeries(timeSeries30);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setURLText("MINOR");
        java.awt.Paint paint17 = legendItem14.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        int int4 = xYPlot2.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint11 = null;
        piePlot9.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot9.setBaseSectionPaint(paint13);
        periodAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot9);
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis6);
        float float17 = xYPlot2.getForegroundAlpha();
        java.awt.Stroke stroke18 = xYPlot2.getDomainGridlineStroke();
        try {
            strokeList0.setStroke((-16777216), stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        categoryPlot34.mapDatasetToRangeAxis(100, (int) (short) 100);
        categoryPlot34.mapDatasetToRangeAxis(2, 5);
        org.jfree.chart.axis.AxisSpace axisSpace42 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace42.ensureAtLeast((double) 1, rectangleEdge44);
        categoryPlot34.setFixedRangeAxisSpace(axisSpace42);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) (-1), (double) ' ', (java.awt.Paint) color10);
        markerAxisBand7.addMarker(intervalMarker11);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot34.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot34.getDataset((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        java.util.List list39 = categoryPlot34.getCategoriesForAxis(categoryAxis38);
        java.awt.Paint paint40 = categoryPlot34.getDomainCrosshairPaint();
        categoryPlot34.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertNull(categoryDataset37);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot1.setBaseSectionPaint(paint5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot1.setBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d, paint7, stroke9);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class13 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis12.getLast();
        org.jfree.data.Range range15 = periodAxis12.getDefaultAutoRange();
        java.awt.Stroke stroke16 = periodAxis12.getTickMarkStroke();
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        valueMarker10.setLabelPaint(paint18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray9 = new float[] { 0L, 100, 3, (byte) 1, (short) 1, 10.0f };
        float[] floatArray10 = color2.getComponents(floatArray9);
        try {
            float[] floatArray11 = color0.getComponents(colorSpace1, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot0.getURLGenerator();
        org.jfree.chart.util.Rotation rotation5 = null;
        try {
            piePlot0.setDirection(rotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.data.KeyToGroupMap keyToGroupMap30 = null;
        try {
            org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset27, keyToGroupMap30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font7 = periodAxis4.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = xYLineAndShapeRenderer8.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        xYLineAndShapeRenderer8.setSeriesFillPaint(100, paint18);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font7, paint18, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("NOID", font7);
        java.lang.String str23 = labelBlock22.getToolTipText();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int29 = xYSeries27.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray30 = xYSeries27.toArray();
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock22, (java.lang.Object) xYSeries27);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setBaseShapesVisible(true);
        java.awt.Font font12 = null;
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, (float) 0L, 0, textMeasurer16);
        xYLineAndShapeRenderer0.setBaseItemLabelPaint(paint13, true);
        java.awt.Shape shape21 = xYLineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Shape shape22 = xYLineAndShapeRenderer0.getLegendLine();
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("NOID", "NOID", "hi!");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) ' ', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        xYStepAreaRenderer6.setPlotArea(false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setDatasetIndex(4);
        double double3 = crosshairState0.getCrosshairDistance();
        crosshairState0.setAnchorY((double) 100);
        crosshairState0.setCrosshairDistance(Double.NaN);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getLabelLinksVisible();
        double double2 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        double double2 = xYBarRenderer0.getMargin();
        xYBarRenderer0.setUseYInterval(true);
        boolean boolean5 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setShadowXOffset((double) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) '#');
        java.awt.Stroke stroke11 = xYBarRenderer0.lookupSeriesOutlineStroke((int) 'a');
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter15 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(0.0d, (double) 4, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter15);
        xYBarRenderer0.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot32.zoomDomainAxes(1.0d, plotRenderingInfo34, point2D35, false);
        xYLineAndShapeRenderer20.setPlot(xYPlot32);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = xYLineAndShapeRenderer20.getBaseURLGenerator();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        xYLineAndShapeRenderer20.notifyListeners(rendererChangeEvent40);
        combinedRangeXYPlot0.setRenderer((int) (short) 1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator43 = xYLineAndShapeRenderer20.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNull(xYURLGenerator39);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator43);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        numberFormat2.setParseIntegerOnly(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", numberFormat1, numberFormat2);
        java.lang.Number number7 = numberFormat1.parse("-3,-3,3,3");
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-3L) + "'", number7.equals((-3L)));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        float float3 = periodAxis1.getMinorTickMarkOutsideLength();
        java.lang.Class class4 = periodAxis1.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        java.util.Date date9 = regularTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class13 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis12.getLast();
        java.util.Date date15 = regularTimePeriod14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date9, timeZone17);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class22 = periodAxis21.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = periodAxis21.getLast();
        java.util.Date date24 = regularTimePeriod23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24, timeZone26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, serialDate36, (-65281));
        java.util.Date date39 = spreadsheetDate31.toDate();
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class42 = periodAxis41.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = periodAxis41.getLast();
        java.util.Date date44 = regularTimePeriod43.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        java.util.TimeZone timeZone46 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44, timeZone46);
        org.jfree.data.time.TimeSeries timeSeries48 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class51 = periodAxis50.getAutoRangeTimePeriodClass();
        float float52 = periodAxis50.getMinorTickMarkOutsideLength();
        java.lang.Class class53 = periodAxis50.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis55 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class56 = periodAxis55.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = periodAxis55.getLast();
        java.util.Date date58 = regularTimePeriod57.getStart();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        org.jfree.chart.axis.PeriodAxis periodAxis61 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class62 = periodAxis61.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = periodAxis61.getLast();
        java.util.Date date64 = regularTimePeriod63.getStart();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date64);
        java.util.TimeZone timeZone66 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date64, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date58, timeZone66);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection69 = new org.jfree.data.time.TimeSeriesCollection(timeSeries48, timeZone66);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date44, timeZone66);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date39, timeZone66);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone66;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date24, timeZone66);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(class62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot1.getLabelDistributor();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot1.axisChanged(axisChangeEvent9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        piePlot1.setLabelGap((double) 0L);
        double double14 = piePlot1.getStartAngle();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart15.getLegend(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle17.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 90.0d + "'", double14 == 90.0d);
        org.junit.Assert.assertNotNull(legendTitle17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font6);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis13, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font18);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) ' ', (double) (byte) -1, (double) (short) 10, (double) 'a', font18);
        org.jfree.data.RangeType rangeType21 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rangeType21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        java.util.List list22 = timeSeriesCollection21.getSeries();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeriesCollection23.getSeries(comparable24);
        java.util.List list26 = timeSeriesCollection23.getSeries();
        org.jfree.data.Range range27 = null;
        try {
            org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection21, list26, range27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xRange' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(timeSeries25);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        double double2 = xYBarRenderer0.getMargin();
        boolean boolean5 = xYBarRenderer0.getItemVisible(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean2 = rangeType0.equals((java.lang.Object) shape1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot34.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot34.getDataset((-1));
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        categoryPlot34.rendererChanged(rendererChangeEvent38);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertNull(categoryDataset37);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = null;
        piePlot34.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint36);
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBaseSectionPaint(paint38);
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBackgroundPaint(paint40);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(1.0d, paint40, stroke42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean45 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker43, layer44);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent47 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) xYPlot12, true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeMinorGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = categoryPlot34.getLegendItems();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer38.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer38.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font45 = xYLineAndShapeRenderer38.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer38.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape50 = xYLineAndShapeRenderer38.lookupLegendShape((int) (short) 1);
        boolean boolean54 = xYLineAndShapeRenderer38.isItemLabelVisible(12, (-16777216), true);
        java.awt.Paint paint55 = xYLineAndShapeRenderer38.getBasePaint();
        categoryPlot34.setDomainGridlinePaint(paint55);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(legendItemCollection37);
        org.junit.Assert.assertNull(font45);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setDrawOutlines(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator((int) (short) 10);
        org.junit.Assert.assertNull(xYItemLabelGenerator12);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        float float3 = periodAxis1.getMinorTickMarkOutsideLength();
        java.lang.Class class4 = periodAxis1.getMajorTickTimePeriodClass();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = null;
        piePlot5.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint7);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot5.getLabelDistributor();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot5.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        piePlot5.axisChanged(axisChangeEvent13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = piePlot5.getURLGenerator();
        piePlot5.setLabelGap((double) 0L);
        double double18 = piePlot5.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = piePlot5.getLabelPadding();
        periodAxis1.setTickLabelInsets(rectangleInsets19);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNull(pieURLGenerator15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 90.0d + "'", double18 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(true);
        java.util.List list3 = segmentedTimeline0.getExceptionSegments();
        long long4 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        numberFormat0.setMaximumIntegerDigits(1);
        numberFormat0.setMaximumFractionDigits(0);
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = null;
        piePlot6.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint8);
        boolean boolean10 = piePlot3D5.equals((java.lang.Object) (-1L));
        double double11 = piePlot3D5.getShadowYOffset();
        boolean boolean12 = piePlot3D5.getSimpleLabels();
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator13 = numberFormat0.formatToCharacterIterator((java.lang.Object) boolean12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        xYBarRenderer0.setShadowXOffset(0.0d);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesCreateEntities((int) (short) 100);
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int11 = xYSeries9.indexOf((java.lang.Number) (byte) 100);
        int int12 = xYSeries9.getMaximumItemCount();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        int int15 = xYPlot13.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate17 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection14, true);
        java.util.List list18 = timeSeriesCollection14.getSeries();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Comparable comparable20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeriesCollection19.getSeries(comparable20);
        java.util.List list22 = timeSeriesCollection19.getSeries();
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range25 = timeSeriesCollection14.getRangeBounds(list22, range23, true);
        xYSeries9.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection14);
        org.jfree.data.Range range27 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(timeSeries21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = logAxis1.equals((java.lang.Object) textBlockAnchor2);
        double double4 = logAxis1.getSmallestValue();
        org.jfree.chart.ChartTheme chartTheme5 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        boolean boolean6 = logAxis1.equals((java.lang.Object) chartTheme5);
        logAxis1.zoomRange(1.0E-100d, 4.0d);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis1, polarItemRenderer10);
        polarPlot11.setAngleGridlinesVisible(true);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint15 = blockBorder14.getPaint();
        polarPlot11.setRadiusGridlinePaint(paint15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double19 = rectangleInsets18.getTop();
        double double21 = rectangleInsets18.calculateTopInset(0.0d);
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis27.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font30 = periodAxis27.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer31.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint36 = xYLineAndShapeRenderer31.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        piePlot38.setStartAngle((double) 1);
        java.awt.Paint paint41 = piePlot38.getLabelPaint();
        xYLineAndShapeRenderer31.setSeriesFillPaint(100, paint41);
        org.jfree.chart.text.TextFragment textFragment44 = new org.jfree.chart.text.TextFragment("hi!", font30, paint41, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("NOID", font30);
        org.jfree.chart.entity.EntityCollection entityCollection48 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = new org.jfree.chart.ChartRenderingInfo(entityCollection48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = chartRenderingInfo49.getPlotInfo();
        int int51 = plotRenderingInfo50.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D52 = plotRenderingInfo50.getDataArea();
        boolean boolean53 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D52);
        labelBlock45.setBounds(rectangle2D52);
        boolean boolean55 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D52);
        rectangleInsets18.trim(rectangle2D52);
        java.awt.geom.Point2D point2D57 = null;
        org.jfree.chart.plot.PlotState plotState58 = null;
        org.jfree.chart.entity.EntityCollection entityCollection59 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo(entityCollection59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = chartRenderingInfo60.getPlotInfo();
        polarPlot11.draw(graphics2D17, rectangle2D52, point2D57, plotState58, plotRenderingInfo61);
        polarPlot11.clearCornerTextItems();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-100d + "'", double4 == 1.0E-100d);
        org.junit.Assert.assertNotNull(chartTheme5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(plotRenderingInfo50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo61);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat7 = null;
        dateAxis6.setDateFormatOverride(dateFormat7);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class11 = periodAxis10.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = periodAxis10.getLast();
        org.jfree.data.Range range13 = periodAxis10.getDefaultAutoRange();
        dateAxis6.setRange(range13);
        org.jfree.data.Range range15 = org.jfree.data.Range.combine(range4, range13);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat18 = null;
        dateAxis17.setDateFormatOverride(dateFormat18);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class22 = periodAxis21.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = periodAxis21.getLast();
        org.jfree.data.Range range24 = periodAxis21.getDefaultAutoRange();
        dateAxis17.setRange(range24);
        double double26 = range24.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range13, range24);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat31 = null;
        dateAxis30.setDateFormatOverride(dateFormat31);
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class35 = periodAxis34.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = periodAxis34.getLast();
        org.jfree.data.Range range37 = periodAxis34.getDefaultAutoRange();
        dateAxis30.setRange(range37);
        double double39 = range37.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) 4, (double) (-1L));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType43 = rectangleConstraint42.getHeightConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat47 = null;
        dateAxis46.setDateFormatOverride(dateFormat47);
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class51 = periodAxis50.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = periodAxis50.getLast();
        org.jfree.data.Range range53 = periodAxis50.getDefaultAutoRange();
        dateAxis46.setRange(range53);
        double double55 = range53.getLowerBound();
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class58 = periodAxis57.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = periodAxis57.getLast();
        org.jfree.data.Range range60 = periodAxis57.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat63 = null;
        dateAxis62.setDateFormatOverride(dateFormat63);
        org.jfree.chart.axis.PeriodAxis periodAxis66 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class67 = periodAxis66.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = periodAxis66.getLast();
        org.jfree.data.Range range69 = periodAxis66.getDefaultAutoRange();
        dateAxis62.setRange(range69);
        org.jfree.data.Range range71 = org.jfree.data.Range.combine(range60, range69);
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat74 = null;
        dateAxis73.setDateFormatOverride(dateFormat74);
        org.jfree.chart.axis.PeriodAxis periodAxis77 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class78 = periodAxis77.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = periodAxis77.getLast();
        org.jfree.data.Range range80 = periodAxis77.getDefaultAutoRange();
        dateAxis73.setRange(range80);
        double double82 = range80.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint83 = new org.jfree.chart.block.RectangleConstraint(range69, range80);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType84 = rectangleConstraint83.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint85 = new org.jfree.chart.block.RectangleConstraint(0.0d, range37, lengthConstraintType43, (double) 1900, range53, lengthConstraintType84);
        org.jfree.data.Range range88 = org.jfree.data.Range.expand(range37, (double) 9, (double) 15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint89 = rectangleConstraint27.toRangeHeight(range37);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType43);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(class67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertNotNull(class78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType84);
        org.junit.Assert.assertNotNull(range88);
        org.junit.Assert.assertNotNull(rectangleConstraint89);
    }
}

