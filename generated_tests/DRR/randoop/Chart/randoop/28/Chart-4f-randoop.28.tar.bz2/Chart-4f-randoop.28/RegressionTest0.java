import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity4 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape1, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (byte) 100, (float) 0L, (double) 100L, (-1.0f), (float) (-1L));
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) '4', xYURLGenerator2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        try {
            xYLineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) '4', xYURLGenerator2, true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            xYLineAndShapeRenderer0.fillRangeGridBand(graphics2D5, xYPlot6, valueAxis7, rectangle2D8, (double) ' ', (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = null;
        try {
            piePlot0.setLabelLinkStyle(pieLabelLinkStyle3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        xYLineAndShapeRenderer0.setBaseURLGenerator(xYURLGenerator1);
        java.awt.Stroke stroke3 = null;
        try {
            xYLineAndShapeRenderer0.setBaseOutlineStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity8 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "hi!", categoryDataset5, (java.lang.Comparable) 100.0d, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-65281) + "'", int1 == (-65281));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        piePlot0.setAutoPopulateSectionOutlineStroke(false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        try {
            java.lang.Number number5 = xYSeries3.getX((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
        org.junit.Assert.assertNotNull(inputStream2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setForegroundAlpha(1.0f);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            piePlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        try {
            java.util.ResourceBundle resourceBundle4 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("January", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator4, false);
        java.awt.Paint paint8 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (byte) 100);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        float[] floatArray2 = new float[] { (-1L) };
        try {
            float[] floatArray3 = color0.getRGBComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        try {
            piePlot3D0.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.TimeZone timeZone0 = null;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) (short) 10, (float) (byte) 100, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity7 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart4, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double7 = periodAxis1.valueToJava2D((double) (short) 0, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint5 = xYLineAndShapeRenderer0.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setStartAngle((double) 1);
        java.awt.Paint paint10 = piePlot7.getLabelPaint();
        xYLineAndShapeRenderer0.setSeriesFillPaint(100, paint10);
        boolean boolean12 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        xYSeries3.add((java.lang.Number) 1, (java.lang.Number) (-1.0d), false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class4 = periodAxis3.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = periodAxis3.getLast();
        java.util.Date date6 = regularTimePeriod5.getStart();
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("", regularTimePeriod1, regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 0, (double) (short) 0, 1.0d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.lang.Object obj2 = chartRenderingInfo1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.expand(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        boolean boolean7 = xYSeries3.getNotify();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("NOID");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key NOID");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.lang.Class class5 = null;
        try {
            periodAxis1.setAutoRangeTimePeriodClass(class5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int[] intArray4 = org.jfree.chart.renderer.RendererUtilities.findLiveItems(xYDataset0, 0, 0.0d, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        try {
            xYSeries3.delete((-1), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: fromIndex = -1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (-1), 10.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBackgroundPaint(paint6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        double double3 = size2D2.width;
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis2.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font5 = periodAxis2.getLabelFont();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list10 = periodAxis2.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        try {
            org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 12, (double) (byte) 100, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            jFreeChart8.draw(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        piePlot0.setBackgroundAlpha((float) (short) 1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setLowerMargin((double) (byte) 100);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setStartAngle((double) 1);
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 1 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator4, false);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.shrink(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        boolean boolean3 = itemLabelPosition1.equals((java.lang.Object) itemLabelAnchor2);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font7 = periodAxis4.getLabelFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list12 = periodAxis4.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        try {
            double double13 = logAxis0.java2DToValue(0.0d, rectangle2D2, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource1, (org.jfree.chart.block.Arrangement) columnArrangement2, (org.jfree.chart.block.Arrangement) columnArrangement3);
        boolean boolean5 = axisSpace0.equals((java.lang.Object) columnArrangement3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = axisSpace0.shrink(rectangle2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) '4', xYURLGenerator2, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        xYBarRenderer6.setNegativeItemLabelPositionFallback(itemLabelPosition8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYBarRenderer6.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        try {
            xYLineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((-65281), itemLabelPosition11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (int) (short) 10, (double) 'a', (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        double double3 = periodAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) 0L, 0, textMeasurer5);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.calculateLeftOutset(0.0d);
        try {
            org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder(paint2, stroke7, rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        try {
            java.lang.Number number2 = numberFormat0.parse("LegendItemEntity: seriesKey=null, dataset=null");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"LegendItemEntity: seriesKey=null, dataset=null\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke7 = xYLineAndShapeRenderer0.lookupSeriesStroke(4);
        java.lang.Boolean boolean9 = xYLineAndShapeRenderer0.getSeriesShapesVisible(0);
        xYLineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYLineAndShapeRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(xYURLGenerator12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            logAxis0.setTickUnit(numberTickUnit1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.reserved(rectangle2D2, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer5.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke12 = xYLineAndShapeRenderer5.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYLineAndShapeRenderer5.drawAnnotations(graphics2D13, rectangle2D14, valueAxis15, valueAxis16, layer17, plotRenderingInfo18);
        try {
            xYPlot0.addRangeMarker(2, marker4, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(layer17);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer7.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke14 = xYLineAndShapeRenderer7.lookupSeriesStroke(4);
        xYBarRenderer0.setSeriesOutlineStroke(0, stroke14, false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("VerticalAlignment.CENTER");
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        try {
            xYSeries3.update((java.lang.Number) (-65281), (java.lang.Number) 4.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = -65281");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setDatasetIndex(4);
        double double3 = crosshairState0.getCrosshairDistance();
        crosshairState0.setAnchorY((double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        int int2 = day0.compareTo(obj1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.lookupLegendShape((int) (short) 1);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer0.drawDomainMarker(graphics2D13, xYPlot14, valueAxis15, marker16, rectangle2D17);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "January");
        java.lang.Object obj6 = chartEntity5.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font7 = periodAxis4.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = xYLineAndShapeRenderer8.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        xYLineAndShapeRenderer8.setSeriesFillPaint(100, paint18);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font7, paint18, (-1.0f));
        java.awt.Paint paint22 = textFragment21.getPaint();
        textTitle1.setPaint(paint22);
        java.awt.Graphics2D graphics2D24 = null;
        try {
            org.jfree.chart.util.Size2D size2D25 = textTitle1.arrange(graphics2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getPreviousDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            jFreeChart9.draw(graphics2D13, rectangle2D14, point2D15, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 100L, (double) (-1));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieToolTipGenerator.DEFAULT_TOOLTIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        java.awt.Paint paint7 = null;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "January", "January", "", shape6, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis2.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font5 = periodAxis2.getLabelFont();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list10 = periodAxis2.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        try {
            org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint18 = null;
        piePlot16.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint18);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot16.setBaseSectionPaint(paint20);
        periodAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot16);
        java.awt.Font font25 = null;
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer29 = null;
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, paint26, (float) 0L, 0, textMeasurer29);
        piePlot16.setSectionOutlinePaint((java.lang.Comparable) 0.0d, paint26);
        xYLineAndShapeRenderer0.setBaseOutlinePaint(paint26);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock30);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int3 = java.awt.Color.HSBtoRGB((float) 10L, 2.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(0.0d, (double) 4, (double) (-1));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer5.removeAnnotations();
        java.awt.geom.RectangularShape rectangularShape10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            gradientXYBarPainter3.paintBar(graphics2D4, xYBarRenderer5, 7, (int) (byte) 100, true, rectangularShape10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double5 = numberAxis1.valueToJava2D((double) 0, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        try {
            timeSeriesCollection21.removeSeries((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class6 = periodAxis5.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = periodAxis5.getLast();
        org.jfree.data.Range range8 = periodAxis5.getDefaultAutoRange();
        dateAxis1.setRange(range8);
        float float10 = dateAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str16 = rectangleEdge15.toString();
        org.jfree.chart.entity.EntityCollection entityCollection17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo(entityCollection17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = chartRenderingInfo18.getPlotInfo();
        try {
            org.jfree.chart.axis.AxisState axisState20 = dateAxis1.draw(graphics2D11, (double) (-1), rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleEdge.RIGHT" + "'", str16.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(plotRenderingInfo19);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart8.setTitle("NOID");
        org.jfree.chart.plot.Plot plot11 = jFreeChart8.getPlot();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        try {
            xYPlot0.mapDatasetToRangeAxis((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        int int8 = xYPlot6.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot6.getDomainAxisEdge((int) '#');
        try {
            double double11 = periodAxis1.java2DToValue(0.0d, rectangle2D5, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "item", (double) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setVisible(false);
        java.awt.Stroke stroke4 = periodAxis1.getMinorTickMarkStroke();
        boolean boolean5 = periodAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex((int) ' ');
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection21);
        try {
            int[] intArray25 = timeSeriesCollection21.getSurroundingItems((int) (short) 1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertEquals((double) number22, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.LegendItem legendItem8 = xYBarRenderer0.getLegendItem((int) (byte) 0, (int) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYBarRenderer0.notifyListeners(rendererChangeEvent9);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 10, (double) (short) 10, 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer9.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYLineAndShapeRenderer9.setBaseToolTipGenerator(xYToolTipGenerator13, true);
        xYLineAndShapeRenderer9.setDrawOutlines(false);
        xYLineAndShapeRenderer9.setBaseShapesVisible(true);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        xYLineAndShapeRenderer9.setBasePaint(paint20);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer22.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYLineAndShapeRenderer22.setBaseToolTipGenerator(xYToolTipGenerator26, true);
        xYLineAndShapeRenderer22.setDrawOutlines(false);
        java.awt.Font font32 = xYLineAndShapeRenderer22.getSeriesItemLabelFont(10);
        java.awt.Paint paint33 = xYLineAndShapeRenderer22.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot34.zoomDomainAxes(1.0d, plotRenderingInfo36, point2D37, false);
        xYLineAndShapeRenderer22.setPlot(xYPlot34);
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer22.getItemOutlineStroke((int) (byte) 0, 7, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer46 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer46.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer46.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font53 = xYLineAndShapeRenderer46.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer46.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape58 = xYLineAndShapeRenderer46.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity59 = new org.jfree.chart.entity.ChartEntity(shape58);
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        java.awt.geom.Point2D point2D63 = null;
        xYPlot60.zoomDomainAxes(1.0d, plotRenderingInfo62, point2D63, false);
        java.awt.Stroke stroke66 = xYPlot60.getDomainGridlineStroke();
        java.awt.Color color67 = java.awt.Color.yellow;
        try {
            org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem(attributedString0, "ThreadContext", "VerticalAlignment.CENTER", "hi!", false, shape5, false, (java.awt.Paint) color7, false, paint20, stroke44, true, shape58, stroke66, (java.awt.Paint) color67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(font32);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(font53);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color67);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.Marker marker19 = null;
        try {
            xYPlot12.addRangeMarker(marker19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = legendTitle3.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setParseIntegerOnly(false);
        java.math.RoundingMode roundingMode3 = null;
        try {
            numberFormat0.setRoundingMode(roundingMode3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double6 = numberAxis1.java2DToValue((double) 'a', rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        xYLineAndShapeRenderer0.setSeriesShapesVisible(1, (java.lang.Boolean) true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        float[] floatArray5 = new float[] { 100L, (short) -1 };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) 'a', 100, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}: ({1}, {2})", graphics2D1, (double) 0L, (float) '4', (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Shape shape11 = null;
        try {
            xYLineAndShapeRenderer0.setBaseShape(shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = logFormat0.format((java.lang.Object) dateTickUnitType1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextOutlinePaint();
        try {
            org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("item", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        float float3 = periodAxis1.getMinorTickMarkOutsideLength();
        java.lang.Class class4 = periodAxis1.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        java.util.Date date9 = regularTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class13 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis12.getLast();
        java.util.Date date15 = regularTimePeriod14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date9, timeZone17);
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class4);
        boolean boolean21 = org.jfree.chart.util.SerialUtilities.isSerializable(class4);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(classLoader20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot5 = periodAxis1.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets6.getTop();
        periodAxis1.setLabelInsets(rectangleInsets6, false);
        double double11 = rectangleInsets6.calculateLeftOutset((double) 0L);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor3 = null;
        try {
            timeSeriesCollection1.setXPosition(timePeriodAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(0.0d);
        double double4 = rectangleInsets0.trimHeight((double) (-65281));
        double double6 = rectangleInsets0.extendHeight((double) 0L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-65285.0d) + "'", double4 == (-65285.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 2 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) '4', xYURLGenerator2, true);
        xYLineAndShapeRenderer0.clearSeriesStrokes(false);
        xYLineAndShapeRenderer0.setBaseSeriesVisible(true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getUseFillPaint();
        xYAreaRenderer0.setOutline(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1.0d, 0.0d, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("Range[0.0,1.0]", (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator0 = new org.jfree.chart.urls.StandardXYURLGenerator();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) '4', xYURLGenerator2, true);
        xYLineAndShapeRenderer0.clearSeriesStrokes(false);
        java.lang.Boolean boolean8 = xYLineAndShapeRenderer0.getSeriesCreateEntities(0);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "January");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator6 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator7 = null;
        try {
            java.lang.String str8 = chartEntity5.getImageMapAreaTag(toolTipTagFragmentGenerator6, uRLTagFragmentGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        double double3 = textTitle1.getWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        double double5 = intervalXYDelegate4.getFixedIntervalWidth();
        try {
            double double8 = intervalXYDelegate4.getEndXValue((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        piePlot0.setLabelGap((double) 0L);
        piePlot0.setLabelLinkMargin((double) 1.0f);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        double double5 = intervalXYDelegate4.getFixedIntervalWidth();
        boolean boolean6 = intervalXYDelegate4.isAutoWidth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(0.0d);
        double double4 = rectangleInsets0.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYLineAndShapeRenderer7.setBaseToolTipGenerator(xYToolTipGenerator11, true);
        xYLineAndShapeRenderer7.setDrawOutlines(false);
        xYLineAndShapeRenderer7.setDrawOutlines(true);
        boolean boolean18 = textAnchor6.equals((java.lang.Object) true);
        try {
            java.awt.Shape shape19 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleEdge.RIGHT", graphics2D1, (float) '4', (float) (byte) -1, textAnchor4, (double) (short) -1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint5 = xYLineAndShapeRenderer0.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setStartAngle((double) 1);
        java.awt.Paint paint10 = piePlot7.getLabelPaint();
        xYLineAndShapeRenderer0.setSeriesFillPaint(100, paint10);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer13.setSeriesShape(12, shape17, false);
        xYLineAndShapeRenderer0.setSeriesShape(0, shape17, false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        java.util.List list22 = timeSeriesCollection21.getSeries();
        try {
            java.lang.Number number25 = timeSeriesCollection21.getStartX(100, (-65281));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBackgroundPaint(paint6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot0.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = piePlot0.getLabelLinkStyle();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer10.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYLineAndShapeRenderer10.setBaseToolTipGenerator(xYToolTipGenerator14, true);
        xYLineAndShapeRenderer10.setDrawOutlines(false);
        java.awt.Font font20 = xYLineAndShapeRenderer10.getSeriesItemLabelFont(10);
        java.awt.Paint paint21 = xYLineAndShapeRenderer10.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot22.zoomDomainAxes(1.0d, plotRenderingInfo24, point2D25, false);
        xYLineAndShapeRenderer10.setPlot(xYPlot22);
        java.awt.Stroke stroke29 = xYPlot22.getDomainZeroBaselineStroke();
        boolean boolean30 = pieLabelLinkStyle9.equals((java.lang.Object) xYPlot22);
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = null;
        try {
            xYPlot22.addDomainMarker(marker31, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = java.awt.Color.yellow;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[0.0,1.0]", font1, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 2, (-65285.0d));
        java.lang.String str5 = verticalAlignment1.toString();
        java.lang.String str6 = verticalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.CENTER" + "'", str5.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.CENTER" + "'", str6.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        double double13 = crosshairState0.getCrosshairDistance();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        abstractPieLabelDistributor4.clear();
        abstractPieLabelDistributor4.clear();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) '4', xYURLGenerator2, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYLineAndShapeRenderer0.notifyListeners(rendererChangeEvent5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYLineAndShapeRenderer11.setBaseToolTipGenerator(xYToolTipGenerator15, true);
        xYLineAndShapeRenderer11.setDrawOutlines(false);
        java.awt.Font font21 = xYLineAndShapeRenderer11.getSeriesItemLabelFont(10);
        java.awt.Paint paint22 = xYLineAndShapeRenderer11.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes(1.0d, plotRenderingInfo25, point2D26, false);
        xYLineAndShapeRenderer11.setPlot(xYPlot23);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint33 = null;
        piePlot31.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint33);
        boolean boolean35 = piePlot3D30.equals((java.lang.Object) (-1L));
        double double36 = piePlot3D30.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis40.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font43 = periodAxis40.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer44 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer44.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint49 = xYLineAndShapeRenderer44.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        piePlot51.setStartAngle((double) 1);
        java.awt.Paint paint54 = piePlot51.getLabelPaint();
        xYLineAndShapeRenderer44.setSeriesFillPaint(100, paint54);
        org.jfree.chart.text.TextFragment textFragment57 = new org.jfree.chart.text.TextFragment("hi!", font43, paint54, (-1.0f));
        java.awt.Color color58 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment59 = new org.jfree.chart.text.TextFragment("hi!", font43, (java.awt.Paint) color58);
        piePlot3D30.setLabelFont(font43);
        xYPlot23.setNoDataMessageFont(font43);
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint64 = null;
        piePlot62.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint64);
        java.awt.Paint paint66 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot62.setBaseSectionPaint(paint66);
        java.awt.Stroke stroke68 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot62.setLabelOutlineStroke(stroke68);
        xYPlot23.setRangeMinorGridlineStroke(stroke68);
        org.jfree.chart.plot.Marker marker72 = null;
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean74 = xYPlot23.removeDomainMarker((int) (short) 0, marker72, layer73);
        try {
            xYPlot0.addRangeMarker(marker10, layer73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class10 = periodAxis9.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis9.getLast();
        try {
            timeSeries7.update(regularTimePeriod11, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint22 = null;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint22);
        boolean boolean24 = piePlot3D19.equals((java.lang.Object) (-1L));
        double double25 = piePlot3D19.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis29.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font32 = periodAxis29.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint38 = xYLineAndShapeRenderer33.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        piePlot40.setStartAngle((double) 1);
        java.awt.Paint paint43 = piePlot40.getLabelPaint();
        xYLineAndShapeRenderer33.setSeriesFillPaint(100, paint43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font32, paint43, (-1.0f));
        java.awt.Color color47 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!", font32, (java.awt.Paint) color47);
        piePlot3D19.setLabelFont(font32);
        xYPlot12.setNoDataMessageFont(font32);
        org.jfree.chart.plot.Marker marker51 = null;
        try {
            boolean boolean52 = xYPlot12.removeRangeMarker(marker51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        double double6 = piePlot3D0.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis10.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font13 = periodAxis10.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint19 = xYLineAndShapeRenderer14.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        piePlot21.setStartAngle((double) 1);
        java.awt.Paint paint24 = piePlot21.getLabelPaint();
        xYLineAndShapeRenderer14.setSeriesFillPaint(100, paint24);
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("hi!", font13, paint24, (-1.0f));
        java.awt.Color color28 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font13, (java.awt.Paint) color28);
        piePlot3D0.setLabelFont(font13);
        java.lang.String str31 = piePlot3D0.getPlotType();
        piePlot3D0.setCircular(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Pie 3D Plot" + "'", str31.equals("Pie 3D Plot"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
        try {
            timeSeries7.update(4, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setForegroundAlpha(1.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot0.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = xYAreaRenderer0.getLegendItem(7, (-1));
        boolean boolean4 = xYAreaRenderer0.getPlotArea();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        int int6 = xYPlot0.getSeriesCount();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot0.drawBackgroundImage(graphics2D7, rectangle2D8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat12 = null;
        dateAxis11.setDateFormatOverride(dateFormat12);
        java.awt.Font font15 = null;
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint16, (float) 0L, 0, textMeasurer19);
        boolean boolean21 = dateAxis11.equals((java.lang.Object) paint16);
        boolean boolean22 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}: ({1}, {2})");
        float float2 = periodAxis1.getMinorTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = logAxis0.equals((java.lang.Object) textBlockAnchor1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo6.getPlotInfo();
        int int8 = plotRenderingInfo7.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D9 = plotRenderingInfo7.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str12 = rectangleEdge11.toString();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint15 = null;
        piePlot13.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint15);
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot13.setBaseSectionPaint(paint17);
        java.awt.Paint paint19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot13.setBackgroundPaint(paint19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = piePlot13.getDrawingSupplier();
        java.lang.Object obj22 = piePlot13.clone();
        piePlot13.clearSectionOutlineStrokes(false);
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = chartRenderingInfo28.getPlotInfo();
        piePlot13.handleClick((int) (byte) -1, (int) (short) 1, plotRenderingInfo29);
        try {
            org.jfree.chart.axis.AxisState axisState31 = logAxis0.draw(graphics2D3, (double) (byte) 1, rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.RIGHT" + "'", str12.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(plotRenderingInfo29);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset27, false);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = logAxis0.equals((java.lang.Object) textBlockAnchor1);
        double double3 = logAxis0.getSmallestValue();
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        logAxis0.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.color.ColorSpace colorSpace6 = null;
        float[] floatArray12 = new float[] { (byte) -1, (-1.0f), 1L, 100, (byte) 0 };
        try {
            float[] floatArray13 = color4.getComponents(colorSpace6, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-100d + "'", double3 == 1.0E-100d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot0.getToolTipGenerator();
        java.lang.String str6 = piePlot0.getPlotType();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font7 = periodAxis4.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = xYLineAndShapeRenderer8.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        xYLineAndShapeRenderer8.setSeriesFillPaint(100, paint18);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font7, paint18, (-1.0f));
        java.awt.Paint paint22 = textFragment21.getPaint();
        textTitle1.setPaint(paint22);
        java.lang.String str24 = textTitle1.getText();
        textTitle1.setMaximumLinesToDisplay((int) (short) 1);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot3.zoomDomainAxes(1.0d, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        double double10 = axisSpace9.getBottom();
        xYPlot3.setFixedRangeAxisSpace(axisSpace9, true);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot3.setDomainCrosshairPaint(paint13);
        boolean boolean15 = xYPlot3.canSelectByRegion();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis17, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font22);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis29, (double) ' ', 0.0d, (double) (byte) 1, (double) 9, font34);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis17, (double) ' ', (double) (byte) -1, (double) (short) 10, (double) 'a', font34);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            xYBarRenderer0.fillDomainGridBand(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis17, rectangle2D37, (double) 2, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}: ({1}, {2})");
        periodAxis1.setLabelURL("RectangleEdge.RIGHT");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 100L, (double) (-1));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        plotRenderingInfo2.setPlotArea(rectangle2D3);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = plotRenderingInfo2.getSubplotInfo((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        xYLineAndShapeRenderer0.setBaseURLGenerator(xYURLGenerator1);
        try {
            xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        int int3 = plotRenderingInfo2.getSubplotCount();
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState5 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        boolean boolean33 = xYPlot12.isRangePannable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot12.getRenderer((int) ' ');
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(xYItemRenderer35);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = null;
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot4.setBaseSectionPaint(paint8);
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        java.awt.Font font13 = null;
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 0L, 0, textMeasurer17);
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) 0.0d, paint14);
        org.jfree.chart.util.Rotation rotation20 = piePlot4.getDirection();
        java.lang.String str21 = rotation20.toString();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Rotation.CLOCKWISE" + "'", str21.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis2.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font5 = periodAxis2.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer6.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint11 = xYLineAndShapeRenderer6.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        piePlot13.setStartAngle((double) 1);
        java.awt.Paint paint16 = piePlot13.getLabelPaint();
        xYLineAndShapeRenderer6.setSeriesFillPaint(100, paint16);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("hi!", font5, paint16, (-1.0f));
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer22.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYLineAndShapeRenderer22.setBaseToolTipGenerator(xYToolTipGenerator26, true);
        xYLineAndShapeRenderer22.setDrawOutlines(false);
        xYLineAndShapeRenderer22.setDrawOutlines(true);
        boolean boolean33 = textAnchor21.equals((java.lang.Object) true);
        try {
            float float34 = textFragment19.calculateBaselineOffset(graphics2D20, textAnchor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setBaseShapesVisible(true);
        java.awt.Font font12 = null;
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, (float) 0L, 0, textMeasurer16);
        xYLineAndShapeRenderer0.setBaseItemLabelPaint(paint13, true);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer0.lookupSeriesStroke(3);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.2d, (double) 1L, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class5 = periodAxis4.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = periodAxis4.getLast();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = null;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot7.setBaseSectionPaint(paint11);
        periodAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis4);
        float float15 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            boolean boolean18 = xYPlot0.removeAnnotation(xYAnnotation16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot5 = periodAxis1.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets6.getTop();
        periodAxis1.setLabelInsets(rectangleInsets6, false);
        java.lang.String str10 = periodAxis1.getLabelToolTip();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint14 = null;
        piePlot12.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint14);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot12.setBaseSectionPaint(paint16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot12.setBackgroundPaint(paint18);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = piePlot12.getDrawingSupplier();
        java.lang.Object obj21 = piePlot12.clone();
        piePlot12.clearSectionOutlineStrokes(false);
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = chartRenderingInfo25.getPlotInfo();
        int int27 = plotRenderingInfo26.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo26.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisSpace axisSpace30 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace30.ensureAtLeast((double) 1, rectangleEdge32);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace34 = periodAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) piePlot12, rectangle2D28, rectangleEdge29, axisSpace30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(plotRenderingInfo26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot0.axisChanged(axisChangeEvent6);
        piePlot0.setShadowYOffset((-65285.0d));
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) ' ', "java.awt.Color[r=255,g=175,b=175]", true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) ' ');
        try {
            org.jfree.data.xy.XYDataItem xYDataItem3 = xYSeries1.remove((java.lang.Number) 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextOutlinePaint();
        try {
            xYBarRenderer0.setSeriesItemLabelPaint((-65281), paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        try {
            org.jfree.chart.plot.XYPlot xYPlot15 = jFreeChart13.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(renderingHints14);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "January");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer10.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYLineAndShapeRenderer10.setBaseToolTipGenerator(xYToolTipGenerator14, true);
        xYLineAndShapeRenderer10.setDrawOutlines(false);
        java.awt.Font font20 = xYLineAndShapeRenderer10.getSeriesItemLabelFont(10);
        java.awt.Paint paint21 = xYLineAndShapeRenderer10.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot22.zoomDomainAxes(1.0d, plotRenderingInfo24, point2D25, false);
        xYLineAndShapeRenderer10.setPlot(xYPlot22);
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint32 = null;
        piePlot30.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint32);
        boolean boolean34 = piePlot3D29.equals((java.lang.Object) (-1L));
        double double35 = piePlot3D29.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis39.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font42 = periodAxis39.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer43.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint48 = xYLineAndShapeRenderer43.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot();
        piePlot50.setStartAngle((double) 1);
        java.awt.Paint paint53 = piePlot50.getLabelPaint();
        xYLineAndShapeRenderer43.setSeriesFillPaint(100, paint53);
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("hi!", font42, paint53, (-1.0f));
        java.awt.Color color57 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment58 = new org.jfree.chart.text.TextFragment("hi!", font42, (java.awt.Paint) color57);
        piePlot3D29.setLabelFont(font42);
        xYPlot22.setNoDataMessageFont(font42);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint63 = null;
        piePlot61.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint63);
        java.awt.Paint paint65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot61.setBaseSectionPaint(paint65);
        java.awt.Stroke stroke67 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot61.setLabelOutlineStroke(stroke67);
        xYPlot22.setRangeMinorGridlineStroke(stroke67);
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat72 = null;
        dateAxis71.setDateFormatOverride(dateFormat72);
        java.awt.Font font75 = null;
        java.awt.Paint paint76 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer79 = null;
        org.jfree.chart.text.TextBlock textBlock80 = org.jfree.chart.text.TextUtilities.createTextBlock("", font75, paint76, (float) 0L, 0, textMeasurer79);
        boolean boolean81 = dateAxis71.equals((java.lang.Object) paint76);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer82 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer82.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer82.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font89 = xYLineAndShapeRenderer82.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer82.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape94 = xYLineAndShapeRenderer82.lookupLegendShape((int) (short) 1);
        dateAxis71.setUpArrow(shape94);
        java.awt.Paint paint96 = dateAxis71.getLabelPaint();
        try {
            org.jfree.chart.LegendItem legendItem97 = new org.jfree.chart.LegendItem(attributedString0, "Rotation.CLOCKWISE", "{0}: ({1}, {2})", "Range[0.0,1.0]", shape6, stroke67, paint96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(textBlock80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(font89);
        org.junit.Assert.assertNotNull(shape94);
        org.junit.Assert.assertNotNull(paint96);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator4, false);
        xYLineAndShapeRenderer0.setUseOutlinePaint(false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = null;
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot4.setBaseSectionPaint(paint8);
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        java.awt.Font font13 = null;
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) 0L, 0, textMeasurer17);
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) 0.0d, paint14);
        org.jfree.chart.util.Rotation rotation20 = piePlot4.getDirection();
        piePlot4.zoom((double) 10L);
        piePlot4.setForegroundAlpha(10.0f);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(rotation20);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        java.lang.Number number6 = null;
        try {
            xYSeries3.add(number6, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'x' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        numberFormat2.setParseIntegerOnly(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", numberFormat1, numberFormat2);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint8 = null;
        piePlot6.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint8);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot6.getLabelDistributor();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot6.axisChanged(axisChangeEvent14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot6.getURLGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = piePlot6.getLegendItems();
        java.lang.Object obj18 = legendItemCollection17.clone();
        boolean boolean19 = standardPieSectionLabelGenerator5.equals(obj18);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis2.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font5 = periodAxis2.getLabelFont();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list10 = periodAxis2.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        axisState0.setTicks(list10);
        axisState0.setCursor((double) (-1L));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.Object obj1 = null;
        boolean boolean2 = horizontalAlignment0.equals(obj1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        piePlot1.setAutoPopulateSectionOutlineStroke(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart8.setTitle("NOID");
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot11 = jFreeChart8.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        piePlot0.setBackgroundAlpha((float) (short) 1);
        double double6 = piePlot0.getInteriorGap();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace0.ensureAtLeast((double) (short) 0, rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        numberFormat2.setParseIntegerOnly(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", numberFormat1, numberFormat2);
        java.text.AttributedString attributedString7 = null;
        standardPieSectionLabelGenerator5.setAttributedLabel(100, attributedString7);
        java.text.AttributedString attributedString10 = standardPieSectionLabelGenerator5.getAttributedLabel(9999);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNull(attributedString10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str1 = rectangleEdge0.toString();
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.RIGHT" + "'", str1.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.String str4 = legendItemEntity3.toString();
        java.awt.Shape shape5 = legendItemEntity3.getArea();
        org.jfree.data.general.Dataset dataset6 = legendItemEntity3.getDataset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str4.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(dataset6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        boolean boolean19 = xYLineAndShapeRenderer0.getDrawSeriesLineAsPath();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            int[] intArray5 = timeSeriesCollection1.getSurroundingItems(0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo6.getPlotInfo();
        int int8 = plotRenderingInfo7.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D9 = plotRenderingInfo7.getDataArea();
        try {
            legendTitle3.draw(graphics2D4, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint22 = null;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint22);
        boolean boolean24 = piePlot3D19.equals((java.lang.Object) (-1L));
        double double25 = piePlot3D19.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis29.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font32 = periodAxis29.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint38 = xYLineAndShapeRenderer33.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        piePlot40.setStartAngle((double) 1);
        java.awt.Paint paint43 = piePlot40.getLabelPaint();
        xYLineAndShapeRenderer33.setSeriesFillPaint(100, paint43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font32, paint43, (-1.0f));
        java.awt.Color color47 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!", font32, (java.awt.Paint) color47);
        piePlot3D19.setLabelFont(font32);
        xYPlot12.setNoDataMessageFont(font32);
        xYPlot12.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        jFreeChart13.setBorderPaint(paint14);
        int int16 = jFreeChart13.getSubtitleCount();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.data.Range range5 = xYLineAndShapeRenderer0.findRangeBounds(xYDataset4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer6.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer6.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font13 = xYLineAndShapeRenderer6.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer6.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape18 = xYLineAndShapeRenderer6.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        xYLineAndShapeRenderer0.setBaseShape(shape18);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator21 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYLineAndShapeRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator21);
        java.lang.Object obj23 = standardXYSeriesLabelGenerator21.clone();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.String str26 = standardXYSeriesLabelGenerator21.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection24, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (6).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 4);
        boolean boolean3 = xYDataItem2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.resizeRange2(0.0d, (double) (short) 0);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("ThreadContext");
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        double double3 = size2D2.getHeight();
        double double4 = size2D2.width;
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart8.setTitle("NOID");
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart8.getTitle();
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 9999 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, number8);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        piePlot11.setStartAngle((double) 1);
        java.awt.Paint paint14 = piePlot11.getLabelPaint();
        java.awt.Paint paint15 = piePlot11.getLabelLinkPaint();
        java.awt.Stroke stroke16 = null;
        piePlot11.setLabelOutlineStroke(stroke16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot11);
        jFreeChart18.setTitle("NOID");
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) year7, jFreeChart18, (int) (byte) 0, 0);
        int int24 = year7.getYear();
        long long25 = year7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke7 = xYLineAndShapeRenderer0.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYLineAndShapeRenderer0.drawAnnotations(graphics2D8, rectangle2D9, valueAxis10, valueAxis11, layer12, plotRenderingInfo13);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        int int7 = plotRenderingInfo6.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray18, numberArray22, numberArray26, numberArray30, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray35);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset36);
        java.awt.Paint paint38 = multiplePiePlot37.getAggregatedItemsPaint();
        try {
            org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem(attributedString0, "", "Rotation.CLOCKWISE", "Pie 3D Plot", (java.awt.Shape) rectangle2D8, paint38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(true);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) (byte) 0);
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        float float8 = periodAxis6.getMinorTickMarkOutsideLength();
        java.lang.Class class9 = periodAxis6.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class12 = periodAxis11.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = periodAxis11.getLast();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class18 = periodAxis17.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = periodAxis17.getLast();
        java.util.Date date20 = regularTimePeriod19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone22);
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class27 = periodAxis26.getAutoRangeTimePeriodClass();
        float float28 = periodAxis26.getMinorTickMarkOutsideLength();
        java.lang.Class class29 = periodAxis26.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class32 = periodAxis31.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = periodAxis31.getLast();
        java.util.Date date34 = regularTimePeriod33.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class38 = periodAxis37.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = periodAxis37.getLast();
        java.util.Date date40 = regularTimePeriod39.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        java.util.TimeZone timeZone42 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone42);
        boolean boolean45 = segmentedTimeline0.containsDomainRange(date14, date34);
        java.lang.Object obj46 = segmentedTimeline0.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        int int33 = xYPlot12.getSeriesCount();
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint38 = null;
        piePlot36.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint38);
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot36.setBaseSectionPaint(paint40);
        java.awt.Paint paint42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot36.setBackgroundPaint(paint42);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(1.0d, paint42, stroke44);
        org.jfree.chart.util.Layer layer46 = null;
        boolean boolean48 = xYPlot12.removeDomainMarker(9, (org.jfree.chart.plot.Marker) valueMarker45, layer46, true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        periodAxis1.setUpperBound((double) (-1));
        periodAxis1.resizeRange((double) 1, 3.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        double double5 = intervalXYDelegate4.getFixedIntervalWidth();
        try {
            double double8 = intervalXYDelegate4.getEndXValue((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (32).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.data.KeyToGroupMap keyToGroupMap29 = null;
        try {
            org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset27, keyToGroupMap29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        java.util.List list22 = timeSeriesCollection21.getSeries();
        org.jfree.data.Range range24 = timeSeriesCollection21.getDomainBounds(true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        java.awt.Paint paint19 = piePlot15.getLabelLinkPaint();
        java.awt.Stroke stroke20 = null;
        piePlot15.setLabelOutlineStroke(stroke20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot15);
        java.awt.Paint paint23 = piePlot15.getLabelOutlinePaint();
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) piePlot15, "MINOR");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator26 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator27 = null;
        try {
            java.lang.String str28 = plotEntity25.getImageMapAreaTag(toolTipTagFragmentGenerator26, uRLTagFragmentGenerator27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        boolean boolean7 = xYSeries3.getNotify();
        int int9 = xYSeries3.indexOf((java.lang.Number) 100);
        try {
            xYSeries3.updateByIndex(4, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator4, false);
        java.awt.Paint paint8 = null;
        xYLineAndShapeRenderer0.setSeriesOutlinePaint(1, paint8);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("RectangleEdge.RIGHT");
        xYLineAndShapeRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        try {
            xYLineAndShapeRenderer0.addAnnotation(xYAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(0.0d, Double.NaN);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.LegendItem legendItem8 = xYBarRenderer0.getLegendItem((int) (byte) 0, (int) ' ');
        java.awt.Color color10 = java.awt.Color.ORANGE;
        xYBarRenderer0.setSeriesOutlinePaint(100, (java.awt.Paint) color10);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = xYBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        boolean boolean6 = xYBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = chartRenderingInfo3.getPlotInfo();
        int int5 = plotRenderingInfo4.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getDataArea();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        java.lang.String str6 = basicProjectInfo4.getVersion();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 1);
        piePlot0.setBackgroundAlpha((float) (byte) 10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        java.lang.String str6 = basicProjectInfo4.getVersion();
        basicProjectInfo4.setVersion("item");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        java.util.Date date7 = year6.getEnd();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list9 = periodAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        float float10 = periodAxis1.getMinorTickMarkOutsideLength();
        java.awt.Shape shape11 = periodAxis1.getRightArrow();
        double double12 = periodAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBackgroundPaint(paint6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot0.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = piePlot0.getLabelLinkStyle();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer10.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYLineAndShapeRenderer10.setBaseToolTipGenerator(xYToolTipGenerator14, true);
        xYLineAndShapeRenderer10.setDrawOutlines(false);
        java.awt.Font font20 = xYLineAndShapeRenderer10.getSeriesItemLabelFont(10);
        java.awt.Paint paint21 = xYLineAndShapeRenderer10.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot22.zoomDomainAxes(1.0d, plotRenderingInfo24, point2D25, false);
        xYLineAndShapeRenderer10.setPlot(xYPlot22);
        java.awt.Stroke stroke29 = xYPlot22.getDomainZeroBaselineStroke();
        boolean boolean30 = pieLabelLinkStyle9.equals((java.lang.Object) xYPlot22);
        java.lang.Object obj31 = null;
        boolean boolean32 = pieLabelLinkStyle9.equals(obj31);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        dateAxis1.zoomRange((double) (-65281), (double) 100.0f);
        java.text.DateFormat dateFormat15 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLowerBound((double) 1);
        dateAxis1.resizeRange2((double) 9, (double) (short) -1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(dateFormat15);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        xYLineAndShapeRenderer20.setBaseLinesVisible(true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = null;
        piePlot34.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint36);
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBaseSectionPaint(paint38);
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBackgroundPaint(paint40);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(1.0d, paint40, stroke42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean45 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker43, layer44);
        java.awt.Stroke stroke46 = xYPlot12.getRangeGridlineStroke();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setURLText("MINOR");
        java.lang.String str17 = legendItem14.getDescription();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "item" + "'", str17.equals("item"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 10.0f);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        boolean boolean4 = dateAxis1.isTickLabelsVisible();
        java.awt.Paint paint5 = dateAxis1.getLabelPaint();
        dateAxis1.setAutoRangeMinimumSize((double) 2L, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot0.getLegendItems();
        org.jfree.chart.util.Rotation rotation12 = piePlot0.getDirection();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(rotation12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.Number number0 = null;
        try {
            org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(number0, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'x' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("java.awt.Color[r=255,g=175,b=175]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        java.lang.Object obj14 = chartChangeEvent12.getSource();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = null;
        piePlot34.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint36);
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBaseSectionPaint(paint38);
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot34.setBackgroundPaint(paint40);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(1.0d, paint40, stroke42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean45 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker43, layer44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        xYPlot12.zoomDomainAxes((-65285.0d), plotRenderingInfo47, point2D48, false);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        float float4 = periodAxis2.getMinorTickMarkOutsideLength();
        java.lang.Class class5 = periodAxis2.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class8 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = periodAxis7.getLast();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone18);
        java.util.List list22 = timeSeriesCollection21.getSeries();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor23 = null;
        try {
            timeSeriesCollection21.setXPosition(timePeriodAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setNotify(true);
        textTitle1.setText("Rotation.CLOCKWISE");
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list9 = periodAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis11.setVisible(false);
        java.awt.Stroke stroke14 = periodAxis11.getMinorTickMarkStroke();
        periodAxis1.setMinorTickMarkStroke(stroke14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint18 = null;
        piePlot16.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint18);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot16.setBaseSectionPaint(paint20);
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot16.setBackgroundPaint(paint22);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot16.getDrawingSupplier();
        java.lang.Object obj25 = piePlot16.clone();
        java.awt.Paint paint26 = piePlot16.getBackgroundPaint();
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot16);
        double double28 = piePlot16.getLabelGap();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.025d + "'", double28 == 0.025d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("January");
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        boolean boolean5 = piePlot3D0.equals((java.lang.Object) (-1L));
        boolean boolean6 = piePlot3D0.getDarkerSides();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getIntegerInstance();
        numberFormat3.setParseIntegerOnly(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", numberFormat2, numberFormat3);
        logFormat0.setExponentFormat(numberFormat2);
        logFormat0.setMaximumFractionDigits(7);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.data.Range range5 = xYLineAndShapeRenderer0.findRangeBounds(xYDataset4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer6.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer6.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font13 = xYLineAndShapeRenderer6.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer6.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape18 = xYLineAndShapeRenderer6.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        xYLineAndShapeRenderer0.setBaseShape(shape18);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = logAxis0.equals((java.lang.Object) textBlockAnchor1);
        double double3 = logAxis0.getSmallestValue();
        org.jfree.chart.ChartTheme chartTheme4 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        boolean boolean5 = logAxis0.equals((java.lang.Object) chartTheme4);
        logAxis0.zoomRange(1.0E-100d, 4.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = null;
        try {
            logAxis0.setTickUnit(numberTickUnit9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-100d + "'", double3 == 1.0E-100d);
        org.junit.Assert.assertNotNull(chartTheme4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        numberFormat2.setParseIntegerOnly(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", numberFormat1, numberFormat2);
        java.text.AttributedString attributedString7 = null;
        standardPieSectionLabelGenerator5.setAttributedLabel(100, attributedString7);
        java.lang.Object obj9 = standardPieSectionLabelGenerator5.clone();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.data.Range range4 = periodAxis1.getDefaultAutoRange();
        java.awt.Stroke stroke5 = periodAxis1.getTickMarkStroke();
        java.awt.Shape shape6 = periodAxis1.getDownArrow();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        xYLineAndShapeRenderer0.setBaseURLGenerator(xYURLGenerator1);
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis7.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font10 = periodAxis7.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint16 = xYLineAndShapeRenderer11.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        piePlot18.setStartAngle((double) 1);
        java.awt.Paint paint21 = piePlot18.getLabelPaint();
        xYLineAndShapeRenderer11.setSeriesFillPaint(100, paint21);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!", font10, paint21, (-1.0f));
        java.awt.Color color25 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("hi!", font10, (java.awt.Paint) color25);
        java.lang.String str27 = color25.toString();
        xYLineAndShapeRenderer0.setSeriesFillPaint((int) (byte) 1, (java.awt.Paint) color25, true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str27.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setParseIntegerOnly(false);
        try {
            java.lang.Object obj4 = numberFormat0.parseObject("hi!");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) 0L, 0, textMeasurer6);
        org.jfree.chart.text.TextLine textLine8 = textBlock7.getLastLine();
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        textBlock7.addLine("", font10, (java.awt.Paint) color11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        piePlot13.setStartAngle((double) 1);
        java.awt.Paint paint16 = piePlot13.getLabelPaint();
        java.awt.Paint paint17 = piePlot13.getLabelLinkPaint();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        piePlot13.drawBackgroundImage(graphics2D18, rectangle2D19);
        java.awt.Paint paint21 = piePlot13.getLabelOutlinePaint();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer25 = new org.jfree.chart.text.G2TextMeasurer(graphics2D24);
        try {
            org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("item", font10, paint21, (float) 1546329600000L, 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(textLine8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke7 = xYLineAndShapeRenderer0.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYLineAndShapeRenderer0.drawAnnotations(graphics2D8, rectangle2D9, valueAxis10, valueAxis11, layer12, plotRenderingInfo13);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true);
        java.awt.Color color19 = java.awt.Color.yellow;
        try {
            xYLineAndShapeRenderer0.setSeriesItemLabelPaint(2147483647, (java.awt.Paint) color19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset27);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax(0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        xYPlot0.clearSelection();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis20.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font23 = periodAxis20.getLabelFont();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list28 = periodAxis20.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge27);
        org.jfree.data.Range range29 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) periodAxis20);
        double double30 = periodAxis20.getLabelAngle();
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setStartTime((long) 2);
        long long3 = segmentedTimeline0.getStartTime();
        segmentedTimeline0.addException((long) 100);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart13.createBufferedImage((int) (byte) 10, 2019);
        int int18 = jFreeChart13.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class11 = periodAxis10.getAutoRangeTimePeriodClass();
        float float12 = periodAxis10.getMinorTickMarkOutsideLength();
        java.lang.Class class13 = periodAxis10.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class16 = periodAxis15.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = periodAxis15.getLast();
        java.util.Date date18 = regularTimePeriod17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class22 = periodAxis21.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = periodAxis21.getLast();
        java.util.Date date24 = regularTimePeriod23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone26);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8, timeZone26);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date4, timeZone26);
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone26;
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-65281));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            timeSeriesCollection0.setSelected(9, 0, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (9).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list9 = periodAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis11.setVisible(false);
        java.awt.Stroke stroke14 = periodAxis11.getMinorTickMarkStroke();
        periodAxis1.setMinorTickMarkStroke(stroke14);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class18 = periodAxis17.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = periodAxis17.getLast();
        java.util.Date date20 = regularTimePeriod19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone22);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, number24);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        piePlot27.setStartAngle((double) 1);
        java.awt.Paint paint30 = piePlot27.getLabelPaint();
        java.awt.Paint paint31 = piePlot27.getLabelLinkPaint();
        java.awt.Stroke stroke32 = null;
        piePlot27.setLabelOutlineStroke(stroke32);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot27);
        jFreeChart34.setTitle("NOID");
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) year23, jFreeChart34, (int) (byte) 0, 0);
        boolean boolean40 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) periodAxis1, (java.lang.Object) chartProgressEvent39);
        chartProgressEvent39.setType(4);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) ' ', (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 2, (-65285.0d));
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources5 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj7 = jFreeChartResources5.handleGetObject("NOID");
        boolean boolean8 = verticalAlignment1.equals((java.lang.Object) jFreeChartResources5);
        java.util.Locale locale9 = jFreeChartResources5.getLocale();
        try {
            java.lang.String str11 = jFreeChartResources5.getString("Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Pie Plot");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(locale9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.08d, 10.0d, (double) 10.0f, (double) 12);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        java.lang.String str1 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.HOUR" + "'", str1.equals("DateTickUnitType.HOUR"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "hi!", 0.025d, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "January");
        java.lang.String str16 = chartEntity15.getURLText();
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint6 = null;
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot4.setBaseSectionPaint(paint8);
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot4);
        periodAxis1.setLabelURL("item");
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint3);
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot1.setBaseSectionPaint(paint5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot1.setBackgroundPaint(paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d, paint7, stroke9);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class13 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis12.getLast();
        org.jfree.data.Range range15 = periodAxis12.getDefaultAutoRange();
        java.awt.Stroke stroke16 = periodAxis12.getTickMarkStroke();
        valueMarker10.setOutlineStroke(stroke16);
        java.lang.Object obj18 = null;
        boolean boolean19 = valueMarker10.equals(obj18);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        java.awt.Image image15 = jFreeChart13.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        double double2 = xYBarRenderer0.getMargin();
        java.awt.Paint paint4 = null;
        xYBarRenderer0.setLegendTextPaint(2019, paint4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', xYToolTipGenerator4, false);
        java.awt.Paint paint8 = null;
        xYLineAndShapeRenderer0.setSeriesOutlinePaint(1, paint8);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator10 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj11 = standardXYSeriesLabelGenerator10.clone();
        xYLineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), (byte) 100, (-1) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("January", "VerticalAlignment.CENTER", numberArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        java.lang.Comparable comparable29 = multiplePiePlot28.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + "Other" + "'", comparable29.equals("Other"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes(1.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = xYPlot6.getDomainGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("ThreadContext", "item", "", "", shape4, paint5, stroke12, (java.awt.Paint) color13);
        legendItem14.setURLText("MINOR");
        legendItem14.setShapeVisible(false);
        legendItem14.setURLText("-3,-3,3,3");
        java.awt.Stroke stroke21 = legendItem14.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        java.lang.Boolean boolean34 = xYLineAndShapeRenderer20.getSeriesLinesVisible((-1));
        xYLineAndShapeRenderer20.setSeriesShapesFilled((int) (byte) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNull(boolean34);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot0.getURLGenerator();
        double double11 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        java.lang.Object obj2 = null;
        flowArrangement0.add(block1, obj2);
        flowArrangement0.clear();
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getBottom();
        xYPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot10.zoomDomainAxes(1.0d, plotRenderingInfo12, point2D13, false);
        java.awt.Stroke stroke16 = xYPlot10.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot10.zoomDomainAxes((double) 1560495599999L, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot10.setDomainAxes(valueAxisArray21);
        xYPlot0.setDomainAxes(valueAxisArray21);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(valueAxisArray21);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate8, (-65281));
        int int11 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean22 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, serialDate20, (-65281));
        int int23 = spreadsheetDate15.getYYYY();
        boolean boolean24 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.lang.String str25 = spreadsheetDate3.getDescription();
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer0.setSeriesShape(12, shape4, false);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = null;
        piePlot7.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint9);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot7.getLabelDistributor();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator12 = piePlot7.getToolTipGenerator();
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) piePlot7, "LegendItemEntity: seriesKey=null, dataset=null", "MINOR");
        java.awt.Paint paint16 = piePlot7.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertNull(pieToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart8.setTitle("NOID");
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart8.getTitle();
        java.lang.Object obj12 = jFreeChart8.getTextAntiAlias();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "Other");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.lookupLegendShape((int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        java.awt.Paint paint19 = piePlot15.getLabelLinkPaint();
        java.awt.Stroke stroke20 = null;
        piePlot15.setLabelOutlineStroke(stroke20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot15);
        java.awt.Paint paint23 = piePlot15.getLabelOutlinePaint();
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) piePlot15, "MINOR");
        org.jfree.chart.plot.Plot plot26 = plotEntity25.getPlot();
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(plot26);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot0.setBaseSectionPaint(paint4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot0.setLabelOutlineStroke(stroke6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot0.datasetChanged(datasetChangeEvent8);
        piePlot0.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer9.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        xYBarRenderer9.setNegativeItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYBarRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        boolean boolean15 = jFreeChart8.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart8.addProgressListener(chartProgressListener16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis19.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font22 = periodAxis19.getLabelFont();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list27 = periodAxis19.refreshTicks(graphics2D23, axisState24, rectangle2D25, rectangleEdge26);
        jFreeChart8.setSubtitles(list27);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setStartAngle((double) 1);
        java.awt.Paint paint6 = piePlot3.getLabelPaint();
        java.awt.Paint paint7 = piePlot3.getLabelLinkPaint();
        java.awt.Stroke stroke8 = null;
        piePlot3.setLabelOutlineStroke(stroke8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart10.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState1, jFreeChart10);
        org.jfree.chart.JFreeChart jFreeChart14 = chartChangeEvent13.getChart();
        java.awt.RenderingHints renderingHints15 = jFreeChart14.getRenderingHints();
        boolean boolean16 = xYAreaRenderer0.equals((java.lang.Object) renderingHints15);
        xYAreaRenderer0.setOutline(false);
        int int19 = xYAreaRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(jFreeChart14);
        org.junit.Assert.assertNotNull(renderingHints15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint22 = null;
        piePlot20.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint22);
        boolean boolean24 = piePlot3D19.equals((java.lang.Object) (-1L));
        double double25 = piePlot3D19.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis29.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font32 = periodAxis29.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint38 = xYLineAndShapeRenderer33.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        piePlot40.setStartAngle((double) 1);
        java.awt.Paint paint43 = piePlot40.getLabelPaint();
        xYLineAndShapeRenderer33.setSeriesFillPaint(100, paint43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("hi!", font32, paint43, (-1.0f));
        java.awt.Color color47 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!", font32, (java.awt.Paint) color47);
        piePlot3D19.setLabelFont(font32);
        xYPlot12.setNoDataMessageFont(font32);
        boolean boolean51 = xYPlot12.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot12.getDomainAxis((int) (short) -1);
        boolean boolean21 = xYPlot12.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        java.lang.Object obj3 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        xYBarRenderer0.clearSeriesPaints(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        try {
            xYBarRenderer0.setSeriesItemLabelPaint(2147483647, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class11 = periodAxis10.getAutoRangeTimePeriodClass();
        float float12 = periodAxis10.getMinorTickMarkOutsideLength();
        java.lang.Class class13 = periodAxis10.getMajorTickTimePeriodClass();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class16 = periodAxis15.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = periodAxis15.getLast();
        java.util.Date date18 = regularTimePeriod17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class22 = periodAxis21.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = periodAxis21.getLast();
        java.util.Date date24 = regularTimePeriod23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone26);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8, timeZone26);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date4, timeZone26);
        int int31 = day30.getMonth();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100, (int) (byte) 0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo2, point2D3, false);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 1560495599999L, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot13.zoomDomainAxes(1.0d, plotRenderingInfo15, point2D16, false);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint23 = null;
        piePlot21.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint23);
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot21.setBaseSectionPaint(paint25);
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot21.setBackgroundPaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(1.0d, paint27, stroke29);
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class33 = periodAxis32.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = periodAxis32.getLast();
        org.jfree.data.Range range35 = periodAxis32.getDefaultAutoRange();
        java.awt.Stroke stroke36 = periodAxis32.getTickMarkStroke();
        valueMarker30.setOutlineStroke(stroke36);
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean39 = xYPlot13.removeDomainMarker(100, (org.jfree.chart.plot.Marker) valueMarker30, layer38);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer40.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer40.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke47 = xYLineAndShapeRenderer40.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        xYLineAndShapeRenderer40.drawAnnotations(graphics2D48, rectangle2D49, valueAxis50, valueAxis51, layer52, plotRenderingInfo53);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer52);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker30.setLabelAnchor(rectangleAnchor56);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes(1.0d, plotRenderingInfo14, point2D15, false);
        xYLineAndShapeRenderer0.setPlot(xYPlot12);
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYLineAndShapeRenderer20.setBaseToolTipGenerator(xYToolTipGenerator24, true);
        xYLineAndShapeRenderer20.setDrawOutlines(false);
        java.awt.Font font30 = xYLineAndShapeRenderer20.getSeriesItemLabelFont(10);
        java.awt.Paint paint31 = xYLineAndShapeRenderer20.getBaseLegendTextPaint();
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        int int33 = xYPlot12.getSeriesCount();
        java.awt.Paint paint34 = xYPlot12.getRangeGridlinePaint();
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font4 = periodAxis1.getLabelFont();
        java.util.TimeZone timeZone5 = periodAxis1.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = combinedRangeXYPlot0.getRenderer(1);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNull(xYItemRenderer20);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class7 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis6.getLast();
        org.jfree.data.Range range9 = periodAxis6.getDefaultAutoRange();
        dateAxis2.setRange(range9);
        double double11 = range9.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 4, (double) (-1L));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getHeightConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat19 = null;
        dateAxis18.setDateFormatOverride(dateFormat19);
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class23 = periodAxis22.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = periodAxis22.getLast();
        org.jfree.data.Range range25 = periodAxis22.getDefaultAutoRange();
        dateAxis18.setRange(range25);
        double double27 = range25.getLowerBound();
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class30 = periodAxis29.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = periodAxis29.getLast();
        org.jfree.data.Range range32 = periodAxis29.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat35 = null;
        dateAxis34.setDateFormatOverride(dateFormat35);
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class39 = periodAxis38.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = periodAxis38.getLast();
        org.jfree.data.Range range41 = periodAxis38.getDefaultAutoRange();
        dateAxis34.setRange(range41);
        org.jfree.data.Range range43 = org.jfree.data.Range.combine(range32, range41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat46 = null;
        dateAxis45.setDateFormatOverride(dateFormat46);
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class50 = periodAxis49.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = periodAxis49.getLast();
        org.jfree.data.Range range52 = periodAxis49.getDefaultAutoRange();
        dateAxis45.setRange(range52);
        double double54 = range52.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range41, range52);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType56 = rectangleConstraint55.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(0.0d, range9, lengthConstraintType15, (double) 1900, range25, lengthConstraintType56);
        org.jfree.data.Range range59 = org.jfree.data.Range.shift(range9, (double) (-2208960000000L));
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType56);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setParseIntegerOnly(false);
        numberFormat0.setGroupingUsed(false);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font7 = periodAxis4.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = xYLineAndShapeRenderer8.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        piePlot15.setStartAngle((double) 1);
        java.awt.Paint paint18 = piePlot15.getLabelPaint();
        xYLineAndShapeRenderer8.setSeriesFillPaint(100, paint18);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font7, paint18, (-1.0f));
        java.awt.Paint paint22 = textFragment21.getPaint();
        textTitle1.setPaint(paint22);
        java.lang.String str24 = textTitle1.getText();
        java.lang.Object obj25 = textTitle1.clone();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getIntegerInstance();
        numberFormat4.setParseIntegerOnly(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", numberFormat3, numberFormat4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", numberFormat1, numberFormat3);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) ' ');
        try {
            java.lang.Number number3 = xYSeries1.getY((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Stroke stroke7 = xYLineAndShapeRenderer0.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYLineAndShapeRenderer0.drawAnnotations(graphics2D8, rectangle2D9, valueAxis10, valueAxis11, layer12, plotRenderingInfo13);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer16.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer16.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font23 = xYLineAndShapeRenderer16.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer16.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape28 = xYLineAndShapeRenderer16.lookupLegendShape((int) (short) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, (double) (byte) -1, 1.0d);
        xYLineAndShapeRenderer0.setSeriesShape(12, shape28);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer34.setSeriesShape(12, shape38, false);
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint43 = null;
        piePlot41.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint43);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor45 = piePlot41.getLabelDistributor();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator46 = piePlot41.getToolTipGenerator();
        org.jfree.chart.entity.PlotEntity plotEntity49 = new org.jfree.chart.entity.PlotEntity(shape38, (org.jfree.chart.plot.Plot) piePlot41, "LegendItemEntity: seriesKey=null, dataset=null", "MINOR");
        java.awt.Stroke stroke50 = piePlot41.getBaseSectionOutlineStroke();
        boolean boolean51 = xYLineAndShapeRenderer0.equals((java.lang.Object) piePlot41);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor45);
        org.junit.Assert.assertNull(pieToolTipGenerator46);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax(0.2d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, number8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class12 = periodAxis11.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = periodAxis11.getLast();
        int int14 = timeSeriesDataItem9.compareTo((java.lang.Object) periodAxis11);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        periodAxis1.setUpperBound((double) (-1));
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.PeriodAxis periodAxis16 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis16.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font19 = periodAxis16.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer20.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint25 = xYLineAndShapeRenderer20.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        piePlot27.setStartAngle((double) 1);
        java.awt.Paint paint30 = piePlot27.getLabelPaint();
        xYLineAndShapeRenderer20.setSeriesFillPaint(100, paint30);
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("hi!", font19, paint30, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("NOID", font19);
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = chartRenderingInfo38.getPlotInfo();
        int int40 = plotRenderingInfo39.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D41 = plotRenderingInfo39.getDataArea();
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D41);
        labelBlock34.setBounds(rectangle2D41);
        boolean boolean44 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D41);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        xYPlot45.zoomDomainAxes(1.0d, plotRenderingInfo47, point2D48, false);
        int int51 = xYPlot45.getSeriesCount();
        java.awt.Font font53 = null;
        java.awt.Paint paint54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer57 = null;
        org.jfree.chart.text.TextBlock textBlock58 = org.jfree.chart.text.TextUtilities.createTextBlock("", font53, paint54, (float) 0L, 0, textMeasurer57);
        xYPlot45.setDomainCrosshairPaint(paint54);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot45.getDomainAxisEdge(0);
        double double62 = numberAxis9.java2DToValue((double) 7, rectangle2D41, rectangleEdge61);
        org.jfree.chart.entity.EntityCollection entityCollection65 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo(entityCollection65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = chartRenderingInfo66.getPlotInfo();
        int int68 = plotRenderingInfo67.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D69 = plotRenderingInfo67.getDataArea();
        boolean boolean70 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean72 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge71);
        org.jfree.chart.entity.EntityCollection entityCollection73 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = new org.jfree.chart.ChartRenderingInfo(entityCollection73);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = chartRenderingInfo74.getPlotInfo();
        int int76 = plotRenderingInfo75.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D77 = plotRenderingInfo75.getDataArea();
        try {
            org.jfree.chart.axis.AxisState axisState78 = periodAxis1.draw(graphics2D6, (double) 3, rectangle2D41, rectangle2D69, rectangleEdge71, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(plotRenderingInfo39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(textBlock58);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + Double.POSITIVE_INFINITY + "'", double62 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(plotRenderingInfo67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(rectangle2D77);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setStartAngle((double) 1);
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer9.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        xYBarRenderer9.setNegativeItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYBarRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        boolean boolean15 = jFreeChart8.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart8.addProgressListener(chartProgressListener16);
        java.util.List list18 = jFreeChart8.getSubtitles();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        org.jfree.chart.ui.Library[] libraryArray12 = basicProjectInfo10.getLibraries();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray12);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        double double2 = periodAxis1.getFixedAutoRange();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer3.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer3.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font10 = xYLineAndShapeRenderer3.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer3.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        java.awt.Shape shape15 = xYLineAndShapeRenderer3.lookupLegendShape((int) (short) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor16, (double) (byte) -1, 1.0d);
        periodAxis1.setUpArrow(shape15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        xYLineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) 0);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(0);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        boolean boolean11 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) (byte) 100);
        double[][] doubleArray6 = xYSeries3.toArray();
        boolean boolean7 = xYSeries3.getNotify();
        int int9 = xYSeries3.indexOf((java.lang.Number) 100);
        boolean boolean10 = xYSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYLineAndShapeRenderer5.setBaseToolTipGenerator(xYToolTipGenerator9, true);
        xYLineAndShapeRenderer5.setDrawOutlines(false);
        xYLineAndShapeRenderer5.setDrawOutlines(true);
        boolean boolean16 = textAnchor4.equals((java.lang.Object) true);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("LegendItemEntity: seriesKey=null, dataset=null", graphics2D1, (float) 1546329600000L, (float) 15, textAnchor4, 0.025d, 100.0f, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = periodAxis1.hasListener(eventListener4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        org.jfree.chart.axis.Timeline timeline12 = null;
        dateAxis1.setTimeline(timeline12);
        org.jfree.chart.plot.Plot plot14 = dateAxis1.getPlot();
        try {
            dateAxis1.zoomRange((double) 1546329600000L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer4.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer4.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer4.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer4.setSeriesItemLabelsVisible((int) (byte) 10, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer13.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean18 = xYLineAndShapeRenderer13.getItemVisible((int) (byte) -1, (-65281));
        java.awt.Paint paint19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        xYLineAndShapeRenderer13.setBaseOutlinePaint(paint19, true);
        xYBarRenderer4.setBaseOutlinePaint(paint19);
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, 0.0d, (double) 2, 100.0d, paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 1, (float) (byte) -1);
        xYBarRenderer0.setSeriesShape(12, shape4, false);
        xYBarRenderer0.setShadowXOffset((double) (byte) 100);
        java.awt.Paint paint10 = xYBarRenderer0.getLegendTextPaint(9);
        java.awt.Paint paint11 = xYBarRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        int int1 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        int int5 = abstractPieLabelDistributor4.getItemCount();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class6 = periodAxis5.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = periodAxis5.getLast();
        org.jfree.data.Range range8 = periodAxis5.getDefaultAutoRange();
        dateAxis1.setRange(range8);
        try {
            dateAxis1.zoomRange((double) 12, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (12.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYLineAndShapeRenderer1.setBaseToolTipGenerator(xYToolTipGenerator5, true);
        xYLineAndShapeRenderer1.setDrawOutlines(false);
        java.awt.Font font11 = xYLineAndShapeRenderer1.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator12, false);
        xYLineAndShapeRenderer1.setBaseCreateEntities(false, true);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = chartRenderingInfo23.getPlotInfo();
        int int25 = plotRenderingInfo24.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo24.getDataArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D26);
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot30.zoomDomainAxes(1.0d, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo39.getPlotInfo();
        int int41 = plotRenderingInfo40.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D42 = plotRenderingInfo40.getDataArea();
        java.awt.geom.Point2D point2D43 = null;
        xYPlot30.zoomDomainAxes((double) (short) 10, 0.025d, plotRenderingInfo40, point2D43);
        try {
            combinedRangeXYPlot0.draw(graphics2D19, rectangle2D26, point2D28, plotState29, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNotNull(plotRenderingInfo24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Color color3 = java.awt.Color.getHSBColor(2.0f, (float) (byte) -1, (float) 0L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
        timeSeries7.removeAgedItems(0L, true);
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class14 = periodAxis13.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getLast();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date16);
        timeSeries19.removeAgedItems(0L, true);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.addAndOrUpdate(timeSeries19);
        java.lang.Number number25 = null;
        try {
            timeSeries7.update((int) 'a', number25);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "NOID", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 2147483647, (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setBaseShapesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        xYLineAndShapeRenderer0.setBasePaint(paint11);
        xYLineAndShapeRenderer0.setDefaultEntityRadius(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer16.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = null;
        xYLineAndShapeRenderer16.setBaseToolTipGenerator(xYToolTipGenerator20, true);
        xYLineAndShapeRenderer16.setDrawOutlines(false);
        java.awt.Font font26 = xYLineAndShapeRenderer16.getSeriesItemLabelFont(10);
        java.awt.Paint paint27 = xYLineAndShapeRenderer16.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot28.zoomDomainAxes(1.0d, plotRenderingInfo30, point2D31, false);
        xYLineAndShapeRenderer16.setPlot(xYPlot28);
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint38 = null;
        piePlot36.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint38);
        boolean boolean40 = piePlot3D35.equals((java.lang.Object) (-1L));
        double double41 = piePlot3D35.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis45 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis45.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font48 = periodAxis45.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer49.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint54 = xYLineAndShapeRenderer49.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot56 = new org.jfree.chart.plot.PiePlot();
        piePlot56.setStartAngle((double) 1);
        java.awt.Paint paint59 = piePlot56.getLabelPaint();
        xYLineAndShapeRenderer49.setSeriesFillPaint(100, paint59);
        org.jfree.chart.text.TextFragment textFragment62 = new org.jfree.chart.text.TextFragment("hi!", font48, paint59, (-1.0f));
        java.awt.Color color63 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment64 = new org.jfree.chart.text.TextFragment("hi!", font48, (java.awt.Paint) color63);
        piePlot3D35.setLabelFont(font48);
        xYPlot28.setNoDataMessageFont(font48);
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint70 = null;
        piePlot68.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint70);
        java.awt.Paint paint72 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot68.setBaseSectionPaint(paint72);
        java.awt.Paint paint74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot68.setBackgroundPaint(paint74);
        java.awt.Stroke stroke76 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker(1.0d, paint74, stroke76);
        xYPlot28.setDomainZeroBaselineStroke(stroke76);
        combinedRangeXYPlot15.add(xYPlot28, (int) '#');
        xYLineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot15);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(font26);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) 0L, 0, textMeasurer9);
        boolean boolean11 = dateAxis1.equals((java.lang.Object) paint6);
        dateAxis1.zoomRange((double) (-65281), (double) 100.0f);
        java.text.DateFormat dateFormat15 = dateAxis1.getDateFormatOverride();
        java.awt.Font font16 = dateAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setStartTime((long) 2);
        long long3 = segmentedTimeline0.getStartTime();
        segmentedTimeline0.setStartTime((long) 4);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setStartAngle((double) 1);
        java.awt.Paint paint5 = piePlot2.getLabelPaint();
        java.awt.Paint paint6 = piePlot2.getLabelLinkPaint();
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("item", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart9.setTitle("NOID");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) crosshairState0, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        java.awt.Paint paint14 = jFreeChart13.getBorderPaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "NOID", "java.awt.Color[r=255,g=175,b=175]");
        java.lang.String str8 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date11 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate18, "NOID", "java.awt.Color[r=255,g=175,b=175]");
        boolean boolean25 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean26 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYAreaRenderer0.getSeriesItemLabelGenerator(10);
        boolean boolean3 = xYAreaRenderer0.getUseFillPaint();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYLineAndShapeRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition2);
        double double4 = xYLineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint5 = xYLineAndShapeRenderer0.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setStartAngle((double) 1);
        java.awt.Paint paint10 = piePlot7.getLabelPaint();
        xYLineAndShapeRenderer0.setSeriesFillPaint(100, paint10);
        try {
            xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2147483647, (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = logAxis0.equals((java.lang.Object) textBlockAnchor1);
        double double3 = logAxis0.getSmallestValue();
        org.jfree.chart.ChartTheme chartTheme4 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        boolean boolean5 = logAxis0.equals((java.lang.Object) chartTheme4);
        double double6 = logAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-100d + "'", double3 == 1.0E-100d);
        org.junit.Assert.assertNotNull(chartTheme4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYLineAndShapeRenderer0.setBaseToolTipGenerator(xYToolTipGenerator4, true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font10 = xYLineAndShapeRenderer0.getSeriesItemLabelFont(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = xYLineAndShapeRenderer0.getItemLabelGenerator(7, 1900, false);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(xYItemLabelGenerator14);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(0.0d, (double) 4, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        xYBarRenderer6.setNegativeItemLabelPositionFallback(itemLabelPosition8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYBarRenderer6.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.jfree.chart.LegendItem legendItem14 = xYBarRenderer6.getLegendItem((int) (byte) 0, (int) ' ');
        java.awt.Color color16 = java.awt.Color.ORANGE;
        xYBarRenderer6.setSeriesOutlinePaint(100, (java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer18.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        xYBarRenderer18.setNegativeItemLabelPositionFallback(itemLabelPosition20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYBarRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        xYBarRenderer6.setBasePositiveItemLabelPosition(itemLabelPosition23, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        xYLineAndShapeRenderer29.setSeriesNegativeItemLabelPosition(0, itemLabelPosition31);
        int int33 = xYLineAndShapeRenderer29.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis39.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font42 = periodAxis39.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer43.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint48 = xYLineAndShapeRenderer43.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot();
        piePlot50.setStartAngle((double) 1);
        java.awt.Paint paint53 = piePlot50.getLabelPaint();
        xYLineAndShapeRenderer43.setSeriesFillPaint(100, paint53);
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("hi!", font42, paint53, (-1.0f));
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("NOID", font42);
        org.jfree.chart.entity.EntityCollection entityCollection60 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo(entityCollection60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = chartRenderingInfo61.getPlotInfo();
        int int63 = plotRenderingInfo62.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D64 = plotRenderingInfo62.getDataArea();
        boolean boolean65 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0E-8d, (-3.0d), rectangle2D64);
        labelBlock57.setBounds(rectangle2D64);
        boolean boolean67 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 2.0f, (double) 100.0f, rectangle2D64);
        xYLineAndShapeRenderer29.setLegendLine((java.awt.Shape) rectangle2D64);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        try {
            gradientXYBarPainter3.paintBarShadow(graphics2D5, xYBarRenderer6, (int) (short) 10, (int) (byte) 100, true, (java.awt.geom.RectangularShape) rectangle2D64, rectangleEdge69, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(plotRenderingInfo62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) true, false);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean8 = xYLineAndShapeRenderer0.equals((java.lang.Object) color7);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) day2);
        boolean boolean4 = periodAxis1.isMinorTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = null;
        piePlot5.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint7);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot5.getLabelDistributor();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot5.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        piePlot5.axisChanged(axisChangeEvent13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = piePlot5.getURLGenerator();
        boolean boolean16 = periodAxis1.equals((java.lang.Object) pieURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNull(pieURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = logAxis0.equals((java.lang.Object) textBlockAnchor1);
        double double3 = logAxis0.getSmallestValue();
        double double5 = logAxis0.calculateValue((-1.0d));
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-100d + "'", double3 == 1.0E-100d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.1d + "'", double5 == 0.1d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        xYPlot0.clearSelection();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot5.zoomDomainAxes(1.0d, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint15 = null;
        piePlot13.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint15);
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot13.setBaseSectionPaint(paint17);
        java.awt.Paint paint19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot13.setBackgroundPaint(paint19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(1.0d, paint19, stroke21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        java.lang.Class class25 = periodAxis24.getAutoRangeTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = periodAxis24.getLast();
        org.jfree.data.Range range27 = periodAxis24.getDefaultAutoRange();
        java.awt.Stroke stroke28 = periodAxis24.getTickMarkStroke();
        valueMarker22.setOutlineStroke(stroke28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = xYPlot5.removeDomainMarker(100, (org.jfree.chart.plot.Marker) valueMarker22, layer30);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer32.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator36 = null;
        xYLineAndShapeRenderer32.setBaseToolTipGenerator(xYToolTipGenerator36, true);
        xYLineAndShapeRenderer32.setDrawOutlines(false);
        java.awt.Font font42 = xYLineAndShapeRenderer32.getSeriesItemLabelFont(10);
        java.awt.Paint paint43 = xYLineAndShapeRenderer32.getBaseLegendTextPaint();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot44.zoomDomainAxes(1.0d, plotRenderingInfo46, point2D47, false);
        xYLineAndShapeRenderer32.setPlot(xYPlot44);
        org.jfree.chart.plot.PiePlot3D piePlot3D51 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint54 = null;
        piePlot52.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint54);
        boolean boolean56 = piePlot3D51.equals((java.lang.Object) (-1L));
        double double57 = piePlot3D51.getShadowYOffset();
        org.jfree.chart.axis.PeriodAxis periodAxis61 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis61.setMinorTickMarkOutsideLength((float) 0);
        java.awt.Font font64 = periodAxis61.getLabelFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer65 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer65.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint70 = xYLineAndShapeRenderer65.getSeriesPaint((int) (short) 100);
        org.jfree.chart.plot.PiePlot piePlot72 = new org.jfree.chart.plot.PiePlot();
        piePlot72.setStartAngle((double) 1);
        java.awt.Paint paint75 = piePlot72.getLabelPaint();
        xYLineAndShapeRenderer65.setSeriesFillPaint(100, paint75);
        org.jfree.chart.text.TextFragment textFragment78 = new org.jfree.chart.text.TextFragment("hi!", font64, paint75, (-1.0f));
        java.awt.Color color79 = java.awt.Color.pink;
        org.jfree.chart.text.TextFragment textFragment80 = new org.jfree.chart.text.TextFragment("hi!", font64, (java.awt.Paint) color79);
        piePlot3D51.setLabelFont(font64);
        xYPlot44.setNoDataMessageFont(font64);
        org.jfree.chart.plot.PiePlot piePlot83 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint85 = null;
        piePlot83.setSectionOutlinePaint((java.lang.Comparable) (-1L), paint85);
        java.awt.Paint paint87 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot83.setBaseSectionPaint(paint87);
        java.awt.Stroke stroke89 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot83.setLabelOutlineStroke(stroke89);
        xYPlot44.setRangeMinorGridlineStroke(stroke89);
        org.jfree.chart.plot.Marker marker93 = null;
        org.jfree.chart.util.Layer layer94 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean95 = xYPlot44.removeDomainMarker((int) (short) 0, marker93, layer94);
        xYPlot0.addDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker22, layer94, false);
        java.awt.Paint paint98 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(font42);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 4.0d + "'", double57 == 4.0d);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNull(paint70);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(layer94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(paint98);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setDatasetIndex(4);
        double double3 = crosshairState0.getCrosshairDistance();
        crosshairState0.setAnchorY((double) 100);
        int int6 = crosshairState0.getDatasetIndex();
        crosshairState0.updateCrosshairY(0.1d, (int) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        java.util.ResourceBundle.clearCache(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        int int2 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        double double5 = intervalXYDelegate4.getFixedIntervalWidth();
        try {
            intervalXYDelegate4.setIntervalPositionFactor((double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }
}

