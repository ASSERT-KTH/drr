import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.lang.Comparable comparable11 = timeSeries6.getKey();
//        timeSeries6.setRangeDescription("February 3");
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442341824L + "'", long9 == 1560442341824L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100 + "'", comparable11.equals(100));
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        java.lang.String str8 = timeSeries6.getDescription();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Overwritten values from: 100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        java.lang.Object obj13 = timeSeries6.clone();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        boolean boolean17 = year15.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(8, year15);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class24);
//        java.lang.String str26 = timeSeries25.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries25.addAndOrUpdate(timeSeries32);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class42 = timeSeries41.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (org.jfree.data.time.RegularTimePeriod) day44);
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries25.addAndOrUpdate(timeSeries39);
//        int int48 = month18.compareTo((java.lang.Object) timeSeries39);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries39.removeChangeListener(seriesChangeListener49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries6.addAndOrUpdate(timeSeries39);
//        timeSeries6.clear();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442342069L + "'", long9 == 1560442342069L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ThreadContext" + "'", str26.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(timeSeries51);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, serialDate5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getLastMillisecond();
//        long long12 = fixedMillisecond9.getSerialIndex();
//        long long13 = fixedMillisecond9.getLastMillisecond();
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(0, serialDate15);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate7.getEndOfCurrentMonth(serialDate16);
//        java.lang.String str18 = serialDate16.getDescription();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate16);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = day19.getMiddleMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442342487L + "'", long10 == 1560442342487L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442342487L + "'", long11 == 1560442342487L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442342487L + "'", long12 == 1560442342487L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442342487L + "'", long13 == 1560442342487L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNull(str18);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(0, serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(10, serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        boolean boolean14 = year12.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(8, year12);
//        long long16 = month15.getLastMillisecond();
//        org.jfree.data.time.Year year17 = month15.getYear();
//        int int18 = day10.compareTo((java.lang.Object) year17);
//        java.lang.String str19 = day10.toString();
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1567321199999L + "'", long16 == 1567321199999L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-August-2019" + "'", str19.equals("17-August-2019"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.lang.Object obj2 = null;
        boolean boolean3 = day0.equals(obj2);
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class7);
//        java.lang.String str9 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        boolean boolean13 = day0.equals((java.lang.Object) fixedMillisecond10);
//        int int14 = day0.getDayOfMonth();
//        int int15 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ThreadContext" + "'", str9.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442342672L + "'", long11 == 1560442342672L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        int int6 = month4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month4.previous();
        java.lang.String str10 = month4.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "August 2019" + "'", str10.equals("August 2019"));
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        int int10 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 10);
//        try {
//            java.lang.Number number18 = timeSeries9.getValue(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442342727L + "'", long13 == 1560442342727L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560442342727L + "'", long14 == 1560442342727L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10L);
        int int20 = day16.getYear();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 1560442275615L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day16.previous();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Date date6 = fixedMillisecond3.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        long long11 = fixedMillisecond8.getSerialIndex();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442343260L + "'", long9 == 1560442343260L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442343260L + "'", long11 == 1560442343260L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
        java.lang.Comparable comparable17 = timeSeries6.getKey();
        java.util.Collection collection18 = timeSeries6.getTimePeriods();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100 + "'", comparable17.equals(100));
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("17-May-1927");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(8, year3);
        long long7 = month6.getLastMillisecond();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.Year year9 = month6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560442299968L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1567321199999L + "'", long7 == 1567321199999L);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        int int4 = day1.compareTo((java.lang.Object) 1L);
//        int int5 = day1.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int5, "September", "", class13);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        boolean boolean19 = year17.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(8, year17);
//        long long21 = month20.getLastMillisecond();
//        org.jfree.data.time.Year year22 = month20.getYear();
//        int int23 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
//        try {
//            org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) -1, year22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1567321199999L + "'", long21 == 1567321199999L);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        java.lang.Object obj13 = timeSeries6.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(5, (int) (short) 10);
//        int int20 = month19.getYearValue();
//        java.lang.String str21 = month19.toString();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, number22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        long long25 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Object obj27 = timeSeriesDataItem26.clone();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442343438L + "'", long9 == 1560442343438L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ThreadContext" + "'", str16.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "May 10" + "'", str21.equals("May 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442343440L + "'", long25 == 1560442343440L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(obj27);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        boolean boolean7 = spreadsheetDate3.equals((java.lang.Object) seriesChangeEvent5);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
        boolean boolean14 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate13);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (-1L) + "'", obj6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class21);
//        java.lang.String str23 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        long long25 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 1560442277367L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1560442272959L);
//        timeSeries13.setDomainDescription("");
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ThreadContext" + "'", str23.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442343741L + "'", long25 == 1560442343741L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        java.lang.Class<?> wildcardClass8 = date7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 13, (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int12 = spreadsheetDate11.getDayOfMonth();
//        java.util.Date date13 = spreadsheetDate11.toDate();
//        int int14 = spreadsheetDate11.getYYYY();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class20);
//        java.lang.String str22 = timeSeries21.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries21.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        long long32 = fixedMillisecond30.getLastMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond30.getLastMillisecond(calendar33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        long long36 = fixedMillisecond35.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class43);
//        java.lang.String str45 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class48 = timeSeries47.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries44.addAndOrUpdate(timeSeries51);
//        int int53 = fixedMillisecond35.compareTo((java.lang.Object) timeSeries52);
//        boolean boolean54 = spreadsheetDate11.equals((java.lang.Object) fixedMillisecond35);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond35.getFirstMillisecond(calendar55);
//        try {
//            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) (-1.0d), false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of java.util.Date.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1927 + "'", int14 == 1927);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ThreadContext" + "'", str22.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442343847L + "'", long31 == 1560442343847L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560442343847L + "'", long32 == 1560442343847L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560442343847L + "'", long34 == 1560442343847L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560442343847L + "'", long36 == 1560442343847L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ThreadContext" + "'", str45.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560442343847L + "'", long56 == 1560442343847L);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int4 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate3.toSerial();
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        java.util.Date date14 = fixedMillisecond11.getEnd();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        boolean boolean16 = spreadsheetDate3.equals((java.lang.Object) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9999 + "'", int6 == 9999);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        long long6 = fixedMillisecond0.getMiddleMillisecond();
//        long long7 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442343936L + "'", long1 == 1560442343936L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442343936L + "'", long2 == 1560442343936L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442343936L + "'", long3 == 1560442343936L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442343936L + "'", long4 == 1560442343936L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442343936L + "'", long6 == 1560442343936L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442343936L + "'", long7 == 1560442343936L);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
//        java.lang.String str29 = timeSeries20.getDescription();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        boolean boolean33 = year31.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(8, year31);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class40);
//        java.lang.String str42 = timeSeries41.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries41.addAndOrUpdate(timeSeries48);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (org.jfree.data.time.RegularTimePeriod) day54);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (org.jfree.data.time.RegularTimePeriod) day60);
//        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries41.addAndOrUpdate(timeSeries55);
//        int int64 = month34.compareTo((java.lang.Object) timeSeries55);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
//        timeSeries55.removeChangeListener(seriesChangeListener65);
//        java.lang.Comparable comparable67 = timeSeries55.getKey();
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
//        boolean boolean71 = year69.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(8, year69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month72.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) month72);
//        long long75 = month72.getFirstMillisecond();
//        long long76 = month72.getMiddleMillisecond();
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month72);
//        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class83 = timeSeries82.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class83);
//        java.lang.String str85 = timeSeries84.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond();
//        long long87 = fixedMillisecond86.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries84.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86, (java.lang.Number) 1560442277367L);
//        java.lang.Number number91 = timeSeriesDataItem90.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = timeSeriesDataItem90.getPeriod();
//        try {
//            timeSeries20.add(timeSeriesDataItem90, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ThreadContext" + "'", str42.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + 10.0f + "'", comparable67.equals(10.0f));
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1564642800000L + "'", long75 == 1564642800000L);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1565981999999L + "'", long76 == 1565981999999L);
//        org.junit.Assert.assertNotNull(class83);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "ThreadContext" + "'", str85.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1560442343984L + "'", long87 == 1560442343984L);
//        org.junit.Assert.assertNull(timeSeriesDataItem88);
//        org.junit.Assert.assertTrue("'" + number91 + "' != '" + 1560442277367L + "'", number91.equals(1560442277367L));
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        long long8 = timeSeries5.getMaximumItemAge();
//        java.util.List list9 = timeSeries5.getItems();
//        java.util.Collection collection10 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class16);
//        java.lang.String str18 = timeSeries17.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.util.Collection collection22 = timeSeries17.getTimePeriods();
//        java.util.Collection collection23 = timeSeries17.getTimePeriods();
//        java.lang.Object obj24 = timeSeries17.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener25);
//        java.lang.String str27 = timeSeries17.getRangeDescription();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(5, (int) (short) 10);
//        int int31 = month30.getYearValue();
//        java.lang.String str32 = month30.toString();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, number33);
//        java.lang.Number number35 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) month30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, (double) (byte) 100);
//        java.util.Date date38 = month30.getEnd();
//        try {
//            org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list9);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ThreadContext" + "'", str18.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560442344037L + "'", long20 == 1560442344037L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ThreadContext" + "'", str27.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "May 10" + "'", str32.equals("May 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNotNull(date38);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
        timeSeries6.setNotify(true);
        int int14 = timeSeries6.getItemCount();
        timeSeries6.setNotify(true);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, (int) (short) 10);
        java.text.DateFormatSymbols dateFormatSymbols3 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        boolean boolean4 = month2.equals((java.lang.Object) dateFormatSymbols3);
        org.junit.Assert.assertNotNull(dateFormatSymbols3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        int int7 = year6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1567321199999L + "'", long5 == 1567321199999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-458));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-571) + "'", int1 == (-571));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "Time");
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        boolean boolean3 = year1.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        org.jfree.data.time.Year year6 = month4.getYear();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int9 = spreadsheetDate8.getDayOfMonth();
//        java.util.Date date10 = spreadsheetDate8.toDate();
//        int int11 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class17);
//        java.lang.String str19 = timeSeries18.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class22 = timeSeries21.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries18.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        long long28 = fixedMillisecond27.getMiddleMillisecond();
//        long long29 = fixedMillisecond27.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class40);
//        java.lang.String str42 = timeSeries41.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries41.addAndOrUpdate(timeSeries48);
//        int int50 = fixedMillisecond32.compareTo((java.lang.Object) timeSeries49);
//        boolean boolean51 = spreadsheetDate8.equals((java.lang.Object) fixedMillisecond32);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays(0, serialDate58);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate58);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(10, serialDate60);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate67 = day66.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate67);
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addDays(0, serialDate68);
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate68);
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addYears(10, serialDate70);
//        boolean boolean73 = spreadsheetDate8.isInRange(serialDate61, serialDate70, 2147483647);
//        int int74 = month4.compareTo((java.lang.Object) serialDate70);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1927 + "'", int11 == 1927);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ThreadContext" + "'", str19.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560442345110L + "'", long28 == 1560442345110L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442345110L + "'", long29 == 1560442345110L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442345110L + "'", long31 == 1560442345110L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560442345111L + "'", long33 == 1560442345111L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ThreadContext" + "'", str42.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        timeSeries9.add(timeSeriesDataItem17, false);
//        java.lang.Number number21 = timeSeriesDataItem17.getValue();
//        timeSeriesDataItem17.setValue((java.lang.Number) 1560442294088L);
//        int int24 = month7.compareTo((java.lang.Object) timeSeriesDataItem17);
//        org.jfree.data.time.Year year25 = month7.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442346061L + "'", long1 == 1560442346061L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442346061L + "'", long2 == 1560442346061L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442346061L + "'", long3 == 1560442346061L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442346061L + "'", long4 == 1560442346061L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0d + "'", number21.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(year25);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        int int7 = month4.getMonth();
        boolean boolean9 = month4.equals((java.lang.Object) 1560442299508L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1567321199999L + "'", long5 == 1567321199999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.lang.String str6 = timeSeries5.getDomainDescription();
//        timeSeries5.setDomainDescription("Last");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        int int12 = day9.compareTo((java.lang.Object) 1L);
//        int int13 = day9.getDayOfMonth();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 2);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class21);
//        int int23 = timeSeries22.getMaximumItemCount();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        boolean boolean27 = year25.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(8, year25);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class34);
//        java.lang.String str36 = timeSeries35.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries35.addAndOrUpdate(timeSeries42);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class46 = timeSeries45.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (org.jfree.data.time.RegularTimePeriod) day54);
//        timeSeries49.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries35.addAndOrUpdate(timeSeries49);
//        int int58 = month28.compareTo((java.lang.Object) timeSeries49);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener59);
//        java.lang.Comparable comparable61 = timeSeries49.getKey();
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
//        boolean boolean65 = year63.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(8, year63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month66.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) month66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month66.previous();
//        timeSeries22.setKey((java.lang.Comparable) month66);
//        int int71 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) month66);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ThreadContext" + "'", str36.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + comparable61 + "' != '" + 10.0f + "'", comparable61.equals(10.0f));
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        long long8 = fixedMillisecond3.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        boolean boolean12 = year10.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(8, year10);
//        long long14 = month13.getLastMillisecond();
//        org.jfree.data.time.Year year15 = month13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
//        int int17 = fixedMillisecond3.compareTo((java.lang.Object) regularTimePeriod16);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442346995L + "'", long7 == 1560442346995L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560442346995L + "'", long8 == 1560442346995L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1567321199999L + "'", long14 == 1567321199999L);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        timeSeries6.setDescription("Jan");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        boolean boolean11 = timeSeries6.getNotify();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate13);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(10, serialDate15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
//        java.lang.String str18 = serialDate15.toString();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(0, serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate27);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears(10, serialDate29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate29);
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate29);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate33);
//        boolean boolean36 = spreadsheetDate1.isInRange(serialDate15, serialDate34, 9999);
//        int int37 = spreadsheetDate1.getMonth();
//        java.lang.String str38 = spreadsheetDate1.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "17-August-2019" + "'", str18.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "17-August-2019" + "'", str32.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "17-May-1927" + "'", str38.equals("17-May-1927"));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-July-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560442303432L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.Year year7 = month4.getYear();
        int int8 = year7.getYear();
        int int9 = year7.getYear();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1567321199999L + "'", long5 == 1567321199999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(8, year30);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class39);
        java.lang.String str41 = timeSeries40.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class44 = timeSeries43.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries40.addAndOrUpdate(timeSeries47);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class51 = timeSeries50.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day53);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class57 = timeSeries56.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (org.jfree.data.time.RegularTimePeriod) day59);
        timeSeries54.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries40.addAndOrUpdate(timeSeries54);
        int int63 = month33.compareTo((java.lang.Object) timeSeries54);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
        timeSeries54.removeChangeListener(seriesChangeListener64);
        java.lang.Comparable comparable66 = timeSeries54.getKey();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        boolean boolean70 = year68.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(8, year68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) month71);
        timeSeries20.setKey((java.lang.Comparable) month71);
        java.util.Calendar calendar75 = null;
        try {
            long long76 = month71.getLastMillisecond(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ThreadContext" + "'", str41.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 10.0f + "'", comparable66.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNull(timeSeriesDataItem73);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class6);
//        java.lang.String str8 = timeSeries7.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries17.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) day26);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries27.addPropertyChangeListener(propertyChangeListener28);
//        long long30 = timeSeries27.getMaximumItemAge();
//        java.lang.Class class31 = timeSeries27.getTimePeriodClass();
//        timeSeries27.setDomainDescription("September");
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries17.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class40);
//        java.lang.String str42 = timeSeries41.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        long long44 = fixedMillisecond43.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        java.util.Collection collection46 = timeSeries41.getTimePeriods();
//        java.util.Collection collection47 = timeSeries41.getTimePeriods();
//        java.lang.Object obj48 = timeSeries41.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries41.removeChangeListener(seriesChangeListener49);
//        java.lang.String str51 = timeSeries41.getRangeDescription();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(5, (int) (short) 10);
//        int int55 = month54.getYearValue();
//        java.lang.String str56 = month54.toString();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month54, number57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        long long60 = fixedMillisecond59.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        timeSeriesDataItem61.setValue((java.lang.Number) 1560442304303L);
//        try {
//            timeSeries17.add(timeSeriesDataItem61);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ThreadContext" + "'", str8.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ThreadContext" + "'", str42.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560442348162L + "'", long44 == 1560442348162L);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertNotNull(obj48);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ThreadContext" + "'", str51.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "May 10" + "'", str56.equals("May 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560442348165L + "'", long60 == 1560442348165L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        timeSeries6.setDescription("Jan");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        timeSeries6.setNotify(false);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(class5);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
//        long long8 = fixedMillisecond3.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442348198L + "'", long7 == 1560442348198L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560442348198L + "'", long8 == 1560442348198L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Last", class6);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442285709L, "", "Thu Jun 13 09:11:21 PDT 2019", class6);
        try {
            timeSeries8.update((int) (byte) 1, (java.lang.Number) 1560442307668L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNull(inputStream7);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class7);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(0, (int) (byte) 100);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        boolean boolean15 = year13.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(8, year13);
//        long long17 = month16.getLastMillisecond();
//        org.jfree.data.time.Year year18 = month16.getYear();
//        org.jfree.data.time.Year year19 = month16.getYear();
//        int int20 = year19.getYear();
//        int int21 = year19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries11.setNotify(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442348240L + "'", long1 == 1560442348240L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442348240L + "'", long2 == 1560442348240L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442348240L + "'", long4 == 1560442348240L);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1567321199999L + "'", long17 == 1567321199999L);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, 3);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond3.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) day14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
//        long long18 = timeSeries15.getMaximumItemAge();
//        java.util.List list19 = timeSeries15.getItems();
//        java.util.Collection collection20 = timeSeries15.getTimePeriods();
//        timeSeries15.setRangeDescription("13-July-2019");
//        boolean boolean23 = fixedMillisecond3.equals((java.lang.Object) timeSeries15);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442348320L + "'", long7 == 1560442348320L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442348320L + "'", long9 == 1560442348320L);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries6.setMaximumItemCount((int) (byte) 0);
//        java.util.List list13 = timeSeries6.getItems();
//        long long14 = timeSeries6.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class20);
//        timeSeries21.setDescription("Jan");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener24);
//        long long26 = timeSeries21.getMaximumItemAge();
//        java.lang.String str27 = timeSeries21.getDescription();
//        java.util.Collection collection28 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        timeSeries6.setDomainDescription("17-May-1927");
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
//        timeSeries6.add(regularTimePeriod33, (java.lang.Number) 1560442328292L, false);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442348407L + "'", long9 == 1560442348407L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Jan" + "'", str27.equals("Jan"));
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10L);
        timeSeriesDataItem3.setValue((java.lang.Number) 1560442274289L);
        timeSeriesDataItem3.setValue((java.lang.Number) 1560442297014L);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10L);
        int int20 = day16.getYear();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 1560442275615L);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day16.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) day10);
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int15 = spreadsheetDate14.getDayOfMonth();
        java.util.Date date16 = spreadsheetDate14.toDate();
        int int17 = spreadsheetDate14.getYYYY();
        int int18 = spreadsheetDate14.getDayOfMonth();
        boolean boolean19 = fixedMillisecond9.equals((java.lang.Object) int18);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 17 + "'", int15 == 17);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1927 + "'", int17 == 1927);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17 + "'", int18 == 17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class6);
        java.lang.String str8 = timeSeries7.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) day26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener28);
        long long30 = timeSeries27.getMaximumItemAge();
        java.lang.Class class31 = timeSeries27.getTimePeriodClass();
        timeSeries27.setDomainDescription("September");
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries17.addAndOrUpdate(timeSeries27);
        java.util.List list35 = timeSeries27.getItems();
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ThreadContext" + "'", str8.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class6);
        java.lang.String str8 = timeSeries7.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(8, year23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
        int int28 = month26.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries17.addOrUpdate(regularTimePeriod29, (double) (byte) 10);
        java.util.Date date32 = regularTimePeriod29.getStart();
        java.util.Date date33 = regularTimePeriod29.getStart();
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ThreadContext" + "'", str8.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1560442276173L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
        timeSeries11.clear();
        java.lang.Comparable comparable13 = timeSeries11.getKey();
        timeSeries11.setRangeDescription("13-July-2019");
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "Overwritten values from: 100" + "'", comparable13.equals("Overwritten values from: 100"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(8, year14);
        long long18 = month17.getLastMillisecond();
        org.jfree.data.time.Year year19 = month17.getYear();
        org.jfree.data.time.Year year20 = month17.getYear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(8, year20);
        java.lang.Number number22 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries11.getNotify();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1567321199999L + "'", long18 == 1567321199999L);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class10);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", class10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442275193L, class10);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries(comparable0, "January", "Thu Jun 13 09:11:34 PDT 2019", class10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(uRL12);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        long long10 = fixedMillisecond8.getLastMillisecond();
//        long long11 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, class16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.util.Date date25 = fixedMillisecond22.getEnd();
//        java.lang.Class<?> wildcardClass26 = date25.getClass();
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date25, timeZone27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date25);
//        boolean boolean30 = fixedMillisecond3.equals((java.lang.Object) date25);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond3.getFirstMillisecond(calendar31);
//        java.lang.String str33 = fixedMillisecond3.toString();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond3.getMiddleMillisecond(calendar34);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442349084L + "'", long7 == 1560442349084L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442349085L + "'", long9 == 1560442349085L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442349085L + "'", long10 == 1560442349085L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442349085L + "'", long11 == 1560442349085L);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560442349084L + "'", long32 == 1560442349084L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 09:12:29 PDT 2019" + "'", str33.equals("Thu Jun 13 09:12:29 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560442349084L + "'", long35 == 1560442349084L);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
        java.lang.String str29 = timeSeries20.getDescription();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) year30);
        long long32 = year30.getSerialIndex();
        long long33 = year30.getSerialIndex();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = org.jfree.chart.util.ObjectUtilities.deepClone(collection11);
//        java.util.Collection collection13 = org.jfree.chart.util.ObjectUtilities.deepClone(collection11);
//        java.util.Collection collection14 = org.jfree.chart.util.ObjectUtilities.deepClone(collection13);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442349419L + "'", long9 == 1560442349419L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertNotNull(collection14);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class11);
//        java.lang.String str13 = timeSeries12.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries19);
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class27);
//        java.lang.String str29 = timeSeries28.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1560442277367L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 1560442272959L);
//        try {
//            timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1560442290829L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ThreadContext" + "'", str13.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ThreadContext" + "'", str29.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442349497L + "'", long31 == 1560442349497L);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int3 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        int int5 = day0.getMonth();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class21);
//        java.lang.String str23 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        long long25 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 1560442277367L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1560442272959L);
//        java.lang.String str31 = timeSeries13.getDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries13.addChangeListener(seriesChangeListener32);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond37.getFirstMillisecond(calendar40);
//        long long42 = fixedMillisecond37.getFirstMillisecond();
//        long long43 = fixedMillisecond37.getLastMillisecond();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ThreadContext" + "'", str23.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442349530L + "'", long25 == 1560442349530L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560442349532L + "'", long41 == 1560442349532L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560442349532L + "'", long42 == 1560442349532L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560442349532L + "'", long43 == 1560442349532L);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
        java.lang.String str29 = timeSeries6.getDomainDescription();
        java.lang.String str30 = timeSeries6.getDescription();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeriesDataItem34.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem34.getPeriod();
        timeSeries6.add(timeSeriesDataItem34, true);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        java.lang.Object obj10 = timeSeries5.clone();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(8, year12);
        long long16 = month15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
        try {
            timeSeries5.update((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1560442318633L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1567321199999L + "'", long16 == 1567321199999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int5 = spreadsheetDate2.toSerial();
        int int6 = spreadsheetDate2.toSerial();
        try {
            int int8 = spreadsheetDate2.compareTo((java.lang.Object) 1560442311719L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9999 + "'", int5 == 9999);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9999 + "'", int6 == 9999);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) day10);
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        long long13 = fixedMillisecond9.getSerialIndex();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442350145L + "'", long13 == 1560442350145L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.util.List list2 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list2);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
//        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        int int9 = day6.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        long long13 = fixedMillisecond11.getLastMillisecond();
//        long long14 = fixedMillisecond11.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class18);
//        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long14, class19);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) day26);
//        java.util.Date date28 = fixedMillisecond25.getEnd();
//        java.lang.Class<?> wildcardClass29 = date28.getClass();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date28, timeZone30);
//        boolean boolean32 = day6.equals((java.lang.Object) class19);
//        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Value", class3, class19);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(classLoader5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442350235L + "'", long12 == 1560442350235L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442350235L + "'", long13 == 1560442350235L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560442350235L + "'", long14 == 1560442350235L);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNull(inputStream20);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNull(obj33);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10L);
//        java.lang.Number number13 = timeSeriesDataItem12.getValue();
//        java.lang.Object obj14 = timeSeriesDataItem12.clone();
//        java.lang.Object obj15 = timeSeriesDataItem12.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem12.getPeriod();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442350476L + "'", long9 == 1560442350476L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10L + "'", number13.equals(10L));
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442350536L + "'", long1 == 1560442350536L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442350536L + "'", long2 == 1560442350536L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442350536L + "'", long4 == 1560442350536L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442350536L + "'", long5 == 1560442350536L);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int21 = spreadsheetDate20.getMonth();
//        boolean boolean22 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        try {
//            org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate4.getPreviousDayOfWeek(17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-33660) + "'", int15 == (-33660));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17 + "'", int18 == 17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
//        java.lang.Object obj4 = seriesChangeEvent3.getSource();
//        boolean boolean5 = spreadsheetDate1.equals((java.lang.Object) seriesChangeEvent3);
//        int int6 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getLastMillisecond();
//        long long12 = fixedMillisecond9.getSerialIndex();
//        long long13 = fixedMillisecond9.getLastMillisecond();
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(0, serialDate15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate16.getEndOfCurrentMonth(serialDate19);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(8, serialDate19);
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate1.getEndOfCurrentMonth(serialDate22);
//        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1L) + "'", obj4.equals((-1L)));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442350622L + "'", long10 == 1560442350622L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442350622L + "'", long11 == 1560442350622L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442350622L + "'", long12 == 1560442350622L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442350622L + "'", long13 == 1560442350622L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(8, year14);
        long long18 = month17.getLastMillisecond();
        org.jfree.data.time.Year year19 = month17.getYear();
        org.jfree.data.time.Year year20 = month17.getYear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(8, year20);
        java.lang.Number number22 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year20.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1567321199999L + "'", long18 == 1567321199999L);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int9 = spreadsheetDate8.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.util.Date date11 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate14);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(0, serialDate20);
        boolean boolean22 = spreadsheetDate8.isInRange(serialDate15, serialDate20);
        java.lang.String str23 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int27 = spreadsheetDate26.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int29 = spreadsheetDate26.toSerial();
        boolean boolean30 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "17-May-1927" + "'", str23.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 17 + "'", int27 == 17);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9999 + "'", int29 == 9999);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class11);
//        java.lang.String str13 = timeSeries12.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 10L);
//        java.lang.Number number19 = timeSeriesDataItem18.getValue();
//        timeSeriesDataItem18.setValue((java.lang.Number) 1560442278793L);
//        java.lang.Number number22 = timeSeriesDataItem18.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem18.getPeriod();
//        timeSeriesDataItem18.setValue((java.lang.Number) 1560442273404L);
//        try {
//            timeSeries1.add(timeSeriesDataItem18);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ThreadContext" + "'", str13.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560442351030L + "'", long15 == 1560442351030L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10L + "'", number19.equals(10L));
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1560442278793L + "'", number22.equals(1560442278793L));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(31);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10L);
        timeSeriesDataItem3.setValue((java.lang.Number) 1560442274289L);
        java.lang.Number number6 = null;
        timeSeriesDataItem3.setValue(number6);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, 3);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62069990400000L) + "'", long6 == (-62069990400000L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int3 = day0.compareTo((java.lang.Object) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        java.lang.Object obj10 = timeSeries5.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries5.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        timeSeries13.removeAgedItems(1560442296969L, false);
        timeSeries13.setNotify(false);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond11.getLastMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond11.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560442272957L);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class25);
//        java.lang.String str27 = timeSeries26.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        int int30 = timeSeries29.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries26.addAndOrUpdate(timeSeries29);
//        int int32 = fixedMillisecond11.compareTo((java.lang.Object) timeSeries31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond11.previous();
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560442351167L + "'", long16 == 1560442351167L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ThreadContext" + "'", str27.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        java.lang.String str15 = timeSeries13.getDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries13.createCopy(0, (-33660));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str15);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10L);
//        java.lang.Number number13 = timeSeriesDataItem12.getValue();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate18 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(0, serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        long long25 = fixedMillisecond23.getLastMillisecond();
//        long long26 = fixedMillisecond23.getSerialIndex();
//        long long27 = fixedMillisecond23.getLastMillisecond();
//        java.util.Date date28 = fixedMillisecond23.getTime();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, serialDate29);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate21.getEndOfCurrentMonth(serialDate30);
//        java.lang.String str32 = serialDate30.getDescription();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate30);
//        int int34 = timeSeriesDataItem12.compareTo((java.lang.Object) day33);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442351372L + "'", long9 == 1560442351372L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10L + "'", number13.equals(10L));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560442351374L + "'", long24 == 1560442351374L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442351374L + "'", long25 == 1560442351374L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560442351374L + "'", long26 == 1560442351374L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560442351374L + "'", long27 == 1560442351374L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 1560442271565L);
//        long long33 = day29.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560452399999L + "'", long33 == 1560452399999L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Year year6 = month4.getYear();
        int int7 = month4.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10L);
        int int4 = day0.getYear();
        boolean boolean6 = day0.equals((java.lang.Object) 1560442272957L);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        int int16 = spreadsheetDate4.getDayOfWeek();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(0, serialDate23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate23);
//        java.lang.String str26 = serialDate23.toString();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate23);
//        boolean boolean28 = spreadsheetDate4.isOn(serialDate23);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-33660) + "'", int15 == (-33660));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-July-2019" + "'", str26.equals("13-July-2019"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int21 = spreadsheetDate20.getMonth();
//        boolean boolean22 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        spreadsheetDate4.setDescription("hi!");
//        java.lang.String str26 = spreadsheetDate4.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-33660) + "'", int15 == (-33660));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17 + "'", int18 == 17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "17-May-1927" + "'", str26.equals("17-May-1927"));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(30, 17, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        long long7 = day6.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int11 = spreadsheetDate10.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int14 = spreadsheetDate13.getMonth();
//        boolean boolean15 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
//        int int24 = spreadsheetDate13.compare(serialDate21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int27 = spreadsheetDate26.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getMonth();
//        boolean boolean31 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate13);
//        boolean boolean34 = day6.equals((java.lang.Object) spreadsheetDate13);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442352338L + "'", long1 == 1560442352338L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442352338L + "'", long2 == 1560442352338L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442352338L + "'", long3 == 1560442352338L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442352338L + "'", long4 == 1560442352338L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 17 + "'", int11 == 17);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-33660) + "'", int24 == (-33660));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 17 + "'", int27 == 17);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        long long10 = fixedMillisecond8.getLastMillisecond();
//        long long11 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, class16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.util.Date date25 = fixedMillisecond22.getEnd();
//        java.lang.Class<?> wildcardClass26 = date25.getClass();
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date25, timeZone27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date25);
//        boolean boolean30 = fixedMillisecond3.equals((java.lang.Object) date25);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date25);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date25);
//        int int33 = day32.getDayOfMonth();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442352508L + "'", long7 == 1560442352508L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442352509L + "'", long9 == 1560442352509L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442352509L + "'", long10 == 1560442352509L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442352509L + "'", long11 == 1560442352509L);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 13 + "'", int33 == 13);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        long long10 = fixedMillisecond8.getLastMillisecond();
//        long long11 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, class16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.util.Date date25 = fixedMillisecond22.getEnd();
//        java.lang.Class<?> wildcardClass26 = date25.getClass();
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date25, timeZone27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date25);
//        boolean boolean30 = fixedMillisecond3.equals((java.lang.Object) date25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond3.next();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442352710L + "'", long7 == 1560442352710L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442352711L + "'", long9 == 1560442352711L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442352711L + "'", long10 == 1560442352711L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442352711L + "'", long11 == 1560442352711L);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.Year year7 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1567321199999L + "'", long5 == 1567321199999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(0, serialDate22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(10, serialDate24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate24);
//        boolean boolean27 = spreadsheetDate4.isAfter(serialDate24);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        int int31 = day28.compareTo((java.lang.Object) 1L);
//        int int32 = day28.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int32, "September", "", class40);
//        try {
//            int int43 = spreadsheetDate4.compareTo((java.lang.Object) "");
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-33660) + "'", int15 == (-33660));
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 13 + "'", int32 == 13);
//        org.junit.Assert.assertNotNull(class40);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class21);
//        java.lang.String str23 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        long long25 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 1560442277367L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1560442272959L);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        boolean boolean33 = year31.equals((java.lang.Object) "Time");
//        long long34 = year31.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
//        java.lang.Object obj36 = null;
//        boolean boolean37 = year31.equals(obj36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560442291443L);
//        java.lang.String str40 = year31.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year31.next();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ThreadContext" + "'", str23.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442353011L + "'", long25 == 1560442353011L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
        java.lang.String str29 = timeSeries20.getDescription();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(8, year31);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class40);
        java.lang.String str42 = timeSeries41.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries41.addAndOrUpdate(timeSeries48);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (org.jfree.data.time.RegularTimePeriod) day54);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (org.jfree.data.time.RegularTimePeriod) day60);
        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries41.addAndOrUpdate(timeSeries55);
        int int64 = month34.compareTo((java.lang.Object) timeSeries55);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
        timeSeries55.removeChangeListener(seriesChangeListener65);
        java.lang.Comparable comparable67 = timeSeries55.getKey();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        boolean boolean71 = year69.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(8, year69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month72.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) month72);
        long long75 = month72.getFirstMillisecond();
        long long76 = month72.getMiddleMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month72);
        java.lang.String str78 = timeSeries20.getDescription();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ThreadContext" + "'", str42.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(class52);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + 10.0f + "'", comparable67.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1564642800000L + "'", long75 == 1564642800000L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1565981999999L + "'", long76 == 1565981999999L);
        org.junit.Assert.assertNull(str78);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.setRangeDescription("ClassContext");
        timeSeries5.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        java.lang.String str23 = timeSeries20.getDescription();
        timeSeries20.setRangeDescription("ClassContext");
        timeSeries20.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener28);
        timeSeries20.setDomainDescription("Last");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        boolean boolean35 = year33.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(8, year33);
        long long37 = month36.getLastMillisecond();
        org.jfree.data.time.Year year38 = month36.getYear();
        org.jfree.data.time.Year year39 = month36.getYear();
        int int40 = year39.getYear();
        long long41 = year39.getSerialIndex();
        java.lang.String str42 = year39.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year39, (double) 1560442304348L);
        long long45 = year39.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1567321199999L + "'", long37 == 1567321199999L);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019" + "'", str42.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.removeAgedItems(1560442339962L, false);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class7);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(0, (int) (byte) 100);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class22 = timeSeries21.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) day24);
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond23.getLastMillisecond(calendar27);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond23.getLastMillisecond(calendar29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond23.previous();
//        try {
//            timeSeries11.update(regularTimePeriod31, (java.lang.Number) 1560442297072L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442354367L + "'", long1 == 1560442354367L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442354367L + "'", long2 == 1560442354367L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442354367L + "'", long4 == 1560442354367L);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560442354370L + "'", long28 == 1560442354370L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560442354370L + "'", long30 == 1560442354370L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries6.setMaximumItemCount((int) (byte) 0);
//        java.util.List list13 = timeSeries6.getItems();
//        long long14 = timeSeries6.getMaximumItemAge();
//        java.lang.String str15 = timeSeries6.getDomainDescription();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442354386L + "'", long9 == 1560442354386L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int21 = spreadsheetDate20.getMonth();
//        boolean boolean22 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        java.lang.Object obj24 = null;
//        boolean boolean25 = spreadsheetDate20.equals(obj24);
//        org.jfree.data.time.SerialDate serialDate26 = null;
//        try {
//            int int27 = spreadsheetDate20.compare(serialDate26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-33660) + "'", int15 == (-33660));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17 + "'", int18 == 17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", class7);
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Jan", class7);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNull(uRL10);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(0, serialDate9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(10, serialDate11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate11);
//        java.lang.String str14 = serialDate11.toString();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate11);
//        serialDate16.setDescription("hi!");
//        try {
//            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(17, serialDate16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "17-August-2019" + "'", str14.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.lang.Object obj6 = null;
        int int7 = year5.compareTo(obj6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        int int10 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
//        timeSeries6.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        long long16 = fixedMillisecond14.getLastMillisecond();
//        long long17 = fixedMillisecond14.getSerialIndex();
//        long long18 = fixedMillisecond14.getLastMillisecond();
//        java.util.Date date19 = fixedMillisecond14.getTime();
//        long long20 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        int int22 = timeSeries6.getMaximumItemCount();
//        timeSeries6.removeAgedItems(true);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560442354507L + "'", long15 == 1560442354507L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560442354507L + "'", long16 == 1560442354507L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560442354507L + "'", long17 == 1560442354507L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560442354507L + "'", long18 == 1560442354507L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560442354507L + "'", long20 == 1560442354507L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10L);
//        java.lang.Number number13 = timeSeriesDataItem12.getValue();
//        java.lang.Object obj14 = timeSeriesDataItem12.clone();
//        java.lang.Number number15 = timeSeriesDataItem12.getValue();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442354566L + "'", long9 == 1560442354566L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10L + "'", number13.equals(10L));
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class9);
//        java.lang.String str11 = timeSeries10.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        boolean boolean15 = day2.equals((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560442275323L);
//        try {
//            java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) fixedMillisecond12);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ThreadContext" + "'", str11.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442354617L + "'", long13 == 1560442354617L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int4 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate3.toSerial();
        int int7 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate3.getNearestDayOfWeek(4);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(8, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9999 + "'", int6 == 9999);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 17 + "'", int7 == 17);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1927);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) day10);
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        long long14 = fixedMillisecond9.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442354659L + "'", long13 == 1560442354659L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560442354659L + "'", long14 == 1560442354659L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(0, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(10, serialDate8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
        int int11 = day10.getYear();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(serialDate12);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        java.util.Date date3 = spreadsheetDate1.toDate();
//        int int4 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class10);
//        java.lang.String str12 = timeSeries11.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        long long22 = fixedMillisecond20.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond20.getLastMillisecond(calendar23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class33);
//        java.lang.String str35 = timeSeries34.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries34.addAndOrUpdate(timeSeries41);
//        int int43 = fixedMillisecond25.compareTo((java.lang.Object) timeSeries42);
//        boolean boolean44 = spreadsheetDate1.equals((java.lang.Object) fixedMillisecond25);
//        long long45 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond25.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1927 + "'", int4 == 1927);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ThreadContext" + "'", str12.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560442354785L + "'", long21 == 1560442354785L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560442354785L + "'", long22 == 1560442354785L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560442354785L + "'", long24 == 1560442354785L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560442354786L + "'", long26 == 1560442354786L);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ThreadContext" + "'", str35.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560442354786L + "'", long45 == 1560442354786L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Last", class4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) day11);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date13, timeZone16);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(inputStream5);
        org.junit.Assert.assertNotNull(uRL6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.lang.Object obj6 = timeSeries1.clone();
        java.lang.Class<?> wildcardClass7 = obj6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.lang.Object obj6 = timeSeries1.clone();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) 2147483647);
        timeSeries1.setRangeDescription("Last");
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0f + "'", comparable11.equals(10.0f));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        long long8 = fixedMillisecond3.getSerialIndex();
//        long long9 = fixedMillisecond3.getLastMillisecond();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442355450L + "'", long7 == 1560442355450L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560442355450L + "'", long8 == 1560442355450L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442355450L + "'", long9 == 1560442355450L);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(8, year30);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class39);
        java.lang.String str41 = timeSeries40.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class44 = timeSeries43.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries40.addAndOrUpdate(timeSeries47);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class51 = timeSeries50.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day53);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class57 = timeSeries56.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (org.jfree.data.time.RegularTimePeriod) day59);
        timeSeries54.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries40.addAndOrUpdate(timeSeries54);
        int int63 = month33.compareTo((java.lang.Object) timeSeries54);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
        timeSeries54.removeChangeListener(seriesChangeListener64);
        java.lang.Comparable comparable66 = timeSeries54.getKey();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        boolean boolean70 = year68.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(8, year68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) month71);
        timeSeries20.setKey((java.lang.Comparable) month71);
        timeSeries20.setDescription("Thu Jun 13 09:11:54 PDT 2019");
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ThreadContext" + "'", str41.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 10.0f + "'", comparable66.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNull(timeSeriesDataItem73);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.setRangeDescription("ClassContext");
        timeSeries5.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener13);
        timeSeries5.setDomainDescription("Last");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(8, year18);
        long long22 = month21.getLastMillisecond();
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.Year year24 = month21.getYear();
        int int25 = year24.getYear();
        long long26 = year24.getSerialIndex();
        java.lang.String str27 = year24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 1560442304348L);
        long long30 = year24.getLastMillisecond();
        long long31 = year24.getLastMillisecond();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1567321199999L + "'", long22 == 1567321199999L);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class7);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(0, (int) (byte) 100);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        long long16 = fixedMillisecond14.getLastMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getLastMillisecond(calendar17);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, class21);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (byte) 100);
//        timeSeries25.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class33);
//        java.lang.String str35 = timeSeries34.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries34.addAndOrUpdate(timeSeries41);
//        java.lang.Class class43 = timeSeries41.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class49);
//        java.lang.String str51 = timeSeries50.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        long long53 = fixedMillisecond52.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 1560442277367L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 1560442272959L);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        boolean boolean61 = year59.equals((java.lang.Object) "Time");
//        long long62 = year59.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
//        java.lang.Object obj64 = null;
//        boolean boolean65 = year59.equals(obj64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year59, (java.lang.Number) 1560442291443L);
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) year59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year59, (double) 1560442299508L);
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class77 = timeSeries76.getTimePeriodClass();
//        java.lang.Class class78 = org.jfree.data.time.RegularTimePeriod.downsize(class77);
//        java.io.InputStream inputStream79 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class78);
//        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442299508L, "2019", "ERROR : Relative To String", class78);
//        java.util.Collection collection81 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        timeSeries80.setMaximumItemCount(1927);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442356261L + "'", long1 == 1560442356261L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442356261L + "'", long2 == 1560442356261L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442356261L + "'", long4 == 1560442356261L);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560442356262L + "'", long15 == 1560442356262L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560442356262L + "'", long16 == 1560442356262L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560442356262L + "'", long18 == 1560442356262L);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ThreadContext" + "'", str35.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ThreadContext" + "'", str51.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560442356267L + "'", long53 == 1560442356267L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertNotNull(class77);
//        org.junit.Assert.assertNotNull(class78);
//        org.junit.Assert.assertNull(inputStream79);
//        org.junit.Assert.assertNotNull(collection81);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int3 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int6 = spreadsheetDate5.getMonth();
//        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate13);
//        int int16 = spreadsheetDate5.compare(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int19 = spreadsheetDate18.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int22 = spreadsheetDate21.getMonth();
//        boolean boolean23 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate30);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(0, serialDate31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate31);
//        java.lang.String str34 = serialDate31.toString();
//        boolean boolean35 = spreadsheetDate5.isAfter(serialDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int38 = spreadsheetDate37.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int41 = spreadsheetDate40.getMonth();
//        boolean boolean42 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean43 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        int int44 = spreadsheetDate40.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-33660) + "'", int16 == (-33660));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 17 + "'", int19 == 17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-July-2019" + "'", str34.equals("13-July-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 17 + "'", int38 == 17);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 17 + "'", int44 == 17);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Jan", class5);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Jan", class10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class5, class10);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=-1]", class5);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Date date6 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        long long8 = day7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442291562L, "13-July-2019", "hi!", class5);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        java.lang.String str13 = timeSeries6.getDomainDescription();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442357974L + "'", long9 == 1560442357974L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        java.lang.Object obj13 = timeSeries6.clone();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        boolean boolean17 = year15.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(8, year15);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class24);
//        java.lang.String str26 = timeSeries25.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries25.addAndOrUpdate(timeSeries32);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class42 = timeSeries41.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (org.jfree.data.time.RegularTimePeriod) day44);
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries25.addAndOrUpdate(timeSeries39);
//        int int48 = month18.compareTo((java.lang.Object) timeSeries39);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries39.removeChangeListener(seriesChangeListener49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries6.addAndOrUpdate(timeSeries39);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class57 = timeSeries56.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class57);
//        java.lang.String str59 = timeSeries58.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class62 = timeSeries61.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries61.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (org.jfree.data.time.RegularTimePeriod) day64);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries58.addAndOrUpdate(timeSeries65);
//        java.lang.String str67 = timeSeries65.getDescription();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate69 = day68.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day68, (double) 10L);
//        int int72 = day68.getYear();
//        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) day68, (java.lang.Number) 1560442275615L);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day75.previous();
//        java.lang.String str77 = day75.toString();
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) day68, (org.jfree.data.time.RegularTimePeriod) day75);
//        long long79 = day75.getSerialIndex();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442358057L + "'", long9 == 1560442358057L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ThreadContext" + "'", str26.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "ThreadContext" + "'", str59.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNull(str67);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "13-June-2019" + "'", str77.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries78);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 43629L + "'", long79 == 43629L);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        int int6 = month4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.previous();
        java.lang.String str8 = month4.toString();
        int int9 = month4.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "August 2019" + "'", str8.equals("August 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj5 = seriesChangeEvent4.getSource();
        boolean boolean6 = spreadsheetDate2.equals((java.lang.Object) seriesChangeEvent4);
        int int7 = spreadsheetDate2.getMonth();
        java.lang.String str8 = spreadsheetDate2.toString();
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-459), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1L) + "'", obj5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-May-1927" + "'", str8.equals("17-May-1927"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        timeSeries6.setDescription("Jan");
        timeSeries6.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries6.addChangeListener(seriesChangeListener11);
        java.lang.Comparable comparable13 = timeSeries6.getKey();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class10);
        java.lang.String str12 = timeSeries11.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) day17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class22 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) day24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) day30);
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries11.addAndOrUpdate(timeSeries25);
        int int34 = month4.compareTo((java.lang.Object) timeSeries25);
        int int35 = month4.getMonth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ThreadContext" + "'", str12.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 8 + "'", int35 == 8);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Date date6 = fixedMillisecond3.getEnd();
//        java.util.Date date7 = fixedMillisecond3.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond3.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442359143L + "'", long9 == 1560442359143L);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class8);
//        java.lang.String str10 = timeSeries9.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        boolean boolean14 = day1.equals((java.lang.Object) fixedMillisecond11);
//        org.jfree.data.time.SerialDate serialDate15 = day1.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(0, serialDate22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate22);
//        java.lang.String str25 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate22);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate15.getEndOfCurrentMonth(serialDate26);
//        try {
//            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1900, serialDate26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ThreadContext" + "'", str10.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442359178L + "'", long12 == 1560442359178L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-July-2019" + "'", str25.equals("13-July-2019"));
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        long long10 = fixedMillisecond8.getLastMillisecond();
//        long long11 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, class16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.util.Date date25 = fixedMillisecond22.getEnd();
//        java.lang.Class<?> wildcardClass26 = date25.getClass();
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date25, timeZone27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date25);
//        boolean boolean30 = fixedMillisecond3.equals((java.lang.Object) date25);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date25);
//        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442359220L + "'", long7 == 1560442359220L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442359221L + "'", long9 == 1560442359221L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442359221L + "'", long10 == 1560442359221L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442359221L + "'", long11 == 1560442359221L);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate32);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-452));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -452");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        timeSeries9.add(timeSeriesDataItem17, false);
//        java.lang.Number number21 = timeSeriesDataItem17.getValue();
//        timeSeriesDataItem17.setValue((java.lang.Number) 1560442294088L);
//        int int24 = month7.compareTo((java.lang.Object) timeSeriesDataItem17);
//        timeSeriesDataItem17.setValue((java.lang.Number) 1560442283723L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442359466L + "'", long1 == 1560442359466L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442359466L + "'", long2 == 1560442359466L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442359466L + "'", long3 == 1560442359466L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442359466L + "'", long4 == 1560442359466L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0d + "'", number21.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.util.Collection collection8 = timeSeries5.getTimePeriods();
        java.lang.Comparable comparable9 = timeSeries5.getKey();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0f + "'", comparable9.equals(10.0f));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.lang.Object obj6 = timeSeries1.clone();
//        long long7 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getLastMillisecond();
//        long long12 = fixedMillisecond9.getSerialIndex();
//        long long13 = fixedMillisecond9.getLastMillisecond();
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(0, serialDate15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day17, (double) 1560442276732L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442359636L + "'", long10 == 1560442359636L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442359636L + "'", long11 == 1560442359636L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442359636L + "'", long12 == 1560442359636L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442359636L + "'", long13 == 1560442359636L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        int int7 = timeSeries6.getMaximumItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int11 = day8.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.previous();
//        timeSeries6.delete(regularTimePeriod12);
//        timeSeries6.setMaximumItemAge(1560442342672L);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class21);
//        java.lang.String str23 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        int int26 = timeSeries25.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries22.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        timeSeries25.add(regularTimePeriod29, (double) (short) 0);
//        int int32 = timeSeries25.getMaximumItemCount();
//        timeSeries25.setNotify(true);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate36 = day35.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class42 = timeSeries41.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class42);
//        java.lang.String str44 = timeSeries43.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        long long46 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        boolean boolean48 = day35.equals((java.lang.Object) fixedMillisecond45);
//        java.lang.Number number49 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries6.addAndOrUpdate(timeSeries25);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ThreadContext" + "'", str23.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ThreadContext" + "'", str44.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560442359738L + "'", long46 == 1560442359738L);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 1560442277367L);
//        java.lang.Number number13 = timeSeriesDataItem12.getValue();
//        java.lang.Number number14 = timeSeriesDataItem12.getValue();
//        timeSeriesDataItem12.setValue((java.lang.Number) 1560442287624L);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442360029L + "'", long9 == 1560442360029L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1560442277367L + "'", number13.equals(1560442277367L));
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1560442277367L + "'", number14.equals(1560442277367L));
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.setRangeDescription("ClassContext");
        timeSeries5.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, 8, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int3 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int6 = spreadsheetDate5.getMonth();
//        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate13);
//        int int16 = spreadsheetDate5.compare(serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int19 = spreadsheetDate18.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int22 = spreadsheetDate21.getMonth();
//        boolean boolean23 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate30);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(0, serialDate31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate31);
//        java.lang.String str34 = serialDate31.toString();
//        boolean boolean35 = spreadsheetDate5.isAfter(serialDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int38 = spreadsheetDate37.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int41 = spreadsheetDate40.getMonth();
//        boolean boolean42 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean43 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        java.lang.String str44 = spreadsheetDate5.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-33660) + "'", int16 == (-33660));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 17 + "'", int19 == 17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-July-2019" + "'", str34.equals("13-July-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 17 + "'", int38 == 17);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "17-May-1927" + "'", str44.equals("17-May-1927"));
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Date date8 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        boolean boolean14 = year12.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(8, year12);
//        long long16 = month15.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.String str18 = month15.toString();
//        long long19 = month15.getSerialIndex();
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1565981999999L + "'", long16 == 1565981999999L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "August 2019" + "'", str18.equals("August 2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24236L + "'", long19 == 24236L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int5 = spreadsheetDate4.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate4.toSerial();
        int int8 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SerialDate serialDate9 = serialDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9999 + "'", int8 == 9999);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        java.lang.Object obj13 = timeSeries6.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener14);
//        java.lang.String str16 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(5, (int) (short) 10);
//        int int20 = month19.getYearValue();
//        java.lang.String str21 = month19.toString();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, number22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442360554L + "'", long9 == 1560442360554L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ThreadContext" + "'", str16.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "May 10" + "'", str21.equals("May 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.removeAgedItems(false);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10L);
        timeSeriesDataItem3.setValue((java.lang.Number) 1560442274289L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class11);
        java.lang.String str13 = timeSeries12.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(8, year20);
        long long24 = month23.getLastMillisecond();
        org.jfree.data.time.Year year25 = month23.getYear();
        org.jfree.data.time.Year year26 = month23.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(8, year26);
        java.lang.Number number28 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year26);
        boolean boolean29 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries17);
        java.lang.Number number30 = timeSeriesDataItem3.getValue();
        java.lang.Number number31 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ThreadContext" + "'", str13.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1567321199999L + "'", long24 == 1567321199999L);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1560442274289L + "'", number30.equals(1560442274289L));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1560442274289L + "'", number31.equals(1560442274289L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        long long5 = fixedMillisecond3.getLastMillisecond();
//        long long6 = fixedMillisecond3.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, class11);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) day18);
//        java.util.Date date20 = fixedMillisecond17.getEnd();
//        java.lang.Class<?> wildcardClass21 = date20.getClass();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date20, timeZone22);
//        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class11);
//        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResource("May 10", class11);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) day31);
//        java.lang.Object obj33 = timeSeries28.clone();
//        java.lang.Class<?> wildcardClass34 = obj33.getClass();
//        java.lang.Class class35 = null;
//        java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass34, class35);
//        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class11, class35);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442361200L + "'", long4 == 1560442361200L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442361200L + "'", long5 == 1560442361200L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442361200L + "'", long6 == 1560442361200L);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(inputStream12);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(obj24);
//        org.junit.Assert.assertNull(uRL25);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj36);
//        org.junit.Assert.assertNull(obj37);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        int int10 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
//        boolean boolean12 = timeSeries11.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) day17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        long long21 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond16.getLastMillisecond(calendar23);
//        long long25 = fixedMillisecond16.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560442361379L + "'", long20 == 1560442361379L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560442361379L + "'", long21 == 1560442361379L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560442361379L + "'", long24 == 1560442361379L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442361379L + "'", long25 == 1560442361379L);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day13);
//        java.util.Date date15 = fixedMillisecond12.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getYear();
//        int int18 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day16);
//        long long19 = day16.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class7);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(0, (int) (byte) 100);
//        timeSeries11.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class19);
//        java.lang.String str21 = timeSeries20.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) day26);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.addAndOrUpdate(timeSeries27);
//        java.lang.Class class29 = timeSeries27.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class35 = timeSeries34.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class35);
//        java.lang.String str37 = timeSeries36.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 1560442277367L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 1560442272959L);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        boolean boolean47 = year45.equals((java.lang.Object) "Time");
//        long long48 = year45.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = year45.equals(obj50);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 1560442291443L);
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) year45);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = year45.equals(obj55);
//        java.util.Calendar calendar57 = null;
//        try {
//            long long58 = year45.getLastMillisecond(calendar57);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442361533L + "'", long1 == 1560442361533L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442361533L + "'", long2 == 1560442361533L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442361533L + "'", long4 == 1560442361533L);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ThreadContext" + "'", str21.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ThreadContext" + "'", str37.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560442361562L + "'", long39 == 1560442361562L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1546329600000L + "'", long48 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        java.lang.Object obj13 = timeSeries6.clone();
//        timeSeries6.setDescription("Last");
//        timeSeries6.removeAgedItems(false);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442361581L + "'", long9 == 1560442361581L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertNotNull(obj13);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class7);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(0, (int) (byte) 100);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        long long16 = fixedMillisecond14.getLastMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getLastMillisecond(calendar17);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, class21);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (byte) 100);
//        timeSeries25.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class33);
//        java.lang.String str35 = timeSeries34.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries34.addAndOrUpdate(timeSeries41);
//        java.lang.Class class43 = timeSeries41.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class49);
//        java.lang.String str51 = timeSeries50.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        long long53 = fixedMillisecond52.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 1560442277367L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 1560442272959L);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        boolean boolean61 = year59.equals((java.lang.Object) "Time");
//        long long62 = year59.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
//        java.lang.Object obj64 = null;
//        boolean boolean65 = year59.equals(obj64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year59, (java.lang.Number) 1560442291443L);
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) year59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year59, (double) 1560442299508L);
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class77 = timeSeries76.getTimePeriodClass();
//        java.lang.Class class78 = org.jfree.data.time.RegularTimePeriod.downsize(class77);
//        java.io.InputStream inputStream79 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class78);
//        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442299508L, "2019", "ERROR : Relative To String", class78);
//        java.util.Collection collection81 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = fixedMillisecond82.previous();
//        long long84 = fixedMillisecond82.getFirstMillisecond();
//        java.lang.Number number85 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond82);
//        try {
//            timeSeries11.delete((int) (short) -1, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442361621L + "'", long1 == 1560442361621L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442361621L + "'", long2 == 1560442361621L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442361621L + "'", long4 == 1560442361621L);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560442361623L + "'", long15 == 1560442361623L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560442361623L + "'", long16 == 1560442361623L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560442361623L + "'", long18 == 1560442361623L);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ThreadContext" + "'", str35.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ThreadContext" + "'", str51.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560442361652L + "'", long53 == 1560442361652L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertNotNull(class77);
//        org.junit.Assert.assertNotNull(class78);
//        org.junit.Assert.assertNull(inputStream79);
//        org.junit.Assert.assertNotNull(collection81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560442361656L + "'", long84 == 1560442361656L);
//        org.junit.Assert.assertTrue("'" + number85 + "' != '" + 1.560442299508E12d + "'", number85.equals(1.560442299508E12d));
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setNotify(true);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        int int7 = timeSeries6.getMaximumItemCount();
        java.util.Collection collection8 = timeSeries6.getTimePeriods();
        java.util.Collection collection9 = org.jfree.chart.util.ObjectUtilities.deepClone(collection8);
        boolean boolean10 = timeSeries1.equals((java.lang.Object) collection9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        java.util.Date date3 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(10, serialDate14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
//        java.lang.String str17 = serialDate14.toString();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate14);
//        int int20 = spreadsheetDate1.compare(serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int23 = spreadsheetDate22.getDayOfMonth();
//        java.util.Date date24 = spreadsheetDate22.toDate();
//        int int25 = spreadsheetDate22.getYYYY();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class31);
//        java.lang.String str33 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries32.addAndOrUpdate(timeSeries39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        long long42 = fixedMillisecond41.getMiddleMillisecond();
//        long long43 = fixedMillisecond41.getLastMillisecond();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond41.getLastMillisecond(calendar44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        long long47 = fixedMillisecond46.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class54 = timeSeries53.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class54);
//        java.lang.String str56 = timeSeries55.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class59 = timeSeries58.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (org.jfree.data.time.RegularTimePeriod) day61);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries55.addAndOrUpdate(timeSeries62);
//        int int64 = fixedMillisecond46.compareTo((java.lang.Object) timeSeries63);
//        boolean boolean65 = spreadsheetDate22.equals((java.lang.Object) fixedMillisecond46);
//        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "17-August-2019" + "'", str17.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-36739) + "'", int20 == (-36739));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 17 + "'", int23 == 17);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1927 + "'", int25 == 1927);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ThreadContext" + "'", str33.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560442361778L + "'", long42 == 1560442361778L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560442361778L + "'", long43 == 1560442361778L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560442361778L + "'", long45 == 1560442361778L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560442361779L + "'", long47 == 1560442361779L);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "ThreadContext" + "'", str56.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(serialDate66);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.previous();
//        long long14 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
//        int int21 = fixedMillisecond12.compareTo((java.lang.Object) day19);
//        java.lang.Number number22 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442362856L + "'", long9 == 1560442362856L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560442362856L + "'", long14 == 1560442362856L);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNull(number22);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class9);
//        java.lang.String str11 = timeSeries10.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        boolean boolean15 = day2.equals((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560442275323L);
//        java.lang.String str18 = timeSeries1.getDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries1.addChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        boolean boolean24 = year22.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(8, year22);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class31);
//        java.lang.String str33 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries32.addAndOrUpdate(timeSeries39);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (org.jfree.data.time.RegularTimePeriod) day45);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (org.jfree.data.time.RegularTimePeriod) day51);
//        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries32.addAndOrUpdate(timeSeries46);
//        int int55 = month25.compareTo((java.lang.Object) timeSeries46);
//        java.util.Collection collection56 = timeSeries46.getTimePeriods();
//        int int57 = timeSeries46.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class63 = timeSeries62.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day65.previous();
//        int int68 = day65.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day65, (java.lang.Number) 1560442277367L);
//        int int71 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) day65);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day65, (java.lang.Number) 1560442358057L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 13-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ThreadContext" + "'", str11.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442362974L + "'", long13 == 1560442362974L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ThreadContext" + "'", str33.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        timeSeries6.setKey((java.lang.Comparable) 1560442283723L);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection11 = timeSeries6.getTimePeriods();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        java.lang.Object obj13 = timeSeries6.clone();
//        java.util.Collection collection14 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class22 = timeSeries21.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class22);
//        java.lang.String str24 = timeSeries23.getRangeDescription();
//        boolean boolean25 = year15.equals((java.lang.Object) timeSeries23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year15.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries6.addOrUpdate(regularTimePeriod26, (java.lang.Number) 1560442356892L);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442363046L + "'", long9 == 1560442363046L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ThreadContext" + "'", str24.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(9999, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries5.getDescription();
        timeSeries5.setRangeDescription("ClassContext");
        timeSeries5.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener13);
        timeSeries5.setDomainDescription("Last");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(8, year18);
        long long22 = month21.getLastMillisecond();
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.Year year24 = month21.getYear();
        int int25 = year24.getYear();
        long long26 = year24.getSerialIndex();
        java.lang.String str27 = year24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 1560442304348L);
        int int30 = timeSeries5.getItemCount();
        java.lang.String str31 = timeSeries5.getDomainDescription();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1567321199999L + "'", long22 == 1567321199999L);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Last" + "'", str31.equals("Last"));
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, serialDate5);
//        java.lang.String str7 = serialDate6.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int10 = spreadsheetDate9.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int13 = spreadsheetDate12.getMonth();
//        boolean boolean14 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(0, serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate20);
//        int int23 = spreadsheetDate12.compare(serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int26 = spreadsheetDate25.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int29 = spreadsheetDate28.getMonth();
//        boolean boolean30 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        spreadsheetDate12.setDescription("hi!");
//        org.jfree.data.time.SerialDate serialDate34 = serialDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        int int35 = spreadsheetDate12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-July-2019" + "'", str7.equals("13-July-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 17 + "'", int10 == 17);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-33660) + "'", int23 == (-33660));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 17 + "'", int26 == 17);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5 + "'", int29 == 5);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 17 + "'", int35 == 17);
//        org.junit.Assert.assertNotNull(serialDate36);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, (int) (short) 10);
        int int3 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.Year year7 = month4.getYear();
        int int8 = year7.getYear();
        java.lang.String str9 = year7.toString();
        long long10 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1567321199999L + "'", long5 == 1567321199999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Thu Jun 13 09:12:01 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442363482L + "'", long1 == 1560442363482L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442363482L + "'", long2 == 1560442363482L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442363482L + "'", long3 == 1560442363482L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442363482L + "'", long4 == 1560442363482L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.Year year7 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1567321199999L + "'", long5 == 1567321199999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int5 = spreadsheetDate2.toSerial();
        int int6 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate2.getNearestDayOfWeek(4);
        int int9 = spreadsheetDate2.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9999 + "'", int5 == 9999);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 17 + "'", int6 == 17);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.fireSeriesChanged();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Date date6 = fixedMillisecond3.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date6, timeZone9);
        java.util.Calendar calendar11 = null;
        try {
            year10.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getDayOfMonth();
//        int int4 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int9 = spreadsheetDate8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int11 = spreadsheetDate8.toSerial();
//        int int12 = spreadsheetDate8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int16 = spreadsheetDate15.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int19 = spreadsheetDate18.getMonth();
//        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate26);
//        int int29 = spreadsheetDate18.compare(serialDate26);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate35 = day34.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(0, serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate36);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(10, serialDate38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate38);
//        boolean boolean41 = spreadsheetDate18.isAfter(serialDate38);
//        boolean boolean43 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, serialDate38, (int) (short) -1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int47 = spreadsheetDate46.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate46);
//        java.util.Date date49 = spreadsheetDate46.toDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate52 = day51.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate52);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays(0, serialDate58);
//        boolean boolean60 = spreadsheetDate46.isInRange(serialDate53, serialDate58);
//        boolean boolean61 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int64 = spreadsheetDate63.getMonth();
//        int int65 = spreadsheetDate63.getDayOfMonth();
//        int int66 = spreadsheetDate63.getDayOfWeek();
//        int int67 = spreadsheetDate63.getDayOfMonth();
//        boolean boolean68 = spreadsheetDate46.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
//        java.lang.Object obj73 = seriesChangeEvent72.getSource();
//        boolean boolean74 = spreadsheetDate70.equals((java.lang.Object) seriesChangeEvent72);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate79 = day78.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate79);
//        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addDays(0, serialDate80);
//        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate80);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond();
//        long long85 = fixedMillisecond84.getMiddleMillisecond();
//        long long86 = fixedMillisecond84.getLastMillisecond();
//        long long87 = fixedMillisecond84.getSerialIndex();
//        long long88 = fixedMillisecond84.getLastMillisecond();
//        java.util.Date date89 = fixedMillisecond84.getTime();
//        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.createInstance(date89);
//        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addMonths(0, serialDate90);
//        org.jfree.data.time.SerialDate serialDate92 = serialDate82.getEndOfCurrentMonth(serialDate91);
//        boolean boolean94 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate70, serialDate92, 9);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9999 + "'", int11 == 9999);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 17 + "'", int16 == 17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-33660) + "'", int29 == (-33660));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 17 + "'", int47 == 17);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 5 + "'", int64 == 5);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 17 + "'", int65 == 17);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 17 + "'", int67 == 17);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + obj73 + "' != '" + (-1L) + "'", obj73.equals((-1L)));
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560442363611L + "'", long85 == 1560442363611L);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560442363611L + "'", long86 == 1560442363611L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1560442363611L + "'", long87 == 1560442363611L);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560442363611L + "'", long88 == 1560442363611L);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(serialDate90);
//        org.junit.Assert.assertNotNull(serialDate91);
//        org.junit.Assert.assertNotNull(serialDate92);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10L);
//        java.lang.Number number13 = timeSeriesDataItem12.getValue();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) day18);
//        long long20 = fixedMillisecond17.getMiddleMillisecond();
//        boolean boolean21 = timeSeriesDataItem12.equals((java.lang.Object) long20);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) day26);
//        java.lang.Object obj28 = timeSeries23.clone();
//        long long29 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        long long32 = fixedMillisecond31.getMiddleMillisecond();
//        long long33 = fixedMillisecond31.getLastMillisecond();
//        long long34 = fixedMillisecond31.getSerialIndex();
//        long long35 = fixedMillisecond31.getLastMillisecond();
//        java.util.Date date36 = fixedMillisecond31.getTime();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(0, serialDate37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day39, (double) 1560442276732L, false);
//        int int43 = timeSeriesDataItem12.compareTo((java.lang.Object) day39);
//        java.lang.String str44 = day39.toString();
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442365277L + "'", long9 == 1560442365277L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10L + "'", number13.equals(10L));
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560442365278L + "'", long20 == 1560442365278L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560442365280L + "'", long32 == 1560442365280L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560442365280L + "'", long33 == 1560442365280L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560442365280L + "'", long34 == 1560442365280L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560442365280L + "'", long35 == 1560442365280L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "13-June-2019" + "'", str44.equals("13-June-2019"));
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(0, serialDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate7);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(10, serialDate9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        java.lang.String str12 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate9);
//        try {
//            org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-August-2019" + "'", str12.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays(6, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10L);
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int21 = spreadsheetDate20.getMonth();
//        boolean boolean22 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        spreadsheetDate4.setDescription("hi!");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int28 = spreadsheetDate27.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int31 = spreadsheetDate30.getMonth();
//        boolean boolean32 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate38);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays(0, serialDate39);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate39);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears(10, serialDate41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate41);
//        java.lang.String str44 = serialDate41.toString();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate52 = day51.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate52);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays(0, serialDate53);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate53);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addYears(10, serialDate55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate55);
//        java.lang.String str58 = serialDate55.toString();
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate55);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate59);
//        boolean boolean62 = spreadsheetDate27.isInRange(serialDate41, serialDate60, 9999);
//        int int63 = spreadsheetDate27.getMonth();
//        boolean boolean64 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-33660) + "'", int15 == (-33660));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17 + "'", int18 == 17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 17 + "'", int28 == 17);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 5 + "'", int31 == 5);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "17-August-2019" + "'", str44.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "17-August-2019" + "'", str58.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 5 + "'", int63 == 5);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 1L);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) day11);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        java.lang.Class<?> wildcardClass14 = date13.getClass();
        int int15 = fixedMillisecond2.compareTo((java.lang.Object) wildcardClass14);
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(classLoader16);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.util.Date date8 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        boolean boolean14 = year12.equals((java.lang.Object) "Time");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(8, year12);
//        long long16 = month15.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener18);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1565981999999L + "'", long16 == 1565981999999L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Thu Jun 13 09:11:21 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(0, serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(10, serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        int int11 = day10.getYear();
//        long long12 = day10.getSerialIndex();
//        long long13 = day10.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43694L + "'", long12 == 43694L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1566111599999L + "'", long13 == 1566111599999L);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) day13);
//        java.util.Date date15 = fixedMillisecond12.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        int int17 = day16.getYear();
//        int int18 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day16);
//        int int19 = day16.getDayOfMonth();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        long long10 = fixedMillisecond8.getLastMillisecond();
//        long long11 = fixedMillisecond8.getSerialIndex();
//        long long12 = fixedMillisecond8.getLastMillisecond();
//        java.util.Date date13 = fixedMillisecond8.getTime();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(0, serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate6.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class26);
//        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", class26);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class34);
//        java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Overwritten values from: 100", class26, class34);
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, "", "17-May-1927", class26);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442366550L + "'", long1 == 1560442366550L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442366550L + "'", long2 == 1560442366550L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442366550L + "'", long3 == 1560442366550L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442366550L + "'", long4 == 1560442366550L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442366551L + "'", long9 == 1560442366551L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442366551L + "'", long10 == 1560442366551L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560442366551L + "'", long11 == 1560442366551L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442366551L + "'", long12 == 1560442366551L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNull(uRL28);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNull(obj36);
//        org.junit.Assert.assertNotNull(class37);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class8);
//        java.lang.String str10 = timeSeries9.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        java.util.Collection collection14 = timeSeries9.getTimePeriods();
//        java.util.Collection collection15 = timeSeries9.getTimePeriods();
//        java.lang.Object obj16 = timeSeries9.clone();
//        java.lang.Class<?> wildcardClass17 = obj16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442324993L, "", "February 3", (java.lang.Class) wildcardClass17);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ThreadContext" + "'", str10.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442366794L + "'", long12 == 1560442366794L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate13);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(10, serialDate15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
//        java.lang.String str18 = serialDate15.toString();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(0, serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate27);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears(10, serialDate29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate29);
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate29);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate33);
//        boolean boolean36 = spreadsheetDate1.isInRange(serialDate15, serialDate34, 9999);
//        int int37 = spreadsheetDate1.getMonth();
//        java.lang.Object obj38 = null;
//        try {
//            int int39 = spreadsheetDate1.compareTo(obj38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "17-August-2019" + "'", str18.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "17-August-2019" + "'", str32.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
        java.util.Date date7 = fixedMillisecond3.getTime();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        java.util.Date date14 = fixedMillisecond11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date7, timeZone17);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
//        java.lang.String str7 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10L);
//        java.lang.Number number13 = timeSeriesDataItem12.getValue();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(0, serialDate22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(10, serialDate24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate24);
//        java.lang.String str27 = serialDate24.toString();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate24);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate28);
//        boolean boolean30 = timeSeriesDataItem12.equals((java.lang.Object) serialDate28);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442367213L + "'", long9 == 1560442367213L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10L + "'", number13.equals(10L));
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "17-August-2019" + "'", str27.equals("17-August-2019"));
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", class7);
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class7);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNull(inputStream10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getMonth();
//        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int21 = spreadsheetDate20.getMonth();
//        boolean boolean22 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(0, serialDate28);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate28);
//        int int31 = spreadsheetDate20.compare(serialDate28);
//        int int32 = spreadsheetDate20.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int38 = spreadsheetDate37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate37);
//        int int40 = spreadsheetDate37.toSerial();
//        int int41 = spreadsheetDate37.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate37);
//        boolean boolean43 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-33660) + "'", int15 == (-33660));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17 + "'", int18 == 17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-33660) + "'", int31 == (-33660));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 17 + "'", int38 == 17);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9999 + "'", int40 == 9999);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 17 + "'", int41 == 17);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "Time");
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.lang.Class<?> wildcardClass6 = year0.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries6.addAndOrUpdate(timeSeries9);
        timeSeries6.setNotify(true);
        int int14 = timeSeries6.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
        java.util.List list17 = timeSeries6.getItems();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(8, year30);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "ThreadContext", class39);
        java.lang.String str41 = timeSeries40.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class44 = timeSeries43.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries40.addAndOrUpdate(timeSeries47);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class51 = timeSeries50.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day53);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f);
        java.lang.Class class57 = timeSeries56.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (org.jfree.data.time.RegularTimePeriod) day59);
        timeSeries54.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries40.addAndOrUpdate(timeSeries54);
        int int63 = month33.compareTo((java.lang.Object) timeSeries54);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
        timeSeries54.removeChangeListener(seriesChangeListener64);
        java.lang.Comparable comparable66 = timeSeries54.getKey();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        boolean boolean70 = year68.equals((java.lang.Object) "Time");
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(8, year68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) month71);
        timeSeries20.setKey((java.lang.Comparable) month71);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month71, (java.lang.Number) 1560442298713L);
        long long77 = month71.getLastMillisecond();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ThreadContext" + "'", str41.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 10.0f + "'", comparable66.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNull(timeSeriesDataItem73);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1567321199999L + "'", long77 == 1567321199999L);
    }
}

