import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        int int3 = week2.getWeek();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 9);
        long long7 = week6.getLastMillisecond();
        java.util.Date date8 = week6.getStart();
        int int9 = week2.compareTo((java.lang.Object) date8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61822972800001L) + "'", long7 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, 9);
        long long5 = week4.getLastMillisecond();
        java.util.Date date6 = week4.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 9);
        long long14 = week13.getLastMillisecond();
        long long15 = week13.getFirstMillisecond();
        long long16 = week13.getLastMillisecond();
        java.lang.String str17 = week13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week13.next();
        java.util.Date date20 = week13.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date24 = week23.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date20, timeZone25);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date20, timeZone28);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date33 = week32.getEnd();
        int int34 = week32.getYearValue();
        long long35 = week32.getMiddleMillisecond();
        java.util.Date date36 = week32.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date36);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61822972800001L) + "'", long14 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61823577600000L) + "'", long15 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61822972800001L) + "'", long16 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 100, 9" + "'", str17.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62146843200001L) + "'", long35 == (-62146843200001L));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 9);
        int int7 = week6.getWeek();
        java.util.Date date8 = week6.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 9);
        long long14 = week13.getLastMillisecond();
        java.util.Date date15 = week13.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(100, 9);
        long long22 = week21.getLastMillisecond();
        java.util.Date date23 = week21.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date28 = week27.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date23, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date8, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date3, timeZone29);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date37 = week36.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date3, timeZone38);
        long long41 = week40.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61822972800001L) + "'", long14 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61822972800001L) + "'", long22 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 578L + "'", long41 == 578L);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getFirstMillisecond();
        int int7 = week2.getWeek();
        long long8 = week2.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str16 = timePeriodFormatException10.toString();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException10.getSuppressed();
        int int18 = week2.compareTo((java.lang.Object) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61823577600000L) + "'", long6 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61823275200001L) + "'", long8 == (-61823275200001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, 9);
        long long5 = week4.getLastMillisecond();
        java.util.Date date6 = week4.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 9);
        long long13 = week12.getLastMillisecond();
        long long14 = week12.getFirstMillisecond();
        long long15 = week12.getLastMillisecond();
        java.lang.String str16 = week12.toString();
        java.lang.Class<?> wildcardClass17 = week12.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date28 = week27.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone29);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date21, timeZone32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61822972800001L) + "'", long13 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61823577600000L) + "'", long14 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61822972800001L) + "'", long15 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 100, 9" + "'", str16.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class35);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int16 = week2.compareTo((java.lang.Object) wildcardClass7);
        long long17 = week2.getSerialIndex();
        java.util.Date date18 = week2.getStart();
        long long19 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week2.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62146843200001L) + "'", long19 == (-62146843200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 9);
        long long6 = week5.getLastMillisecond();
        long long7 = week5.getFirstMillisecond();
        long long8 = week5.getLastMillisecond();
        java.lang.String str9 = week5.toString();
        java.lang.Class<?> wildcardClass10 = week5.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date14 = week13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone22);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date28 = week27.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(100, 9);
        int int32 = week31.getWeek();
        java.util.Date date33 = week31.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass35 = timeZone34.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(100, 9);
        long long39 = week38.getLastMillisecond();
        java.util.Date date40 = week38.getStart();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone41);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(100, 9);
        long long47 = week46.getLastMillisecond();
        java.util.Date date48 = week46.getStart();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date53 = week52.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date53, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date48, timeZone54);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date33, timeZone54);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date28, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date14, timeZone54);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date14);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61822972800001L) + "'", long6 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61823577600000L) + "'", long7 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61822972800001L) + "'", long8 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 9" + "'", str9.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61822972800001L) + "'", long39 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61822972800001L) + "'", long47 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod59);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.lang.String str9 = week2.toString();
        long long10 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62147145600000L) + "'", long7 == (-62147145600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 0" + "'", str9.equals("Week 35, 0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62146843200001L) + "'", long10 == (-62146843200001L));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (byte) 10);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        int int5 = week2.getWeek();
        long long6 = week2.getFirstMillisecond();
        java.util.Date date7 = week2.getEnd();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61823577600000L) + "'", long6 == (-61823577600000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 577L + "'", long9 == 577L);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        long long5 = week2.getFirstMillisecond();
        long long6 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61823577600000L) + "'", long5 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61822972800001L) + "'", long6 == (-61822972800001L));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date3 = week2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
        java.util.Date date7 = week6.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        try {
            org.jfree.data.time.Year year9 = week8.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 63L + "'", long3 == 63L);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        long long6 = week5.getLastMillisecond();
        java.lang.String str7 = week5.toString();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        org.jfree.data.time.Year year14 = week13.getYear();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(8, year14);
        boolean boolean16 = week5.equals((java.lang.Object) week15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62115091200001L) + "'", long6 == (-62115091200001L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 1" + "'", str7.equals("Week 35, 1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getSerialIndex();
        int int7 = week2.getWeek();
        long long8 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 577L + "'", long6 == 577L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61822972800001L) + "'", long8 == (-61822972800001L));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) '#');
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61002864000001L) + "'", long3 == (-61002864000001L));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        java.util.Date date3 = week1.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(48, year5);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (-1));
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getMiddleMillisecond();
        long long7 = week2.getMiddleMillisecond();
        java.util.Date date8 = week2.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 577L + "'", long4 == 577L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61823275200001L) + "'", long5 == (-61823275200001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61823275200001L) + "'", long6 == (-61823275200001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61823275200001L) + "'", long7 == (-61823275200001L));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date13 = week12.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date21 = week20.getEnd();
        java.lang.Object obj22 = null;
        int int23 = week20.compareTo(obj22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass25 = timeZone24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 9);
        long long29 = week28.getLastMillisecond();
        java.util.Date date30 = week28.getStart();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        int int34 = week20.compareTo((java.lang.Object) wildcardClass25);
        long long35 = week20.getFirstMillisecond();
        java.lang.String str36 = week20.toString();
        java.lang.String str37 = week20.toString();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(100, 9);
        long long43 = week42.getLastMillisecond();
        java.util.Date date44 = week42.getStart();
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date44, timeZone45);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(100, 9);
        long long52 = week51.getLastMillisecond();
        long long53 = week51.getFirstMillisecond();
        long long54 = week51.getLastMillisecond();
        java.lang.String str55 = week51.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week51.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week51.next();
        java.util.Date date58 = week51.getEnd();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date62 = week61.getEnd();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date62, timeZone63);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date58, timeZone63);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date58, timeZone66);
        boolean boolean68 = week20.equals((java.lang.Object) date58);
        int int69 = week16.compareTo((java.lang.Object) date58);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 100, 9" + "'", str6.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61822972800001L) + "'", long29 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62147145600000L) + "'", long35 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 35, 0" + "'", str36.equals("Week 35, 0"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 35, 0" + "'", str37.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61822972800001L) + "'", long43 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-61822972800001L) + "'", long52 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61823577600000L) + "'", long53 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61822972800001L) + "'", long54 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 100, 9" + "'", str55.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        int int3 = week2.getWeek();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 9);
        long long7 = week6.getLastMillisecond();
        java.util.Date date8 = week6.getStart();
        int int9 = week2.compareTo((java.lang.Object) date8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 9);
        long long15 = week14.getLastMillisecond();
        long long16 = week14.getFirstMillisecond();
        long long17 = week14.getLastMillisecond();
        java.lang.String str18 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week14.next();
        long long20 = week14.getSerialIndex();
        int int21 = week14.getWeek();
        long long22 = week14.getLastMillisecond();
        boolean boolean23 = week10.equals((java.lang.Object) long22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61822972800001L) + "'", long7 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61822972800001L) + "'", long15 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61823577600000L) + "'", long16 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61822972800001L) + "'", long17 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 100, 9" + "'", str18.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 577L + "'", long20 == 577L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61822972800001L) + "'", long22 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        long long11 = week10.getLastMillisecond();
        long long12 = week10.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.String str16 = timePeriodFormatException14.toString();
        boolean boolean17 = week10.equals((java.lang.Object) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 9");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass31 = timePeriodFormatException30.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException33.getSuppressed();
        java.lang.String str35 = timePeriodFormatException33.toString();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str39 = timePeriodFormatException38.toString();
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException38.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.String str44 = timePeriodFormatException38.toString();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(100, 9);
        long long48 = week47.getLastMillisecond();
        long long49 = week47.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str52 = timePeriodFormatException51.toString();
        java.lang.String str53 = timePeriodFormatException51.toString();
        boolean boolean54 = week47.equals((java.lang.Object) timePeriodFormatException51);
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str58 = timePeriodFormatException57.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException57.addSuppressed((java.lang.Throwable) timePeriodFormatException60);
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 0");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException66);
        java.lang.String str68 = timePeriodFormatException27.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61823577600000L) + "'", long12 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str44.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61822972800001L) + "'", long48 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-61823577600000L) + "'", long49 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str52.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str53.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str58.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 100, 9" + "'", str68.equals("org.jfree.data.time.TimePeriodFormatException: Week 100, 9"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        int int11 = week10.getYearValue();
        java.lang.String str12 = week10.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 100, 9" + "'", str6.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 48, 10" + "'", str12.equals("Week 48, 10"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.util.Date date7 = week2.getStart();
        java.lang.String str8 = week2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 0" + "'", str8.equals("Week 35, 0"));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 100, 9" + "'", str6.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 577L + "'", long8 == 577L);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        int int5 = week2.getWeek();
        long long6 = week2.getFirstMillisecond();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
        int int9 = week2.compareTo((java.lang.Object) wildcardClass8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 9);
        long long13 = week12.getLastMillisecond();
        long long14 = week12.getFirstMillisecond();
        long long15 = week12.getLastMillisecond();
        java.lang.String str16 = week12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week12.next();
        java.util.Date date19 = week12.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date23 = week22.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date19, timeZone24);
        java.util.Date date27 = week26.getStart();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 9);
        long long31 = week30.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week30.previous();
        java.util.Date date33 = regularTimePeriod32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date27, timeZone34);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61823577600000L) + "'", long6 == (-61823577600000L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61822972800001L) + "'", long13 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61823577600000L) + "'", long14 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61822972800001L) + "'", long15 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 100, 9" + "'", str16.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61822972800001L) + "'", long31 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass6 = timeZone5.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 9);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 9);
        long long18 = week17.getLastMillisecond();
        java.util.Date date19 = week17.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date24 = week23.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone25);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date4, timeZone25);
        int int29 = week28.getYearValue();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(100, 9);
        int int33 = week32.getWeek();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 9);
        long long37 = week36.getLastMillisecond();
        java.util.Date date38 = week36.getStart();
        int int39 = week32.compareTo((java.lang.Object) date38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.util.Date date42 = week40.getEnd();
        boolean boolean43 = week28.equals((java.lang.Object) week40);
        java.util.Calendar calendar44 = null;
        try {
            week40.peg(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61822972800001L) + "'", long10 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61822972800001L) + "'", long18 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61822972800001L) + "'", long37 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        java.lang.Object obj5 = null;
        int int6 = week2.compareTo(obj5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 9);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        long long13 = week12.getLastMillisecond();
        long long14 = week12.getMiddleMillisecond();
        boolean boolean15 = week2.equals((java.lang.Object) week12);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 9);
        long long21 = week20.getLastMillisecond();
        java.util.Date date22 = week20.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 9);
        long long29 = week28.getLastMillisecond();
        long long30 = week28.getFirstMillisecond();
        long long31 = week28.getLastMillisecond();
        java.lang.String str32 = week28.toString();
        java.lang.Class<?> wildcardClass33 = week28.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date37 = week36.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date44 = week43.getStart();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone45);
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date37, timeZone48);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
        boolean boolean51 = week12.equals((java.lang.Object) class25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61822972800001L) + "'", long10 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61822972800001L) + "'", long13 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61823275200001L) + "'", long14 == (-61823275200001L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61822972800001L) + "'", long21 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61822972800001L) + "'", long29 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61823577600000L) + "'", long30 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61822972800001L) + "'", long31 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 100, 9" + "'", str32.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        boolean boolean9 = week2.equals((java.lang.Object) timePeriodFormatException6);
        java.lang.Class<?> wildcardClass10 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        boolean boolean16 = week2.equals((java.lang.Object) regularTimePeriod15);
        long long17 = week2.getFirstMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            week2.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61823577600000L) + "'", long17 == (-61823577600000L));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 6);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 9);
        long long8 = week7.getLastMillisecond();
        long long9 = week7.getFirstMillisecond();
        long long10 = week7.getLastMillisecond();
        long long11 = week7.getSerialIndex();
        int int12 = week7.getYearValue();
        boolean boolean13 = week2.equals((java.lang.Object) int12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(1, 6);
        java.util.Date date17 = week16.getEnd();
        int int18 = week2.compareTo((java.lang.Object) date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date22 = week21.getEnd();
        int int23 = week21.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week21.next();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date28 = week27.getEnd();
        java.lang.Object obj29 = null;
        int int30 = week27.compareTo(obj29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(100, 9);
        long long36 = week35.getLastMillisecond();
        java.util.Date date37 = week35.getStart();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone38);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        int int41 = week27.compareTo((java.lang.Object) wildcardClass32);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(100, 9);
        long long45 = week44.getLastMillisecond();
        long long46 = week44.getFirstMillisecond();
        long long47 = week44.getLastMillisecond();
        java.lang.String str48 = week44.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week44.next();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(100, 9);
        long long55 = week54.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week54.previous();
        java.util.Date date57 = regularTimePeriod56.getStart();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date57, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date51, timeZone58);
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date61, timeZone62);
        boolean boolean64 = week21.equals((java.lang.Object) wildcardClass32);
        boolean boolean65 = week2.equals((java.lang.Object) wildcardClass32);
        java.util.Calendar calendar66 = null;
        try {
            week2.peg(calendar66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 6" + "'", str3.equals("Week 1, 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61822972800001L) + "'", long8 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823577600000L) + "'", long9 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61822972800001L) + "'", long10 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 577L + "'", long11 == 577L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61822972800001L) + "'", long36 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61822972800001L) + "'", long45 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61823577600000L) + "'", long46 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61822972800001L) + "'", long47 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 100, 9" + "'", str48.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-61822972800001L) + "'", long55 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        boolean boolean9 = week2.equals((java.lang.Object) timePeriodFormatException6);
        java.lang.Class<?> wildcardClass10 = week2.getClass();
        java.util.Date date11 = week2.getEnd();
        int int12 = week2.getYearValue();
        java.lang.Class<?> wildcardClass13 = week2.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getSerialIndex();
        java.lang.Class<?> wildcardClass7 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        long long9 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 577L + "'", long6 == 577L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823577600000L) + "'", long9 == (-61823577600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int16 = week2.compareTo((java.lang.Object) wildcardClass7);
        long long17 = week2.getSerialIndex();
        java.util.Date date18 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week2.previous();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = week2.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        boolean boolean9 = week2.equals((java.lang.Object) timePeriodFormatException6);
        int int10 = week2.getWeek();
        long long11 = week2.getLastMillisecond();
        long long12 = week2.getFirstMillisecond();
        long long13 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61823577600000L) + "'", long12 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61822972800001L) + "'", long13 == (-61822972800001L));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, (int) '4');
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date4 = week3.getEnd();
        java.lang.Object obj5 = null;
        int int6 = week3.compareTo(obj5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 9);
        long long12 = week11.getLastMillisecond();
        java.util.Date date13 = week11.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        int int17 = week3.compareTo((java.lang.Object) wildcardClass8);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 9);
        long long21 = week20.getLastMillisecond();
        long long22 = week20.getFirstMillisecond();
        long long23 = week20.getLastMillisecond();
        java.lang.String str24 = week20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week20.next();
        java.util.Date date27 = week20.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 9);
        long long31 = week30.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week30.previous();
        java.util.Date date33 = regularTimePeriod32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date27, timeZone34);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date40 = week39.getStart();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date40, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date40);
        java.lang.Class<?> wildcardClass44 = date40.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(100, 9);
        int int48 = week47.getWeek();
        java.util.Date date49 = week47.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass51 = timeZone50.getClass();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(100, 9);
        long long55 = week54.getLastMillisecond();
        java.util.Date date56 = week54.getStart();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date56, timeZone57);
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(100, 9);
        long long63 = week62.getLastMillisecond();
        java.util.Date date64 = week62.getStart();
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date69 = week68.getEnd();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date69, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date64, timeZone70);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date49, timeZone70);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date40, timeZone70);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date27, timeZone70);
        try {
            org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date0, timeZone70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61822972800001L) + "'", long12 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61822972800001L) + "'", long21 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61823577600000L) + "'", long22 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61822972800001L) + "'", long23 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 100, 9" + "'", str24.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61822972800001L) + "'", long31 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-61822972800001L) + "'", long55 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61822972800001L) + "'", long63 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        long long6 = week5.getLastMillisecond();
        java.lang.String str7 = week5.toString();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        long long9 = week5.getFirstMillisecond();
        long long10 = week5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62115091200001L) + "'", long6 == (-62115091200001L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 1" + "'", str7.equals("Week 35, 1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62115696000000L) + "'", long9 == (-62115696000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62115696000000L) + "'", long10 == (-62115696000000L));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 6);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 9);
        long long8 = week7.getLastMillisecond();
        long long9 = week7.getFirstMillisecond();
        long long10 = week7.getLastMillisecond();
        long long11 = week7.getSerialIndex();
        int int12 = week7.getYearValue();
        boolean boolean13 = week2.equals((java.lang.Object) int12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(1, 6);
        java.util.Date date17 = week16.getEnd();
        int int18 = week2.compareTo((java.lang.Object) date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week2.next();
        try {
            org.jfree.data.time.Year year20 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 6" + "'", str3.equals("Week 1, 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61822972800001L) + "'", long8 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823577600000L) + "'", long9 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61822972800001L) + "'", long10 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 577L + "'", long11 == 577L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date6 = week5.getEnd();
        boolean boolean7 = week2.equals((java.lang.Object) date6);
        int int8 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.next();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        int int5 = week2.getWeek();
        long long6 = week2.getFirstMillisecond();
        java.util.Date date7 = week2.getEnd();
        java.util.Date date8 = week2.getEnd();
        java.lang.Class<?> wildcardClass9 = date8.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61823577600000L) + "'", long6 == (-61823577600000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int16 = week2.compareTo((java.lang.Object) wildcardClass7);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(100, 9);
        long long20 = week19.getLastMillisecond();
        long long21 = week19.getFirstMillisecond();
        long long22 = week19.getLastMillisecond();
        java.lang.String str23 = week19.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week19.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week19.next();
        java.util.Date date26 = week19.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(100, 9);
        long long30 = week29.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week29.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date26, timeZone33);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date39 = week38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date39, timeZone40);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date39);
        java.lang.Class<?> wildcardClass43 = date39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date39);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(100, 9);
        long long48 = week47.getLastMillisecond();
        long long49 = week47.getFirstMillisecond();
        long long50 = week47.getLastMillisecond();
        long long51 = week47.getSerialIndex();
        java.lang.Class<?> wildcardClass52 = week47.getClass();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(100, 9);
        int int56 = week55.getWeek();
        java.util.Date date57 = week55.getStart();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass59 = timeZone58.getClass();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(100, 9);
        long long63 = week62.getLastMillisecond();
        java.util.Date date64 = week62.getStart();
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date64, timeZone65);
        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(100, 9);
        long long71 = week70.getLastMillisecond();
        java.util.Date date72 = week70.getStart();
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date72);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date77 = week76.getEnd();
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date77, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date72, timeZone78);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date57, timeZone78);
        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date85 = week84.getEnd();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date85, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date57, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date39, timeZone86);
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date39);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61822972800001L) + "'", long20 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61823577600000L) + "'", long21 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61822972800001L) + "'", long22 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 100, 9" + "'", str23.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61822972800001L) + "'", long30 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61822972800001L) + "'", long48 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-61823577600000L) + "'", long49 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61822972800001L) + "'", long50 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 577L + "'", long51 == 577L);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61822972800001L) + "'", long63 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(class67);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-61822972800001L) + "'", long71 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertNull(regularTimePeriod89);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getLastMillisecond();
        long long7 = week5.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week5.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61822972800001L) + "'", long6 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61823275200001L) + "'", long7 == (-61823275200001L));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 48 + "'", int9 == 48);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        int int5 = week2.getWeek();
        long long6 = week2.getFirstMillisecond();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
        int int9 = week2.compareTo((java.lang.Object) wildcardClass8);
        int int10 = week2.getYearValue();
        try {
            org.jfree.data.time.Year year11 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61823577600000L) + "'", long6 == (-61823577600000L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int16 = week2.compareTo((java.lang.Object) wildcardClass7);
        long long17 = week2.getSerialIndex();
        java.util.Date date18 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        int int21 = week2.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        java.util.Calendar calendar22 = null;
        try {
            week2.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 8);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getLastMillisecond();
        long long7 = week5.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        java.util.Date date9 = week5.getStart();
        java.lang.Class<?> wildcardClass10 = week5.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61822972800001L) + "'", long6 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61823275200001L) + "'", long7 == (-61823275200001L));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        boolean boolean9 = week2.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        java.lang.String str14 = timePeriodFormatException12.toString();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException12.getSuppressed();
        int int16 = week2.compareTo((java.lang.Object) timePeriodFormatException12);
        int int18 = week2.compareTo((java.lang.Object) (short) -1);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = week2.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 577L + "'", long6 == 577L);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date4 = week3.getEnd();
        java.lang.Object obj5 = null;
        int int6 = week3.compareTo(obj5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 9);
        long long12 = week11.getLastMillisecond();
        java.util.Date date13 = week11.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        int int17 = week3.compareTo((java.lang.Object) wildcardClass8);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 9);
        long long21 = week20.getLastMillisecond();
        long long22 = week20.getFirstMillisecond();
        long long23 = week20.getLastMillisecond();
        java.lang.String str24 = week20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week20.next();
        java.util.Date date27 = week20.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 9);
        long long31 = week30.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week30.previous();
        java.util.Date date33 = regularTimePeriod32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date27, timeZone34);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass38 = timeZone37.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date27, timeZone37);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date27);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date44 = week43.getStart();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44, timeZone45);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date44);
        java.util.Date date48 = week47.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(100, 9);
        int int52 = week51.getWeek();
        java.util.Date date53 = week51.getStart();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass55 = timeZone54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(100, 9);
        long long59 = week58.getLastMillisecond();
        java.util.Date date60 = week58.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date60, timeZone61);
        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(100, 9);
        long long67 = week66.getLastMillisecond();
        java.util.Date date68 = week66.getStart();
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date73 = week72.getEnd();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date73, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date68, timeZone74);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date53, timeZone74);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date48, timeZone74);
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date27, timeZone74);
        try {
            org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date0, timeZone74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61822972800001L) + "'", long12 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61822972800001L) + "'", long21 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61823577600000L) + "'", long22 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61822972800001L) + "'", long23 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 100, 9" + "'", str24.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61822972800001L) + "'", long31 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-61822972800001L) + "'", long59 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(class63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-61822972800001L) + "'", long67 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod76);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getLastMillisecond();
        long long7 = week5.getMiddleMillisecond();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 9);
        long long13 = week12.getLastMillisecond();
        java.util.Date date14 = week12.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 9);
        long long21 = week20.getLastMillisecond();
        java.util.Date date22 = week20.getStart();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date27 = week26.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone28);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        int int32 = week5.compareTo((java.lang.Object) class17);
        java.util.Calendar calendar33 = null;
        try {
            week5.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61822972800001L) + "'", long6 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61823275200001L) + "'", long7 == (-61823275200001L));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61822972800001L) + "'", long13 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61822972800001L) + "'", long21 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date3 = week2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        int int11 = week10.getWeek();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 9);
        long long18 = week17.getLastMillisecond();
        java.util.Date date19 = week17.getStart();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date19, timeZone20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 9);
        long long26 = week25.getLastMillisecond();
        java.util.Date date27 = week25.getStart();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date32 = week31.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone33);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date12, timeZone33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date3, timeZone33);
        long long38 = week37.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61822972800001L) + "'", long18 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61822972800001L) + "'", long26 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61823275200001L) + "'", long38 == (-61823275200001L));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass6 = timeZone5.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 9);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 9);
        long long18 = week17.getLastMillisecond();
        java.util.Date date19 = week17.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date24 = week23.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone25);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date4, timeZone25);
        int int29 = week28.getYearValue();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(100, 9);
        int int33 = week32.getWeek();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 9);
        long long37 = week36.getLastMillisecond();
        java.util.Date date38 = week36.getStart();
        int int39 = week32.compareTo((java.lang.Object) date38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.util.Date date42 = week40.getEnd();
        boolean boolean43 = week28.equals((java.lang.Object) week40);
        long long44 = week40.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61822972800001L) + "'", long10 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61822972800001L) + "'", long18 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61822972800001L) + "'", long37 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61823577600000L) + "'", long44 == (-61823577600000L));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int16 = week2.compareTo((java.lang.Object) wildcardClass7);
        long long17 = week2.getFirstMillisecond();
        java.lang.String str18 = week2.toString();
        java.util.Date date19 = week2.getEnd();
        int int20 = week2.getWeek();
        java.util.Calendar calendar21 = null;
        try {
            week2.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62147145600000L) + "'", long17 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 0" + "'", str18.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date3 = week2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        int int11 = week10.getWeek();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 9);
        long long18 = week17.getLastMillisecond();
        java.util.Date date19 = week17.getStart();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date19, timeZone20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 9);
        long long26 = week25.getLastMillisecond();
        java.util.Date date27 = week25.getStart();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date32 = week31.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone33);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date12, timeZone33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date3, timeZone33);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date41 = week40.getEnd();
        java.lang.Object obj42 = null;
        int int43 = week40.compareTo(obj42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass45 = timeZone44.getClass();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(100, 9);
        long long49 = week48.getLastMillisecond();
        java.util.Date date50 = week48.getStart();
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date50, timeZone51);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
        int int54 = week40.compareTo((java.lang.Object) wildcardClass45);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(100, 9);
        long long58 = week57.getLastMillisecond();
        long long59 = week57.getFirstMillisecond();
        long long60 = week57.getLastMillisecond();
        java.lang.String str61 = week57.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week57.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week57.next();
        java.util.Date date64 = week57.getEnd();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(100, 9);
        long long68 = week67.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = week67.previous();
        java.util.Date date70 = regularTimePeriod69.getStart();
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date70, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date64, timeZone71);
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass75 = timeZone74.getClass();
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date64, timeZone74);
        java.util.Locale locale77 = null;
        try {
            org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date3, timeZone74, locale77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61822972800001L) + "'", long18 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61822972800001L) + "'", long26 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-61822972800001L) + "'", long49 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61822972800001L) + "'", long58 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-61823577600000L) + "'", long59 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61822972800001L) + "'", long60 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Week 100, 9" + "'", str61.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-61822972800001L) + "'", long68 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNotNull(wildcardClass75);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 9);
        int int7 = week6.getWeek();
        java.util.Date date8 = week6.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 9);
        long long14 = week13.getLastMillisecond();
        java.util.Date date15 = week13.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(100, 9);
        long long22 = week21.getLastMillisecond();
        java.util.Date date23 = week21.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date28 = week27.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date23, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date8, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date3, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61822972800001L) + "'", long14 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61822972800001L) + "'", long22 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        int int5 = week2.getWeek();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61823577600000L) + "'", long4 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date9 = week8.getEnd();
        java.lang.Object obj10 = null;
        int int11 = week8.compareTo(obj10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        long long13 = week8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week8.next();
        java.lang.String str15 = week8.toString();
        java.util.Date date16 = week8.getEnd();
        boolean boolean17 = week2.equals((java.lang.Object) date16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week2.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62147145600000L) + "'", long13 == (-62147145600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 0" + "'", str15.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62147145600000L) + "'", long7 == (-62147145600000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62146843200001L) + "'", long9 == (-62146843200001L));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, 9);
        long long5 = week4.getLastMillisecond();
        java.util.Date date6 = week4.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 9);
        long long13 = week12.getLastMillisecond();
        java.util.Date date14 = week12.getStart();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date19 = week18.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 9);
        long long29 = week28.getLastMillisecond();
        java.util.Date date30 = week28.getStart();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        int int32 = week31.getWeek();
        java.util.Date date33 = week31.getEnd();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date33, timeZone34);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61822972800001L) + "'", long5 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61822972800001L) + "'", long13 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61822972800001L) + "'", long29 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 48 + "'", int32 == 48);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getStart();
        int int5 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.lang.Class<?> wildcardClass7 = week2.getClass();
        java.lang.Class<?> wildcardClass8 = week2.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 9);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getLastMillisecond();
        long long7 = week5.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        java.lang.String str9 = week5.toString();
        java.util.Date date10 = week5.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61822972800001L) + "'", long3 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61822972800001L) + "'", long6 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61823275200001L) + "'", long7 == (-61823275200001L));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 48, 10" + "'", str9.equals("Week 48, 10"));
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date9 = week8.getEnd();
        java.lang.Object obj10 = null;
        int int11 = week8.compareTo(obj10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass13 = timeZone12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(100, 9);
        long long17 = week16.getLastMillisecond();
        java.util.Date date18 = week16.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        int int22 = week8.compareTo((java.lang.Object) wildcardClass13);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 9);
        long long26 = week25.getLastMillisecond();
        long long27 = week25.getFirstMillisecond();
        long long28 = week25.getLastMillisecond();
        java.lang.String str29 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week25.next();
        java.util.Date date32 = week25.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(100, 9);
        long long36 = week35.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week35.previous();
        java.util.Date date38 = regularTimePeriod37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date32, timeZone39);
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date42, timeZone43);
        boolean boolean45 = week2.equals((java.lang.Object) wildcardClass13);
        int int46 = week2.getYearValue();
        long long47 = week2.getFirstMillisecond();
        java.util.Calendar calendar48 = null;
        try {
            week2.peg(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61822972800001L) + "'", long17 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61822972800001L) + "'", long26 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61823577600000L) + "'", long27 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-61822972800001L) + "'", long28 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 100, 9" + "'", str29.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61822972800001L) + "'", long36 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62147145600000L) + "'", long47 == (-62147145600000L));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int16 = week2.compareTo((java.lang.Object) wildcardClass7);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(100, 9);
        long long20 = week19.getLastMillisecond();
        long long21 = week19.getFirstMillisecond();
        long long22 = week19.getLastMillisecond();
        java.lang.String str23 = week19.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week19.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week19.next();
        java.util.Date date26 = week19.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(100, 9);
        long long30 = week29.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week29.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date26, timeZone33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass37 = timeZone36.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date26, timeZone36);
        java.util.Date date39 = week38.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61822972800001L) + "'", long11 == (-61822972800001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61822972800001L) + "'", long20 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61823577600000L) + "'", long21 == (-61823577600000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61822972800001L) + "'", long22 == (-61822972800001L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 100, 9" + "'", str23.equals("Week 100, 9"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61822972800001L) + "'", long30 == (-61822972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(date39);
    }
}

