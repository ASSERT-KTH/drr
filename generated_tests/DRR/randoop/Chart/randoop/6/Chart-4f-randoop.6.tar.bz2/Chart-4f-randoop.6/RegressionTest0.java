import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Paint paint0 = null;
        java.awt.Paint paint1 = null;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity4 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color14 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer5.setLegendTextPaint(0, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem(attributedString0, "", "", "{0}", shape4, (java.awt.Paint) color14, stroke16, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1561964399999L, (double) 100L, (double) 'a', (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke2, rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, (int) (short) -1, (double) (-1.0f), (double) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity4 = new org.jfree.chart.entity.PlotEntity(shape0, plot1, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator2, true);
        java.awt.Stroke stroke5 = null;
        try {
            barRenderer0.setBaseStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener1 = null;
        try {
            xYStepAreaRenderer0.removeChangeListener(rendererChangeListener1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = null;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 10, dateTickUnitType2, (int) '#', dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("hi!", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis11 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray10);
        symbolAxis11.resizeRange((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint18 = barRenderer16.lookupSeriesOutlinePaint((int) 'a');
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        try {
            barRenderer0.drawRangeLine(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) symbolAxis11, rectangle2D14, 0.0d, paint18, stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        try {
            barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        org.jfree.data.Range range2 = null;
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(xYDataset0, list1, range2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color9 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer0.setLegendTextPaint(0, (java.awt.Paint) color9);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "{0}", "{0}", categoryDataset3, (java.lang.Comparable) 1561964399999L, (java.lang.Comparable) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            boolean boolean3 = timeSeriesCollection0.isSelected((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (32).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYStepAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        timeSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            java.lang.Number number5 = timeSeriesCollection0.getEndX((int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity32 = new org.jfree.chart.entity.JFreeChartEntity(shape23, jFreeChart29, "{0}", "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        double double13 = symbolAxis7.getLowerMargin();
        org.jfree.data.Range range14 = null;
        try {
            symbolAxis7.setRangeWithMargins(range14, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 1900, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 2.0f, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter3 = null;
        try {
            standardChartTheme1.setXYBarPainter(xYBarPainter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color14 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer5.setLegendTextPaint(0, (java.awt.Paint) color14);
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape4, (java.awt.Paint) color14);
        int int17 = color14.getTransparency();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        try {
            standardChartTheme1.setDrawingSupplier(drawingSupplier10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'supplier' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        java.io.ObjectOutputStream objectOutputStream17 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape12, objectOutputStream17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color8 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean9 = textAnchor6.equals((java.lang.Object) color8);
        try {
            java.awt.Shape shape10 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("{0}", graphics2D1, (float) 100L, (float) (byte) 0, textAnchor4, (double) 1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker5.setLabelTextAnchor(textAnchor6);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) '#', (float) 100, textAnchor6, 0.0d, 100.0f, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Pie Plot");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        try {
            barRenderer0.setPlot(categoryPlot11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        timeSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        java.util.List list5 = null;
        org.jfree.data.Range range6 = null;
        try {
            org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, list5, range6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 0, (double) '#', 3, (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Pie Plot", class1);
//        org.junit.Assert.assertNull(inputStream2);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor3 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor3.sort();
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("{0}", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart11.createBufferedImage((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            boolean boolean3 = timeSeriesCollection0.isSelected((int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        double double13 = symbolAxis7.getLowerMargin();
        org.jfree.data.RangeType rangeType14 = null;
        try {
            symbolAxis7.setRangeType(rangeType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        java.util.List list12 = null;
        try {
            jFreeChart11.setSubtitles(list12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) -1);
        barRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYStepAreaRenderer0.getSeriesItemLabelGenerator((int) (byte) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYStepAreaRenderer0.setSeriesToolTipGenerator((int) (byte) 0, xYToolTipGenerator4, true);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Pie Plot");
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity17 = new org.jfree.chart.entity.CategoryItemEntity(shape11, "", "", categoryDataset14, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme1.setSmallFont(font3);
        java.awt.Font font5 = standardChartTheme1.getSmallFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setSectionDepth((double) (short) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Paint paint6 = null;
        try {
            ringPlot0.setLabelLinkPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Paint paint0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setSeriesShape((int) (short) 10, shape9, true);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) ' ', stroke13);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = valueMarker16.getLabelOffset();
        double double19 = rectangleInsets17.calculateLeftInset(12.0d);
        try {
            org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder(paint0, stroke13, rectangleInsets17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        jFreeChart11.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        xYStepAreaRenderer0.setRangeBase((double) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        timeSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            java.lang.Number number5 = timeSeriesCollection0.getX((int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setShadowXOffset((double) '#');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator6);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint12 = barRenderer10.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = barRenderer10.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape18 = null;
        barRenderer10.setLegendShape(100, shape18);
        boolean boolean20 = barRenderer10.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape21 = barRenderer10.getBaseLegendShape();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape21, (double) (short) 0, (double) ' ');
        numberAxis3D9.setDownArrow(shape21);
        boolean boolean26 = numberAxis3D9.isTickMarksVisible();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10, 0.0f);
        numberAxis3D9.setLeftArrow(shape29);
        barRenderer0.setSeriesShape(0, shape29, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        java.awt.Font font29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendItem28.setLabelFont(font29);
        java.awt.Shape shape31 = legendItem28.getLine();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine2.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double20 = numberAxis3D0.lengthToJava2D(0.0d, rectangle2D18, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Color color4 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        ringPlot0.setInsets(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot0.setOutlineStroke(stroke5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        ringPlot0.notifyListeners(plotChangeEvent7);
        java.awt.Paint paint9 = ringPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean6 = rectangleEdge4.equals((java.lang.Object) 2);
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        try {
            double double8 = categoryAxis3D0.getCategoryEnd((int) ' ', 3, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setSectionDepth((double) (short) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        try {
            ringPlot0.setInteriorGap((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = null;
        try {
            textBlock5.draw(graphics2D6, 0.0f, (float) (short) 0, textBlockAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list17 = symbolAxis7.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = null;
        try {
            timeSeriesCollection1.setGroup(datasetGroup2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        double double13 = symbolAxis7.getLowerMargin();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double17 = symbolAxis7.valueToJava2D(0.0d, rectangle2D15, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        double double4 = rectangleInsets2.calculateLeftInset(12.0d);
        double double6 = rectangleInsets2.trimHeight((double) 1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-5.0d) + "'", double6 == (-5.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        barRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        java.lang.String str4 = ringPlot2.getPlotType();
        boolean boolean5 = ringPlot2.getAutoPopulateSectionPaint();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace8.ensureAtLeast(axisSpace9);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace11 = categoryAxis3D0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) ringPlot2, rectangle2D6, rectangleEdge7, axisSpace8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie Plot" + "'", str4.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        numberAxis3D0.setFixedAutoRange((double) 10);
        double double19 = numberAxis3D0.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-8d + "'", double19 == 1.0E-8d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.lang.Object obj2 = numberAxis3D0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        java.awt.Paint paint4 = barRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getLabelInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        ringPlot5.setInsets(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot5.setOutlineStroke(stroke10);
        boolean boolean12 = numberAxis3D1.hasListener((java.util.EventListener) ringPlot5);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot5);
        java.util.List list14 = jFreeChart13.getSubtitles();
        segmentedTimeline0.setExceptionSegments(list14);
        try {
            boolean boolean17 = segmentedTimeline0.containsDomainValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.title.LegendTitle cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        axisSpace0.setRight(0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = xYStepAreaRenderer0.lookupSeriesFillPaint((int) (byte) 0);
        xYStepAreaRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.lang.String str2 = ringPlot0.getPlotType();
        boolean boolean3 = ringPlot0.getAutoPopulateSectionPaint();
        ringPlot0.setSimpleLabels(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(3);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        java.awt.Paint paint29 = legendItem28.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        double double2 = rectangleInsets1.getRight();
        double double4 = rectangleInsets1.trimWidth((double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets1.createInsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-5.0d) + "'", double4 == (-5.0d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        org.jfree.chart.title.Title title2 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity5 = new org.jfree.chart.entity.TitleEntity(shape1, title2, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor8.sort();
        ringPlot5.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", font3, (org.jfree.chart.plot.Plot) ringPlot5, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart12.addProgressListener(chartProgressListener13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 0, jFreeChart12, chartChangeEventType15);
        jFreeChart12.clearSubtitles();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setLabelToolTip("");
        java.awt.Font font12 = symbolAxis7.getLabelFont();
        float float13 = symbolAxis7.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setSectionDepth((double) (short) 1);
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        ringPlot0.setInsets(rectangleInsets3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = ringPlot0.getLabelDistributor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities((int) (short) 0);
        boolean boolean15 = barRenderer0.getItemVisible((-1), (int) '4');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            double double3 = timeSeriesCollection0.getStartYValue((int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color9 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer0.setLegendTextPaint(0, (java.awt.Paint) color9);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint((-1));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        double double4 = xYStepAreaRenderer0.getRangeBase();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        numberAxis3D0.setFixedAutoRange((double) 10);
        org.jfree.data.Range range19 = numberAxis3D0.getRange();
        numberAxis3D0.configure();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getUpperBound();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker16, rectangle2D17);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator19, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer23.getToolTipGenerator((int) (short) 10, 0, false);
        double double30 = barRenderer23.getItemMargin();
        java.awt.Stroke stroke31 = barRenderer23.getBaseStroke();
        try {
            barRenderer0.setSeriesStroke((-1), stroke31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesStroke((int) (short) 0);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, paint11);
        xYStepAreaRenderer0.setSeriesItemLabelPaint(2, paint11, false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis3D15.getLabelInsets();
        double double17 = rectangleInsets16.getRight();
        double double19 = rectangleInsets16.calculateBottomInset(0.0d);
        boolean boolean20 = xYStepAreaRenderer0.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker2.setStartValue((double) 1.0f);
        intervalMarker2.setEndValue((double) 900000L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        boolean boolean1 = logFormat0.isParseIntegerOnly();
        try {
            java.lang.Object obj3 = logFormat0.parseObject("hi!");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer18.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color27 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer18.setLegendTextPaint(0, (java.awt.Paint) color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape17, (java.awt.Paint) color27);
        symbolAxis7.setGridBandAlternatePaint((java.awt.Paint) color27);
        double double31 = symbolAxis7.getFixedDimension();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint29 = barRenderer27.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = barRenderer27.getToolTipGenerator((int) (short) 10, 0, false);
        double double34 = barRenderer27.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint37 = barRenderer35.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator41 = barRenderer35.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape43 = null;
        barRenderer35.setLegendShape(100, shape43);
        boolean boolean45 = barRenderer35.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape46 = barRenderer35.getBaseLegendShape();
        barRenderer27.setBaseShape(shape46);
        xYStepAreaRenderer25.setSeriesShape((int) ' ', shape46);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint52 = barRenderer50.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator56 = barRenderer50.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape58 = null;
        barRenderer50.setLegendShape(100, shape58);
        boolean boolean60 = barRenderer50.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape61 = barRenderer50.getBaseLegendShape();
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape61, (double) (short) 0, (double) ' ');
        numberAxis3D49.setDownArrow(shape61);
        java.awt.Shape[] shapeArray66 = new java.awt.Shape[] { shape23, shape46, shape61 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier67 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray66);
        try {
            java.awt.Stroke stroke68 = defaultDrawingSupplier67.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryToolTipGenerator41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(categoryToolTipGenerator56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(shapeArray66);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        java.awt.Paint paint4 = valueMarker1.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker1.getLabelOffsetType();
        java.lang.Class class6 = null;
        try {
            java.util.EventListener[] eventListenerArray7 = valueMarker1.getListeners(class6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean4 = xYStepAreaRenderer1.getBaseCreateEntities();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepAreaRenderer1.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator6, true);
        xYStepAreaRenderer1.removeAnnotations();
        boolean boolean10 = domainOrder0.equals((java.lang.Object) xYStepAreaRenderer1);
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint14 = standardChartTheme13.getAxisLabelPaint();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme13.setSmallFont(font15);
        xYStepAreaRenderer1.setSeriesItemLabelFont(4, font15);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Color color1 = java.awt.Color.getColor("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        jFreeChart11.removeLegend();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj18 = textTitle17.clone();
        try {
            jFreeChart11.addSubtitle(1, (org.jfree.chart.title.Title) textTitle17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont((int) '#', font14, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj3 = intervalMarker2.clone();
        double double4 = intervalMarker2.getEndValue();
        java.awt.Paint paint5 = null;
        try {
            intervalMarker2.setPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        boolean boolean17 = numberAxis3D0.isTickMarksVisible();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10, 0.0f);
        numberAxis3D0.setLeftArrow(shape20);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone(shape20);
        org.jfree.chart.plot.Plot plot23 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape20, plot23, "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString((double) 10L);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("");
        seriesException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        ringPlot0.axisChanged(axisChangeEvent2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.2d, "", true);
        logFormat3.setMinimumFractionDigits(2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot4.getLabelPadding();
        double double13 = rectangleInsets12.getLeft();
        double double15 = rectangleInsets12.extendHeight((double) 100.0f);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 104.0d + "'", double15 == 104.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 3, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Object obj0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getLabelInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        ringPlot5.setInsets(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot5.setOutlineStroke(stroke10);
        boolean boolean12 = numberAxis3D1.hasListener((java.util.EventListener) ringPlot5);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot5);
        jFreeChart13.setNotify(false);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean4 = xYStepAreaRenderer1.getBaseItemLabelsVisible();
        boolean boolean5 = xYStepAreaRenderer1.getPlotArea();
        xYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer1);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj3 = intervalMarker2.clone();
        double double4 = intervalMarker2.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker6.setLabelAnchor(rectangleAnchor7);
        intervalMarker2.setLabelAnchor(rectangleAnchor7);
        java.awt.Stroke stroke10 = intervalMarker2.getOutlineStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        boolean boolean17 = numberAxis3D0.isTickMarksVisible();
        numberAxis3D0.setAutoTickUnitSelection(false, true);
        java.awt.Paint paint21 = numberAxis3D0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor3 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor3.sort();
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor3);
        ringPlot0.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        try {
            valueMarker1.setAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((-5.0d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        ringPlot4.datasetChanged(datasetChangeEvent12);
        ringPlot4.clearSectionOutlineStrokes(false);
        ringPlot4.setMinimumArcAngleToDraw((double) (-1L));
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        float float13 = symbolAxis7.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        double double5 = timeSeriesCollection0.getDomainLowerBound(true);
        try {
            double double8 = timeSeriesCollection0.getYValue(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean12 = rectangleEdge10.equals((java.lang.Object) 2);
        try {
            double double13 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) (-5.0d), (java.lang.Comparable) 3, categoryDataset7, 0.0d, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = symbolAxis7.getLabelInsets();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = xYStepAreaRenderer0.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = xYStepAreaRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(drawingSupplier6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) 2);
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        try {
            double double10 = numberAxis3D0.lengthToJava2D((double) 1900, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setShadowXOffset((double) '#');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(drawingSupplier8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        double double1 = xYBarRenderer0.getBarAlignmentFactor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainPannable();
        java.awt.geom.Point2D point2D2 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font7);
        textBlock5.addLine(textLine8);
        java.awt.Font font11 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint14 = standardChartTheme13.getAxisLabelPaint();
        java.awt.Font font17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("hi!", font17);
        java.awt.Paint paint19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font17, paint19);
        standardChartTheme13.setShadowPaint(paint19);
        java.awt.Paint paint22 = standardChartTheme13.getThermometerPaint();
        try {
            textBlock5.addLine("TextAnchor.TOP_RIGHT", font11, paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj2 = textTitle1.clone();
        double double3 = textTitle1.getWidth();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        java.awt.Paint paint4 = null;
        try {
            valueMarker1.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean6 = rectangleEdge4.equals((java.lang.Object) 2);
        try {
            double double7 = categoryAxis3D0.getCategoryMiddle(4, 9, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        java.awt.Paint paint14 = jFreeChart11.getBackgroundPaint();
        try {
            org.jfree.chart.title.Title title16 = jFreeChart11.getSubtitle((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color9 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer0.setLegendTextPaint(0, (java.awt.Paint) color9);
        int int11 = color9.getBlue();
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color9, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint4 = standardChartTheme3.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme3.setSmallFont(font5);
        standardChartTheme1.setRegularFont(font5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) font5);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 900000L);
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape1, plot2, "Size2D[width=0.0, height=100.0]", "PlotOrientation.VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter11 = standardChartTheme1.getXYBarPainter();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        standardChartTheme1.setThermometerPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNotNull(xYBarPainter11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        boolean boolean17 = numberAxis3D0.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis3D18.getLabelInsets();
        double double20 = numberAxis3D18.getFixedAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint23 = barRenderer21.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = barRenderer21.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape29 = null;
        barRenderer21.setLegendShape(100, shape29);
        boolean boolean31 = barRenderer21.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape32 = barRenderer21.getBaseLegendShape();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        double double36 = numberAxis3D35.getUpperBound();
        org.jfree.chart.plot.Marker marker37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        barRenderer21.drawRangeMarker(graphics2D33, categoryPlot34, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, marker37, rectangle2D38);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint43 = barRenderer41.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = barRenderer41.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape49 = null;
        barRenderer41.setLegendShape(100, shape49);
        boolean boolean51 = barRenderer41.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape52 = barRenderer41.getBaseLegendShape();
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape52, (double) (short) 0, (double) ' ');
        numberAxis3D40.setDownArrow(shape52);
        numberAxis3D40.setFixedAutoRange((double) 10);
        org.jfree.data.Range range59 = numberAxis3D40.getRange();
        numberAxis3D35.setRangeWithMargins(range59, false, true);
        numberAxis3D18.setRange(range59);
        numberAxis3D0.setRange(range59);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.handleClick(0, (int) (short) 0, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1, lengthConstraintType2, (double) (-1L), range4, lengthConstraintType5);
        java.lang.String str7 = lengthConstraintType2.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraintType.RANGE" + "'", str7.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        double double19 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesStroke((int) (byte) 100, stroke21);
        java.awt.Stroke stroke24 = barRenderer0.getSeriesStroke((int) '#');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(stroke24);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        double double5 = timeSeriesCollection0.getDomainLowerBound(true);
        try {
            timeSeriesCollection0.removeSeries(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.RenderingSource renderingSource4 = null;
        xYPlot0.select((double) (byte) 100, 0.05d, rectangle2D3, renderingSource4);
        boolean boolean6 = xYPlot0.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer18.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color27 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer18.setLegendTextPaint(0, (java.awt.Paint) color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape17, (java.awt.Paint) color27);
        symbolAxis7.setGridBandAlternatePaint((java.awt.Paint) color27);
        java.lang.String str31 = symbolAxis7.getLabelToolTip();
        java.awt.Paint paint32 = symbolAxis7.getLabelPaint();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font7);
        textBlock5.addLine(textLine8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        try {
            java.awt.Shape shape17 = textBlock5.calculateBounds(graphics2D10, (float) (short) 100, (float) (short) 10, textBlockAnchor13, (float) (-2208960000000L), (float) ' ', (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        java.awt.Shape shape22 = barRenderer0.getItemShape(100, (int) 'a', true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator24, true);
        boolean boolean27 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            int int2 = defaultXYDataset0.getItemCount((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        boolean boolean14 = jFreeChart11.getAntiAlias();
        org.jfree.chart.StandardChartTheme standardChartTheme16 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint17 = standardChartTheme16.getAxisLabelPaint();
        try {
            jFreeChart11.setTextAntiAlias((java.lang.Object) paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.Color[r=64,g=64,b=64] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "", "");
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D((double) (byte) 0, (double) 100L);
        double double8 = size2D7.getHeight();
        boolean boolean9 = library4.equals((java.lang.Object) size2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Pie Plot");
        java.awt.Font font2 = null;
        try {
            labelBlock1.setFont(font2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        timeSeriesDataItem3.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean7 = ringPlot6.isCircular();
        java.lang.String str8 = ringPlot6.getPlotType();
        boolean boolean9 = timeSeriesDataItem3.equals((java.lang.Object) ringPlot6);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        boolean boolean11 = xYPlot10.isDomainCrosshairLockedOnData();
        java.awt.Color color13 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int14 = color13.getBlue();
        xYPlot10.setRangeMinorGridlinePaint((java.awt.Paint) color13);
        ringPlot6.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        boolean boolean21 = numberAxis3D1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getToolTipGenerator((-1), 10, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        timeSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        try {
            java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setShadowYOffset(12.0d);
        boolean boolean4 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        ringPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setShadowYOffset(12.0d);
        boolean boolean4 = ringPlot0.isCircular();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        boolean boolean6 = xYPlot5.isDomainZoomable();
        boolean boolean7 = xYPlot5.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        xYPlot5.setDomainAxisLocation(1, axisLocation9, false);
        java.awt.Paint paint12 = xYPlot5.getRangeMinorGridlinePaint();
        ringPlot0.setLabelLinkPaint(paint12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean6 = barRenderer0.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double double8 = barRenderer7.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer7.getBaseNegativeItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean17 = barRenderer11.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        double double19 = barRenderer18.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer18.getBaseNegativeItemLabelPosition();
        barRenderer11.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis3D23.getLabelInsets();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D23.setTickMarkPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        boolean boolean28 = ringPlot27.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D29.getLabelInsets();
        ringPlot27.setInsets(rectangleInsets30);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot27.setOutlineStroke(stroke32);
        boolean boolean34 = numberAxis3D23.hasListener((java.util.EventListener) ringPlot27);
        boolean boolean35 = itemLabelPosition20.equals((java.lang.Object) ringPlot27);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.Point2D point2D38 = null;
        org.jfree.chart.plot.PlotState plotState39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            ringPlot27.draw(graphics2D36, rectangle2D37, point2D38, plotState39, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean11 = barRenderer0.isSeriesVisible((int) (short) 1);
        java.lang.Boolean boolean13 = barRenderer0.getSeriesCreateEntities((int) (short) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = barRenderer11.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape19 = null;
        barRenderer11.setLegendShape(100, shape19);
        boolean boolean21 = barRenderer11.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape22 = barRenderer11.getBaseLegendShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer11.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Color color1 = color0.darker();
        java.awt.color.ColorSpace colorSpace2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint8 = barRenderer6.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer6.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape14 = null;
        barRenderer6.setSeriesShape((int) (short) 10, shape14, true);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer6.setSeriesOutlineStroke((int) ' ', stroke18);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color22 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean23 = textAnchor20.equals((java.lang.Object) color22);
        barRenderer6.setBaseItemLabelPaint((java.awt.Paint) color22);
        float[] floatArray31 = new float[] { 0.0f, 100L, 1, 100, 1561964399999L, (short) -1 };
        float[] floatArray32 = color22.getColorComponents(floatArray31);
        float[] floatArray33 = java.awt.Color.RGBtoHSB(2, (int) (short) -1, 500, floatArray31);
        try {
            float[] floatArray34 = color1.getColorComponents(colorSpace2, floatArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint8 = barRenderer6.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer6.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape14 = null;
        barRenderer6.setLegendShape(100, shape14);
        boolean boolean16 = barRenderer6.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape17 = barRenderer6.getBaseLegendShape();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape17, (double) (short) 0, (double) ' ');
        numberAxis3D5.setDownArrow(shape17);
        boolean boolean22 = numberAxis3D5.isTickMarksVisible();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10, 0.0f);
        numberAxis3D5.setLeftArrow(shape25);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        boolean boolean29 = ringPlot28.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis3D30.getLabelInsets();
        ringPlot28.setInsets(rectangleInsets31);
        org.jfree.data.general.DatasetGroup datasetGroup33 = ringPlot28.getDatasetGroup();
        java.awt.Paint paint34 = ringPlot28.getBackgroundPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme37 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint38 = standardChartTheme37.getAxisLabelPaint();
        java.awt.Font font41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("hi!", font41);
        java.awt.Paint paint43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock44 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font41, paint43);
        standardChartTheme37.setShadowPaint(paint43);
        java.lang.String str46 = standardChartTheme37.getName();
        boolean boolean47 = standardChartTheme37.isShadowVisible();
        java.awt.Paint paint48 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme37.setCrosshairPaint(paint48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke51 = categoryPlot50.getDomainGridlineStroke();
        java.awt.Font font55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine56 = new org.jfree.chart.text.TextLine("hi!", font55);
        java.awt.Paint paint57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock58 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font55, paint57);
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint57, stroke59);
        categoryPlot50.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker60);
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot50.setDomainGridlinePaint((java.awt.Paint) color62);
        categoryPlot50.setRangePannable(false);
        java.awt.Stroke stroke66 = categoryPlot50.getRangeMinorGridlineStroke();
        java.awt.Shape shape69 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 900000L);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer70 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer70.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean73 = xYStepAreaRenderer70.getBaseItemLabelsVisible();
        java.awt.Stroke stroke75 = xYStepAreaRenderer70.lookupSeriesStroke((int) (short) 0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer76 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer76.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean79 = xYStepAreaRenderer76.getBaseItemLabelsVisible();
        java.awt.Stroke stroke81 = xYStepAreaRenderer76.lookupSeriesStroke((int) (short) 0);
        java.awt.Font font85 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine86 = new org.jfree.chart.text.TextLine("hi!", font85);
        java.awt.Paint paint87 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock88 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font85, paint87);
        xYStepAreaRenderer76.setSeriesItemLabelPaint(2, paint87, false);
        try {
            org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "Size2D[width=0.0, height=100.0]", false, shape25, false, paint34, true, paint48, stroke66, false, shape69, stroke75, paint87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(datasetGroup33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(textBlock44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "{0}" + "'", str46.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(textBlock58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(font85);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(textBlock88);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Comparable comparable1 = null;
        try {
            categoryAxis3D0.addCategoryLabelToolTip(comparable1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor8.sort();
        ringPlot5.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", font3, (org.jfree.chart.plot.Plot) ringPlot5, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart12.addProgressListener(chartProgressListener13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 0, jFreeChart12, chartChangeEventType15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = null;
        try {
            jFreeChart12.titleChanged(titleChangeEvent17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj4 = intervalMarker3.clone();
        double double5 = intervalMarker3.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker7.setLabelAnchor(rectangleAnchor8);
        intervalMarker3.setLabelAnchor(rectangleAnchor8);
        try {
            java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        numberAxis3D0.setFixedAutoRange((double) 10);
        org.jfree.data.Range range19 = numberAxis3D0.getRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis3D0.setStandardTickUnits(tickUnitSource20);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 104.0d, (-5.0d), (double) (byte) 1, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint6 = xYStepAreaRenderer0.getItemLabelPaint((int) (byte) 0, 7, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYStepAreaRenderer0.setBaseToolTipGenerator(xYToolTipGenerator7, false);
        xYStepAreaRenderer0.setRangeBase(0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray16);
        symbolAxis17.resizeRange((double) (short) 0);
        symbolAxis17.setLabelToolTip("");
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis17);
        java.awt.Paint paint23 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        double double4 = rectangleInsets3.getRight();
        java.lang.String str5 = rectangleInsets3.toString();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets3);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = xYStepAreaRenderer0.getLegendItemToolTipGenerator();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.lang.Boolean boolean8 = xYStepAreaRenderer0.getSeriesVisible((int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator4);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font7);
        textBlock5.addLine(textLine8);
        org.jfree.chart.text.TextLine textLine10 = textBlock5.getLastLine();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textLine10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        double double7 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10L, 100.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        boolean boolean12 = categoryPlot0.isDomainCrosshairVisible();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot0.handleClick(0, (-1), plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.clearDomainMarkers();
        java.awt.Paint paint15 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        boolean boolean4 = xYStepAreaRenderer0.getPlotArea();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        java.awt.Paint paint14 = jFreeChart11.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart11.removeProgressListener(chartProgressListener15);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.lang.String str2 = ringPlot0.getPlotType();
        boolean boolean3 = ringPlot0.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        long long6 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
        java.awt.Stroke stroke8 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = ringPlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int1 = numberTickUnit0.getMinorTickCount();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        standardChartTheme7.setShadowPaint(paint13);
        ringPlot2.setBackgroundPaint(paint13);
        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = xYBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator19);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        double double2 = numberAxis3D0.getFixedAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape11 = null;
        barRenderer3.setLegendShape(100, shape11);
        boolean boolean13 = barRenderer3.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape14 = barRenderer3.getBaseLegendShape();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getUpperBound();
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        barRenderer3.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, marker19, rectangle2D20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer23.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape31 = null;
        barRenderer23.setLegendShape(100, shape31);
        boolean boolean33 = barRenderer23.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape34 = barRenderer23.getBaseLegendShape();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape34, (double) (short) 0, (double) ' ');
        numberAxis3D22.setDownArrow(shape34);
        numberAxis3D22.setFixedAutoRange((double) 10);
        org.jfree.data.Range range41 = numberAxis3D22.getRange();
        numberAxis3D17.setRangeWithMargins(range41, false, true);
        numberAxis3D0.setRange(range41);
        double double46 = numberAxis3D0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        java.awt.Shape shape16 = multiplePiePlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType14 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis3D15.getLabelInsets();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D15.setTickMarkPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean20 = ringPlot19.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D21.getLabelInsets();
        ringPlot19.setInsets(rectangleInsets22);
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot19.setOutlineStroke(stroke24);
        boolean boolean26 = numberAxis3D15.hasListener((java.util.EventListener) ringPlot19);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot19);
        jFreeChart27.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType14, jFreeChart27);
        textTitle13.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        textTitle13.setID("");
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle13.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState38 = barRenderer0.initialise(graphics2D11, rectangle2D34, categoryPlot35, 2, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(dateTickUnitType14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font6);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot8.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor11 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor11.sort();
        ringPlot8.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor11);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("{0}", font6, (org.jfree.chart.plot.Plot) ringPlot8, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot8.getLabelPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot8, (java.lang.Integer) (-1), plotRenderingInfo18);
        org.jfree.data.general.DatasetGroup datasetGroup20 = ringPlot0.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNull(datasetGroup20);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        ringPlot0.setInsets(rectangleInsets3);
        java.lang.String str5 = rectangleInsets3.toString();
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme7.setSmallFont(font9);
        boolean boolean11 = rectangleInsets3.equals((java.lang.Object) font9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1, lengthConstraintType2, (double) (-1L), range4, lengthConstraintType5);
        double double7 = rectangleConstraint6.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean5 = ringPlot1.equals((java.lang.Object) color4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = ringPlot1.getLegendItems();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean12 = ringPlot11.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor14 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor14.sort();
        ringPlot11.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor14);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("{0}", font9, (org.jfree.chart.plot.Plot) ringPlot11, true);
        ringPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepAreaRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator5, true);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = null;
        timeSeriesCollection8.seriesChanged(seriesChangeEvent9);
        org.jfree.data.Range range11 = xYStepAreaRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        java.lang.Object obj12 = jFreeChart11.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) -1);
        barRenderer0.setShadowYOffset((double) 1.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.LegendItem legendItem6 = xYStepAreaRenderer0.getLegendItem((int) '4', (-9999));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean4 = xYStepAreaRenderer1.getBaseItemLabelsVisible();
        boolean boolean5 = xYStepAreaRenderer1.getPlotArea();
        xYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer1);
        xYStepAreaRenderer1.setShapesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        try {
            double double8 = intervalXYDelegate5.getStartXValue(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.data.general.DatasetGroup datasetGroup15 = timeSeriesCollection1.getGroup();
        java.lang.Object obj16 = datasetGroup15.clone();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(datasetGroup15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        org.jfree.chart.plot.Plot plot14 = ringPlot4.getRootPlot();
        java.lang.Object obj15 = null;
        boolean boolean16 = plot14.equals(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepAreaRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator5, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYStepAreaRenderer0.getSeriesToolTipGenerator(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        try {
            int int24 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) defaultXYDataset0, (int) (short) -1, (double) (byte) 100, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        double double9 = barRenderer2.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint12 = barRenderer10.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = barRenderer10.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape18 = null;
        barRenderer10.setLegendShape(100, shape18);
        boolean boolean20 = barRenderer10.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape21 = barRenderer10.getBaseLegendShape();
        barRenderer2.setBaseShape(shape21);
        xYStepAreaRenderer0.setSeriesShape((int) ' ', shape21);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape21, (double) ' ', (double) 2.0f);
        java.awt.Paint[] paintArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray29 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint33 = barRenderer31.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = barRenderer31.getToolTipGenerator((int) (short) 10, 0, false);
        double double38 = barRenderer31.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint41 = barRenderer39.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = barRenderer39.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape47 = null;
        barRenderer39.setLegendShape(100, shape47);
        boolean boolean49 = barRenderer39.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape50 = barRenderer39.getBaseLegendShape();
        barRenderer31.setBaseShape(shape50);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer54 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint56 = barRenderer54.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator60 = barRenderer54.getToolTipGenerator((int) (short) 10, 0, false);
        double double61 = barRenderer54.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint64 = barRenderer62.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator68 = barRenderer62.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape70 = null;
        barRenderer62.setLegendShape(100, shape70);
        boolean boolean72 = barRenderer62.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape73 = barRenderer62.getBaseLegendShape();
        barRenderer54.setBaseShape(shape73);
        xYStepAreaRenderer52.setSeriesShape((int) ' ', shape73);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D76 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer77 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint79 = barRenderer77.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator83 = barRenderer77.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape85 = null;
        barRenderer77.setLegendShape(100, shape85);
        boolean boolean87 = barRenderer77.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape88 = barRenderer77.getBaseLegendShape();
        java.awt.Shape shape91 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape88, (double) (short) 0, (double) ' ');
        numberAxis3D76.setDownArrow(shape88);
        java.awt.Shape[] shapeArray93 = new java.awt.Shape[] { shape50, shape73, shape88 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier94 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray27, paintArray28, strokeArray29, strokeArray30, shapeArray93);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor95 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean96 = defaultDrawingSupplier94.equals((java.lang.Object) rectangleAnchor95);
        java.awt.Shape shape99 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape21, rectangleAnchor95, (double) 1.0f, 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(categoryToolTipGenerator45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNull(categoryToolTipGenerator60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNull(categoryToolTipGenerator68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNull(categoryToolTipGenerator83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(shape88);
        org.junit.Assert.assertNotNull(shape91);
        org.junit.Assert.assertNotNull(shapeArray93);
        org.junit.Assert.assertNotNull(rectangleAnchor95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(shape99);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        double double2 = numberAxis3D0.getFixedAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape11 = null;
        barRenderer3.setLegendShape(100, shape11);
        boolean boolean13 = barRenderer3.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape14 = barRenderer3.getBaseLegendShape();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getUpperBound();
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        barRenderer3.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, marker19, rectangle2D20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer23.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape31 = null;
        barRenderer23.setLegendShape(100, shape31);
        boolean boolean33 = barRenderer23.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape34 = barRenderer23.getBaseLegendShape();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape34, (double) (short) 0, (double) ' ');
        numberAxis3D22.setDownArrow(shape34);
        numberAxis3D22.setFixedAutoRange((double) 10);
        org.jfree.data.Range range41 = numberAxis3D22.getRange();
        numberAxis3D17.setRangeWithMargins(range41, false, true);
        numberAxis3D0.setRange(range41);
        double double46 = range41.getLowerBound();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = symbolAxis7.getTickLabelInsets();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        double double19 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesStroke((int) (byte) 100, stroke21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke25 = categoryPlot24.getDomainGridlineStroke();
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("hi!", font29);
        java.awt.Paint paint31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font29, paint31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint31, stroke33);
        categoryPlot24.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker34);
        boolean boolean36 = categoryPlot24.isDomainCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        double double38 = categoryAxis3D37.getCategoryMargin();
        float float39 = categoryAxis3D37.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = null;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType43 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = numberAxis3D44.getLabelInsets();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D44.setTickMarkPaint((java.awt.Paint) color46);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        boolean boolean49 = ringPlot48.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis3D50.getLabelInsets();
        ringPlot48.setInsets(rectangleInsets51);
        java.awt.Stroke stroke53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot48.setOutlineStroke(stroke53);
        boolean boolean55 = numberAxis3D44.hasListener((java.util.EventListener) ringPlot48);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot48);
        jFreeChart56.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent59 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType43, jFreeChart56);
        textTitle42.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart56);
        textTitle42.setID("");
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle42.getBounds();
        try {
            barRenderer0.drawDomainMarker(graphics2D23, categoryPlot24, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, categoryMarker40, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(textBlock32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.2d + "'", double38 == 0.2d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickUnitType43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray16);
        symbolAxis17.resizeRange((double) (short) 0);
        symbolAxis17.setLabelToolTip("");
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = xYPlot0.getRenderer((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNull(xYItemRenderer24);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape11, "{0}", "");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        java.awt.Shape shape22 = barRenderer0.getItemShape(100, (int) 'a', true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator24, true);
        boolean boolean27 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) true, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation32, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString(1.05d);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean6 = barRenderer0.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double double8 = barRenderer7.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer7.getBaseNegativeItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer0.getURLGenerator((int) '4', 100, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint23 = barRenderer21.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = barRenderer21.getToolTipGenerator((int) (short) 10, 0, false);
        double double28 = barRenderer21.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint31 = barRenderer29.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = barRenderer29.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape37 = null;
        barRenderer29.setLegendShape(100, shape37);
        boolean boolean39 = barRenderer29.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape40 = barRenderer29.getBaseLegendShape();
        barRenderer21.setBaseShape(shape40);
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint44 = barRenderer42.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape40, paint44);
        java.awt.Font font46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendItem45.setLabelFont(font46);
        java.awt.Stroke stroke48 = legendItem45.getLineStroke();
        barRenderer0.setBaseStroke(stroke48);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemLineVisible(100, (int) (short) 1);
        boolean boolean4 = xYLineAndShapeRenderer0.getBaseLinesVisible();
        xYLineAndShapeRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemLineVisible(100, (int) (short) 1);
        boolean boolean4 = xYLineAndShapeRenderer0.getBaseLinesVisible();
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer0.getSeriesLinesVisible((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        int int3 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.Plot plot5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D6.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot10.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D12.getLabelInsets();
        ringPlot10.setInsets(rectangleInsets13);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot10.setOutlineStroke(stroke15);
        boolean boolean17 = numberAxis3D6.hasListener((java.util.EventListener) ringPlot10);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot10);
        java.awt.Paint paint20 = ringPlot10.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot10.setLabelPadding(rectangleInsets21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType25 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis3D26.getLabelInsets();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D26.setTickMarkPaint((java.awt.Paint) color28);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        boolean boolean31 = ringPlot30.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D32.getLabelInsets();
        ringPlot30.setInsets(rectangleInsets33);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot30.setOutlineStroke(stroke35);
        boolean boolean37 = numberAxis3D26.hasListener((java.util.EventListener) ringPlot30);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot30);
        jFreeChart38.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType25, jFreeChart38);
        textTitle24.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart38);
        textTitle24.setID("");
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle24.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker47.setLabelAnchor(rectangleAnchor48);
        java.awt.Paint paint50 = valueMarker47.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = valueMarker47.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets21.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType51, lengthAdjustmentType52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean56 = rectangleEdge54.equals((java.lang.Object) 2);
        org.jfree.chart.axis.AxisSpace axisSpace57 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace58 = new org.jfree.chart.axis.AxisSpace();
        axisSpace57.ensureAtLeast(axisSpace58);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean63 = rectangleEdge61.equals((java.lang.Object) 2);
        boolean boolean64 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge61);
        axisSpace58.add((double) 10, rectangleEdge61);
        axisSpace58.setRight((double) 1561964399999L);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace68 = categoryAxis3D2.reserveSpace(graphics2D4, plot5, rectangle2D53, rectangleEdge54, axisSpace58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(dateTickUnitType25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(lengthAdjustmentType51);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace14 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        axisSpace14.ensureAtLeast(axisSpace15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean20 = rectangleEdge18.equals((java.lang.Object) 2);
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge18);
        axisSpace15.add((double) 10, rectangleEdge18);
        axisSpace15.setRight((double) 1561964399999L);
        xYPlot12.setFixedRangeAxisSpace(axisSpace15, false);
        categoryPlot0.setFixedDomainAxisSpace(axisSpace15, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            categoryPlot0.handleClick(100, (int) (byte) 10, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (short) 1);
        int int6 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getSeriesToolTipGenerator(7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = barRenderer0.getSeriesItemLabelGenerator(0);
        barRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 0.08d);
        xYDataItem2.setY((java.lang.Number) (byte) 0);
        java.lang.Number number5 = xYDataItem2.getY();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 0.08d);
        java.lang.Object obj3 = xYDataItem2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        java.awt.Image image12 = null;
        ringPlot4.setBackgroundImage(image12);
        ringPlot4.setNoDataMessage("1");
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Color color5 = java.awt.Color.BLACK;
        java.awt.Color color6 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("{0}", font2, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color17 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean18 = textAnchor15.equals((java.lang.Object) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D12, 1.0f, (float) (-2208960000000L), textAnchor15, (double) 900000L, textAnchor20);
        try {
            textLine7.draw(graphics2D8, (float) (byte) 0, 2.0f, textAnchor15, (float) 1561964399999L, (float) (byte) 0, 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape21);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        java.awt.Shape shape22 = barRenderer0.getItemShape(100, (int) 'a', true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator24, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = barRenderer0.getPlot();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(categoryPlot27);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL");
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint3 = standardChartTheme2.getAxisLabelPaint();
        java.awt.Paint paint4 = standardChartTheme2.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter5 = standardChartTheme2.getBarPainter();
        boolean boolean6 = defaultXYDataset0.equals((java.lang.Object) standardChartTheme2);
        int int7 = defaultXYDataset0.getSeriesCount();
        try {
            double double10 = defaultXYDataset0.getXValue(7, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(barPainter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesStroke((int) (short) 0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYStepAreaRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYURLGenerator6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        java.awt.Paint paint13 = barRenderer0.getShadowPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 60000L, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean19 = categoryPlot0.removeAnnotation(categoryAnnotation17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        java.awt.Font font29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendItem28.setLabelFont(font29);
        java.lang.Object obj31 = legendItem28.clone();
        java.awt.Stroke stroke32 = legendItem28.getLineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = null;
        try {
            legendItem28.setFillPaintTransformer(gradientPaintTransformer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Color color1 = color0.darker();
        java.lang.String str2 = color1.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=178,g=44,b=178]" + "'", str2.equals("java.awt.Color[r=178,g=44,b=178]"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        try {
            boolean boolean3 = xYPlot0.removeAnnotation(xYAnnotation1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 6, 1.0E-8d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getUpperBound();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker16, rectangle2D17);
        numberAxis3D14.setAutoRangeMinimumSize((double) (short) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint23 = barRenderer21.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = barRenderer21.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape29 = null;
        barRenderer21.setLegendShape(100, shape29);
        boolean boolean31 = barRenderer21.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape32 = barRenderer21.getBaseLegendShape();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        double double36 = numberAxis3D35.getUpperBound();
        org.jfree.chart.plot.Marker marker37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        barRenderer21.drawRangeMarker(graphics2D33, categoryPlot34, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, marker37, rectangle2D38);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint43 = barRenderer41.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = barRenderer41.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape49 = null;
        barRenderer41.setLegendShape(100, shape49);
        boolean boolean51 = barRenderer41.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape52 = barRenderer41.getBaseLegendShape();
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape52, (double) (short) 0, (double) ' ');
        numberAxis3D40.setDownArrow(shape52);
        numberAxis3D40.setFixedAutoRange((double) 10);
        org.jfree.data.Range range59 = numberAxis3D40.getRange();
        numberAxis3D35.setRangeWithMargins(range59, false, true);
        org.jfree.data.time.DateRange dateRange63 = new org.jfree.data.time.DateRange(range59);
        numberAxis3D14.setRangeWithMargins(range59);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.axis.AxisState axisState66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean70 = rectangleEdge68.equals((java.lang.Object) 2);
        try {
            java.util.List list71 = numberAxis3D14.refreshTicks(graphics2D65, axisState66, rectangle2D67, rectangleEdge68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint8 = barRenderer6.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean12 = barRenderer6.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        double double14 = barRenderer13.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer13.getBaseNegativeItemLabelPosition();
        barRenderer6.setPositiveItemLabelPositionFallback(itemLabelPosition15);
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font20);
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font20, paint22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint22, stroke24);
        barRenderer6.setBaseStroke(stroke24);
        xYPlot0.setRangeCrosshairStroke(stroke24);
        xYPlot0.clearAnnotations();
        int int29 = xYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer18.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color27 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer18.setLegendTextPaint(0, (java.awt.Paint) color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape17, (java.awt.Paint) color27);
        symbolAxis7.setGridBandAlternatePaint((java.awt.Paint) color27);
        java.lang.String str31 = symbolAxis7.getLabelToolTip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        double double33 = barRenderer32.getMinimumBarLength();
        barRenderer32.setShadowXOffset(0.0d);
        barRenderer32.setShadowXOffset((double) '#');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = null;
        barRenderer32.setBaseURLGenerator(categoryURLGenerator38);
        java.awt.Paint paint40 = barRenderer32.getBaseItemLabelPaint();
        boolean boolean41 = symbolAxis7.equals((java.lang.Object) paint40);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset1, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        polarPlot20.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        boolean boolean23 = polarPlot20.isAngleGridlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
        polarPlot20.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit25);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        float float2 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        double[][] doubleArray7 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isDomainZoomable();
        boolean boolean13 = xYPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot11.getDomainAxisEdge();
        try {
            double double15 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) (short) 0, (java.lang.Comparable) (byte) -1, categoryDataset8, (double) 10L, rectangle2D10, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot0.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace4 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj9 = intervalMarker8.clone();
        double double10 = intervalMarker8.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker12.setLabelAnchor(rectangleAnchor13);
        intervalMarker8.setLabelAnchor(rectangleAnchor13);
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = xYPlot0.removeRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker8, layer16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        double double4 = ringPlot1.getShadowXOffset();
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis12 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray11);
        symbolAxis12.resizeRange((double) (short) 0);
        symbolAxis12.setLabelToolTip("");
        java.awt.Font font17 = symbolAxis12.getLabelFont();
        ringPlot1.setLabelFont(font17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer18.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color27 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer18.setLegendTextPaint(0, (java.awt.Paint) color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape17, (java.awt.Paint) color27);
        symbolAxis7.setGridBandAlternatePaint((java.awt.Paint) color27);
        java.awt.Color color31 = color27.brighter();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        int int2 = xYPlot0.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) (short) 10, plotRenderingInfo4, point2D5, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        legendItem28.setDescription("");
        legendItem28.setShapeVisible(true);
        java.awt.Stroke stroke33 = legendItem28.getOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint36 = barRenderer34.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = barRenderer34.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape42 = null;
        barRenderer34.setLegendShape(100, shape42);
        boolean boolean44 = barRenderer34.getAutoPopulateSeriesStroke();
        boolean boolean45 = legendItem28.equals((java.lang.Object) barRenderer34);
        legendItem28.setLineVisible(true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener15 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener15);
        try {
            java.lang.Number number19 = timeSeriesCollection1.getY(9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        boolean boolean19 = segmentedTimeline0.equals((java.lang.Object) boolean18);
        java.util.List list20 = segmentedTimeline0.getExceptionSegments();
        boolean boolean23 = segmentedTimeline0.containsDomainRange(0L, (long) 7);
        long long24 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 86400000L + "'", long24 == 86400000L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        double double4 = numberAxis3D2.getFixedAutoRange();
        int int5 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D2);
        java.awt.Stroke stroke6 = xYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint6 = xYStepAreaRenderer0.getItemLabelPaint((int) (byte) 0, 7, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYStepAreaRenderer0.setBaseToolTipGenerator(xYToolTipGenerator7, false);
        xYStepAreaRenderer0.setOutline(false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        double double2 = rectangleInsets1.getRight();
        double double4 = rectangleInsets1.calculateBottomInset(0.0d);
        double double6 = rectangleInsets1.trimHeight((double) 1900);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1894.0d + "'", double6 == 1894.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        polarPlot20.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        boolean boolean23 = polarPlot20.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.jfree.chart.StandardChartTheme standardChartTheme14 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint15 = standardChartTheme14.getAxisLabelPaint();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("hi!", font18);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font18, paint20);
        standardChartTheme14.setShadowPaint(paint20);
        java.lang.String str23 = standardChartTheme14.getName();
        org.jfree.chart.StandardChartTheme standardChartTheme25 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint26 = standardChartTheme25.getAxisLabelPaint();
        java.awt.Font font27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme25.setSmallFont(font27);
        standardChartTheme14.setRegularFont(font27);
        standardChartTheme14.setShadowVisible(true);
        java.awt.Paint paint32 = standardChartTheme14.getTickLabelPaint();
        barRenderer0.setBasePaint(paint32, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{0}" + "'", str23.equals("{0}"));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint3 = standardChartTheme2.getAxisLabelPaint();
        java.awt.Paint paint4 = standardChartTheme2.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter5 = standardChartTheme2.getBarPainter();
        boolean boolean6 = defaultXYDataset0.equals((java.lang.Object) standardChartTheme2);
        try {
            java.lang.Number number9 = defaultXYDataset0.getY(2147483647, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(barPainter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.util.SortOrder sortOrder4 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme1.setSmallFont(font3);
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint7 = standardChartTheme6.getAxisLabelPaint();
        java.awt.Paint paint8 = standardChartTheme6.getDomainGridlinePaint();
        standardChartTheme1.setRangeGridlinePaint(paint8);
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint16 = barRenderer14.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer14.getToolTipGenerator((int) (short) 10, 0, false);
        double double21 = barRenderer14.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint24 = barRenderer22.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = barRenderer22.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape30 = null;
        barRenderer22.setLegendShape(100, shape30);
        boolean boolean32 = barRenderer22.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape33 = barRenderer22.getBaseLegendShape();
        barRenderer14.setBaseShape(shape33);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint39 = barRenderer37.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator43 = barRenderer37.getToolTipGenerator((int) (short) 10, 0, false);
        double double44 = barRenderer37.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer45 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint47 = barRenderer45.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator51 = barRenderer45.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape53 = null;
        barRenderer45.setLegendShape(100, shape53);
        boolean boolean55 = barRenderer45.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape56 = barRenderer45.getBaseLegendShape();
        barRenderer37.setBaseShape(shape56);
        xYStepAreaRenderer35.setSeriesShape((int) ' ', shape56);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer60 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint62 = barRenderer60.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator66 = barRenderer60.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape68 = null;
        barRenderer60.setLegendShape(100, shape68);
        boolean boolean70 = barRenderer60.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape71 = barRenderer60.getBaseLegendShape();
        java.awt.Shape shape74 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape71, (double) (short) 0, (double) ' ');
        numberAxis3D59.setDownArrow(shape71);
        java.awt.Shape[] shapeArray76 = new java.awt.Shape[] { shape33, shape56, shape71 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier77 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray76);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean79 = defaultDrawingSupplier77.equals((java.lang.Object) rectangleAnchor78);
        java.awt.Shape shape80 = defaultDrawingSupplier77.getNextShape();
        standardChartTheme1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier77);
        java.awt.Paint paint82 = standardChartTheme1.getBaselinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(categoryToolTipGenerator43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(categoryToolTipGenerator51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNull(categoryToolTipGenerator66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(shapeArray76);
        org.junit.Assert.assertNotNull(rectangleAnchor78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace8.ensureAtLeast(axisSpace9);
        xYPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        boolean boolean14 = xYPlot13.isDomainZoomable();
        boolean boolean15 = xYPlot13.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot13.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean21 = xYStepAreaRenderer18.getBaseItemLabelsVisible();
        boolean boolean22 = xYStepAreaRenderer18.getPlotArea();
        xYPlot17.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18);
        int int24 = xYPlot13.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18);
        org.jfree.chart.LegendItem legendItem27 = xYStepAreaRenderer18.getLegendItem((int) '#', (int) (byte) 100);
        xYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18, true);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot0.getRangeAxis(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertNull(valueAxis31);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = ringPlot4.getURLGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieURLGenerator14);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getSeriesToolTipGenerator(7);
        barRenderer0.setShadowYOffset(0.2d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.lang.String str2 = ringPlot0.getPlotType();
        boolean boolean3 = ringPlot0.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        long long6 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
        java.awt.Stroke stroke8 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod7);
        ringPlot0.setMinimumArcAngleToDraw(0.2d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(stroke8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Class class7 = periodAxis6.getMajorTickTimePeriodClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", class7);
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone10);
        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] { 13, Double.NEGATIVE_INFINITY, 0.05d, (byte) 100, date9, "PlotOrientation.VERTICAL" };
        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths();
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray17);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray13, (java.lang.Comparable[]) strArray14, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparableArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Paint paint2 = periodAxis1.getMinorTickMarkPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getUpperBound();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker16, rectangle2D17);
        numberAxis3D14.setAutoTickUnitSelection(true);
        org.jfree.data.Range range21 = numberAxis3D14.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setSectionDepth((double) (short) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        ringPlot2.datasetChanged(datasetChangeEvent6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        ringPlot2.setShadowPaint((java.awt.Paint) color8);
        int int10 = year1.compareTo((java.lang.Object) ringPlot2);
        long long11 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62198899200000L) + "'", long11 == (-62198899200000L));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) -1);
        int int21 = barRenderer0.getColumnCount();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = null;
        barRenderer0.setSeriesURLGenerator((int) ' ', categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraintType.RANGE", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot0.getDataset();
        categoryPlot0.setCrosshairDatasetIndex(9, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot0.getOrientation();
        boolean boolean17 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        ringPlot4.setShadowYOffset(12.0d);
        boolean boolean8 = ringPlot4.isCircular();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("1", font2, (org.jfree.chart.plot.Plot) ringPlot4, false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        boolean boolean10 = symbolAxis7.isNegativeArrowVisible();
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        symbolAxis7.setTickLabelPaint(paint11);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color14 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer5.setLegendTextPaint(0, (java.awt.Paint) color14);
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape4, (java.awt.Paint) color14);
        java.lang.Object obj17 = legendItem16.clone();
        java.lang.Comparable comparable18 = legendItem16.getSeriesKey();
        java.awt.Paint paint19 = legendItem16.getOutlinePaint();
        java.text.AttributedString attributedString20 = legendItem16.getAttributedLabel();
        java.lang.String str21 = legendItem16.getDescription();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(attributedString20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{0}" + "'", str21.equals("{0}"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.util.List list6 = textBlock5.getLines();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset();
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot0.addDomainMarker(2147483647, categoryMarker16, layer17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers((int) (short) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getDomainTickBandPaint();
        boolean boolean5 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = xYStepAreaRenderer0.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = xYStepAreaRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("10", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        jFreeChart12.setNotify(false);
        java.lang.Object obj15 = jFreeChart12.clone();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis3D17.getLabelInsets();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D17.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        boolean boolean22 = ringPlot21.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis3D23.getLabelInsets();
        ringPlot21.setInsets(rectangleInsets24);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot21.setOutlineStroke(stroke26);
        boolean boolean28 = numberAxis3D17.hasListener((java.util.EventListener) ringPlot21);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Paint paint31 = ringPlot21.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot21.setLabelPadding(rectangleInsets32);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType36 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D37.getLabelInsets();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D37.setTickMarkPaint((java.awt.Paint) color39);
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        boolean boolean42 = ringPlot41.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = numberAxis3D43.getLabelInsets();
        ringPlot41.setInsets(rectangleInsets44);
        java.awt.Stroke stroke46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot41.setOutlineStroke(stroke46);
        boolean boolean48 = numberAxis3D37.hasListener((java.util.EventListener) ringPlot41);
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot41);
        jFreeChart49.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType36, jFreeChart49);
        textTitle35.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart49);
        textTitle35.setID("");
        java.awt.geom.Rectangle2D rectangle2D56 = textTitle35.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker58.setLabelAnchor(rectangleAnchor59);
        java.awt.Paint paint61 = valueMarker58.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = valueMarker58.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets32.createAdjustedRectangle(rectangle2D56, lengthAdjustmentType62, lengthAdjustmentType63);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo65 = null;
        try {
            jFreeChart12.draw(graphics2D16, rectangle2D56, chartRenderingInfo65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(dateTickUnitType36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(lengthAdjustmentType62);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        double double17 = barRenderer16.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer16.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesPositiveItemLabelPosition(4, itemLabelPosition18, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer0.getBaseURLGenerator();
        boolean boolean22 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.data.general.DatasetGroup datasetGroup15 = timeSeriesCollection1.getGroup();
        try {
            java.lang.Number number18 = timeSeriesCollection1.getEndY((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(datasetGroup15);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockContainer15.getPadding();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        try {
            textBlock5.setLineAlignment(horizontalAlignment6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) 0, (double) 100L);
        java.lang.String str3 = size2D2.toString();
        size2D2.height = 10.0f;
        size2D2.setHeight((double) 2147483647);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=100.0]" + "'", str3.equals("Size2D[width=0.0, height=100.0]"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.util.Collection collection1 = xYStepAreaRenderer0.getAnnotations();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = xYStepAreaRenderer0.getSeriesURLGenerator((int) (short) 0);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNull(xYURLGenerator3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean18 = categoryPlot0.removeAnnotation(categoryAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot0.getDataset();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        java.awt.Image image15 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeMinorGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getQuadrantPaint(0);
        java.awt.Paint paint4 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.lang.String str1 = dateRange0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        java.lang.Object obj9 = numberAxis3D5.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj13 = intervalMarker12.clone();
        double double14 = intervalMarker12.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker16.setLabelAnchor(rectangleAnchor17);
        intervalMarker12.setLabelAnchor(rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepAreaRenderer0.drawRangeMarker(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.plot.Marker) intervalMarker12, rectangle2D20);
        org.jfree.data.RangeType rangeType22 = null;
        try {
            numberAxis3D5.setRangeType(rangeType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            java.lang.Number number9 = timeSeriesCollection0.getY((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        numberAxis3D0.setTickMarksVisible(true);
        numberAxis3D0.setUpperMargin((double) 1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        boolean boolean16 = blockContainer15.isEmpty();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        boolean boolean12 = categoryPlot0.isDomainCrosshairVisible();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer18.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator20, true);
        double[][] doubleArray25 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray25);
        org.jfree.data.Range range27 = barRenderer18.findRangeBounds(categoryDataset26);
        categoryPlot0.setDataset(10, categoryDataset26);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        double double17 = barRenderer16.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer16.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesPositiveItemLabelPosition(4, itemLabelPosition18, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = barRenderer0.getItemLabelGenerator(4, 0, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator25);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, false);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        float float12 = ringPlot4.getForegroundAlpha();
        ringPlot4.setLabelGap((double) 3600000L);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        double double16 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = intervalMarker2.getLabelOffsetType();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray23);
        symbolAxis24.resizeRange((double) (short) 0);
        symbolAxis24.setAutoTickUnitSelection(false, true);
        double double30 = symbolAxis24.getLowerMargin();
        boolean boolean31 = multiplePiePlot16.equals((java.lang.Object) symbolAxis24);
        java.lang.String str33 = symbolAxis24.valueToString((double) (byte) -1);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        symbolAxis24.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        ringPlot4.datasetChanged(datasetChangeEvent12);
        java.awt.Paint paint14 = null;
        ringPlot4.setOutlinePaint(paint14);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        standardChartTheme7.setShadowPaint(paint13);
        ringPlot2.setBackgroundPaint(paint13);
        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
        xYBarRenderer0.setShadowYOffset((double) (-1.0f));
        xYBarRenderer0.setMargin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Shape shape12 = barRenderer0.getSeriesShape((int) (short) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setSectionDepth((double) (short) 1);
        java.awt.Paint paint5 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) "Pie Plot");
        double double6 = ringPlot0.getInteriorGap();
        ringPlot0.setBackgroundImageAlignment(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        boolean boolean4 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = xYStepAreaRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace8.ensureAtLeast(axisSpace9);
        xYPlot0.setFixedRangeAxisSpace(axisSpace9);
        axisSpace9.setTop((double) 9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        xYLineAndShapeRenderer0.setBaseLinesVisible(true);
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 100, false);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape12 = null;
        barRenderer4.setLegendShape(100, shape12);
        boolean boolean14 = barRenderer4.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape15 = barRenderer4.getBaseLegendShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer4.getLegendItemLabelGenerator();
        java.awt.Shape shape18 = barRenderer4.lookupLegendShape((int) (short) 0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D19.getLabelInsets();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D19.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean24 = ringPlot23.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis3D25.getLabelInsets();
        ringPlot23.setInsets(rectangleInsets26);
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot23.setOutlineStroke(stroke28);
        boolean boolean30 = numberAxis3D19.hasListener((java.util.EventListener) ringPlot23);
        java.awt.Image image31 = null;
        ringPlot23.setBackgroundImage(image31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Color color35 = color34.darker();
        ringPlot23.setSectionPaint((java.lang.Comparable) (-2208960000000L), (java.awt.Paint) color34);
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem(attributedString0, "Pie Plot", "TextAnchor.TOP_RIGHT", "hi!", shape18, (java.awt.Paint) color34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint13 = standardChartTheme12.getAxisLabelPaint();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme12.setSmallFont(font14);
        standardChartTheme1.setRegularFont(font14);
        org.jfree.chart.StandardChartTheme standardChartTheme18 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint19 = standardChartTheme18.getAxisLabelPaint();
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("hi!", font22);
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font22, paint24);
        standardChartTheme18.setShadowPaint(paint24);
        java.lang.String str27 = standardChartTheme18.getName();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter28 = standardChartTheme18.getXYBarPainter();
        standardChartTheme1.setXYBarPainter(xYBarPainter28);
        java.awt.Paint paint30 = standardChartTheme1.getPlotOutlinePaint();
        java.awt.Paint paint31 = standardChartTheme1.getTitlePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{0}" + "'", str27.equals("{0}"));
        org.junit.Assert.assertNotNull(xYBarPainter28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        int int4 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        timeSeries3.setMaximumItemAge(0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj3 = intervalMarker2.clone();
        intervalMarker2.setAlpha(0.0f);
        intervalMarker2.setStartValue(1.0d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYStepAreaRenderer0.getURLGenerator(0, (-1), true);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot8.isCircular();
        ringPlot8.setSectionDepth((double) (short) 1);
        java.awt.Paint paint13 = ringPlot8.getSectionOutlinePaint((java.lang.Comparable) "Pie Plot");
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        ringPlot8.setOutlinePaint((java.awt.Paint) color14);
        xYStepAreaRenderer0.setBasePaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(xYURLGenerator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset();
        categoryPlot0.mapDatasetToRangeAxis(15, (int) (byte) 10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        barRenderer0.setShadowVisible(false);
        java.awt.Paint paint6 = barRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        java.awt.Font font29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendItem28.setLabelFont(font29);
        java.awt.Paint paint31 = legendItem28.getLabelPaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint3 = standardChartTheme2.getAxisLabelPaint();
        java.awt.Paint paint4 = standardChartTheme2.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter5 = standardChartTheme2.getBarPainter();
        boolean boolean6 = defaultXYDataset0.equals((java.lang.Object) standardChartTheme2);
        try {
            java.lang.Comparable comparable8 = defaultXYDataset0.getSeriesKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(barPainter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D3.getLabelInsets();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D3.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D9.getLabelInsets();
        ringPlot7.setInsets(rectangleInsets10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot7.setOutlineStroke(stroke12);
        boolean boolean14 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot7);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot7);
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType2, jFreeChart15);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("hi!", font23);
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font23, paint25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint25, stroke27);
        jFreeChart15.setBackgroundPaint(paint25);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        double double5 = timeSeriesCollection0.getDomainLowerBound(true);
        try {
            boolean boolean8 = timeSeriesCollection0.isSelected(13, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (13).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemLineVisible(100, (int) (short) 1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYLineAndShapeRenderer0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        timeSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        try {
            double double7 = timeSeriesCollection0.getEndYValue((int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 500, (double) 10.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker2.setStartValue((double) 10.0f);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        ringPlot5.setInsets(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot5.setOutlineStroke(stroke10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        ringPlot5.drawBackgroundImage(graphics2D12, rectangle2D13);
        ringPlot5.setIgnoreNullValues(false);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint3 = standardChartTheme2.getAxisLabelPaint();
        java.awt.Paint paint4 = standardChartTheme2.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter5 = standardChartTheme2.getBarPainter();
        boolean boolean6 = defaultXYDataset0.equals((java.lang.Object) standardChartTheme2);
        try {
            double double9 = defaultXYDataset0.getYValue(4, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(barPainter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean5 = ringPlot1.equals((java.lang.Object) color4);
        java.lang.String str6 = ringPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ERROR : Relative To String", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

