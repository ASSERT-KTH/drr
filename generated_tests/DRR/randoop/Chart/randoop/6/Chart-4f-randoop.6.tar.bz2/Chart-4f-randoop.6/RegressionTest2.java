import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getUpperBound();
        numberAxis3D0.setVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        logFormat0.setMinimumIntegerDigits((int) (short) 10);
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat(0.2d, "", true);
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Number number10 = logFormat7.parse("", parsePosition9);
        java.lang.StringBuffer stringBuffer12 = null;
        java.text.FieldPosition fieldPosition13 = null;
        java.lang.StringBuffer stringBuffer14 = logFormat7.format(0L, stringBuffer12, fieldPosition13);
        java.text.FieldPosition fieldPosition15 = null;
        java.lang.StringBuffer stringBuffer16 = logFormat0.format((double) ' ', stringBuffer12, fieldPosition15);
        java.lang.String str18 = logFormat0.format((double) 10.0f);
        try {
            java.util.Currency currency19 = logFormat0.getCurrency();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(stringBuffer14);
        org.junit.Assert.assertNotNull(stringBuffer16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10^1.0" + "'", str18.equals("10^1.0"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor8.sort();
        ringPlot5.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", font3, (org.jfree.chart.plot.Plot) ringPlot5, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart12.addProgressListener(chartProgressListener13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 0, jFreeChart12, chartChangeEventType15);
        int int17 = jFreeChart12.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartChangeListener chartChangeListener18 = null;
        try {
            jFreeChart12.addChangeListener(chartChangeListener18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        int int3 = categoryAxis3D0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        timeSeriesDataItem3.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean7 = ringPlot6.isCircular();
        java.lang.String str8 = ringPlot6.getPlotType();
        boolean boolean9 = timeSeriesDataItem3.equals((java.lang.Object) ringPlot6);
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("{0}");
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint14 = standardChartTheme13.getAxisLabelPaint();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme13.setSmallFont(font15);
        standardChartTheme11.setRegularFont(font15);
        ringPlot6.setLabelFont(font15);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke20 = categoryPlot19.getDomainGridlineStroke();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("hi!", font24);
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font24, paint26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint26, stroke28);
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker29);
        boolean boolean31 = categoryPlot19.isDomainCrosshairVisible();
        java.awt.Paint paint32 = categoryPlot19.getDomainCrosshairPaint();
        ringPlot6.setNoDataMessagePaint(paint32);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor35 = new org.jfree.chart.plot.PieLabelDistributor(100);
        ringPlot6.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D7.setTickMarkPaint((java.awt.Paint) color9);
        java.lang.Object obj11 = numberAxis3D7.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj15 = intervalMarker14.clone();
        double double16 = intervalMarker14.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker18.setLabelAnchor(rectangleAnchor19);
        intervalMarker14.setLabelAnchor(rectangleAnchor19);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYStepAreaRenderer2.drawRangeMarker(graphics2D5, xYPlot6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.plot.Marker) intervalMarker14, rectangle2D22);
        int int24 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D7);
        java.awt.Font font27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("hi!", font27);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        boolean boolean30 = ringPlot29.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor32 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor32.sort();
        ringPlot29.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor32);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("{0}", font27, (org.jfree.chart.plot.Plot) ringPlot29, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener37 = null;
        jFreeChart36.addProgressListener(chartProgressListener37);
        java.awt.Paint paint39 = jFreeChart36.getBackgroundPaint();
        xYPlot0.setRangeMinorGridlinePaint(paint39);
        boolean boolean41 = xYPlot0.isDomainPannable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainPannable();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        float float3 = xYPlot0.getForegroundAlpha();
        double double4 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot0.setDomainAxis(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) 12.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        java.awt.Paint paint16 = symbolAxis8.getLabelPaint();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean18 = symbolAxis8.equals((java.lang.Object) stroke17);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        try {
            xYPlot0.setDomainAxisLocation(0, axisLocation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot0.setRangeAxis(valueAxis14);
        boolean boolean16 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        java.util.List list16 = blockContainer15.getBlocks();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj19 = textTitle18.clone();
        textTitle18.setWidth((double) 10);
        textTitle18.setVisible(false);
        blockContainer15.add((org.jfree.chart.block.Block) textTitle18);
        textTitle18.setPadding((double) 1.0f, (double) 0.0f, (double) 10L, (double) 900000L);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setSectionDepth((double) (short) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        ringPlot2.datasetChanged(datasetChangeEvent6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        ringPlot2.setShadowPaint((java.awt.Paint) color8);
        int int10 = year1.compareTo((java.lang.Object) ringPlot2);
        double double11 = ringPlot2.getStartAngle();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker13.getLabelOffset();
        double double16 = rectangleInsets14.calculateLeftInset(12.0d);
        ringPlot2.setInsets(rectangleInsets14);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("Pie Plot");
        double double20 = textTitle19.getHeight();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets14.createOutsetRectangle(rectangle2D21, false, false);
        org.jfree.chart.axis.Axis axis25 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D21, axis25, "Layer.BACKGROUND");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart17.removeProgressListener(chartProgressListener23);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        jFreeChart12.setNotify(false);
        jFreeChart12.clearSubtitles();
        jFreeChart12.removeLegend();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        boolean boolean6 = xYPlot0.canSelectByRegion();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(legendItemCollection7);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) (-1L), (double) (-2208960000000L), plotRenderingInfo3, point2D4);
        categoryPlot0.setDomainCrosshairVisible(true);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        boolean boolean6 = intervalXYDelegate5.isAutoWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint6 = standardChartTheme5.getAxisLabelPaint();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, paint11);
        standardChartTheme5.setShadowPaint(paint11);
        ringPlot0.setBackgroundPaint(paint11);
        java.awt.Stroke stroke15 = null;
        ringPlot0.setLabelOutlineStroke(stroke15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock12);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        boolean boolean14 = barRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) 1561964399999L, 10.0f, (float) (-1));
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        xYPlot0.clearRangeMarkers(0);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker14.setLabelAnchor(rectangleAnchor15);
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot0.addRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker14, layer17, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = xYPlot0.getAxisOffset();
        org.jfree.chart.plot.Marker marker21 = null;
        boolean boolean22 = xYPlot0.removeDomainMarker(marker21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        java.lang.Object obj9 = numberAxis3D5.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj13 = intervalMarker12.clone();
        double double14 = intervalMarker12.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker16.setLabelAnchor(rectangleAnchor17);
        intervalMarker12.setLabelAnchor(rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepAreaRenderer0.drawRangeMarker(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.plot.Marker) intervalMarker12, rectangle2D20);
        java.awt.Paint paint22 = xYPlot4.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        java.lang.Object obj14 = jFreeChart11.clone();
        jFreeChart11.fireChartChanged();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        boolean boolean11 = standardChartTheme1.isShadowVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        double double27 = numberAxis3D26.getUpperBound();
        org.jfree.chart.plot.Marker marker28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        barRenderer12.drawRangeMarker(graphics2D24, categoryPlot25, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, marker28, rectangle2D29);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        barRenderer12.setBaseToolTipGenerator(categoryToolTipGenerator31, true);
        boolean boolean34 = standardChartTheme1.equals((java.lang.Object) barRenderer12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot35 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj36 = multiplePiePlot35.clone();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType39 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis3D40.getLabelInsets();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D40.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        boolean boolean45 = ringPlot44.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis3D46.getLabelInsets();
        ringPlot44.setInsets(rectangleInsets47);
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot44.setOutlineStroke(stroke49);
        boolean boolean51 = numberAxis3D40.hasListener((java.util.EventListener) ringPlot44);
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot44);
        jFreeChart52.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent55 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType39, jFreeChart52);
        textTitle38.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart52);
        multiplePiePlot35.setPieChart(jFreeChart52);
        jFreeChart52.setAntiAlias(false);
        standardChartTheme1.apply(jFreeChart52);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(dateTickUnitType39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }
}

