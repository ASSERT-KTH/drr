import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, 2, (int) (short) 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        int int3 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D2.getCategoryLabelPositions();
        categoryAxis3D2.setMaximumCategoryLabelLines(6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean6 = barRenderer0.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double double8 = barRenderer7.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer7.getBaseNegativeItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = barRenderer0.getToolTipGenerator((int) (byte) 10, 13, true);
        org.jfree.chart.LegendItem legendItem19 = barRenderer0.getLegendItem((int) (short) 0, 9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertNull(legendItem19);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        try {
            double double8 = intervalXYDelegate5.getStartXValue((-9999), 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        xYPlot0.clearRangeMarkers(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot0.getRangeMarkers(layer12);
        org.jfree.chart.StandardChartTheme standardChartTheme15 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint16 = standardChartTheme15.getAxisLabelPaint();
        java.awt.Paint paint17 = standardChartTheme15.getLabelLinkPaint();
        xYPlot0.setDomainGridlinePaint(paint17);
        boolean boolean19 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo2 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray3 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo2 };
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.centerRange((double) 1561964399999L);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray3);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemLineVisible(2, (int) (byte) 10);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemShapeFilled((int) (byte) 10, (int) (short) 100);
        xYLineAndShapeRenderer0.setSeriesShapesVisible((int) 'a', (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        jFreeChart17.setAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        try {
            jFreeChart17.handleClick(7, 0, chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        java.lang.Object obj9 = numberAxis3D5.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj13 = intervalMarker12.clone();
        double double14 = intervalMarker12.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker16.setLabelAnchor(rectangleAnchor17);
        intervalMarker12.setLabelAnchor(rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepAreaRenderer0.drawRangeMarker(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.plot.Marker) intervalMarker12, rectangle2D20);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint24 = barRenderer22.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean28 = barRenderer22.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        double double30 = barRenderer29.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = barRenderer29.getBaseNegativeItemLabelPosition();
        barRenderer22.setPositiveItemLabelPositionFallback(itemLabelPosition31);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation33 = null;
        boolean boolean34 = barRenderer22.removeAnnotation(categoryAnnotation33);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = barRenderer22.getURLGenerator((int) '4', 100, true);
        boolean boolean39 = intervalMarker12.equals((java.lang.Object) categoryURLGenerator38);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(categoryURLGenerator38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        double double2 = numberAxis3D0.getFixedAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape11 = null;
        barRenderer3.setLegendShape(100, shape11);
        boolean boolean13 = barRenderer3.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape14 = barRenderer3.getBaseLegendShape();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getUpperBound();
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        barRenderer3.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, marker19, rectangle2D20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer23.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape31 = null;
        barRenderer23.setLegendShape(100, shape31);
        boolean boolean33 = barRenderer23.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape34 = barRenderer23.getBaseLegendShape();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape34, (double) (short) 0, (double) ' ');
        numberAxis3D22.setDownArrow(shape34);
        numberAxis3D22.setFixedAutoRange((double) 10);
        org.jfree.data.Range range41 = numberAxis3D22.getRange();
        numberAxis3D17.setRangeWithMargins(range41, false, true);
        numberAxis3D0.setRange(range41);
        numberAxis3D0.setTickMarkOutsideLength((float) (-62198899200000L));
        numberAxis3D0.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        double double17 = barRenderer16.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer16.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesPositiveItemLabelPosition(4, itemLabelPosition18, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint28 = barRenderer26.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = barRenderer26.getToolTipGenerator((int) (short) 10, 0, false);
        double double33 = barRenderer26.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint36 = barRenderer34.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = barRenderer34.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape42 = null;
        barRenderer34.setLegendShape(100, shape42);
        boolean boolean44 = barRenderer34.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape45 = barRenderer34.getBaseLegendShape();
        barRenderer26.setBaseShape(shape45);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint49 = barRenderer47.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape45, paint49);
        legendItem50.setDescription("");
        legendItem50.setShapeVisible(true);
        java.awt.Stroke stroke55 = legendItem50.getOutlineStroke();
        try {
            barRenderer0.setSeriesOutlineStroke(2147483647, stroke55, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryToolTipGenerator32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme1.setSmallFont(font3);
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint7 = standardChartTheme6.getAxisLabelPaint();
        java.awt.Paint paint8 = standardChartTheme6.getDomainGridlinePaint();
        standardChartTheme1.setRangeGridlinePaint(paint8);
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint16 = barRenderer14.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer14.getToolTipGenerator((int) (short) 10, 0, false);
        double double21 = barRenderer14.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint24 = barRenderer22.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = barRenderer22.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape30 = null;
        barRenderer22.setLegendShape(100, shape30);
        boolean boolean32 = barRenderer22.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape33 = barRenderer22.getBaseLegendShape();
        barRenderer14.setBaseShape(shape33);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint39 = barRenderer37.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator43 = barRenderer37.getToolTipGenerator((int) (short) 10, 0, false);
        double double44 = barRenderer37.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer45 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint47 = barRenderer45.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator51 = barRenderer45.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape53 = null;
        barRenderer45.setLegendShape(100, shape53);
        boolean boolean55 = barRenderer45.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape56 = barRenderer45.getBaseLegendShape();
        barRenderer37.setBaseShape(shape56);
        xYStepAreaRenderer35.setSeriesShape((int) ' ', shape56);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer60 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint62 = barRenderer60.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator66 = barRenderer60.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape68 = null;
        barRenderer60.setLegendShape(100, shape68);
        boolean boolean70 = barRenderer60.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape71 = barRenderer60.getBaseLegendShape();
        java.awt.Shape shape74 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape71, (double) (short) 0, (double) ' ');
        numberAxis3D59.setDownArrow(shape71);
        java.awt.Shape[] shapeArray76 = new java.awt.Shape[] { shape33, shape56, shape71 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier77 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray76);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean79 = defaultDrawingSupplier77.equals((java.lang.Object) rectangleAnchor78);
        java.awt.Shape shape80 = defaultDrawingSupplier77.getNextShape();
        standardChartTheme1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier77);
        java.awt.Paint paint82 = null;
        try {
            standardChartTheme1.setItemLabelPaint(paint82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(categoryToolTipGenerator43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(categoryToolTipGenerator51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNull(categoryToolTipGenerator66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(shapeArray76);
        org.junit.Assert.assertNotNull(rectangleAnchor78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(shape80);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        int int14 = ringPlot4.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            java.lang.Comparable comparable2 = defaultXYDataset0.getSeriesKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        java.awt.Font font29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendItem28.setLabelFont(font29);
        legendItem28.setShapeVisible(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font29);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
//        boolean boolean3 = ringPlot2.isCircular();
//        ringPlot2.setShadowYOffset(12.0d);
//        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
//        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
//        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
//        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
//        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
//        standardChartTheme7.setShadowPaint(paint13);
//        ringPlot2.setBackgroundPaint(paint13);
//        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
//        xYBarRenderer0.setShadowYOffset((double) (-1.0f));
//        double double21 = xYBarRenderer0.getShadowYOffset();
//        boolean boolean22 = xYBarRenderer0.getShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertNotNull(font11);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertNotNull(textBlock14);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        intervalXYDelegate5.setAutoWidth(false);
        double double8 = intervalXYDelegate5.getIntervalPositionFactor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean6 = barRenderer0.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double double8 = barRenderer7.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer7.getBaseNegativeItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        barRenderer0.setShadowYOffset(2.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        boolean boolean2 = rangeType0.equals((java.lang.Object) false);
        java.lang.String str3 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RangeType.POSITIVE" + "'", str3.equals("RangeType.POSITIVE"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        java.lang.Object obj9 = numberAxis3D5.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj13 = intervalMarker12.clone();
        double double14 = intervalMarker12.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker16.setLabelAnchor(rectangleAnchor17);
        intervalMarker12.setLabelAnchor(rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepAreaRenderer0.drawRangeMarker(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.plot.Marker) intervalMarker12, rectangle2D20);
        double double22 = xYPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        boolean boolean10 = symbolAxis7.isNegativeArrowVisible();
        java.awt.Paint paint11 = null;
        try {
            symbolAxis7.setTickMarkPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape13 = null;
        barRenderer5.setLegendShape(100, shape13);
        boolean boolean15 = barRenderer5.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape16 = barRenderer5.getBaseLegendShape();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, (double) (short) 0, (double) ' ');
        numberAxis3D4.setDownArrow(shape16);
        boolean boolean21 = numberAxis3D4.isTickMarksVisible();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10, 0.0f);
        numberAxis3D4.setLeftArrow(shape24);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer27.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean30 = xYStepAreaRenderer27.getBaseItemLabelsVisible();
        java.awt.Stroke stroke32 = xYStepAreaRenderer27.lookupSeriesStroke((int) (short) 0);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraintType.RANGE", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "Pie Plot", "TextAnchor.TOP_RIGHT", shape26, stroke32, (java.awt.Paint) color33);
        java.awt.Shape shape35 = legendItem34.getShape();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        timeSeriesCollection0.seriesChanged(seriesChangeEvent1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            timeSeriesCollection0.setSelected((-9999), (int) 'a', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-9999).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        ringPlot4.setShadowYOffset(12.0d);
        boolean boolean8 = ringPlot4.isCircular();
        ringPlot4.setLabelGap((double) (short) -1);
        timeSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        double double12 = barRenderer5.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint15 = barRenderer13.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = barRenderer13.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape21 = null;
        barRenderer13.setLegendShape(100, shape21);
        boolean boolean23 = barRenderer13.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape24 = barRenderer13.getBaseLegendShape();
        barRenderer5.setBaseShape(shape24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint28 = barRenderer26.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape24, paint28);
        legendItem29.setDescription("");
        legendItem29.setShapeVisible(true);
        java.awt.Stroke stroke34 = legendItem29.getOutlineStroke();
        boolean boolean35 = dateTickUnitType0.equals((java.lang.Object) legendItem29);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 3600000L, (float) ' ');
        legendItem29.setLine(shape38);
        java.awt.Paint paint40 = legendItem29.getOutlinePaint();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer7.getToolTipGenerator((int) (short) 10, 0, false);
        double double14 = barRenderer7.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = barRenderer15.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape23 = null;
        barRenderer15.setLegendShape(100, shape23);
        boolean boolean25 = barRenderer15.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape26 = barRenderer15.getBaseLegendShape();
        barRenderer7.setBaseShape(shape26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint30 = barRenderer28.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape26, paint30);
        legendItem31.setDescription("");
        legendItem31.setShapeVisible(true);
        java.awt.Stroke stroke36 = legendItem31.getOutlineStroke();
        boolean boolean37 = dateTickUnitType2.equals((java.lang.Object) legendItem31);
        java.text.DateFormat dateFormat39 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit40 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 100, dateTickUnitType2, (int) (short) 0, dateFormat39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setSeriesShape((int) (short) 10, shape9, true);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) ' ', stroke13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color17 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean18 = textAnchor15.equals((java.lang.Object) color17);
        barRenderer1.setBaseItemLabelPaint((java.awt.Paint) color17);
        float[] floatArray26 = new float[] { 0.0f, 100L, 1, 100, 1561964399999L, (short) -1 };
        float[] floatArray27 = color17.getColorComponents(floatArray26);
        float[] floatArray28 = color0.getRGBColorComponents(floatArray26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        boolean boolean12 = categoryPlot0.isDomainCrosshairVisible();
        java.awt.Paint paint13 = categoryPlot0.getDomainCrosshairPaint();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        try {
            int int17 = categoryPlot0.getRangeAxisIndex(valueAxis16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Pie Plot");
        java.lang.Object obj2 = labelBlock1.clone();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape13 = null;
        barRenderer5.setLegendShape(100, shape13);
        boolean boolean15 = barRenderer5.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape16 = barRenderer5.getBaseLegendShape();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, (double) (short) 0, (double) ' ');
        numberAxis3D4.setDownArrow(shape16);
        boolean boolean21 = numberAxis3D4.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        polarPlot23.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        boolean boolean26 = polarPlot23.isAngleGridlinesVisible();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot23.setAngleGridlinePaint((java.awt.Paint) color27);
        labelBlock1.setPaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.lang.String str2 = ringPlot0.getPlotType();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color9 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer0.setLegendTextPaint(0, (java.awt.Paint) color9);
        boolean boolean12 = barRenderer0.isSeriesVisible(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        boolean boolean14 = barRenderer0.getBaseItemLabelsVisible();
        java.awt.Shape shape16 = null;
        barRenderer0.setLegendShape(7, shape16);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getUpperBound();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker16, rectangle2D17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = barRenderer20.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape28 = null;
        barRenderer20.setLegendShape(100, shape28);
        boolean boolean30 = barRenderer20.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape31 = barRenderer20.getBaseLegendShape();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape31, (double) (short) 0, (double) ' ');
        numberAxis3D19.setDownArrow(shape31);
        numberAxis3D19.setFixedAutoRange((double) 10);
        org.jfree.data.Range range38 = numberAxis3D19.getRange();
        numberAxis3D14.setRangeWithMargins(range38, false, true);
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange(range38);
        double double44 = dateRange42.constrain(0.05d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.panRangeAxes((double) 900000L, plotRenderingInfo3, point2D4);
        xYPlot0.setDomainCrosshairValue((double) 0L, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = categoryPlot9.getDomainGridlineStroke();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("hi!", font14);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font14, paint16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint16, stroke18);
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = categoryPlot9.isDomainCrosshairVisible();
        categoryPlot9.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot9.getDomainAxisLocation((int) (short) -1);
        xYPlot0.setDomainAxisLocation(axisLocation25, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        xYPlot0.zoomRangeAxes((double) 9, plotRenderingInfo29, point2D30, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setLabelToolTip("");
        symbolAxis7.setUpperBound((double) 100L);
        symbolAxis7.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType16 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint23 = barRenderer21.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = barRenderer21.getToolTipGenerator((int) (short) 10, 0, false);
        double double28 = barRenderer21.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint31 = barRenderer29.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = barRenderer29.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape37 = null;
        barRenderer29.setLegendShape(100, shape37);
        boolean boolean39 = barRenderer29.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape40 = barRenderer29.getBaseLegendShape();
        barRenderer21.setBaseShape(shape40);
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint44 = barRenderer42.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape40, paint44);
        legendItem45.setDescription("");
        legendItem45.setShapeVisible(true);
        java.awt.Stroke stroke50 = legendItem45.getOutlineStroke();
        boolean boolean51 = dateTickUnitType16.equals((java.lang.Object) legendItem45);
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 3600000L, (float) ' ');
        legendItem45.setLine(shape54);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity58 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) symbolAxis7, shape54, "13-June-2019", "");
        org.jfree.data.time.DateRange dateRange59 = new org.jfree.data.time.DateRange();
        symbolAxis7.setRangeWithMargins((org.jfree.data.Range) dateRange59, true, true);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(dateTickUnitType16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape54);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        timeSeriesDataItem3.setValue((java.lang.Number) 0L);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double double7 = barRenderer6.getMinimumBarLength();
        barRenderer6.setShadowXOffset(0.0d);
        barRenderer6.setShadowXOffset((double) '#');
        barRenderer6.setAutoPopulateSeriesPaint(false);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) barRenderer6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj3 = intervalMarker2.clone();
        intervalMarker2.setAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke7 = categoryPlot6.getDomainGridlineStroke();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint13, stroke15);
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = categoryPlot6.getRangeZeroBaselinePaint();
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer23.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape31 = null;
        barRenderer23.setLegendShape(100, shape31);
        boolean boolean33 = barRenderer23.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape34 = barRenderer23.getBaseLegendShape();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        double double38 = numberAxis3D37.getUpperBound();
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        barRenderer23.drawRangeMarker(graphics2D35, categoryPlot36, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, marker39, rectangle2D40);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint45 = barRenderer43.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = barRenderer43.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape51 = null;
        barRenderer43.setLegendShape(100, shape51);
        boolean boolean53 = barRenderer43.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape54 = barRenderer43.getBaseLegendShape();
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape54, (double) (short) 0, (double) ' ');
        numberAxis3D42.setDownArrow(shape54);
        numberAxis3D42.setFixedAutoRange((double) 10);
        org.jfree.data.Range range61 = numberAxis3D42.getRange();
        numberAxis3D37.setRangeWithMargins(range61, false, true);
        numberAxis3D37.resizeRange((double) 'a', (double) 100L);
        categoryPlot6.setRangeAxis(9, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(categoryToolTipGenerator49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(range61);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        waferMapPlot1.setRenderer(waferMapRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        java.util.List list16 = blockContainer15.getBlocks();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
        double double19 = numberTickUnit18.getSize();
        boolean boolean20 = blockContainer15.equals((java.lang.Object) numberTickUnit18);
        java.lang.Object obj21 = blockContainer15.clone();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = xYStepAreaRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot0.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer5.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean8 = xYStepAreaRenderer5.getBaseItemLabelsVisible();
        boolean boolean9 = xYStepAreaRenderer5.getPlotArea();
        xYPlot4.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer5);
        int int11 = xYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomRangeAxes(0.14d, (double) (byte) -1, plotRenderingInfo14, point2D15);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        double double21 = polarPlot20.getMaxRadius();
        java.awt.Paint paint22 = polarPlot20.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.05d + "'", double21 == 1.05d);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        java.awt.Paint paint14 = jFreeChart11.getBackgroundPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            java.awt.image.BufferedImage bufferedImage19 = jFreeChart11.createBufferedImage((int) (byte) -1, 3, 7, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        java.lang.String str17 = symbolAxis8.valueToString((double) (byte) -1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = symbolAxis8.getMarkerBand();
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNull(markerAxisBand18);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        java.lang.String str3 = axisSpace0.toString();
        axisSpace0.setBottom((-1.0d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        jFreeChart11.removeLegend();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj17 = textTitle16.clone();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        boolean boolean19 = xYPlot18.isDomainZoomable();
        int int20 = xYPlot18.getDatasetCount();
        boolean boolean21 = textTitle16.equals((java.lang.Object) int20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D22.getLabelInsets();
        double double24 = rectangleInsets23.getRight();
        double double26 = rectangleInsets23.calculateBottomInset(0.0d);
        textTitle16.setMargin(rectangleInsets23);
        textTitle16.setURLText("java.awt.Color[r=178,g=44,b=178]");
        jFreeChart11.removeSubtitle((org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.plot.Plot plot31 = jFreeChart11.getPlot();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(plot31);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}");
        periodAxis1.setMinorTickMarkOutsideLength(100.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.lang.Object obj2 = standardChartTheme1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = standardChartTheme1.getAxisOffset();
        java.awt.Paint paint4 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint5 = standardChartTheme1.getItemLabelPaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        multiplePiePlot0.setBackgroundImageAlignment((int) (short) 10);
        multiplePiePlot0.setLimit((double) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font28 = barRenderer27.getBaseItemLabelFont();
        boolean boolean29 = multiplePiePlot0.equals((java.lang.Object) font28);
        java.awt.Shape shape30 = multiplePiePlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Class class4 = periodAxis3.getMajorTickTimePeriodClass();
        java.lang.Class class5 = periodAxis3.getMinorTickTimePeriodClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("10", class5);
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Class class10 = periodAxis9.getMajorTickTimePeriodClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", class10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Layer.BACKGROUND", class5, class10);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor1.sort();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint13 = standardChartTheme12.getAxisLabelPaint();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme12.setSmallFont(font14);
        standardChartTheme1.setRegularFont(font14);
        standardChartTheme1.setShadowVisible(true);
        java.awt.Paint paint19 = standardChartTheme1.getTickLabelPaint();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint24 = barRenderer22.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = barRenderer22.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape30 = null;
        barRenderer22.setLegendShape(100, shape30);
        boolean boolean32 = barRenderer22.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape33 = barRenderer22.getBaseLegendShape();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape33, (double) (short) 0, (double) ' ');
        numberAxis3D21.setDownArrow(shape33);
        boolean boolean38 = numberAxis3D21.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer39);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        polarPlot40.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis41);
        boolean boolean43 = polarPlot40.isAngleGridlinesVisible();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot40.setAngleGridlinePaint((java.awt.Paint) color44);
        java.awt.Font font46 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        polarPlot40.setAngleLabelFont(font46);
        standardChartTheme1.setRegularFont(font46);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        java.awt.Paint paint16 = symbolAxis8.getLabelPaint();
        symbolAxis8.centerRange((double) 13);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.lang.Boolean boolean12 = barRenderer0.getSeriesCreateEntities((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getSeriesToolTipGenerator(7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = barRenderer20.getToolTipGenerator((int) (short) 10, 0, false);
        double double27 = barRenderer20.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint30 = barRenderer28.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = barRenderer28.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape36 = null;
        barRenderer28.setLegendShape(100, shape36);
        boolean boolean38 = barRenderer28.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape39 = barRenderer28.getBaseLegendShape();
        barRenderer20.setBaseShape(shape39);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint43 = barRenderer41.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape39, paint43);
        try {
            barRenderer0.setSeriesShape((-1), shape39, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        ringPlot0.setInsets(rectangleInsets3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint6 = ringPlot0.getBackgroundPaint();
        ringPlot0.clearSectionOutlinePaints(true);
        double double9 = ringPlot0.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        multiplePiePlot0.setBackgroundImageAlignment((int) (short) 10);
        multiplePiePlot0.setLimit((double) (byte) 1);
        java.awt.Shape shape27 = multiplePiePlot0.getLegendItemShape();
        multiplePiePlot0.setLimit((double) 9999);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Pie Plot");
        java.awt.Paint paint2 = labelBlock1.getPaint();
        labelBlock1.setToolTipText("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj1 = standardXYToolTipGenerator0.clone();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot3.isOutlineVisible();
        timeSeriesCollection2.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        double double10 = timeSeriesCollection2.getDomainUpperBound(true);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            java.lang.String str14 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (int) (byte) 100, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10, layer11);
        java.awt.Stroke stroke13 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        boolean boolean1 = logFormat0.isParseIntegerOnly();
        logFormat0.setMaximumIntegerDigits((int) '#');
        boolean boolean4 = logFormat0.isParseIntegerOnly();
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        axisSpace5.ensureAtLeast(axisSpace6);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        double double10 = categoryAxis3D9.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis3D16.getLabelInsets();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D16.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        boolean boolean21 = ringPlot20.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D22.getLabelInsets();
        ringPlot20.setInsets(rectangleInsets23);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot20.setOutlineStroke(stroke25);
        boolean boolean27 = numberAxis3D16.hasListener((java.util.EventListener) ringPlot20);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot20);
        java.awt.Paint paint30 = ringPlot20.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot20.setLabelPadding(rectangleInsets31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType35 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D36.getLabelInsets();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D36.setTickMarkPaint((java.awt.Paint) color38);
        org.jfree.chart.plot.RingPlot ringPlot40 = new org.jfree.chart.plot.RingPlot();
        boolean boolean41 = ringPlot40.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D42.getLabelInsets();
        ringPlot40.setInsets(rectangleInsets43);
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot40.setOutlineStroke(stroke45);
        boolean boolean47 = numberAxis3D36.hasListener((java.util.EventListener) ringPlot40);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot40);
        jFreeChart48.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType35, jFreeChart48);
        textTitle34.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart48);
        textTitle34.setID("");
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle34.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker57.setLabelAnchor(rectangleAnchor58);
        java.awt.Paint paint60 = valueMarker57.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = valueMarker57.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets31.createAdjustedRectangle(rectangle2D55, lengthAdjustmentType61, lengthAdjustmentType62);
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        boolean boolean65 = xYPlot64.isDomainZoomable();
        boolean boolean66 = xYPlot64.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = xYPlot64.getDomainAxisEdge();
        double double68 = categoryAxis3D9.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D55, rectangleEdge67);
        axisSpace6.ensureAtLeast(3.0d, rectangleEdge67);
        java.lang.String str70 = logFormat0.format((java.lang.Object) 3.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(dateTickUnitType35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(lengthAdjustmentType61);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10^0.48" + "'", str70.equals("10^0.48"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        double double8 = timeSeriesCollection0.getDomainUpperBound(true);
        org.jfree.data.general.DatasetGroup datasetGroup9 = timeSeriesCollection0.getGroup();
        timeSeriesCollection0.clearSelection();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme1.setSmallFont(font3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        boolean boolean7 = pieLabelLinkStyle5.equals((java.lang.Object) itemLabelAnchor6);
        standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint9 = standardChartTheme1.getBaselinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D4.getLabelInsets();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D4.setTickMarkPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot8.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D10.getLabelInsets();
        ringPlot8.setInsets(rectangleInsets11);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot8.setOutlineStroke(stroke13);
        boolean boolean15 = numberAxis3D4.hasListener((java.util.EventListener) ringPlot8);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType3, jFreeChart16);
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        boolean boolean21 = rotation0.equals((java.lang.Object) jFreeChart16);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("Pie Plot");
        double double25 = textTitle24.getHeight();
        int int26 = textTitle24.getMaximumLinesToDisplay();
        try {
            jFreeChart16.addSubtitle(2, (org.jfree.chart.title.Title) textTitle24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj3 = intervalMarker2.clone();
        intervalMarker2.setAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke7 = categoryPlot6.getDomainGridlineStroke();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint13, stroke15);
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = categoryPlot6.getRangeZeroBaselinePaint();
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot6);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis3D23.getLabelInsets();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D23.setTickMarkPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        boolean boolean28 = ringPlot27.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D29.getLabelInsets();
        ringPlot27.setInsets(rectangleInsets30);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot27.setOutlineStroke(stroke32);
        boolean boolean34 = numberAxis3D23.hasListener((java.util.EventListener) ringPlot27);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot27);
        java.awt.Paint paint37 = ringPlot27.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot27.setLabelPadding(rectangleInsets38);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType42 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = numberAxis3D43.getLabelInsets();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D43.setTickMarkPaint((java.awt.Paint) color45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        boolean boolean48 = ringPlot47.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = numberAxis3D49.getLabelInsets();
        ringPlot47.setInsets(rectangleInsets50);
        java.awt.Stroke stroke52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot47.setOutlineStroke(stroke52);
        boolean boolean54 = numberAxis3D43.hasListener((java.util.EventListener) ringPlot47);
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot47);
        jFreeChart55.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent58 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType42, jFreeChart55);
        textTitle41.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart55);
        textTitle41.setID("");
        java.awt.geom.Rectangle2D rectangle2D62 = textTitle41.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker64.setLabelAnchor(rectangleAnchor65);
        java.awt.Paint paint67 = valueMarker64.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType68 = valueMarker64.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets38.createAdjustedRectangle(rectangle2D62, lengthAdjustmentType68, lengthAdjustmentType69);
        try {
            categoryPlot6.drawBackground(graphics2D22, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(dateTickUnitType42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(lengthAdjustmentType68);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
//        boolean boolean3 = ringPlot2.isCircular();
//        ringPlot2.setShadowYOffset(12.0d);
//        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
//        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
//        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
//        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
//        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
//        standardChartTheme7.setShadowPaint(paint13);
//        ringPlot2.setBackgroundPaint(paint13);
//        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
//        xYBarRenderer0.setShadowYOffset((double) (-1.0f));
//        boolean boolean21 = xYBarRenderer0.getShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertNotNull(font11);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertNotNull(textBlock14);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            double double3 = defaultXYDataset0.getYValue((-1), 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean6 = rectangleEdge4.equals((java.lang.Object) 2);
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        axisSpace1.add((double) 10, rectangleEdge4);
        double double9 = axisSpace1.getLeft();
        axisSpace1.setLeft((double) 1560668399999L);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(500);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean6 = barRenderer0.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double double8 = barRenderer7.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer7.getBaseNegativeItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer0.getURLGenerator((int) '4', 100, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        double double18 = barRenderer17.getMinimumBarLength();
        barRenderer17.setShadowXOffset(0.0d);
        barRenderer17.setShadowXOffset((double) '#');
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint26 = barRenderer24.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean30 = barRenderer24.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        double double32 = barRenderer31.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer31.getBaseNegativeItemLabelPosition();
        barRenderer24.setPositiveItemLabelPositionFallback(itemLabelPosition33);
        barRenderer17.setSeriesNegativeItemLabelPosition(9, itemLabelPosition33, true);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition33, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.util.List list5 = null;
        try {
            xYPlot0.mapDatasetToRangeAxes((int) (short) 10, list5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo2 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray3 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo2 };
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = periodAxis1.getLast();
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        java.awt.Paint paint16 = symbolAxis8.getLabelPaint();
        boolean boolean17 = symbolAxis8.isTickLabelsVisible();
        symbolAxis8.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = symbolAxis8.getTickLabelInsets();
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font2 = barRenderer1.getBaseItemLabelFont();
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_RIGHT", font2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.lang.String str8 = textAnchor7.toString();
        try {
            textLine3.draw(graphics2D4, (float) 9, (float) 7, textAnchor7, 0.0f, (float) (short) 10, (double) 1560668399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str8.equals("TextAnchor.TOP_RIGHT"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesOutlineStroke(1);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray12);
        symbolAxis13.resizeRange((double) (short) 0);
        symbolAxis13.setLabelToolTip("");
        symbolAxis13.setUpperBound((double) 100L);
        symbolAxis13.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType22 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint29 = barRenderer27.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = barRenderer27.getToolTipGenerator((int) (short) 10, 0, false);
        double double34 = barRenderer27.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint37 = barRenderer35.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator41 = barRenderer35.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape43 = null;
        barRenderer35.setLegendShape(100, shape43);
        boolean boolean45 = barRenderer35.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape46 = barRenderer35.getBaseLegendShape();
        barRenderer27.setBaseShape(shape46);
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint50 = barRenderer48.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape46, paint50);
        legendItem51.setDescription("");
        legendItem51.setShapeVisible(true);
        java.awt.Stroke stroke56 = legendItem51.getOutlineStroke();
        boolean boolean57 = dateTickUnitType22.equals((java.lang.Object) legendItem51);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 3600000L, (float) ' ');
        legendItem51.setLine(shape60);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity64 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) symbolAxis13, shape60, "13-June-2019", "");
        xYStepAreaRenderer0.setBaseLegendShape(shape60);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(dateTickUnitType22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryToolTipGenerator41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(shape60);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesStroke((int) (short) 0);
        java.awt.Font font7 = xYStepAreaRenderer0.lookupLegendTextFont(0);
        boolean boolean8 = xYStepAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYStepAreaRenderer0.getLegendItems();
        java.util.Iterator iterator10 = legendItemCollection9.iterator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(iterator10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.awt.Paint paint10 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker12.setLabelAnchor(rectangleAnchor13);
        java.awt.Paint paint15 = valueMarker12.getPaint();
        standardChartTheme1.setTitlePaint(paint15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.2d, "", true);
        java.text.ParsePosition parsePosition5 = null;
        java.lang.Number number6 = logFormat3.parse("", parsePosition5);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat3.format(0L, stringBuffer8, fieldPosition9);
        java.text.ParsePosition parsePosition12 = null;
        java.lang.Number number13 = logFormat3.parse("Pie Plot", parsePosition12);
        int int14 = logFormat3.getMaximumFractionDigits();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        java.util.List list16 = blockContainer15.getBlocks();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj19 = textTitle18.clone();
        textTitle18.setWidth((double) 10);
        textTitle18.setVisible(false);
        blockContainer15.add((org.jfree.chart.block.Block) textTitle18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textTitle18.getHorizontalAlignment();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        int int2 = periodAxis1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "", "");
        java.lang.String str5 = library4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font7);
        textBlock5.addLine(textLine8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        try {
            java.awt.Shape shape17 = textBlock5.calculateBounds(graphics2D10, (float) 9, (float) 86400000L, textBlockAnchor13, (float) 9, (float) 5, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        standardChartTheme7.setShadowPaint(paint13);
        ringPlot2.setBackgroundPaint(paint13);
        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
        xYBarRenderer0.setUseYInterval(false);
        xYBarRenderer0.setDrawBarOutline(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer7.setBaseFillPaint(paint8);
        int int10 = xYStepAreaRenderer7.getPassCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        boolean boolean12 = xYStepAreaRenderer7.equals((java.lang.Object) axisLocation11);
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        legendItem28.setDescription("");
        legendItem28.setShapeVisible(true);
        java.awt.Stroke stroke33 = legendItem28.getOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint36 = barRenderer34.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = barRenderer34.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape42 = null;
        barRenderer34.setLegendShape(100, shape42);
        boolean boolean44 = barRenderer34.getAutoPopulateSeriesStroke();
        boolean boolean45 = legendItem28.equals((java.lang.Object) barRenderer34);
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Class class49 = periodAxis48.getMajorTickTimePeriodClass();
        java.io.InputStream inputStream50 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", class49);
        java.util.Date date51 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date51, timeZone52);
        boolean boolean54 = legendItem28.equals((java.lang.Object) timeZone52);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNull(inputStream50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("{0}", graphics2D1, (float) 2, (float) 500, 0.0d, 1.0f, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme1.setSmallFont(font3);
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint7 = standardChartTheme6.getAxisLabelPaint();
        java.awt.Paint paint8 = standardChartTheme6.getDomainGridlinePaint();
        standardChartTheme1.setRangeGridlinePaint(paint8);
        java.awt.Paint paint10 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = standardChartTheme1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isDomainZoomable();
        boolean boolean4 = xYPlot2.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot2.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer7.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean10 = xYStepAreaRenderer7.getBaseItemLabelsVisible();
        boolean boolean11 = xYStepAreaRenderer7.getPlotArea();
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer7);
        int int13 = xYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot2.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        boolean boolean11 = standardChartTheme1.isShadowVisible();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setCrosshairPaint(paint12);
        java.awt.Paint paint14 = standardChartTheme1.getPlotBackgroundPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.lang.String str2 = ringPlot0.getPlotType();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot0.getDataset();
        categoryPlot0.setCrosshairDatasetIndex(9, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot0.getOrientation();
        float float17 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        double double8 = timeSeriesCollection0.getDomainUpperBound(true);
        java.lang.Object obj9 = timeSeriesCollection0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        boolean boolean14 = barRenderer0.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke17 = categoryPlot16.getDomainGridlineStroke();
        java.awt.Font font21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("hi!", font21);
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font21, paint23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint23, stroke25);
        categoryPlot16.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot16.getDataset();
        categoryPlot16.setCrosshairDatasetIndex(9, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = categoryPlot16.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        double double34 = categoryAxis3D33.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis3D40.getLabelInsets();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D40.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        boolean boolean45 = ringPlot44.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis3D46.getLabelInsets();
        ringPlot44.setInsets(rectangleInsets47);
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot44.setOutlineStroke(stroke49);
        boolean boolean51 = numberAxis3D40.hasListener((java.util.EventListener) ringPlot44);
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot44);
        java.awt.Paint paint54 = ringPlot44.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot44.setLabelPadding(rectangleInsets55);
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType59 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = numberAxis3D60.getLabelInsets();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D60.setTickMarkPaint((java.awt.Paint) color62);
        org.jfree.chart.plot.RingPlot ringPlot64 = new org.jfree.chart.plot.RingPlot();
        boolean boolean65 = ringPlot64.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D66 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = numberAxis3D66.getLabelInsets();
        ringPlot64.setInsets(rectangleInsets67);
        java.awt.Stroke stroke69 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot64.setOutlineStroke(stroke69);
        boolean boolean71 = numberAxis3D60.hasListener((java.util.EventListener) ringPlot64);
        org.jfree.chart.JFreeChart jFreeChart72 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot64);
        jFreeChart72.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent75 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType59, jFreeChart72);
        textTitle58.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart72);
        textTitle58.setID("");
        java.awt.geom.Rectangle2D rectangle2D79 = textTitle58.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker81 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker81.setLabelAnchor(rectangleAnchor82);
        java.awt.Paint paint84 = valueMarker81.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = valueMarker81.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType86 = null;
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets55.createAdjustedRectangle(rectangle2D79, lengthAdjustmentType85, lengthAdjustmentType86);
        org.jfree.chart.plot.XYPlot xYPlot88 = new org.jfree.chart.plot.XYPlot();
        boolean boolean89 = xYPlot88.isDomainZoomable();
        boolean boolean90 = xYPlot88.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = xYPlot88.getDomainAxisEdge();
        double double92 = categoryAxis3D33.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D79, rectangleEdge91);
        try {
            barRenderer0.drawBackground(graphics2D15, categoryPlot16, rectangle2D79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(dateTickUnitType59);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        standardChartTheme7.setShadowPaint(paint13);
        ringPlot2.setBackgroundPaint(paint13);
        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
        xYBarRenderer0.setUseYInterval(false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator22 = null;
        xYBarRenderer0.setSeriesItemLabelGenerator(1900, xYItemLabelGenerator22, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.lang.Object obj2 = standardChartTheme1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = standardChartTheme1.getAxisOffset();
        java.awt.Paint paint4 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        standardChartTheme1.setGridBandPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D3.getLabelInsets();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D3.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D9.getLabelInsets();
        ringPlot7.setInsets(rectangleInsets10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot7.setOutlineStroke(stroke12);
        boolean boolean14 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot7);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot7);
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType2, jFreeChart15);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        textTitle1.setID("");
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = textTitle1.arrange(graphics2D22, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor2 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor2.sort();
        int int4 = pieLabelDistributor2.getItemCount();
        boolean boolean5 = tickUnits0.equals((java.lang.Object) pieLabelDistributor2);
        java.lang.Object obj6 = tickUnits0.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter11 = standardChartTheme1.getXYBarPainter();
        boolean boolean12 = standardChartTheme1.isShadowVisible();
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] {};
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint19 = barRenderer17.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = barRenderer17.getToolTipGenerator((int) (short) 10, 0, false);
        double double24 = barRenderer17.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = barRenderer25.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape33 = null;
        barRenderer25.setLegendShape(100, shape33);
        boolean boolean35 = barRenderer25.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape36 = barRenderer25.getBaseLegendShape();
        barRenderer17.setBaseShape(shape36);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint42 = barRenderer40.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator46 = barRenderer40.getToolTipGenerator((int) (short) 10, 0, false);
        double double47 = barRenderer40.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint50 = barRenderer48.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = barRenderer48.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape56 = null;
        barRenderer48.setLegendShape(100, shape56);
        boolean boolean58 = barRenderer48.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape59 = barRenderer48.getBaseLegendShape();
        barRenderer40.setBaseShape(shape59);
        xYStepAreaRenderer38.setSeriesShape((int) ' ', shape59);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint65 = barRenderer63.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = barRenderer63.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape71 = null;
        barRenderer63.setLegendShape(100, shape71);
        boolean boolean73 = barRenderer63.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape74 = barRenderer63.getBaseLegendShape();
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape74, (double) (short) 0, (double) ' ');
        numberAxis3D62.setDownArrow(shape74);
        java.awt.Shape[] shapeArray79 = new java.awt.Shape[] { shape36, shape59, shape74 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier80 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray14, strokeArray15, strokeArray16, shapeArray79);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean82 = defaultDrawingSupplier80.equals((java.lang.Object) rectangleAnchor81);
        java.awt.Shape shape83 = defaultDrawingSupplier80.getNextShape();
        standardChartTheme1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier80);
        java.awt.Shape shape85 = defaultDrawingSupplier80.getNextShape();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNotNull(xYBarPainter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(categoryToolTipGenerator46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(categoryToolTipGenerator54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(categoryToolTipGenerator69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(shapeArray79);
        org.junit.Assert.assertNotNull(rectangleAnchor81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(shape83);
        org.junit.Assert.assertNotNull(shape85);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        int int3 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer8.getToolTipGenerator((int) (short) 10, 0, false);
        double double15 = barRenderer8.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint18 = barRenderer16.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = barRenderer16.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape24 = null;
        barRenderer16.setLegendShape(100, shape24);
        boolean boolean26 = barRenderer16.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape27 = barRenderer16.getBaseLegendShape();
        barRenderer8.setBaseShape(shape27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint31 = barRenderer29.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape27, paint31);
        categoryAxis3D2.setTickLabelPaint(paint31);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint4 = standardChartTheme3.getAxisLabelPaint();
        java.awt.Paint paint5 = standardChartTheme3.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter6 = standardChartTheme3.getBarPainter();
        barRenderer0.setBarPainter(barPainter6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(barPainter6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        double double2 = textTitle1.getHeight();
        java.lang.String str3 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape13 = null;
        barRenderer5.setLegendShape(100, shape13);
        boolean boolean15 = barRenderer5.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape16 = barRenderer5.getBaseLegendShape();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, (double) (short) 0, (double) ' ');
        xYStepAreaRenderer0.setLegendShape(5, shape16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        xYPlot0.setRangePannable(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        java.awt.Paint paint4 = ringPlot1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10, layer11);
        int int13 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean8 = barRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean6 = barRenderer0.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double double8 = barRenderer7.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer7.getBaseNegativeItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot15.isOutlineVisible();
        timeSeriesCollection14.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean19 = ringPlot15.equals((java.lang.Object) color18);
        barRenderer0.setShadowPaint((java.awt.Paint) color18);
        barRenderer0.setShadowVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        double double6 = intervalXYDelegate5.getIntervalWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        ringPlot1.setShadowYOffset((double) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        ringPlot1.handleClick(0, (int) (byte) -1, plotRenderingInfo8);
        ringPlot1.setOuterSeparatorExtension(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        numberAxis3D0.setTickMarksVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer7.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape15 = null;
        barRenderer7.setLegendShape(100, shape15);
        boolean boolean17 = barRenderer7.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape18 = barRenderer7.getBaseLegendShape();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (short) 0, (double) ' ');
        numberAxis3D6.setDownArrow(shape18);
        numberAxis3D6.setFixedAutoRange((double) 10);
        org.jfree.data.Range range25 = numberAxis3D6.getRange();
        numberAxis3D0.setRange(range25);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart11.createBufferedImage(0, 3, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (3) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10, 0.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) 'a', (int) (byte) 100, (java.lang.Comparable) month6, "TextBlockAnchor.CENTER_RIGHT", "Layer.BACKGROUND");
        org.jfree.data.general.PieDataset pieDataset13 = pieSectionEntity12.getDataset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(pieDataset13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font7);
        textBlock5.addLine(textLine8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        try {
            textBlock5.draw(graphics2D10, (float) 2147483647, (float) 2, textBlockAnchor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        boolean boolean14 = barRenderer0.getBaseItemLabelsVisible();
        int int15 = barRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setShadowXOffset((double) '#');
        barRenderer0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers((int) (short) 100, layer2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = null;
        try {
            xYPlot0.setOrientation(plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isDomainZoomable();
        boolean boolean14 = xYPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot12.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot12.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        double double20 = categoryAxis3D19.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis3D26.getLabelInsets();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D26.setTickMarkPaint((java.awt.Paint) color28);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        boolean boolean31 = ringPlot30.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D32.getLabelInsets();
        ringPlot30.setInsets(rectangleInsets33);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot30.setOutlineStroke(stroke35);
        boolean boolean37 = numberAxis3D26.hasListener((java.util.EventListener) ringPlot30);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot30);
        java.awt.Paint paint40 = ringPlot30.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot30.setLabelPadding(rectangleInsets41);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType45 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis3D46.getLabelInsets();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D46.setTickMarkPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot();
        boolean boolean51 = ringPlot50.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = numberAxis3D52.getLabelInsets();
        ringPlot50.setInsets(rectangleInsets53);
        java.awt.Stroke stroke55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot50.setOutlineStroke(stroke55);
        boolean boolean57 = numberAxis3D46.hasListener((java.util.EventListener) ringPlot50);
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot50);
        jFreeChart58.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType45, jFreeChart58);
        textTitle44.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart58);
        textTitle44.setID("");
        java.awt.geom.Rectangle2D rectangle2D65 = textTitle44.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker67.setLabelAnchor(rectangleAnchor68);
        java.awt.Paint paint70 = valueMarker67.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType71 = valueMarker67.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets41.createAdjustedRectangle(rectangle2D65, lengthAdjustmentType71, lengthAdjustmentType72);
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot();
        boolean boolean75 = xYPlot74.isDomainZoomable();
        boolean boolean76 = xYPlot74.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = xYPlot74.getDomainAxisEdge();
        double double78 = categoryAxis3D19.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D65, rectangleEdge77);
        org.jfree.chart.RenderingSource renderingSource79 = null;
        xYPlot12.select((double) 9, (double) 'a', rectangle2D65, renderingSource79);
        try {
            legendTitle10.draw(graphics2D11, rectangle2D65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(dateTickUnitType45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(lengthAdjustmentType71);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme1.setSmallFont(font3);
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint7 = standardChartTheme6.getAxisLabelPaint();
        java.awt.Paint paint8 = standardChartTheme6.getDomainGridlinePaint();
        standardChartTheme1.setRangeGridlinePaint(paint8);
        java.awt.Paint paint10 = standardChartTheme1.getRangeGridlinePaint();
        java.awt.Paint paint11 = standardChartTheme1.getGridBandPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        multiplePiePlot0.setBackgroundImageAlignment((int) (short) 10);
        multiplePiePlot0.setLimit((double) (byte) 1);
        java.awt.Shape shape27 = multiplePiePlot0.getLegendItemShape();
        org.jfree.chart.util.TableOrder tableOrder28 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(tableOrder28);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        barRenderer0.setShadowYOffset((double) 100);
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color8 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean9 = textAnchor6.equals((java.lang.Object) color8);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D3, 1.0f, (float) (-2208960000000L), textAnchor6, (double) 900000L, textAnchor11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor11, (double) 6);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        xYLineAndShapeRenderer0.setBaseLinesVisible(true);
        java.lang.Boolean boolean5 = xYLineAndShapeRenderer0.getSeriesVisibleInLegend(128);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        java.awt.Paint paint4 = valueMarker1.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke7 = categoryPlot6.getDomainGridlineStroke();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint13, stroke15);
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color18);
        categoryPlot6.setRangePannable(false);
        java.awt.Stroke stroke22 = categoryPlot6.getRangeMinorGridlineStroke();
        valueMarker1.setOutlineStroke(stroke22);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        standardChartTheme7.setShadowPaint(paint13);
        ringPlot2.setBackgroundPaint(paint13);
        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
        xYBarRenderer0.setUseYInterval(false);
        xYBarRenderer0.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font2 = barRenderer1.getBaseItemLabelFont();
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_RIGHT", font2);
        org.jfree.chart.text.TextFragment textFragment4 = null;
        textLine3.removeFragment(textFragment4);
        org.junit.Assert.assertNotNull(font2);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//        java.lang.Class class2 = periodAxis1.getMajorTickTimePeriodClass();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D4.getLabelInsets();
//        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        numberAxis3D4.setTickMarkPaint((java.awt.Paint) color6);
//        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
//        boolean boolean9 = ringPlot8.isCircular();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D10.getLabelInsets();
//        ringPlot8.setInsets(rectangleInsets11);
//        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
//        ringPlot8.setOutlineStroke(stroke13);
//        boolean boolean15 = numberAxis3D4.hasListener((java.util.EventListener) ringPlot8);
//        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot8);
//        java.awt.Paint paint18 = ringPlot8.getSectionPaint((java.lang.Comparable) 2.0f);
//        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        ringPlot8.setLabelPadding(rectangleInsets19);
//        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("Pie Plot");
//        org.jfree.chart.axis.DateTickUnitType dateTickUnitType23 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis3D24.getLabelInsets();
//        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        numberAxis3D24.setTickMarkPaint((java.awt.Paint) color26);
//        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
//        boolean boolean29 = ringPlot28.isCircular();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis3D30.getLabelInsets();
//        ringPlot28.setInsets(rectangleInsets31);
//        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
//        ringPlot28.setOutlineStroke(stroke33);
//        boolean boolean35 = numberAxis3D24.hasListener((java.util.EventListener) ringPlot28);
//        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot28);
//        jFreeChart36.setNotify(false);
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType23, jFreeChart36);
//        textTitle22.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart36);
//        textTitle22.setID("");
//        java.awt.geom.Rectangle2D rectangle2D43 = textTitle22.getBounds();
//        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) '#');
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        valueMarker45.setLabelAnchor(rectangleAnchor46);
//        java.awt.Paint paint48 = valueMarker45.getPaint();
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = valueMarker45.getLabelOffsetType();
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
//        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets19.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType49, lengthAdjustmentType50);
//        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.BOTTOM;
//        boolean boolean54 = rectangleEdge52.equals((java.lang.Object) 2);
//        double double55 = periodAxis1.java2DToValue((double) (-1), rectangle2D51, rectangleEdge52);
//        periodAxis1.setMinorTickMarksVisible(false);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(rectangleInsets5);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(rectangleInsets11);
//        org.junit.Assert.assertNotNull(stroke13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(paint18);
//        org.junit.Assert.assertNotNull(rectangleInsets19);
//        org.junit.Assert.assertNotNull(dateTickUnitType23);
//        org.junit.Assert.assertNotNull(rectangleInsets25);
//        org.junit.Assert.assertNotNull(color26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(rectangleInsets31);
//        org.junit.Assert.assertNotNull(stroke33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(rectangle2D43);
//        org.junit.Assert.assertNotNull(rectangleAnchor46);
//        org.junit.Assert.assertNotNull(paint48);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType49);
//        org.junit.Assert.assertNotNull(rectangle2D51);
//        org.junit.Assert.assertNotNull(rectangleEdge52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.560463199999375E12d + "'", double55 == 1.560463199999375E12d);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.LEFT", graphics2D1, 0.5f, (float) 10L, (double) 86400000L, 1.0f, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font6);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot8.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor11 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor11.sort();
        ringPlot8.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor11);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("{0}", font6, (org.jfree.chart.plot.Plot) ringPlot8, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot8.getLabelPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot8, (java.lang.Integer) (-1), plotRenderingInfo18);
        double double20 = ringPlot0.getStartAngle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 90.0d + "'", double20 == 90.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke18 = categoryPlot17.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        int int20 = categoryPlot17.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = categoryAxis3D19.getCategoryLabelPositions();
        java.util.List list22 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis34 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray33);
        symbolAxis34.resizeRange((double) (short) 0);
        symbolAxis34.setLabelToolTip("");
        symbolAxis34.setUpperBound((double) 100L);
        symbolAxis34.setVerticalTickLabels(true);
        java.awt.Stroke stroke43 = symbolAxis34.getAxisLineStroke();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType47 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = numberAxis3D48.getLabelInsets();
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D48.setTickMarkPaint((java.awt.Paint) color50);
        org.jfree.chart.plot.RingPlot ringPlot52 = new org.jfree.chart.plot.RingPlot();
        boolean boolean53 = ringPlot52.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis3D54.getLabelInsets();
        ringPlot52.setInsets(rectangleInsets55);
        java.awt.Stroke stroke57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot52.setOutlineStroke(stroke57);
        boolean boolean59 = numberAxis3D48.hasListener((java.util.EventListener) ringPlot52);
        org.jfree.chart.JFreeChart jFreeChart60 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot52);
        jFreeChart60.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent63 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType47, jFreeChart60);
        textTitle46.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart60);
        textTitle46.setID("");
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle46.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double69 = symbolAxis34.java2DToValue((-1.0d), rectangle2D67, rectangleEdge68);
        try {
            double double70 = categoryAxis3D19.getCategoryJava2DCoordinate(categoryAnchor23, 500, 2, rectangle2D26, rectangleEdge68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(dateTickUnitType47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.NEGATIVE_INFINITY + "'", double69 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, 5, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer7.getToolTipGenerator((int) (short) 10, 0, false);
        double double14 = barRenderer7.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = barRenderer15.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape23 = null;
        barRenderer15.setLegendShape(100, shape23);
        boolean boolean25 = barRenderer15.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape26 = barRenderer15.getBaseLegendShape();
        barRenderer7.setBaseShape(shape26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint30 = barRenderer28.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape26, paint30);
        legendItem31.setDescription("");
        legendItem31.setShapeVisible(true);
        boolean boolean36 = xYPlot0.equals((java.lang.Object) legendItem31);
        java.lang.String str37 = legendItem31.getToolTipText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot0.getDataset();
        categoryPlot0.setCrosshairDatasetIndex(9, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryDataset12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D3.getLabelInsets();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D3.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D9.getLabelInsets();
        ringPlot7.setInsets(rectangleInsets10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot7.setOutlineStroke(stroke12);
        boolean boolean14 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot7);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot7);
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType2, jFreeChart15);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        boolean boolean21 = ringPlot20.isCircular();
        ringPlot20.setSectionDepth((double) (short) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        ringPlot20.datasetChanged(datasetChangeEvent24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        ringPlot20.setShadowPaint((java.awt.Paint) color26);
        textTitle1.setBackgroundPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        boolean boolean19 = segmentedTimeline0.equals((java.lang.Object) boolean18);
        java.util.List list20 = segmentedTimeline0.getExceptionSegments();
        boolean boolean23 = segmentedTimeline0.containsDomainRange(0L, (long) 7);
        long long24 = segmentedTimeline0.getStartTime();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2208960000000L) + "'", long24 == (-2208960000000L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemShapeVisible((int) (short) -1, 100);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYLineAndShapeRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setLabelURL("hi!");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1L), (double) 10.0f, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraintType.RANGE" + "'", str1.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        multiplePiePlot0.setDataset(categoryDataset4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer18.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color27 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer18.setLegendTextPaint(0, (java.awt.Paint) color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape17, (java.awt.Paint) color27);
        symbolAxis7.setGridBandAlternatePaint((java.awt.Paint) color27);
        java.lang.String str31 = symbolAxis7.getLabelToolTip();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) symbolAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.Range range34 = combinedRangeXYPlot32.getDataRange(valueAxis33);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        double double13 = symbolAxis7.getLowerMargin();
        double double14 = symbolAxis7.getLabelAngle();
        symbolAxis7.setAxisLineVisible(true);
        org.jfree.data.RangeType rangeType17 = symbolAxis7.getRangeType();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType17);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean5 = ringPlot1.equals((java.lang.Object) color4);
        java.awt.Stroke stroke6 = ringPlot1.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = ringPlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(pieURLGenerator7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        polarPlot20.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        java.awt.Font font23 = polarPlot20.getAngleLabelFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        polarPlot20.zoomRangeAxes(3.0d, plotRenderingInfo25, point2D26);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font23);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
//        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
//        int int4 = color3.getBlue();
//        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
//        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
//        java.awt.Paint paint8 = barRenderer6.lookupSeriesOutlinePaint((int) 'a');
//        boolean boolean12 = barRenderer6.getItemCreateEntity((int) (byte) 100, (-1), false);
//        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
//        double double14 = barRenderer13.getMinimumBarLength();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer13.getBaseNegativeItemLabelPosition();
//        barRenderer6.setPositiveItemLabelPositionFallback(itemLabelPosition15);
//        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font20);
//        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
//        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font20, paint22);
//        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint22, stroke24);
//        barRenderer6.setBaseStroke(stroke24);
//        xYPlot0.setRangeCrosshairStroke(stroke24);
//        xYPlot0.clearAnnotations();
//        xYPlot0.setDomainPannable(true);
//        java.awt.geom.GeneralPath generalPath31 = null;
//        org.jfree.chart.axis.PeriodAxis periodAxis33 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//        java.lang.Class class34 = periodAxis33.getMajorTickTimePeriodClass();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D36.getLabelInsets();
//        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        numberAxis3D36.setTickMarkPaint((java.awt.Paint) color38);
//        org.jfree.chart.plot.RingPlot ringPlot40 = new org.jfree.chart.plot.RingPlot();
//        boolean boolean41 = ringPlot40.isCircular();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D42.getLabelInsets();
//        ringPlot40.setInsets(rectangleInsets43);
//        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
//        ringPlot40.setOutlineStroke(stroke45);
//        boolean boolean47 = numberAxis3D36.hasListener((java.util.EventListener) ringPlot40);
//        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot40);
//        java.awt.Paint paint50 = ringPlot40.getSectionPaint((java.lang.Comparable) 2.0f);
//        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        ringPlot40.setLabelPadding(rectangleInsets51);
//        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle("Pie Plot");
//        org.jfree.chart.axis.DateTickUnitType dateTickUnitType55 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis3D56.getLabelInsets();
//        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        numberAxis3D56.setTickMarkPaint((java.awt.Paint) color58);
//        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot();
//        boolean boolean61 = ringPlot60.isCircular();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.util.RectangleInsets rectangleInsets63 = numberAxis3D62.getLabelInsets();
//        ringPlot60.setInsets(rectangleInsets63);
//        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
//        ringPlot60.setOutlineStroke(stroke65);
//        boolean boolean67 = numberAxis3D56.hasListener((java.util.EventListener) ringPlot60);
//        org.jfree.chart.JFreeChart jFreeChart68 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot60);
//        jFreeChart68.setNotify(false);
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent71 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType55, jFreeChart68);
//        textTitle54.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart68);
//        textTitle54.setID("");
//        java.awt.geom.Rectangle2D rectangle2D75 = textTitle54.getBounds();
//        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker((double) '#');
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        valueMarker77.setLabelAnchor(rectangleAnchor78);
//        java.awt.Paint paint80 = valueMarker77.getPaint();
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType81 = valueMarker77.getLabelOffsetType();
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType82 = null;
//        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets51.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType81, lengthAdjustmentType82);
//        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.util.RectangleEdge.BOTTOM;
//        boolean boolean86 = rectangleEdge84.equals((java.lang.Object) 2);
//        double double87 = periodAxis33.java2DToValue((double) (-1), rectangle2D83, rectangleEdge84);
//        org.jfree.chart.RenderingSource renderingSource88 = null;
//        xYPlot0.select(generalPath31, rectangle2D83, renderingSource88);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertNotNull(itemLabelPosition15);
//        org.junit.Assert.assertNotNull(font20);
//        org.junit.Assert.assertNotNull(paint22);
//        org.junit.Assert.assertNotNull(textBlock23);
//        org.junit.Assert.assertNotNull(stroke24);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(rectangleInsets37);
//        org.junit.Assert.assertNotNull(color38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(rectangleInsets43);
//        org.junit.Assert.assertNotNull(stroke45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNull(paint50);
//        org.junit.Assert.assertNotNull(rectangleInsets51);
//        org.junit.Assert.assertNotNull(dateTickUnitType55);
//        org.junit.Assert.assertNotNull(rectangleInsets57);
//        org.junit.Assert.assertNotNull(color58);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(rectangleInsets63);
//        org.junit.Assert.assertNotNull(stroke65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(rectangle2D75);
//        org.junit.Assert.assertNotNull(rectangleAnchor78);
//        org.junit.Assert.assertNotNull(paint80);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType81);
//        org.junit.Assert.assertNotNull(rectangle2D83);
//        org.junit.Assert.assertNotNull(rectangleEdge84);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.560463199999375E12d + "'", double87 == 1.560463199999375E12d);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = null;
        timeSeriesCollection6.seriesChanged(seriesChangeEvent7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, true);
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, true);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = null;
        timeSeriesCollection14.seriesChanged(seriesChangeEvent15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14, true);
        org.jfree.data.general.DatasetGroup datasetGroup19 = timeSeriesCollection14.getGroup();
        timeSeriesCollection6.setGroup(datasetGroup19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate21 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(datasetGroup19);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        java.lang.Object obj14 = standardPieSectionLabelGenerator12.clone();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.block.CenterArrangement centerArrangement16 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        boolean boolean22 = ringPlot21.isCircular();
        java.lang.String str23 = ringPlot21.getPlotType();
        boolean boolean24 = ringPlot21.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getLastMillisecond();
        long long27 = month25.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month25.next();
        java.awt.Stroke stroke29 = ringPlot21.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod28);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer30 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement16, (org.jfree.data.general.Dataset) timeSeriesCollection17, (java.lang.Comparable) regularTimePeriod28);
        try {
            java.text.AttributedString attributedString31 = standardPieSectionLabelGenerator12.generateAttributedSectionLabel(pieDataset15, (java.lang.Comparable) regularTimePeriod28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pie Plot" + "'", str23.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(stroke29);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean4 = xYStepAreaRenderer1.getBaseItemLabelsVisible();
        java.awt.Stroke stroke6 = xYStepAreaRenderer1.lookupSeriesStroke((int) (short) 0);
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font10);
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font10, paint12);
        xYStepAreaRenderer1.setSeriesItemLabelPaint(2, paint12, false);
        java.awt.Stroke stroke17 = xYStepAreaRenderer1.lookupSeriesOutlineStroke((int) (byte) 1);
        boolean boolean18 = textAnchor0.equals((java.lang.Object) xYStepAreaRenderer1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setShadowYOffset(12.0d);
        boolean boolean4 = ringPlot0.isCircular();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Image image6 = null;
        ringPlot0.setBackgroundImage(image6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.data.general.DatasetGroup datasetGroup15 = timeSeriesCollection1.getGroup();
        try {
            timeSeriesCollection1.setSelected(0, (int) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(datasetGroup15);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        java.util.List list16 = blockContainer15.getBlocks();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
        double double19 = numberTickUnit18.getSize();
        boolean boolean20 = blockContainer15.equals((java.lang.Object) numberTickUnit18);
        blockContainer15.setID("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker7.getLabelOffset();
        valueMarker7.setAlpha((float) (short) 0);
        boolean boolean11 = intervalXYDelegate5.equals((java.lang.Object) (short) 0);
        double double12 = intervalXYDelegate5.getIntervalPositionFactor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5d + "'", double12 == 0.5d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot0.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace4 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        double double8 = categoryAxis3D7.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D14.getLabelInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D14.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        boolean boolean19 = ringPlot18.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis3D20.getLabelInsets();
        ringPlot18.setInsets(rectangleInsets21);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot18.setOutlineStroke(stroke23);
        boolean boolean25 = numberAxis3D14.hasListener((java.util.EventListener) ringPlot18);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot18);
        java.awt.Paint paint28 = ringPlot18.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot18.setLabelPadding(rectangleInsets29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType33 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis3D34.getLabelInsets();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D34.setTickMarkPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        boolean boolean39 = ringPlot38.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis3D40.getLabelInsets();
        ringPlot38.setInsets(rectangleInsets41);
        java.awt.Stroke stroke43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot38.setOutlineStroke(stroke43);
        boolean boolean45 = numberAxis3D34.hasListener((java.util.EventListener) ringPlot38);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot38);
        jFreeChart46.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType33, jFreeChart46);
        textTitle32.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart46);
        textTitle32.setID("");
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle32.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker55.setLabelAnchor(rectangleAnchor56);
        java.awt.Paint paint58 = valueMarker55.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = valueMarker55.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets29.createAdjustedRectangle(rectangle2D53, lengthAdjustmentType59, lengthAdjustmentType60);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        boolean boolean63 = xYPlot62.isDomainZoomable();
        boolean boolean64 = xYPlot62.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot62.getDomainAxisEdge();
        double double66 = categoryAxis3D7.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D53, rectangleEdge65);
        org.jfree.chart.RenderingSource renderingSource67 = null;
        xYPlot0.select((double) 9, (double) 'a', rectangle2D53, renderingSource67);
        boolean boolean69 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(dateTickUnitType33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(lengthAdjustmentType59);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        boolean boolean6 = ringPlot2.isCircular();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot2);
        categoryPlot0.notifyListeners(plotChangeEvent7);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isDomainZoomable();
        boolean boolean8 = xYPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot6.getDomainAxisEdge();
        boolean boolean10 = timeSeriesCollection0.hasListener((java.util.EventListener) xYPlot6);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list13 = segmentedTimeline12.getExceptionSegments();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, list13, false);
        try {
            double double18 = timeSeriesCollection0.getEndYValue(6, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor2 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor2.sort();
        int int4 = pieLabelDistributor2.getItemCount();
        boolean boolean5 = tickUnits0.equals((java.lang.Object) pieLabelDistributor2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit(Double.NaN);
        try {
            org.jfree.chart.axis.TickUnit tickUnit8 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        float float13 = symbolAxis7.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint4 = standardChartTheme3.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme3.setSmallFont(font5);
        standardChartTheme1.setRegularFont(font5);
        java.awt.Paint paint8 = standardChartTheme1.getLegendItemPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj5 = multiplePiePlot4.clone();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D9.setTickMarkPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot13.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis3D15.getLabelInsets();
        ringPlot13.setInsets(rectangleInsets16);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot13.setOutlineStroke(stroke18);
        boolean boolean20 = numberAxis3D9.hasListener((java.util.EventListener) ringPlot13);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot13);
        jFreeChart21.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType8, jFreeChart21);
        textTitle7.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart21);
        multiplePiePlot4.setPieChart(jFreeChart21);
        java.util.List list27 = jFreeChart21.getSubtitles();
        int int28 = month0.compareTo((java.lang.Object) list27);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke18 = categoryPlot17.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        int int20 = categoryPlot17.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = categoryAxis3D19.getCategoryLabelPositions();
        java.util.List list22 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D19);
        int int23 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Pie Plot");
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        jFreeChart11.removeLegend();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj17 = textTitle16.clone();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        boolean boolean19 = xYPlot18.isDomainZoomable();
        int int20 = xYPlot18.getDatasetCount();
        boolean boolean21 = textTitle16.equals((java.lang.Object) int20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D22.getLabelInsets();
        double double24 = rectangleInsets23.getRight();
        double double26 = rectangleInsets23.calculateBottomInset(0.0d);
        textTitle16.setMargin(rectangleInsets23);
        textTitle16.setURLText("java.awt.Color[r=178,g=44,b=178]");
        jFreeChart11.removeSubtitle((org.jfree.chart.title.Title) textTitle16);
        java.lang.String str31 = textTitle16.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Pie Plot" + "'", str31.equals("Pie Plot"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        int int2 = xYPlot0.getDatasetCount();
        xYPlot0.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isOutlineVisible();
        timeSeriesCollection6.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6, true);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isDomainZoomable();
        boolean boolean14 = xYPlot12.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot12.getDomainAxisEdge();
        boolean boolean16 = timeSeriesCollection6.hasListener((java.util.EventListener) xYPlot12);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeriesCollection6.getSeries((java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot0.zoomDomainAxes((double) 3600000L, plotRenderingInfo22, point2D23, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(timeSeries19);
        org.junit.Assert.assertNull(xYItemRenderer20);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            double double9 = timeSeriesCollection0.getEndYValue(3, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo3 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray4 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo3 };
        periodAxis2.setLabelInfo(periodAxisLabelInfoArray4);
        java.lang.Class class6 = periodAxis2.getAutoRangeTimePeriodClass();
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class6);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray4);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(uRL7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        axisSpace2.ensureAtLeast(axisSpace3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) 2);
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        axisSpace3.add((double) 10, rectangleEdge6);
        axisSpace3.setRight((double) 1561964399999L);
        xYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator18 = xYStepAreaRenderer16.getSeriesItemLabelGenerator((int) (byte) 1);
        xYPlot0.setRenderer(13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(xYItemLabelGenerator18);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 15, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        legendItemBlockContainer14.setURLText("RectangleAnchor.LEFT");
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        boolean boolean6 = xYPlot5.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getDomainGridlineStroke();
        xYPlot5.setRangeGridlineStroke(stroke8);
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray16);
        symbolAxis17.setAutoTickUnitSelection(true);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            xYStepAreaRenderer0.fillDomainGridBand(graphics2D4, xYPlot5, (org.jfree.chart.axis.ValueAxis) symbolAxis17, rectangle2D20, 1.05d, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape1 = xYAreaRenderer0.getLegendArea();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker2.setStartValue((double) 10.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        intervalMarker2.setLabelAnchor(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 60000L, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot0.getDataset();
        java.awt.Paint paint18 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double1 = logAxis0.getBase();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        standardChartTheme7.setShadowPaint(paint13);
        ringPlot2.setBackgroundPaint(paint13);
        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
        xYBarRenderer0.setUseYInterval(false);
        xYBarRenderer0.setMargin(0.0d);
        double double23 = xYBarRenderer0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        xYPlot0.setRangeCrosshairValue((double) 0.0f, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        try {
            boolean boolean14 = xYPlot0.removeAnnotation(xYAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isDomainZoomable();
        boolean boolean13 = xYPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot11.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer16.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean19 = xYStepAreaRenderer16.getBaseItemLabelsVisible();
        boolean boolean20 = xYStepAreaRenderer16.getPlotArea();
        xYPlot15.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer16);
        int int22 = xYPlot11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot11.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(9, axisLocation23);
        boolean boolean25 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer18.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color27 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer18.setLegendTextPaint(0, (java.awt.Paint) color27);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape17, (java.awt.Paint) color27);
        symbolAxis7.setGridBandAlternatePaint((java.awt.Paint) color27);
        java.lang.String str31 = symbolAxis7.getLabelToolTip();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) symbolAxis7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = combinedRangeXYPlot32.getRenderer((int) 'a');
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(xYItemRenderer34);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        xYPlot0.clearRangeMarkers(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot0.getRangeMarkers(layer12);
        xYPlot0.mapDatasetToDomainAxis(7, 6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Polar Plot", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        legendItem28.setDescription("");
        legendItem28.setShapeVisible(true);
        java.awt.Stroke stroke33 = legendItem28.getOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint36 = barRenderer34.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = barRenderer34.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape42 = null;
        barRenderer34.setLegendShape(100, shape42);
        boolean boolean44 = barRenderer34.getAutoPopulateSeriesStroke();
        boolean boolean45 = legendItem28.equals((java.lang.Object) barRenderer34);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer34.getSeriesURLGenerator((int) (byte) 10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryURLGenerator47);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis28 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray27);
        symbolAxis28.resizeRange((double) (short) 0);
        symbolAxis28.setAutoTickUnitSelection(false, true);
        double double34 = symbolAxis28.getLowerMargin();
        double double35 = symbolAxis28.getLabelAngle();
        polarPlot20.setAxis((org.jfree.chart.axis.ValueAxis) symbolAxis28);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        int int2 = xYPlot0.getDatasetCount();
        xYPlot0.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) 128, (double) 10L, plotRenderingInfo8, point2D9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        xYPlot0.datasetChanged(datasetChangeEvent11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        xYPlot0.datasetChanged(datasetChangeEvent11);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getRangeAxisForDataset((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 100 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.resizeRange2((double) (byte) 0, (double) 500);
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("hi!", font16);
        java.awt.Color color19 = java.awt.Color.BLACK;
        java.awt.Color color20 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color19);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("{0}", font16, (java.awt.Paint) color19);
        java.awt.Color color22 = java.awt.Color.BLACK;
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace24 = new org.jfree.chart.axis.AxisSpace();
        axisSpace23.ensureAtLeast(axisSpace24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean29 = rectangleEdge27.equals((java.lang.Object) 2);
        boolean boolean30 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge27);
        axisSpace24.add((double) 10, rectangleEdge27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        boolean boolean35 = xYPlot34.isDomainZoomable();
        boolean boolean36 = xYPlot34.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot34.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = null;
        boolean boolean43 = xYPlot34.render(graphics2D38, rectangle2D39, 500, plotRenderingInfo41, crosshairState42);
        xYPlot34.clearRangeMarkers(0);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker48.setLabelAnchor(rectangleAnchor49);
        org.jfree.chart.util.Layer layer51 = null;
        xYPlot34.addRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker48, layer51, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = xYPlot34.getAxisOffset();
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("", font16, (java.awt.Paint) color22, rectangleEdge27, horizontalAlignment32, verticalAlignment33, rectangleInsets54);
        symbolAxis7.setTickLabelInsets(rectangleInsets54);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangleInsets54);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        double double7 = barRenderer0.getItemMargin();
        java.awt.Font font8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setBaseItemLabelFont(font8);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint2 = piePlot3D1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        try {
            legendTitle10.setLegendItemGraphicEdge(rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor1.sort();
        int int3 = pieLabelDistributor1.getItemCount();
        java.lang.String str4 = pieLabelDistributor1.toString();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord5 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setLabelToolTip("");
        java.awt.Font font12 = symbolAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        boolean boolean16 = xYPlot15.isDomainZoomable();
        boolean boolean17 = xYPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot15.getRenderer();
        java.awt.Stroke stroke19 = xYPlot15.getDomainCrosshairStroke();
        java.awt.geom.GeneralPath generalPath20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D21.getLabelInsets();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        boolean boolean26 = ringPlot25.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D27.getLabelInsets();
        ringPlot25.setInsets(rectangleInsets28);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot25.setOutlineStroke(stroke30);
        boolean boolean32 = numberAxis3D21.hasListener((java.util.EventListener) ringPlot25);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot25);
        java.awt.Paint paint35 = ringPlot25.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot25.setLabelPadding(rectangleInsets36);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType40 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis3D41.getLabelInsets();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D41.setTickMarkPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        boolean boolean46 = ringPlot45.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = numberAxis3D47.getLabelInsets();
        ringPlot45.setInsets(rectangleInsets48);
        java.awt.Stroke stroke50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot45.setOutlineStroke(stroke50);
        boolean boolean52 = numberAxis3D41.hasListener((java.util.EventListener) ringPlot45);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot45);
        jFreeChart53.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType40, jFreeChart53);
        textTitle39.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart53);
        textTitle39.setID("");
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle39.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker62.setLabelAnchor(rectangleAnchor63);
        java.awt.Paint paint65 = valueMarker62.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = valueMarker62.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets36.createAdjustedRectangle(rectangle2D60, lengthAdjustmentType66, lengthAdjustmentType67);
        org.jfree.chart.RenderingSource renderingSource69 = null;
        xYPlot15.select(generalPath20, rectangle2D60, renderingSource69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        java.util.List list72 = symbolAxis7.refreshTicks(graphics2D13, axisState14, rectangle2D60, rectangleEdge71);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(dateTickUnitType40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(lengthAdjustmentType66);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNull(list72);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        polarPlot20.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        boolean boolean23 = polarPlot20.isAngleGridlinesVisible();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot20.setAngleGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = polarPlot20.getRenderer();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(polarItemRenderer26);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10, layer11);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Stroke stroke15 = valueMarker14.getStroke();
        xYPlot0.setRangeMinorGridlineStroke(stroke15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        java.lang.Object obj9 = numberAxis3D5.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj13 = intervalMarker12.clone();
        double double14 = intervalMarker12.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker16.setLabelAnchor(rectangleAnchor17);
        intervalMarker12.setLabelAnchor(rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepAreaRenderer0.drawRangeMarker(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.plot.Marker) intervalMarker12, rectangle2D20);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker25.setStartValue((double) 10.0f);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator28 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str29 = standardXYToolTipGenerator28.getFormatString();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator33 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", "Size2D[width=0.0, height=100.0]");
        java.lang.Object obj34 = null;
        boolean boolean35 = standardXYURLGenerator33.equals(obj34);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer36 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator28, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator33);
        boolean boolean37 = intervalMarker25.equals((java.lang.Object) standardXYURLGenerator33);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        boolean boolean39 = xYPlot38.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace40 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace41 = new org.jfree.chart.axis.AxisSpace();
        axisSpace40.ensureAtLeast(axisSpace41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean46 = rectangleEdge44.equals((java.lang.Object) 2);
        boolean boolean47 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge44);
        axisSpace41.add((double) 10, rectangleEdge44);
        axisSpace41.setRight((double) 1561964399999L);
        xYPlot38.setFixedRangeAxisSpace(axisSpace41, false);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker54.setLabelTextAnchor(textAnchor55);
        java.awt.Shape shape61 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint64 = barRenderer62.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator68 = barRenderer62.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color71 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer62.setLegendTextPaint(0, (java.awt.Paint) color71);
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape61, (java.awt.Paint) color71);
        legendItem73.setToolTipText("{0}");
        boolean boolean76 = valueMarker54.equals((java.lang.Object) "{0}");
        org.jfree.chart.util.Layer layer77 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean78 = xYPlot38.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker54, layer77);
        boolean boolean80 = xYPlot4.removeDomainMarker(128, (org.jfree.chart.plot.Marker) intervalMarker25, layer77, false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}: ({1}, {2})" + "'", str29.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNull(categoryToolTipGenerator68);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(layer77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        double double7 = intervalXYDelegate5.getDomainUpperBound(true);
        double double9 = intervalXYDelegate5.getDomainLowerBound(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        xYPlot0.setRangeCrosshairValue(104.0d, true);
        xYPlot0.setNoDataMessage("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0d));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        java.lang.Object obj5 = timeSeriesDataItem3.clone();
        boolean boolean6 = timeSeriesDataItem3.isSelected();
        java.lang.Number number7 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray23);
        symbolAxis24.resizeRange((double) (short) 0);
        symbolAxis24.setAutoTickUnitSelection(false, true);
        double double30 = symbolAxis24.getLowerMargin();
        boolean boolean31 = multiplePiePlot16.equals((java.lang.Object) symbolAxis24);
        java.lang.String str33 = symbolAxis24.valueToString((double) (byte) -1);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        categoryPlot0.configureDomainAxes();
        boolean boolean36 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        boolean boolean39 = xYPlot38.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace40 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace41 = new org.jfree.chart.axis.AxisSpace();
        axisSpace40.ensureAtLeast(axisSpace41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean46 = rectangleEdge44.equals((java.lang.Object) 2);
        boolean boolean47 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge44);
        axisSpace41.add((double) 10, rectangleEdge44);
        axisSpace41.setRight((double) 1561964399999L);
        xYPlot38.setFixedRangeAxisSpace(axisSpace41, false);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker54.setLabelTextAnchor(textAnchor55);
        java.awt.Shape shape61 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint64 = barRenderer62.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator68 = barRenderer62.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color71 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer62.setLegendTextPaint(0, (java.awt.Paint) color71);
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape61, (java.awt.Paint) color71);
        legendItem73.setToolTipText("{0}");
        boolean boolean76 = valueMarker54.equals((java.lang.Object) "{0}");
        org.jfree.chart.util.Layer layer77 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean78 = xYPlot38.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker54, layer77);
        java.util.Collection collection79 = categoryPlot0.getRangeMarkers((-9999), layer77);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNull(categoryToolTipGenerator68);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(layer77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(collection79);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            timeSeries3.add(regularTimePeriod4, (double) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint8 = barRenderer6.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean12 = barRenderer6.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        double double14 = barRenderer13.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer13.getBaseNegativeItemLabelPosition();
        barRenderer6.setPositiveItemLabelPositionFallback(itemLabelPosition15);
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font20);
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font20, paint22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint22, stroke24);
        barRenderer6.setBaseStroke(stroke24);
        xYPlot0.setRangeCrosshairStroke(stroke24);
        xYPlot0.clearAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(xYItemRenderer29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isOutlineVisible();
        timeSeriesCollection1.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean6 = ringPlot2.equals((java.lang.Object) color5);
        numberAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        double double7 = barRenderer0.getItemMargin();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer0.getURLGenerator(5, 5, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setShadowXOffset((double) '#');
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke9 = categoryPlot8.getDomainGridlineStroke();
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("hi!", font13);
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font13, paint15);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint15, stroke17);
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        boolean boolean20 = categoryPlot8.isDomainCrosshairVisible();
        categoryPlot8.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot8.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        barRenderer26.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator28, true);
        double[][] doubleArray33 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray33);
        org.jfree.data.Range range35 = barRenderer26.findRangeBounds(categoryDataset34);
        categoryPlot8.setDataset(10, categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        double double39 = categoryAxis3D38.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = numberAxis3D45.getLabelInsets();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D45.setTickMarkPaint((java.awt.Paint) color47);
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot();
        boolean boolean50 = ringPlot49.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = numberAxis3D51.getLabelInsets();
        ringPlot49.setInsets(rectangleInsets52);
        java.awt.Stroke stroke54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot49.setOutlineStroke(stroke54);
        boolean boolean56 = numberAxis3D45.hasListener((java.util.EventListener) ringPlot49);
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot49);
        java.awt.Paint paint59 = ringPlot49.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot49.setLabelPadding(rectangleInsets60);
        org.jfree.chart.title.TextTitle textTitle63 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType64 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D65 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = numberAxis3D65.getLabelInsets();
        java.awt.Color color67 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D65.setTickMarkPaint((java.awt.Paint) color67);
        org.jfree.chart.plot.RingPlot ringPlot69 = new org.jfree.chart.plot.RingPlot();
        boolean boolean70 = ringPlot69.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D71 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = numberAxis3D71.getLabelInsets();
        ringPlot69.setInsets(rectangleInsets72);
        java.awt.Stroke stroke74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot69.setOutlineStroke(stroke74);
        boolean boolean76 = numberAxis3D65.hasListener((java.util.EventListener) ringPlot69);
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot69);
        jFreeChart77.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent80 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType64, jFreeChart77);
        textTitle63.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart77);
        textTitle63.setID("");
        java.awt.geom.Rectangle2D rectangle2D84 = textTitle63.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker86 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker86.setLabelAnchor(rectangleAnchor87);
        java.awt.Paint paint89 = valueMarker86.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType90 = valueMarker86.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType91 = null;
        java.awt.geom.Rectangle2D rectangle2D92 = rectangleInsets60.createAdjustedRectangle(rectangle2D84, lengthAdjustmentType90, lengthAdjustmentType91);
        org.jfree.chart.plot.XYPlot xYPlot93 = new org.jfree.chart.plot.XYPlot();
        boolean boolean94 = xYPlot93.isDomainZoomable();
        boolean boolean95 = xYPlot93.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge96 = xYPlot93.getDomainAxisEdge();
        double double97 = categoryAxis3D38.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D84, rectangleEdge96);
        org.jfree.chart.util.RectangleEdge rectangleEdge98 = null;
        try {
            double double99 = barRenderer0.getItemMiddle(comparable6, (java.lang.Comparable) 1.0E-8d, categoryDataset34, categoryAxis37, rectangle2D84, rectangleEdge98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(paint59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(dateTickUnitType64);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangleAnchor87);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(lengthAdjustmentType90);
        org.junit.Assert.assertNotNull(rectangle2D92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertNotNull(rectangleEdge96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot0.getRenderer();
        java.awt.Stroke stroke4 = xYPlot0.getDomainCrosshairStroke();
        java.awt.geom.GeneralPath generalPath5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D6.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot10.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D12.getLabelInsets();
        ringPlot10.setInsets(rectangleInsets13);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot10.setOutlineStroke(stroke15);
        boolean boolean17 = numberAxis3D6.hasListener((java.util.EventListener) ringPlot10);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot10);
        java.awt.Paint paint20 = ringPlot10.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot10.setLabelPadding(rectangleInsets21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType25 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis3D26.getLabelInsets();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D26.setTickMarkPaint((java.awt.Paint) color28);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        boolean boolean31 = ringPlot30.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D32.getLabelInsets();
        ringPlot30.setInsets(rectangleInsets33);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot30.setOutlineStroke(stroke35);
        boolean boolean37 = numberAxis3D26.hasListener((java.util.EventListener) ringPlot30);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot30);
        jFreeChart38.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType25, jFreeChart38);
        textTitle24.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart38);
        textTitle24.setID("");
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle24.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker47.setLabelAnchor(rectangleAnchor48);
        java.awt.Paint paint50 = valueMarker47.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = valueMarker47.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets21.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType51, lengthAdjustmentType52);
        org.jfree.chart.RenderingSource renderingSource54 = null;
        xYPlot0.select(generalPath5, rectangle2D45, renderingSource54);
        double double56 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(dateTickUnitType25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(lengthAdjustmentType51);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        boolean boolean19 = segmentedTimeline0.equals((java.lang.Object) boolean18);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = segmentedTimeline0.getBaseTimeline();
        try {
            segmentedTimeline20.addException((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(segmentedTimeline20);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        int int3 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) 10L);
        timeSeriesDataItem11.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot14.isCircular();
        java.lang.String str16 = ringPlot14.getPlotType();
        boolean boolean17 = timeSeriesDataItem11.equals((java.lang.Object) ringPlot14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.addOrUpdate(timeSeriesDataItem11);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (-1.0d));
        boolean boolean23 = timeSeriesDataItem22.isSelected();
        java.lang.Object obj24 = timeSeriesDataItem22.clone();
        timeSeriesDataItem22.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries7.addOrUpdate(timeSeriesDataItem22);
        java.awt.Font font28 = categoryAxis3D2.getTickLabelFont((java.lang.Comparable) timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pie Plot" + "'", str16.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.util.Collection collection1 = xYStepAreaRenderer0.getAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color11 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer2.setLegendTextPaint(0, (java.awt.Paint) color11);
        barRenderer2.setAutoPopulateSeriesShape(false);
        boolean boolean15 = xYStepAreaRenderer0.equals((java.lang.Object) barRenderer2);
        barRenderer2.setMaximumBarWidth((-5.0d));
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        double double21 = polarPlot20.getMaxRadius();
        boolean boolean22 = polarPlot20.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.05d + "'", double21 == 1.05d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        double double6 = intervalXYDelegate5.getIntervalPositionFactor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        double double4 = rectangleInsets2.calculateLeftInset(12.0d);
        double double6 = rectangleInsets2.extendHeight(0.0d);
        double double7 = rectangleInsets2.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.0d + "'", double6 == 6.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getUpperBound();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) numberAxis3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        java.lang.String str7 = ringPlot5.getPlotType();
        boolean boolean8 = ringPlot5.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        long long11 = month9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.awt.Stroke stroke13 = ringPlot5.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod12);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection1, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.data.general.DatasetGroup datasetGroup15 = timeSeriesCollection1.getGroup();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(datasetGroup15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.panRangeAxes((double) 900000L, plotRenderingInfo3, point2D4);
        xYPlot0.setDomainCrosshairValue((double) 0L, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = categoryPlot9.getDomainGridlineStroke();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("hi!", font14);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font14, paint16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint16, stroke18);
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = categoryPlot9.isDomainCrosshairVisible();
        categoryPlot9.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot9.getDomainAxisLocation((int) (short) -1);
        xYPlot0.setDomainAxisLocation(axisLocation25, false);
        xYPlot0.mapDatasetToRangeAxis((int) ' ', 6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D3.getLabelInsets();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D3.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D9.getLabelInsets();
        ringPlot7.setInsets(rectangleInsets10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot7.setOutlineStroke(stroke12);
        boolean boolean14 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot7);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot7);
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType2, jFreeChart15);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        textTitle1.setID("");
        org.jfree.chart.StandardChartTheme standardChartTheme23 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint24 = standardChartTheme23.getAxisLabelPaint();
        java.awt.Font font27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("hi!", font27);
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font27, paint29);
        standardChartTheme23.setShadowPaint(paint29);
        textTitle1.setPaint(paint29);
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("hi!", font36);
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock39 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font36, paint38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint38, stroke40);
        textTitle1.setBackgroundPaint(paint38);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(textBlock39);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Pie Plot", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemLineVisible(2, (int) (byte) 10);
        boolean boolean4 = xYLineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke3 = categoryPlot2.getDomainGridlineStroke();
        xYPlot0.setRangeGridlineStroke(stroke3);
        java.util.List list5 = xYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers((int) (short) 100, layer2);
        xYPlot0.setRangeCrosshairValue(0.0d, true);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer8.getItemLineVisible(100, (int) (short) 1);
        boolean boolean12 = xYLineAndShapeRenderer8.getBaseLinesVisible();
        java.awt.Paint paint13 = xYLineAndShapeRenderer8.getBaseItemLabelPaint();
        xYPlot0.setRangeCrosshairPaint(paint13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter11 = standardChartTheme1.getXYBarPainter();
        boolean boolean12 = standardChartTheme1.isShadowVisible();
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] {};
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint19 = barRenderer17.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = barRenderer17.getToolTipGenerator((int) (short) 10, 0, false);
        double double24 = barRenderer17.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = barRenderer25.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape33 = null;
        barRenderer25.setLegendShape(100, shape33);
        boolean boolean35 = barRenderer25.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape36 = barRenderer25.getBaseLegendShape();
        barRenderer17.setBaseShape(shape36);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint42 = barRenderer40.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator46 = barRenderer40.getToolTipGenerator((int) (short) 10, 0, false);
        double double47 = barRenderer40.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint50 = barRenderer48.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = barRenderer48.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape56 = null;
        barRenderer48.setLegendShape(100, shape56);
        boolean boolean58 = barRenderer48.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape59 = barRenderer48.getBaseLegendShape();
        barRenderer40.setBaseShape(shape59);
        xYStepAreaRenderer38.setSeriesShape((int) ' ', shape59);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint65 = barRenderer63.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = barRenderer63.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape71 = null;
        barRenderer63.setLegendShape(100, shape71);
        boolean boolean73 = barRenderer63.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape74 = barRenderer63.getBaseLegendShape();
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape74, (double) (short) 0, (double) ' ');
        numberAxis3D62.setDownArrow(shape74);
        java.awt.Shape[] shapeArray79 = new java.awt.Shape[] { shape36, shape59, shape74 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier80 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray14, strokeArray15, strokeArray16, shapeArray79);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean82 = defaultDrawingSupplier80.equals((java.lang.Object) rectangleAnchor81);
        java.awt.Shape shape83 = defaultDrawingSupplier80.getNextShape();
        standardChartTheme1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier80);
        java.awt.Paint paint85 = defaultDrawingSupplier80.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNotNull(xYBarPainter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(categoryToolTipGenerator46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(categoryToolTipGenerator54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(categoryToolTipGenerator69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(shapeArray79);
        org.junit.Assert.assertNotNull(rectangleAnchor81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(shape83);
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        barRenderer0.setShadowVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Paint paint9 = barRenderer0.lookupLegendTextPaint(1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        double double8 = timeSeriesCollection0.getDomainUpperBound(true);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range11, lengthConstraintType12, (double) (-1L), range14, lengthConstraintType15);
        java.lang.String str17 = lengthConstraintType15.toString();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        boolean boolean19 = ringPlot18.isCircular();
        ringPlot18.setSectionDepth((double) (short) 1);
        java.awt.Paint paint23 = ringPlot18.getSectionOutlinePaint((java.lang.Comparable) "Pie Plot");
        double double24 = ringPlot18.getInteriorGap();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle25 = ringPlot18.getLabelLinkStyle();
        boolean boolean26 = lengthConstraintType15.equals((java.lang.Object) ringPlot18);
        java.awt.Shape shape27 = ringPlot18.getLegendItemShape();
        java.awt.Image image28 = null;
        ringPlot18.setBackgroundImage(image28);
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleConstraintType.RANGE" + "'", str17.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.08d + "'", double24 == 0.08d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        double double2 = ringPlot0.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesOutlinePaint((int) (short) -1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        boolean boolean19 = segmentedTimeline0.equals((java.lang.Object) boolean18);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer23.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape31 = null;
        barRenderer23.setLegendShape(100, shape31);
        boolean boolean33 = barRenderer23.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape34 = barRenderer23.getBaseLegendShape();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape34, (double) (short) 0, (double) ' ');
        numberAxis3D22.setDownArrow(shape34);
        boolean boolean39 = numberAxis3D22.isTickMarksVisible();
        boolean boolean40 = segmentedTimeline21.equals((java.lang.Object) boolean39);
        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean42 = segmentedTimeline21.containsDomainValue(date41);
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment43 = segmentedTimeline20.getSegment(date41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(segmentedTimeline20);
        org.junit.Assert.assertNotNull(segmentedTimeline21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        boolean boolean14 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker18.setStartValue((double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isDomainCrosshairLockedOnData();
        java.awt.Color color24 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int25 = color24.getBlue();
        xYPlot21.setRangeMinorGridlinePaint((java.awt.Paint) color24);
        xYPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker31.setLabelAnchor(rectangleAnchor32);
        java.awt.Paint paint34 = valueMarker31.getPaint();
        double double35 = valueMarker31.getValue();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot21.addDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker31, layer36, false);
        java.lang.String str39 = layer36.toString();
        categoryPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker18, layer36);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = null;
        org.jfree.chart.util.Layer layer43 = null;
        try {
            categoryPlot0.addDomainMarker(9, categoryMarker42, layer43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 35.0d + "'", double35 == 35.0d);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.BACKGROUND" + "'", str39.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        double double4 = ringPlot1.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj4 = multiplePiePlot3.clone();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        multiplePiePlot3.setAggregatedItemsPaint((java.awt.Paint) color5);
        textTitle1.setPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer5.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color14 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer5.setLegendTextPaint(0, (java.awt.Paint) color14);
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "{0}", "hi!", "{0}", shape4, (java.awt.Paint) color14);
        legendItem16.setSeriesKey((java.lang.Comparable) 0);
        java.awt.Color color20 = java.awt.Color.BLACK;
        java.awt.Color color21 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color20);
        legendItem16.setOutlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        double double4 = rectangleInsets2.calculateBottomInset((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers((int) (short) 100, layer2);
        java.awt.Stroke stroke4 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        double double21 = polarPlot20.getMaxRadius();
        java.awt.Stroke stroke22 = null;
        polarPlot20.setRadiusGridlineStroke(stroke22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        polarPlot20.zoomDomainAxes(12.0d, (double) 900000L, plotRenderingInfo26, point2D27);
        boolean boolean29 = polarPlot20.isAngleLabelsVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        polarPlot20.zoomDomainAxes((double) 100.0f, plotRenderingInfo31, point2D32, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.05d + "'", double21 == 1.05d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        boolean boolean12 = categoryPlot0.isDomainCrosshairVisible();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer18.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator20, true);
        double[][] doubleArray25 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray25);
        org.jfree.data.Range range27 = barRenderer18.findRangeBounds(categoryDataset26);
        categoryPlot0.setDataset(10, categoryDataset26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset26, (-1.0d));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(range31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        xYStepAreaRenderer0.setPlot(xYPlot4);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYStepAreaRenderer0.setSeriesItemLabelGenerator((int) (short) 10, xYItemLabelGenerator7, false);
        xYStepAreaRenderer0.setPlotArea(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setSectionDepth((double) (short) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        ringPlot2.datasetChanged(datasetChangeEvent6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        ringPlot2.setShadowPaint((java.awt.Paint) color8);
        int int10 = year1.compareTo((java.lang.Object) ringPlot2);
        double double11 = ringPlot2.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        try {
            java.lang.Number number4 = timeSeriesCollection1.getY(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        java.lang.String str1 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.NONE" + "'", str1.equals("DomainOrder.NONE"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setShadowXOffset((double) '#');
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean13 = barRenderer7.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        double double15 = barRenderer14.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer14.getBaseNegativeItemLabelPosition();
        barRenderer7.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        barRenderer0.setSeriesNegativeItemLabelPosition(9, itemLabelPosition16, true);
        barRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        double double4 = categoryAxis3D3.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D10.getLabelInsets();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D10.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot14.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis3D16.getLabelInsets();
        ringPlot14.setInsets(rectangleInsets17);
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot14.setOutlineStroke(stroke19);
        boolean boolean21 = numberAxis3D10.hasListener((java.util.EventListener) ringPlot14);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot14);
        java.awt.Paint paint24 = ringPlot14.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot14.setLabelPadding(rectangleInsets25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType29 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis3D30.getLabelInsets();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D30.setTickMarkPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        boolean boolean35 = ringPlot34.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D36.getLabelInsets();
        ringPlot34.setInsets(rectangleInsets37);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot34.setOutlineStroke(stroke39);
        boolean boolean41 = numberAxis3D30.hasListener((java.util.EventListener) ringPlot34);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot34);
        jFreeChart42.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType29, jFreeChart42);
        textTitle28.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart42);
        textTitle28.setID("");
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle28.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker51.setLabelAnchor(rectangleAnchor52);
        java.awt.Paint paint54 = valueMarker51.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = valueMarker51.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets25.createAdjustedRectangle(rectangle2D49, lengthAdjustmentType55, lengthAdjustmentType56);
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        boolean boolean59 = xYPlot58.isDomainZoomable();
        boolean boolean60 = xYPlot58.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot58.getDomainAxisEdge();
        double double62 = categoryAxis3D3.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D49, rectangleEdge61);
        categoryAxis3D3.setLowerMargin((double) (short) 10);
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        categoryPlot0.setRangeCrosshairValue(6.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(dateTickUnitType29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType55);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 10L);
        timeSeriesDataItem7.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot10.isCircular();
        java.lang.String str12 = ringPlot10.getPlotType();
        boolean boolean13 = timeSeriesDataItem7.equals((java.lang.Object) ringPlot10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0d));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeries3.setDomainDescription("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        try {
            timeSeries3.update(13, (java.lang.Number) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        java.awt.Paint paint14 = ringPlot4.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot4.setLabelPadding(rectangleInsets15);
        java.awt.Stroke stroke17 = ringPlot4.getLabelLinkStroke();
        double double18 = ringPlot4.getSectionDepth();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Paint paint3 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint4 = standardChartTheme1.getWallPaint();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        ringPlot5.setInsets(rectangleInsets8);
        boolean boolean10 = standardChartTheme1.equals((java.lang.Object) rectangleInsets8);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font7);
        textBlock5.addLine(textLine8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        try {
            textBlock5.draw(graphics2D10, (float) ' ', 0.0f, textBlockAnchor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = xYStepAreaRenderer0.getLegendItemToolTipGenerator();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        try {
            xYStepAreaRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.4d, 1.05d, (int) (short) -1, (java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10, 0.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) 'a', (int) (byte) 100, (java.lang.Comparable) month6, "TextBlockAnchor.CENTER_RIGHT", "Layer.BACKGROUND");
        java.lang.String str13 = pieSectionEntity12.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PieSection: 97, 100(June 2019)" + "'", str13.equals("PieSection: 97, 100(June 2019)"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getLabelInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        ringPlot5.setInsets(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot5.setOutlineStroke(stroke10);
        boolean boolean12 = numberAxis3D1.hasListener((java.util.EventListener) ringPlot5);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot5);
        java.util.List list14 = jFreeChart13.getSubtitles();
        segmentedTimeline0.setExceptionSegments(list14);
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Class class20 = periodAxis19.getMajorTickTimePeriodClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", class20);
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(date16, date22);
        try {
            boolean boolean26 = segmentedTimeline0.containsDomainValue(date22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.title.LegendTitle cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        org.jfree.chart.plot.Plot plot14 = ringPlot4.getRootPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        plot14.markerChanged(markerChangeEvent15);
        plot14.setBackgroundImageAlignment(15);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter1 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        boolean boolean2 = basicProjectInfo0.equals((java.lang.Object) gradientXYBarPainter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace8.ensureAtLeast(axisSpace9);
        xYPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        boolean boolean14 = xYPlot13.isDomainZoomable();
        boolean boolean15 = xYPlot13.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot13.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean21 = xYStepAreaRenderer18.getBaseItemLabelsVisible();
        boolean boolean22 = xYStepAreaRenderer18.getPlotArea();
        xYPlot17.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18);
        int int24 = xYPlot13.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18);
        org.jfree.chart.LegendItem legendItem27 = xYStepAreaRenderer18.getLegendItem((int) '#', (int) (byte) 100);
        xYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18, true);
        boolean boolean30 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.lang.String str10 = standardChartTheme1.getName();
        boolean boolean11 = standardChartTheme1.isShadowVisible();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setCrosshairPaint(paint12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint16 = barRenderer14.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer14.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape22 = null;
        barRenderer14.setLegendShape(100, shape22);
        boolean boolean24 = barRenderer14.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape25 = barRenderer14.getBaseLegendShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = barRenderer14.getLegendItemToolTipGenerator();
        java.awt.Font font30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("hi!", font30);
        java.awt.Color color33 = java.awt.Color.BLACK;
        java.awt.Color color34 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color33);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("{0}", font30, (java.awt.Paint) color33);
        barRenderer14.setSeriesPaint(0, (java.awt.Paint) color33, false);
        boolean boolean38 = org.jfree.chart.util.PaintUtilities.equal(paint12, (java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesStroke((int) (short) 0);
        java.awt.Font font7 = xYStepAreaRenderer0.lookupLegendTextFont(0);
        boolean boolean8 = xYStepAreaRenderer0.getBaseCreateEntities();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYStepAreaRenderer0.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke12 = categoryPlot11.getDomainGridlineStroke();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("hi!", font16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font16, paint18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint18, stroke20);
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setDomainGridlinePaint((java.awt.Paint) color23);
        java.awt.Paint paint25 = categoryPlot11.getRangeZeroBaselinePaint();
        xYStepAreaRenderer0.setSeriesPaint((int) ' ', paint25, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemLineVisible(100, (int) (short) 1);
        boolean boolean4 = xYLineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font6);
        boolean boolean8 = xYLineAndShapeRenderer0.equals((java.lang.Object) font6);
        xYLineAndShapeRenderer0.setDrawSeriesLineAsPath(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.util.Collection collection1 = xYStepAreaRenderer0.getAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer0.getPositiveItemLabelPosition(7, 5, true);
        double double6 = itemLabelPosition5.getAngle();
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        double double2 = numberAxis3D0.getFixedAutoRange();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        boolean boolean4 = xYPlot3.isDomainZoomable();
        boolean boolean5 = xYPlot3.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot3.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot3.getFixedRangeAxisSpace();
        numberAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = null;
        try {
            xYPlot3.setSeriesRenderingOrder(seriesRenderingOrder9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        java.lang.Object obj3 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.util.Collection collection1 = xYStepAreaRenderer0.getAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer0.getPositiveItemLabelPosition(7, 5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint8 = barRenderer6.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = barRenderer6.getLegendItemURLGenerator();
        barRenderer6.setShadowVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer6.getSeriesNegativeItemLabelPosition(0);
        xYStepAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13, false);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            java.lang.Comparable comparable8 = timeSeriesCollection0.getSeriesKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (35).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        double double4 = ringPlot1.getShadowXOffset();
        ringPlot1.clearSectionPaints(true);
        double double7 = ringPlot1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        double double1 = xYCrosshairState0.getAnchorX();
        xYCrosshairState0.setAnchorX((double) 13);
        xYCrosshairState0.updateCrosshairY((double) 60000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot0.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer5.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean8 = xYStepAreaRenderer5.getBaseItemLabelsVisible();
        boolean boolean9 = xYStepAreaRenderer5.getPlotArea();
        xYPlot4.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer5);
        int int11 = xYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomRangeAxes(0.14d, (double) (byte) -1, plotRenderingInfo14, point2D15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint19 = barRenderer17.lookupSeriesOutlinePaint((int) 'a');
        barRenderer17.setShadowYOffset((double) 100);
        boolean boolean22 = xYPlot0.equals((java.lang.Object) barRenderer17);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke3 = categoryPlot2.getDomainGridlineStroke();
        xYPlot0.setRangeGridlineStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray12);
        symbolAxis13.resizeRange((double) (short) 0);
        symbolAxis13.setLabelToolTip("");
        symbolAxis13.setUpperBound((double) 100L);
        symbolAxis13.setVerticalTickLabels(true);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) symbolAxis13, polarItemRenderer22);
        int int24 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        long long2 = segmentedTimeline0.getStartTime();
        segmentedTimeline0.addException(60000L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208960000000L) + "'", long2 == (-2208960000000L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Pie Plot");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font3 = barRenderer2.getBaseItemLabelFont();
        labelBlock1.setFont(font3);
        labelBlock1.setToolTipText("Size2D[width=0.0, height=100.0]");
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getLabelInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        ringPlot5.setInsets(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot5.setOutlineStroke(stroke10);
        boolean boolean12 = numberAxis3D1.hasListener((java.util.EventListener) ringPlot5);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot5);
        jFreeChart13.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType0, jFreeChart13);
        java.lang.Object obj17 = null;
        boolean boolean18 = dateTickUnitType0.equals(obj17);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17, layer18);
        intervalMarker17.setLabel("DomainOrder.NONE");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D3.getLabelInsets();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D3.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D9.getLabelInsets();
        ringPlot7.setInsets(rectangleInsets10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot7.setOutlineStroke(stroke12);
        boolean boolean14 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot7);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot7);
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType2, jFreeChart15);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        textTitle1.setID("");
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle1.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets((double) 60000L, 0.0d, (double) (byte) 10, (double) 128);
        textTitle1.setPadding(rectangleInsets27);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 0.5d);
        multiplePiePlot0.setNoDataMessage("10");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer0.getItemLineVisible(100, (int) (short) 1);
        boolean boolean4 = xYLineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Paint paint5 = xYLineAndShapeRenderer0.getBaseItemLabelPaint();
        boolean boolean8 = xYLineAndShapeRenderer0.getItemShapeFilled((int) '#', (int) (byte) 10);
        xYLineAndShapeRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font3);
        java.awt.Color color6 = java.awt.Color.BLACK;
        java.awt.Color color7 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("{0}", font3, (java.awt.Paint) color6);
        java.awt.Color color9 = java.awt.Color.BLACK;
        org.jfree.chart.axis.AxisSpace axisSpace10 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        axisSpace10.ensureAtLeast(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean16 = rectangleEdge14.equals((java.lang.Object) 2);
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge14);
        axisSpace11.add((double) 10, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isDomainZoomable();
        boolean boolean23 = xYPlot21.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot21.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = xYPlot21.render(graphics2D25, rectangle2D26, 500, plotRenderingInfo28, crosshairState29);
        xYPlot21.clearRangeMarkers(0);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker35.setLabelAnchor(rectangleAnchor36);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot21.addRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker35, layer38, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot21.getAxisOffset();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("", font3, (java.awt.Paint) color9, rectangleEdge14, horizontalAlignment19, verticalAlignment20, rectangleInsets41);
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge14);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "DomainOrder.NONE");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleConstraintType.RANGE", dateFormat1, dateFormat2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        ringPlot4.datasetChanged(datasetChangeEvent12);
        ringPlot4.setOutlineVisible(true);
        int int16 = ringPlot4.getPieIndex();
        ringPlot4.setShadowXOffset(0.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}: ({1}, {2})");
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1, lengthConstraintType2, (double) (-1L), range4, lengthConstraintType5);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean10 = xYLineAndShapeRenderer7.getItemLineVisible(100, (int) (short) 1);
        boolean boolean11 = xYLineAndShapeRenderer7.getBaseLinesVisible();
        boolean boolean12 = lengthConstraintType5.equals((java.lang.Object) boolean11);
        java.lang.Object obj13 = null;
        boolean boolean14 = lengthConstraintType5.equals(obj13);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        boolean boolean14 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker18.setStartValue((double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isDomainCrosshairLockedOnData();
        java.awt.Color color24 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int25 = color24.getBlue();
        xYPlot21.setRangeMinorGridlinePaint((java.awt.Paint) color24);
        xYPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker31.setLabelAnchor(rectangleAnchor32);
        java.awt.Paint paint34 = valueMarker31.getPaint();
        double double35 = valueMarker31.getValue();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot21.addDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker31, layer36, false);
        java.lang.String str39 = layer36.toString();
        categoryPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker18, layer36);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = null;
        try {
            intervalMarker18.setLabelOffset(rectangleInsets41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 35.0d + "'", double35 == 35.0d);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.BACKGROUND" + "'", str39.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer0.setSeriesItemLabelGenerator(9999, categoryItemLabelGenerator14, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 3, "PlotOrientation.HORIZONTAL", textAnchor3, textAnchor4, (double) (byte) 0);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        java.awt.Paint paint7 = xYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace8.ensureAtLeast(axisSpace9);
        xYPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        boolean boolean14 = xYPlot13.isDomainZoomable();
        boolean boolean15 = xYPlot13.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot13.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean21 = xYStepAreaRenderer18.getBaseItemLabelsVisible();
        boolean boolean22 = xYStepAreaRenderer18.getPlotArea();
        xYPlot17.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18);
        int int24 = xYPlot13.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18);
        org.jfree.chart.LegendItem legendItem27 = xYStepAreaRenderer18.getLegendItem((int) '#', (int) (byte) 100);
        xYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer18, true);
        org.jfree.chart.axis.AxisSpace axisSpace30 = new org.jfree.chart.axis.AxisSpace();
        xYPlot0.setFixedRangeAxisSpace(axisSpace30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(legendItem27);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        boolean boolean12 = categoryPlot0.isDomainCrosshairVisible();
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        double double16 = categoryAxis3D15.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D22.getLabelInsets();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D22.setTickMarkPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        boolean boolean27 = ringPlot26.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = numberAxis3D28.getLabelInsets();
        ringPlot26.setInsets(rectangleInsets29);
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot26.setOutlineStroke(stroke31);
        boolean boolean33 = numberAxis3D22.hasListener((java.util.EventListener) ringPlot26);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot26);
        java.awt.Paint paint36 = ringPlot26.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot26.setLabelPadding(rectangleInsets37);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType41 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D42.getLabelInsets();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D42.setTickMarkPaint((java.awt.Paint) color44);
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot();
        boolean boolean47 = ringPlot46.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = numberAxis3D48.getLabelInsets();
        ringPlot46.setInsets(rectangleInsets49);
        java.awt.Stroke stroke51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot46.setOutlineStroke(stroke51);
        boolean boolean53 = numberAxis3D42.hasListener((java.util.EventListener) ringPlot46);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot46);
        jFreeChart54.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType41, jFreeChart54);
        textTitle40.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart54);
        textTitle40.setID("");
        java.awt.geom.Rectangle2D rectangle2D61 = textTitle40.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker63.setLabelAnchor(rectangleAnchor64);
        java.awt.Paint paint66 = valueMarker63.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = valueMarker63.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets37.createAdjustedRectangle(rectangle2D61, lengthAdjustmentType67, lengthAdjustmentType68);
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot();
        boolean boolean71 = xYPlot70.isDomainZoomable();
        boolean boolean72 = xYPlot70.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = xYPlot70.getDomainAxisEdge();
        double double74 = categoryAxis3D15.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D61, rectangleEdge73);
        categoryAxis3D15.setLowerMargin((double) (short) 10);
        categoryAxis3D15.removeCategoryLabelToolTip((java.lang.Comparable) (-9999));
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D15);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(dateTickUnitType41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(lengthAdjustmentType67);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        boolean boolean4 = xYPlot3.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke6 = categoryPlot5.getDomainGridlineStroke();
        xYPlot3.setRangeGridlineStroke(stroke6);
        xYStepAreaRenderer0.setBaseStroke(stroke6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint4 = standardChartTheme3.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme3.setSmallFont(font5);
        standardChartTheme1.setRegularFont(font5);
        java.awt.Paint paint8 = standardChartTheme1.getThermometerPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedWidth((double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_RIGHT");
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine1.getFirstTextFragment();
        org.junit.Assert.assertNotNull(textFragment4);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        timeSeriesDataItem3.setValue((java.lang.Number) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Pie Plot");
        double double3 = textTitle2.getHeight();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle2.getBounds();
        org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) textTitle2, "hi!", "TextBlockAnchor.CENTER_RIGHT");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        valueMarker1.setAlpha((float) (short) 0);
        valueMarker1.setValue(1.0E-5d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        java.lang.Object obj14 = standardPieSectionLabelGenerator12.clone();
        java.text.AttributedString attributedString16 = null;
        try {
            standardPieSectionLabelGenerator12.setAttributedLabel((-9999), attributedString16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Class class4 = periodAxis3.getMajorTickTimePeriodClass();
        java.lang.Class class5 = periodAxis3.getMinorTickTimePeriodClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("10", class5);
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", class5);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean6 = barRenderer0.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double double8 = barRenderer7.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer7.getBaseNegativeItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = barRenderer0.removeAnnotation(categoryAnnotation11);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer0.getURLGenerator((int) '4', 100, true);
        barRenderer0.setShadowXOffset((double) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryURLGenerator16);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke3 = categoryPlot2.getDomainGridlineStroke();
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font7);
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint9, stroke11);
        categoryPlot2.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        boolean boolean14 = categoryPlot2.isDomainCrosshairVisible();
        categoryPlot2.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot2.getDomainAxisLocation((int) (short) -1);
        categoryPlot0.setDomainAxisLocation(axisLocation18);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis3D23.getLabelInsets();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D23.setTickMarkPaint((java.awt.Paint) color25);
        java.lang.Object obj27 = numberAxis3D23.clone();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo2 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray3 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo2 };
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class5);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray3);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(classLoader6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        java.awt.Stroke stroke10 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        java.awt.Paint paint14 = ringPlot4.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot4.setLabelPadding(rectangleInsets15);
        ringPlot4.setShadowYOffset(0.025d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        java.awt.Paint paint4 = valueMarker1.getPaint();
        double double5 = valueMarker1.getValue();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        valueMarker1.setPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        ringPlot0.setInsets(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot0.setOutlineStroke(stroke5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        ringPlot0.drawBackgroundImage(graphics2D7, rectangle2D8);
        ringPlot0.setIgnoreNullValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = ringPlot0.getLegendLabelGenerator();
        ringPlot0.setAutoPopulateSectionOutlineStroke(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "PlotOrientation.VERTICAL", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        double double4 = categoryAxis3D3.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D10.getLabelInsets();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D10.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot14.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis3D16.getLabelInsets();
        ringPlot14.setInsets(rectangleInsets17);
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot14.setOutlineStroke(stroke19);
        boolean boolean21 = numberAxis3D10.hasListener((java.util.EventListener) ringPlot14);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot14);
        java.awt.Paint paint24 = ringPlot14.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot14.setLabelPadding(rectangleInsets25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType29 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis3D30.getLabelInsets();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D30.setTickMarkPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        boolean boolean35 = ringPlot34.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D36.getLabelInsets();
        ringPlot34.setInsets(rectangleInsets37);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot34.setOutlineStroke(stroke39);
        boolean boolean41 = numberAxis3D30.hasListener((java.util.EventListener) ringPlot34);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot34);
        jFreeChart42.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType29, jFreeChart42);
        textTitle28.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart42);
        textTitle28.setID("");
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle28.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker51.setLabelAnchor(rectangleAnchor52);
        java.awt.Paint paint54 = valueMarker51.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = valueMarker51.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets25.createAdjustedRectangle(rectangle2D49, lengthAdjustmentType55, lengthAdjustmentType56);
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        boolean boolean59 = xYPlot58.isDomainZoomable();
        boolean boolean60 = xYPlot58.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot58.getDomainAxisEdge();
        double double62 = categoryAxis3D3.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D49, rectangleEdge61);
        categoryAxis3D3.setLowerMargin((double) (short) 10);
        categoryPlot0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3);
        double double66 = categoryAxis3D3.getLowerMargin();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(dateTickUnitType29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType55);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 10.0d + "'", double66 == 10.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        java.awt.Paint paint14 = ringPlot4.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor16 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor16.sort();
        int int18 = pieLabelDistributor16.getItemCount();
        java.lang.String str19 = pieLabelDistributor16.toString();
        boolean boolean20 = ringPlot4.equals((java.lang.Object) str19);
        double double21 = ringPlot4.getLabelGap();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.025d + "'", double21 == 0.025d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        java.lang.Object obj4 = numberAxis3D0.clone();
        org.jfree.data.RangeType rangeType5 = numberAxis3D0.getRangeType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) 'a');
        barRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) false);
        int int17 = barRenderer0.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0d));
        long long4 = month0.getSerialIndex();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint7 = standardChartTheme6.getAxisLabelPaint();
        java.awt.Paint paint8 = standardChartTheme6.getLabelLinkPaint();
        int int9 = month0.compareTo((java.lang.Object) standardChartTheme6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj2 = textTitle1.clone();
        textTitle1.setWidth((double) 10);
        textTitle1.setVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        double double8 = categoryAxis3D7.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D14.getLabelInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D14.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        boolean boolean19 = ringPlot18.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis3D20.getLabelInsets();
        ringPlot18.setInsets(rectangleInsets21);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot18.setOutlineStroke(stroke23);
        boolean boolean25 = numberAxis3D14.hasListener((java.util.EventListener) ringPlot18);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot18);
        java.awt.Paint paint28 = ringPlot18.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot18.setLabelPadding(rectangleInsets29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType33 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis3D34.getLabelInsets();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D34.setTickMarkPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        boolean boolean39 = ringPlot38.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis3D40.getLabelInsets();
        ringPlot38.setInsets(rectangleInsets41);
        java.awt.Stroke stroke43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot38.setOutlineStroke(stroke43);
        boolean boolean45 = numberAxis3D34.hasListener((java.util.EventListener) ringPlot38);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot38);
        jFreeChart46.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType33, jFreeChart46);
        textTitle32.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart46);
        textTitle32.setID("");
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle32.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker55.setLabelAnchor(rectangleAnchor56);
        java.awt.Paint paint58 = valueMarker55.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = valueMarker55.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets29.createAdjustedRectangle(rectangle2D53, lengthAdjustmentType59, lengthAdjustmentType60);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        boolean boolean63 = xYPlot62.isDomainZoomable();
        boolean boolean64 = xYPlot62.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot62.getDomainAxisEdge();
        double double66 = categoryAxis3D7.getCategorySeriesMiddle((int) (short) 100, 1, 2, (int) (short) 1, (double) (-9999), rectangle2D53, rectangleEdge65);
        textTitle1.setPosition(rectangleEdge65);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge65);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(dateTickUnitType33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(lengthAdjustmentType59);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        ringPlot1.setShadowYOffset((double) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        ringPlot1.handleClick(0, (int) (byte) -1, plotRenderingInfo8);
        ringPlot1.setPieIndex(2147483647);
        boolean boolean12 = ringPlot1.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) 6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        boolean boolean5 = piePlot3D1.equals((java.lang.Object) horizontalAlignment4);
        piePlot3D1.setDepthFactor(0.025d);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 10L);
        timeSeriesDataItem7.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot10.isCircular();
        java.lang.String str12 = ringPlot10.getPlotType();
        boolean boolean13 = timeSeriesDataItem7.equals((java.lang.Object) ringPlot10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        timeSeries3.setDescription("10^0.48");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getUpperBound();
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker16, rectangle2D17);
        numberAxis3D14.setAutoRangeMinimumSize((double) (short) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint23 = barRenderer21.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = barRenderer21.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape29 = null;
        barRenderer21.setLegendShape(100, shape29);
        boolean boolean31 = barRenderer21.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape32 = barRenderer21.getBaseLegendShape();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        double double36 = numberAxis3D35.getUpperBound();
        org.jfree.chart.plot.Marker marker37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        barRenderer21.drawRangeMarker(graphics2D33, categoryPlot34, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, marker37, rectangle2D38);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint43 = barRenderer41.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = barRenderer41.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape49 = null;
        barRenderer41.setLegendShape(100, shape49);
        boolean boolean51 = barRenderer41.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape52 = barRenderer41.getBaseLegendShape();
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape52, (double) (short) 0, (double) ' ');
        numberAxis3D40.setDownArrow(shape52);
        numberAxis3D40.setFixedAutoRange((double) 10);
        org.jfree.data.Range range59 = numberAxis3D40.getRange();
        numberAxis3D35.setRangeWithMargins(range59, false, true);
        org.jfree.data.time.DateRange dateRange63 = new org.jfree.data.time.DateRange(range59);
        numberAxis3D14.setRangeWithMargins(range59);
        try {
            org.jfree.data.Range range66 = org.jfree.data.Range.scale(range59, (-5.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'factor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        jFreeChart17.setAntiAlias(false);
        jFreeChart17.setTextAntiAlias(false);
        java.awt.RenderingHints renderingHints27 = null;
        try {
            jFreeChart17.setRenderingHints(renderingHints27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        barRenderer0.setSeriesShape(4, shape9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = barRenderer0.getLegendItems();
        java.lang.Object obj12 = null;
        boolean boolean13 = legendItemCollection11.equals(obj12);
        java.lang.Object obj14 = legendItemCollection11.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = barRenderer15.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        barRenderer15.setSeriesShape(4, shape24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = barRenderer15.getLegendItems();
        java.lang.Object obj27 = null;
        boolean boolean28 = legendItemCollection26.equals(obj27);
        legendItemCollection11.addAll(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Pie Plot");
        java.awt.Paint paint2 = labelBlock1.getPaint();
        java.lang.String str3 = labelBlock1.getToolTipText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        int int2 = xYPlot0.getDatasetCount();
        xYPlot0.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = xYPlot0.getInsets();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepAreaRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        xYStepAreaRenderer0.setSeriesURLGenerator((int) (short) 10, xYURLGenerator6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer0.getBasePositiveItemLabelPosition();
        xYStepAreaRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        boolean boolean14 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker18.setStartValue((double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isDomainCrosshairLockedOnData();
        java.awt.Color color24 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int25 = color24.getBlue();
        xYPlot21.setRangeMinorGridlinePaint((java.awt.Paint) color24);
        xYPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker31.setLabelAnchor(rectangleAnchor32);
        java.awt.Paint paint34 = valueMarker31.getPaint();
        double double35 = valueMarker31.getValue();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot21.addDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker31, layer36, false);
        java.lang.String str39 = layer36.toString();
        categoryPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker18, layer36);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke43 = categoryPlot42.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D();
        int int45 = categoryPlot42.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D44);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions46 = categoryAxis3D44.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(1900, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D44);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 35.0d + "'", double35 == 35.0d);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.BACKGROUND" + "'", str39.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions46);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        boolean boolean1 = logFormat0.isParseIntegerOnly();
        logFormat0.setMaximumIntegerDigits((int) '#');
        boolean boolean4 = logFormat0.isParseIntegerOnly();
        int int5 = logFormat0.getMaximumIntegerDigits();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.DatasetGroup datasetGroup1 = timeSeriesCollection0.getGroup();
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, (double) 128);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1, lengthConstraintType2, (double) (-1L), range4, lengthConstraintType5);
        java.lang.String str7 = lengthConstraintType5.toString();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot8.isCircular();
        ringPlot8.setSectionDepth((double) (short) 1);
        java.awt.Paint paint13 = ringPlot8.getSectionOutlinePaint((java.lang.Comparable) "Pie Plot");
        double double14 = ringPlot8.getInteriorGap();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = ringPlot8.getLabelLinkStyle();
        boolean boolean16 = lengthConstraintType5.equals((java.lang.Object) ringPlot8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = ringPlot8.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraintType.RANGE" + "'", str7.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.08d + "'", double14 == 0.08d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.awt.Color color0 = null;
        try {
            java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str2 = standardXYToolTipGenerator1.getFormatString();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator6 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", "Size2D[width=0.0, height=100.0]");
        java.lang.Object obj7 = null;
        boolean boolean8 = standardXYURLGenerator6.equals(obj7);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator6);
        java.text.NumberFormat numberFormat10 = standardXYToolTipGenerator1.getYFormat();
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", numberFormat10, (java.text.NumberFormat) logFormat11);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setSeriesShape((int) (short) 10, shape8, true);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        boolean boolean17 = textAnchor14.equals((java.lang.Object) color16);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color16);
        double double19 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesStroke((int) (byte) 100, stroke21);
        double double23 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        segmentedTimeline0.addException(0L, (long) '4');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        axisSpace2.ensureAtLeast(axisSpace3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) 2);
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        axisSpace3.add((double) 10, rectangleEdge6);
        axisSpace3.setRight((double) 1561964399999L);
        xYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke16 = categoryPlot15.getDomainGridlineStroke();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font20);
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font20, paint22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint22, stroke24);
        categoryPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker25);
        boolean boolean27 = categoryPlot15.isDomainCrosshairVisible();
        java.awt.Paint paint28 = categoryPlot15.getDomainCrosshairPaint();
        xYPlot0.setRangeCrosshairPaint(paint28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0d));
        boolean boolean6 = timeSeriesDataItem5.isSelected();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        java.awt.Paint paint8 = paintMap0.getPaint((java.lang.Comparable) timeSeriesDataItem5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        legendItem28.setDescription("");
        legendItem28.setShapeVisible(true);
        java.awt.Stroke stroke33 = legendItem28.getOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint36 = barRenderer34.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = barRenderer34.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape42 = null;
        barRenderer34.setLegendShape(100, shape42);
        boolean boolean44 = barRenderer34.getAutoPopulateSeriesStroke();
        boolean boolean45 = legendItem28.equals((java.lang.Object) barRenderer34);
        barRenderer34.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        java.lang.Boolean boolean3 = xYLineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 10);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemShapeVisible((int) (byte) 10, 2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, (double) 128);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke17 = categoryPlot16.getDomainGridlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace19, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        legendItemEntity17.setToolTipText("1");
        java.lang.Comparable comparable20 = legendItemEntity17.getSeriesKey();
        java.awt.Shape shape21 = legendItemEntity17.getArea();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        timeSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        try {
            double double7 = timeSeriesCollection0.getEndXValue(7, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        jFreeChart17.setAntiAlias(false);
        jFreeChart17.removeLegend();
        java.awt.RenderingHints renderingHints26 = null;
        try {
            jFreeChart17.setRenderingHints(renderingHints26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        boolean boolean2 = xYPlot1.isRangeMinorGridlinesVisible();
        java.util.List list3 = xYPlot1.getAnnotations();
        java.util.Collection collection4 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list3);
        boolean boolean5 = standardXYToolTipGenerator0.equals((java.lang.Object) list3);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setDomainAxisLocation(1, axisLocation4, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = categoryPlot9.getDomainGridlineStroke();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("hi!", font14);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font14, paint16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint16, stroke18);
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = categoryPlot9.isDomainCrosshairVisible();
        categoryPlot9.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot9.getDomainAxisLocation((int) (short) -1);
        categoryPlot7.setDomainAxisLocation(axisLocation25);
        xYPlot0.setDomainAxisLocation(axisLocation25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint30 = barRenderer28.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = barRenderer28.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color37 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer28.setLegendTextPaint(0, (java.awt.Paint) color37);
        int int39 = color37.getBlue();
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color37);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        xYPlot0.setRangeGridlinesVisible(false);
        int int8 = xYPlot0.getRendererCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        boolean boolean12 = categoryPlot0.isDomainCrosshairVisible();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(axisSpace17);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.panRangeAxes((double) 900000L, plotRenderingInfo3, point2D4);
        xYPlot0.setDomainCrosshairValue((double) 0L, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = categoryPlot9.getDomainGridlineStroke();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("hi!", font14);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font14, paint16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint16, stroke18);
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = categoryPlot9.isDomainCrosshairVisible();
        categoryPlot9.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot9.getDomainAxisLocation((int) (short) -1);
        xYPlot0.setDomainAxisLocation(axisLocation25, false);
        org.jfree.chart.block.CenterArrangement centerArrangement29 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = null;
        timeSeriesCollection30.seriesChanged(seriesChangeEvent31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        boolean boolean35 = ringPlot34.isCircular();
        java.lang.String str36 = ringPlot34.getPlotType();
        boolean boolean37 = ringPlot34.getAutoPopulateSectionPaint();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        long long39 = month38.getLastMillisecond();
        long long40 = month38.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
        java.awt.Stroke stroke42 = ringPlot34.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod41);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer43 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement29, (org.jfree.data.general.Dataset) timeSeriesCollection30, (java.lang.Comparable) regularTimePeriod41);
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement29);
        java.util.List list45 = blockContainer44.getBlocks();
        try {
            xYPlot0.mapDatasetToRangeAxes(5, list45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Pie Plot" + "'", str36.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561964399999L + "'", long40 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(stroke42);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer0.setBaseFillPaint(paint1);
        int int3 = xYStepAreaRenderer0.getPassCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        boolean boolean5 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        java.lang.Comparable comparable21 = null;
        defaultXYDataset0.removeSeries(comparable21);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17, layer18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor7.sort();
        ringPlot4.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", font2, (org.jfree.chart.plot.Plot) ringPlot4, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        java.awt.Paint paint14 = jFreeChart11.getBackgroundPaint();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = null;
        try {
            jFreeChart11.titleChanged(titleChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str1 = standardXYToolTipGenerator0.getFormatString();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", "Size2D[width=0.0, height=100.0]");
        java.lang.Object obj6 = null;
        boolean boolean7 = standardXYURLGenerator5.equals(obj6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Class class16 = periodAxis15.getMajorTickTimePeriodClass();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis25 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray24);
        symbolAxis25.resizeRange((double) (short) 0);
        symbolAxis25.setAutoTickUnitSelection(false, true);
        double double31 = symbolAxis25.getLowerMargin();
        boolean boolean32 = multiplePiePlot17.equals((java.lang.Object) symbolAxis25);
        java.awt.Paint paint33 = symbolAxis25.getLabelPaint();
        org.jfree.data.time.TimeSeries timeSeries34 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection35 = new org.jfree.data.time.TimeSeriesCollection(timeSeries34);
        try {
            xYStepRenderer8.drawItem(graphics2D9, xYItemRendererState10, rectangle2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) periodAxis15, (org.jfree.chart.axis.ValueAxis) symbolAxis25, (org.jfree.data.xy.XYDataset) timeSeriesCollection35, (int) '#', 5, true, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}: ({1}, {2})" + "'", str1.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj15 = textTitle14.clone();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        boolean boolean17 = xYPlot16.isDomainZoomable();
        int int18 = xYPlot16.getDatasetCount();
        boolean boolean19 = textTitle14.equals((java.lang.Object) int18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis3D20.getLabelInsets();
        double double22 = rectangleInsets21.getRight();
        double double24 = rectangleInsets21.calculateBottomInset(0.0d);
        textTitle14.setMargin(rectangleInsets21);
        jFreeChart12.removeSubtitle((org.jfree.chart.title.Title) textTitle14);
        java.lang.String str27 = textTitle14.getToolTipText();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        java.awt.Paint paint14 = ringPlot4.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot4.setLabelPadding(rectangleInsets15);
        java.awt.Stroke stroke17 = ringPlot4.getLabelLinkStroke();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = ringPlot4.getLabelDistributor();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        boolean boolean2 = periodAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        java.lang.Object obj3 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer1.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape9 = null;
        barRenderer1.setLegendShape(100, shape9);
        boolean boolean11 = barRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = barRenderer1.getBaseLegendShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) (short) 0, (double) ' ');
        numberAxis3D0.setDownArrow(shape12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        java.lang.String str18 = legendItemEntity17.toString();
        java.lang.Comparable comparable19 = legendItemEntity17.getSeriesKey();
        java.lang.Object obj20 = legendItemEntity17.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str18.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getLabelInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D7.getLabelInsets();
        ringPlot5.setInsets(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot5.setOutlineStroke(stroke10);
        boolean boolean12 = numberAxis3D1.hasListener((java.util.EventListener) ringPlot5);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot5);
        jFreeChart13.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType0, jFreeChart13);
        java.awt.Image image17 = jFreeChart13.getBackgroundImage();
        java.awt.RenderingHints renderingHints18 = jFreeChart13.getRenderingHints();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(renderingHints18);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        boolean boolean2 = xYPlot1.isDomainPannable();
        java.awt.Paint paint3 = xYPlot1.getRangeCrosshairPaint();
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) segmentedTimeline0, (java.lang.Object) paint3);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            int int8 = timeSeriesCollection0.getItemCount(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2147483647).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        double double7 = intervalXYDelegate5.getDomainUpperBound(true);
        try {
            java.lang.Number number10 = intervalXYDelegate5.getStartX(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.lang.String str2 = ringPlot0.getPlotType();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer7.getToolTipGenerator((int) (short) 10, 0, false);
        double double14 = barRenderer7.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = barRenderer15.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape23 = null;
        barRenderer15.setLegendShape(100, shape23);
        boolean boolean25 = barRenderer15.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape26 = barRenderer15.getBaseLegendShape();
        barRenderer7.setBaseShape(shape26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint30 = barRenderer28.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape26, paint30);
        ringPlot0.setLabelLinkPaint(paint30);
        double double33 = ringPlot0.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray23);
        symbolAxis24.resizeRange((double) (short) 0);
        symbolAxis24.setAutoTickUnitSelection(false, true);
        double double30 = symbolAxis24.getLowerMargin();
        boolean boolean31 = multiplePiePlot16.equals((java.lang.Object) symbolAxis24);
        java.lang.String str33 = symbolAxis24.valueToString((double) (byte) -1);
        org.jfree.data.Range range34 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        java.awt.Paint paint35 = categoryPlot0.getRangeCrosshairPaint();
        boolean boolean36 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke4 = categoryPlot3.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        int int6 = categoryPlot3.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3D5.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        boolean boolean14 = ringPlot4.getSimpleLabels();
        ringPlot4.setMinimumArcAngleToDraw((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.025d, (double) ' ');
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        double double1 = xYCrosshairState0.getCrosshairDistance();
        double double2 = xYCrosshairState0.getCrosshairDistance();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        boolean boolean14 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        double double17 = categoryAxis3D16.getCategoryMargin();
        float float18 = categoryAxis3D16.getMaximumCategoryLabelWidthRatio();
        double double19 = categoryAxis3D16.getUpperMargin();
        categoryPlot0.setDomainAxis(3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(categoryAnchor2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesStroke((int) (short) 0);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, paint11);
        xYStepAreaRenderer0.setSeriesItemLabelPaint(2, paint11, false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str16 = standardXYToolTipGenerator15.getFormatString();
        xYStepAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{0}: ({1}, {2})" + "'", str16.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isOutlineVisible();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isDomainZoomable();
        boolean boolean8 = xYPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot6.getDomainAxisEdge();
        boolean boolean10 = timeSeriesCollection0.hasListener((java.util.EventListener) xYPlot6);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeriesCollection0.getSeries((java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null");
        try {
            java.lang.Number number16 = timeSeriesCollection0.getStartX(2147483647, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(timeSeries13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        xYBarRenderer0.setShadowXOffset((double) 10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers((int) (short) 100, layer2);
        java.awt.Paint paint4 = xYPlot0.getDomainZeroBaselinePaint();
        xYPlot0.configureRangeAxes();
        java.util.List list6 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setLabelToolTip("");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis3D17.getLabelInsets();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D17.setTickMarkPaint((java.awt.Paint) color19);
        java.lang.Object obj21 = numberAxis3D17.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj25 = intervalMarker24.clone();
        double double26 = intervalMarker24.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker28.setLabelAnchor(rectangleAnchor29);
        intervalMarker24.setLabelAnchor(rectangleAnchor29);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYStepAreaRenderer12.drawRangeMarker(graphics2D15, xYPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.plot.Marker) intervalMarker24, rectangle2D32);
        boolean boolean34 = xYPlot16.isRangeCrosshairLockedOnData();
        boolean boolean35 = symbolAxis7.hasListener((java.util.EventListener) xYPlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("Pie Plot");
        double double41 = textTitle40.getHeight();
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle40.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor43);
        xYPlot16.zoomDomainAxes(35.0d, 0.2d, plotRenderingInfo38, point2D44);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(point2D44);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        ringPlot0.setInsets(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot0.setOutlineStroke(stroke5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        ringPlot0.drawBackgroundImage(graphics2D7, rectangle2D8);
        ringPlot0.setIgnoreNullValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = ringPlot0.getLegendLabelGenerator();
        double double14 = ringPlot0.getExplodePercent((java.lang.Comparable) "ThreadContext");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_RIGHT");
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean13 = barRenderer7.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        double double15 = barRenderer14.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer14.getBaseNegativeItemLabelPosition();
        barRenderer7.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean24 = barRenderer18.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        double double26 = barRenderer25.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer25.getBaseNegativeItemLabelPosition();
        barRenderer18.setPositiveItemLabelPositionFallback(itemLabelPosition27);
        barRenderer7.setBaseNegativeItemLabelPosition(itemLabelPosition27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis3D30.getLabelInsets();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D30.setTickMarkPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        boolean boolean35 = ringPlot34.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D36.getLabelInsets();
        ringPlot34.setInsets(rectangleInsets37);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot34.setOutlineStroke(stroke39);
        boolean boolean41 = numberAxis3D30.hasListener((java.util.EventListener) ringPlot34);
        boolean boolean42 = itemLabelPosition27.equals((java.lang.Object) ringPlot34);
        org.jfree.chart.text.TextAnchor textAnchor43 = itemLabelPosition27.getTextAnchor();
        try {
            textLine1.draw(graphics2D4, 100.0f, (float) (-9999), textAnchor43, (float) (short) 10, (float) 500, (double) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(textAnchor43);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        ringPlot0.setShadowYOffset(12.0d);
        boolean boolean4 = ringPlot0.isCircular();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        try {
            ringPlot0.setInteriorGap((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint3 = standardChartTheme2.getAxisLabelPaint();
        java.awt.Paint paint4 = standardChartTheme2.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter5 = standardChartTheme2.getBarPainter();
        boolean boolean6 = defaultXYDataset0.equals((java.lang.Object) standardChartTheme2);
        java.awt.Paint paint7 = standardChartTheme2.getGridBandAlternatePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(barPainter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font6);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot8.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor11 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor11.sort();
        ringPlot8.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor11);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("{0}", font6, (org.jfree.chart.plot.Plot) ringPlot8, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot8.getLabelPadding();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot8, (java.lang.Integer) (-1), plotRenderingInfo18);
        double double20 = ringPlot8.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-5d + "'", double20 == 1.0E-5d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        long long8 = month7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 10L);
        timeSeriesDataItem10.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot13.isCircular();
        java.lang.String str15 = ringPlot13.getPlotType();
        boolean boolean16 = timeSeriesDataItem10.equals((java.lang.Object) ringPlot13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate(timeSeriesDataItem10);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeriesCollection2.getSeries((java.lang.Comparable) timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pie Plot" + "'", str15.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNull(timeSeries18);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint4 = standardChartTheme3.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme3.setSmallFont(font5);
        standardChartTheme1.setRegularFont(font5);
        java.awt.Paint paint8 = standardChartTheme1.getLegendBackgroundPaint();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) 1561964399999L, 10.0f, (float) (-1));
        java.awt.Color color13 = color12.brighter();
        standardChartTheme1.setItemLabelPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj2 = xYLineAndShapeRenderer1.clone();
        boolean boolean3 = gradientXYBarPainter0.equals(obj2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        barRenderer4.setShadowYOffset((double) 100);
        java.awt.Paint paint10 = barRenderer4.lookupSeriesFillPaint(100);
        barRenderer4.setBase((double) 7);
        boolean boolean13 = gradientXYBarPainter0.equals((java.lang.Object) barRenderer4);
        java.awt.Paint paint15 = null;
        barRenderer4.setSeriesOutlinePaint((int) (byte) 0, paint15, false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int4 = color3.getBlue();
        xYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color3);
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker10.setLabelAnchor(rectangleAnchor11);
        java.awt.Paint paint13 = valueMarker10.getPaint();
        double double14 = valueMarker10.getValue();
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer15, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getDomainAxisLocation(3);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.lang.Comparable comparable2 = legendItem1.getSeriesKey();
        java.awt.Stroke stroke3 = legendItem1.getLineStroke();
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color2);
        java.lang.Comparable comparable4 = null;
        try {
            multiplePiePlot0.setAggregatedItemsKey(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        double double17 = barRenderer16.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer16.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesPositiveItemLabelPosition(4, itemLabelPosition18, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer0.getBaseURLGenerator();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Color color24 = color23.darker();
        barRenderer0.setLegendTextPaint((int) ' ', (java.awt.Paint) color23);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator26);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = ringPlot4.getLabelPadding();
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.calculateTopOutset(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke16 = lineBorder15.getStroke();
        categoryPlot0.setDomainCrosshairStroke(stroke16);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        double double7 = barRenderer0.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer8.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape16 = null;
        barRenderer8.setLegendShape(100, shape16);
        boolean boolean18 = barRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape19 = barRenderer8.getBaseLegendShape();
        barRenderer0.setBaseShape(shape19);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj22 = multiplePiePlot21.clone();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType25 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis3D26.getLabelInsets();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D26.setTickMarkPaint((java.awt.Paint) color28);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        boolean boolean31 = ringPlot30.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D32.getLabelInsets();
        ringPlot30.setInsets(rectangleInsets33);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot30.setOutlineStroke(stroke35);
        boolean boolean37 = numberAxis3D26.hasListener((java.util.EventListener) ringPlot30);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot30);
        jFreeChart38.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType25, jFreeChart38);
        textTitle24.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart38);
        multiplePiePlot21.setPieChart(jFreeChart38);
        jFreeChart38.setAntiAlias(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape19, jFreeChart38);
        java.awt.Font font50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("hi!", font50);
        org.jfree.chart.plot.RingPlot ringPlot52 = new org.jfree.chart.plot.RingPlot();
        boolean boolean53 = ringPlot52.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor55 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor55.sort();
        ringPlot52.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor55);
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart("{0}", font50, (org.jfree.chart.plot.Plot) ringPlot52, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener60 = null;
        jFreeChart59.addProgressListener(chartProgressListener60);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType62 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent63 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 0, jFreeChart59, chartChangeEventType62);
        chartChangeEvent46.setChart(jFreeChart59);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(dateTickUnitType25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        categoryPlot0.setRangePannable(false);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke18 = categoryPlot17.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        int int20 = categoryPlot17.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = categoryAxis3D19.getCategoryLabelPositions();
        java.util.List list22 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D19);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation25, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer4.getToolTipGenerator((int) (short) 10, 0, false);
        double double11 = barRenderer4.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape20 = null;
        barRenderer12.setLegendShape(100, shape20);
        boolean boolean22 = barRenderer12.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape23 = barRenderer12.getBaseLegendShape();
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint27 = barRenderer25.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("{0}", "hi!", "hi!", "{0}", shape23, paint27);
        java.awt.Font font29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendItem28.setLabelFont(font29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendItem28.setLabelPaint((java.awt.Paint) color31);
        legendItem28.setDatasetIndex(10);
        legendItem28.setShapeVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D37.getLabelInsets();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D37.setTickMarkPaint((java.awt.Paint) color39);
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        boolean boolean42 = ringPlot41.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = numberAxis3D43.getLabelInsets();
        ringPlot41.setInsets(rectangleInsets44);
        java.awt.Stroke stroke46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot41.setOutlineStroke(stroke46);
        boolean boolean48 = numberAxis3D37.hasListener((java.util.EventListener) ringPlot41);
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot41);
        java.awt.Paint paint51 = ringPlot41.getSectionPaint((java.lang.Comparable) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot41.setLabelPadding(rectangleInsets52);
        java.awt.Stroke stroke54 = ringPlot41.getLabelLinkStroke();
        legendItem28.setOutlineStroke(stroke54);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        org.jfree.data.category.CategoryDataset categoryDataset23 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryDataset23);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Shape shape14 = barRenderer0.lookupLegendShape((int) (short) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = barRenderer15.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape23 = null;
        barRenderer15.setLegendShape(100, shape23);
        boolean boolean25 = barRenderer15.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape26 = barRenderer15.getBaseLegendShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = barRenderer15.getLegendItemToolTipGenerator();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("hi!", font31);
        java.awt.Color color34 = java.awt.Color.BLACK;
        java.awt.Color color35 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color34);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("{0}", font31, (java.awt.Paint) color34);
        barRenderer15.setSeriesPaint(0, (java.awt.Paint) color34, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        boolean boolean42 = ringPlot41.isCircular();
        ringPlot41.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme46 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint47 = standardChartTheme46.getAxisLabelPaint();
        java.awt.Font font50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("hi!", font50);
        java.awt.Paint paint52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock53 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font50, paint52);
        standardChartTheme46.setShadowPaint(paint52);
        ringPlot41.setBackgroundPaint(paint52);
        xYBarRenderer39.setSeriesOutlinePaint((int) (byte) 0, paint52, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer58 = xYBarRenderer39.getGradientPaintTransformer();
        barRenderer15.setGradientPaintTransformer(gradientPaintTransformer58);
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer58);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(textBlock53);
        org.junit.Assert.assertNotNull(gradientPaintTransformer58);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        polarPlot20.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        boolean boolean23 = polarPlot20.isAngleGridlinesVisible();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot20.setAngleGridlinePaint((java.awt.Paint) color24);
        java.lang.String str26 = polarPlot20.getPlotType();
        double double27 = polarPlot20.getMaxRadius();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Polar Plot" + "'", str26.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.05d + "'", double27 == 1.05d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.isCircular();
        ringPlot2.setShadowYOffset(12.0d);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint8 = standardChartTheme7.getAxisLabelPaint();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, paint13);
        standardChartTheme7.setShadowPaint(paint13);
        ringPlot2.setBackgroundPaint(paint13);
        xYBarRenderer0.setSeriesOutlinePaint((int) (byte) 0, paint13, true);
        xYBarRenderer0.setShadowYOffset((double) (-1.0f));
        double double21 = xYBarRenderer0.getShadowYOffset();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        xYBarRenderer0.setLegendBar(shape23);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = xYBarRenderer0.getItemLabelGenerator(2147483647, (-1), true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        double double30 = barRenderer29.getMinimumBarLength();
        barRenderer29.setShadowXOffset(0.0d);
        barRenderer29.setShadowXOffset((double) '#');
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint38 = barRenderer36.lookupSeriesOutlinePaint((int) 'a');
        boolean boolean42 = barRenderer36.getItemCreateEntity((int) (byte) 100, (-1), false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        double double44 = barRenderer43.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = barRenderer43.getBaseNegativeItemLabelPosition();
        barRenderer36.setPositiveItemLabelPositionFallback(itemLabelPosition45);
        barRenderer29.setSeriesNegativeItemLabelPosition(9, itemLabelPosition45, true);
        org.jfree.chart.text.TextAnchor textAnchor49 = itemLabelPosition45.getRotationAnchor();
        xYBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition45);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(xYItemLabelGenerator28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertNotNull(textAnchor49);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D2.getLabelInsets();
        ringPlot0.setInsets(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot0.setOutlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getDomainGridlineStroke();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font12);
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font12, paint14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint14, stroke16);
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        boolean boolean19 = categoryPlot7.isDomainCrosshairVisible();
        categoryPlot7.setCrosshairDatasetIndex((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot7.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        barRenderer25.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator27, true);
        double[][] doubleArray32 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "PlotOrientation.VERTICAL", doubleArray32);
        org.jfree.data.Range range34 = barRenderer25.findRangeBounds(categoryDataset33);
        categoryPlot7.setDataset(10, categoryDataset33);
        org.jfree.data.general.PieDataset pieDataset37 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 9);
        ringPlot0.setDataset(pieDataset37);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(pieDataset37);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot4.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        org.jfree.chart.plot.Plot plot14 = ringPlot4.getRootPlot();
        ringPlot4.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        java.lang.Object obj23 = jFreeChart17.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        try {
            java.awt.image.BufferedImage bufferedImage28 = jFreeChart17.createBufferedImage((int) (short) 1, 0, (int) (short) -1, chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj15 = textTitle14.clone();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        boolean boolean17 = xYPlot16.isDomainZoomable();
        int int18 = xYPlot16.getDatasetCount();
        boolean boolean19 = textTitle14.equals((java.lang.Object) int18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis3D20.getLabelInsets();
        double double22 = rectangleInsets21.getRight();
        double double24 = rectangleInsets21.calculateBottomInset(0.0d);
        textTitle14.setMargin(rectangleInsets21);
        jFreeChart12.removeSubtitle((org.jfree.chart.title.Title) textTitle14);
        textTitle14.setURLText("RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis3D0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getLabelInsets();
        ringPlot4.setInsets(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot4.setOutlineStroke(stroke9);
        boolean boolean11 = numberAxis3D0.hasListener((java.util.EventListener) ringPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot4);
        java.util.List list13 = jFreeChart12.getSubtitles();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("Pie Plot");
        java.lang.Object obj17 = textTitle16.clone();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        boolean boolean19 = xYPlot18.isDomainZoomable();
        int int20 = xYPlot18.getDatasetCount();
        boolean boolean21 = textTitle16.equals((java.lang.Object) int20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D22.getLabelInsets();
        double double24 = rectangleInsets23.getRight();
        double double26 = rectangleInsets23.calculateBottomInset(0.0d);
        textTitle16.setMargin(rectangleInsets23);
        try {
            jFreeChart12.addSubtitle(13, (org.jfree.chart.title.Title) textTitle16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        standardChartTheme1.setShadowPaint(paint7);
        java.awt.Paint paint10 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint13 = standardChartTheme12.getAxisLabelPaint();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme12.setSmallFont(font14);
        org.jfree.chart.StandardChartTheme standardChartTheme17 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint18 = standardChartTheme17.getAxisLabelPaint();
        java.awt.Paint paint19 = standardChartTheme17.getDomainGridlinePaint();
        standardChartTheme12.setRangeGridlinePaint(paint19);
        java.awt.Paint paint21 = standardChartTheme12.getRangeGridlinePaint();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("hi!", font24);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        boolean boolean27 = ringPlot26.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor29 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor29.sort();
        ringPlot26.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor29);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("{0}", font24, (org.jfree.chart.plot.Plot) ringPlot26, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener34 = null;
        jFreeChart33.addProgressListener(chartProgressListener34);
        java.awt.Paint paint36 = jFreeChart33.getBackgroundPaint();
        standardChartTheme12.setItemLabelPaint(paint36);
        standardChartTheme1.setItemLabelPaint(paint36);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        java.lang.Boolean boolean3 = xYLineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 10);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemShapeFilled(35, 100);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        boolean boolean19 = segmentedTimeline0.equals((java.lang.Object) boolean18);
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean21 = segmentedTimeline0.containsDomainValue(date20);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment23 = segmentedTimeline0.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = null;
        try {
            boolean boolean25 = segment23.before(segment24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(segment23);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        java.util.Date date3 = segmentedTimeline0.getDate((long) (byte) 0);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font5, paint7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint7, stroke9);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        categoryPlot0.setDomainGridlinesVisible(false);
        boolean boolean14 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        intervalMarker18.setStartValue((double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isDomainCrosshairLockedOnData();
        java.awt.Color color24 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        int int25 = color24.getBlue();
        xYPlot21.setRangeMinorGridlinePaint((java.awt.Paint) color24);
        xYPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker31.setLabelAnchor(rectangleAnchor32);
        java.awt.Paint paint34 = valueMarker31.getPaint();
        double double35 = valueMarker31.getValue();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot21.addDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker31, layer36, false);
        java.lang.String str39 = layer36.toString();
        categoryPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker18, layer36);
        boolean boolean41 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 35.0d + "'", double35 == 35.0d);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.BACKGROUND" + "'", str39.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        long long8 = month7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 10L);
        timeSeriesDataItem10.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot13.isCircular();
        java.lang.String str15 = ringPlot13.getPlotType();
        boolean boolean16 = timeSeriesDataItem10.equals((java.lang.Object) ringPlot13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate(timeSeriesDataItem10);
        timeSeries6.removeAgedItems(false);
        timeSeriesCollection2.addSeries(timeSeries6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pie Plot" + "'", str15.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock5.getLineAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = null;
        try {
            java.awt.Shape shape14 = textBlock5.calculateBounds(graphics2D7, (float) 'a', (float) 0L, textBlockAnchor10, (float) 1561964399999L, (float) (short) 100, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 500, plotRenderingInfo7, crosshairState8);
        xYPlot0.clearRangeMarkers(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot0.getRangeMarkers(layer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = xYPlot0.getAxisOffset();
        double double16 = rectangleInsets14.calculateTopInset((double) 3600000L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test471");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
        long long2 = year1.getFirstMillisecond();
        long long3 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62198899200000L) + "'", long2 == (-62198899200000L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        java.lang.Object obj9 = numberAxis3D5.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (-1.0d));
        java.lang.Object obj13 = intervalMarker12.clone();
        double double14 = intervalMarker12.getEndValue();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker16.setLabelAnchor(rectangleAnchor17);
        intervalMarker12.setLabelAnchor(rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepAreaRenderer0.drawRangeMarker(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.plot.Marker) intervalMarker12, rectangle2D20);
        java.awt.Shape shape23 = xYStepAreaRenderer0.getLegendShape(500);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYStepAreaRenderer0.getURLGenerator((int) '4', 35, false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNull(xYURLGenerator27);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 10L);
        timeSeriesDataItem7.setValue((java.lang.Number) 0L);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot10.isCircular();
        java.lang.String str12 = ringPlot10.getPlotType();
        boolean boolean13 = timeSeriesDataItem7.equals((java.lang.Object) ringPlot10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0d));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setShadowXOffset((double) '#');
        barRenderer0.setAutoPopulateSeriesPaint(false);
        java.awt.Paint paint9 = barRenderer0.lookupLegendTextPaint(7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        boolean boolean2 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        java.awt.Stroke stroke3 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        double double1 = xYCrosshairState0.getCrosshairDistance();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYCrosshairState0.updateCrosshairPoint((double) 1L, (double) 2.0f, 1, (int) (short) 10, (double) 15, 1.05d, plotOrientation8);
        int int10 = xYCrosshairState0.getDomainAxisIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}");
        java.lang.Object obj2 = standardChartTheme1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = standardChartTheme1.getAxisOffset();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        boolean boolean5 = xYPlot4.isDomainZoomable();
        boolean boolean6 = xYPlot4.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot4.setDomainAxisLocation(1, axisLocation8, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesOutlinePaint((int) 'a');
        barRenderer11.setShadowYOffset((double) 100);
        java.awt.Paint paint17 = barRenderer11.lookupSeriesFillPaint(100);
        xYPlot4.setRangeGridlinePaint(paint17);
        standardChartTheme1.setTickLabelPaint(paint17);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color11 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer2.setLegendTextPaint(0, (java.awt.Paint) color11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        boolean boolean14 = barRenderer2.removeAnnotation(categoryAnnotation13);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot9.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D11.getLabelInsets();
        ringPlot9.setInsets(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot9.setOutlineStroke(stroke14);
        boolean boolean16 = numberAxis3D5.hasListener((java.util.EventListener) ringPlot9);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        jFreeChart17.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType4, jFreeChart17);
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        multiplePiePlot0.setPieChart(jFreeChart17);
        jFreeChart17.setAntiAlias(false);
        java.awt.Paint paint25 = jFreeChart17.getBorderPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Color color9 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        barRenderer0.setLegendTextPaint(0, (java.awt.Paint) color9);
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean4 = xYStepAreaRenderer1.getBaseItemLabelsVisible();
        boolean boolean5 = xYStepAreaRenderer1.getPlotArea();
        xYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = xYStepAreaRenderer1.getLegendItemURLGenerator();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.data.Range range9 = xYStepAreaRenderer1.findRangeBounds(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor3 = new org.jfree.chart.plot.PieLabelDistributor(100);
        pieLabelDistributor3.sort();
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor3);
        pieLabelDistributor3.distributeLabels(100.0d, 0.0d);
        pieLabelDistributor3.sort();
        pieLabelDistributor3.clear();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean3 = xYStepAreaRenderer0.getBaseItemLabelsVisible();
        java.awt.Stroke stroke5 = xYStepAreaRenderer0.lookupSeriesStroke((int) (short) 0);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, paint11);
        xYStepAreaRenderer0.setSeriesItemLabelPaint(2, paint11, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = xYStepAreaRenderer0.getToolTipGenerator((int) (byte) 10, 1, true);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYStepAreaRenderer0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNull(xYToolTipGenerator18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) 6);
        piePlot3D1.setDarkerSides(false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock5.getLineAlignment();
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font10);
        java.awt.Color color13 = java.awt.Color.BLACK;
        java.awt.Color color14 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color13);
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("{0}", font10, (java.awt.Paint) color13);
        java.awt.Color color16 = java.awt.Color.BLACK;
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        axisSpace17.ensureAtLeast(axisSpace18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean23 = rectangleEdge21.equals((java.lang.Object) 2);
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge21);
        axisSpace18.add((double) 10, rectangleEdge21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        boolean boolean29 = xYPlot28.isDomainZoomable();
        boolean boolean30 = xYPlot28.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot28.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.plot.CrosshairState crosshairState36 = null;
        boolean boolean37 = xYPlot28.render(graphics2D32, rectangle2D33, 500, plotRenderingInfo35, crosshairState36);
        xYPlot28.clearRangeMarkers(0);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker42.setLabelAnchor(rectangleAnchor43);
        org.jfree.chart.util.Layer layer45 = null;
        xYPlot28.addRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker42, layer45, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = xYPlot28.getAxisOffset();
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("", font10, (java.awt.Paint) color16, rectangleEdge21, horizontalAlignment26, verticalAlignment27, rectangleInsets48);
        org.jfree.chart.block.FlowArrangement flowArrangement52 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment27, 0.0d, (double) 0L);
        java.lang.String str53 = horizontalAlignment6.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "HorizontalAlignment.CENTER" + "'", str53.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D3.getLabelInsets();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis3D3.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D9.getLabelInsets();
        ringPlot7.setInsets(rectangleInsets10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot7.setOutlineStroke(stroke12);
        boolean boolean14 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot7);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot7);
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateTickUnitType2, jFreeChart15);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        textTitle1.setID("");
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint23.toUnconstrainedWidth();
        double double25 = rectangleConstraint24.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D26 = textTitle1.arrange(graphics2D22, rectangleConstraint24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape8 = null;
        barRenderer0.setLegendShape(100, shape8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape11 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer0.getSeriesItemLabelGenerator((int) 'a');
        barRenderer0.setMaximumBarWidth(0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        java.awt.Paint paint4 = valueMarker1.getPaint();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setAutoTickUnitSelection(false, true);
        double double14 = symbolAxis8.getLowerMargin();
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) symbolAxis8);
        java.lang.String str17 = symbolAxis8.valueToString((double) (byte) -1);
        double double18 = symbolAxis8.getUpperBound();
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer2.getToolTipGenerator((int) (short) 10, 0, false);
        java.awt.Shape shape10 = null;
        barRenderer2.setLegendShape(100, shape10);
        boolean boolean12 = barRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = barRenderer2.getBaseLegendShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) (short) 0, (double) ' ');
        numberAxis3D1.setDownArrow(shape13);
        boolean boolean18 = numberAxis3D1.isTickMarksVisible();
        boolean boolean19 = segmentedTimeline0.equals((java.lang.Object) boolean18);
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean21 = segmentedTimeline0.containsDomainValue(date20);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment23 = segmentedTimeline0.getSegment(0L);
        segment23.moveIndexToEnd();
        long long26 = segment23.calculateSegmentNumber(0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(segment23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 25566L + "'", long26 == 25566L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer1.setBaseFillPaint(paint2);
        boolean boolean4 = xYStepAreaRenderer1.getShapesVisible();
        boolean boolean5 = gradientXYBarPainter0.equals((java.lang.Object) xYStepAreaRenderer1);
        java.awt.Paint paint9 = xYStepAreaRenderer1.getItemLabelPaint(4, (int) '#', false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray6);
        symbolAxis7.resizeRange((double) (short) 0);
        symbolAxis7.setAutoTickUnitSelection(false, true);
        double double13 = symbolAxis7.getLowerMargin();
        java.awt.Font font18 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis7, (double) 60000L, (double) (short) -1, (double) 3600000L, (double) 10, font18);
        java.awt.Graphics2D graphics2D20 = null;
        double double21 = markerAxisBand19.getHeight(graphics2D20);
        org.jfree.chart.StandardChartTheme standardChartTheme23 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint24 = standardChartTheme23.getAxisLabelPaint();
        java.awt.Font font27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("hi!", font27);
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font27, paint29);
        standardChartTheme23.setShadowPaint(paint29);
        java.lang.String str32 = standardChartTheme23.getName();
        org.jfree.chart.StandardChartTheme standardChartTheme34 = new org.jfree.chart.StandardChartTheme("{0}");
        java.awt.Paint paint35 = standardChartTheme34.getAxisLabelPaint();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme34.setSmallFont(font36);
        standardChartTheme23.setRegularFont(font36);
        java.lang.String str39 = standardChartTheme23.getName();
        boolean boolean40 = markerAxisBand19.equals((java.lang.Object) standardChartTheme23);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{0}" + "'", str32.equals("{0}"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{0}" + "'", str39.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "{0}", "hi!", "", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("hi!", strArray7);
        symbolAxis8.resizeRange((double) (short) 0);
        symbolAxis8.setLabelToolTip("");
        symbolAxis8.setUpperBound((double) 100L);
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend15 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray7);
    }
}

