import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        java.awt.Paint paint3 = null;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, paint1, stroke2, paint3, stroke4, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Stroke stroke2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        double double5 = categoryAxis4.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis4.getTickLabelInsets();
        java.awt.Paint paint8 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Stroke stroke9 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, (java.awt.Paint) color1, stroke2, paint8, stroke9, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        try {
            java.util.List list7 = categoryAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Comparable comparable0 = null;
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Paint paint3 = null;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker(comparable0, paint1, stroke2, paint3, stroke4, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) ' ', (double) 100, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        categoryPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addRangeMarker((int) '4', marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        try {
            boolean boolean3 = categoryPlot0.removeAnnotation(categoryAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = color0.darker();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker2, layer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color2 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", (int) (short) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot2.addDomainMarker((int) (byte) -1, categoryMarker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        categoryAxis1.setFixedDimension(0.05d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str1.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        java.awt.Paint paint9 = null;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 10, (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot0.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = categoryPlot0.removeRangeMarker((int) (byte) 10, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 1);
        java.lang.String str8 = categoryAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        java.awt.Color color12 = java.awt.Color.CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Color color1 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        int int4 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.calculateTopInset((double) 100);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        categoryAxis1.setVisible(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        double double16 = categoryPlot15.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot15.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        try {
            java.util.List list22 = categoryAxis1.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            categoryPlot0.drawBackground(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            boolean boolean16 = categoryPlot0.removeAnnotation(categoryAnnotation14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot6.getRangeAxisEdge();
        try {
            double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, (int) ' ', 0, rectangle2D5, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle((double) 0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot6.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot6.getRangeAxisEdge();
        try {
            double double13 = categoryAxis0.getCategoryMiddle((int) (byte) 1, 2, rectangle2D5, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.darker();
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color4);
        java.awt.Color color7 = color4.brighter();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Paint[] paintArray10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray11 = null;
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke13, stroke14, stroke15, stroke16, stroke17, stroke18 };
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke20, stroke21, stroke22, stroke23, stroke24 };
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, paintArray12, strokeArray19, strokeArray25, shapeArray26);
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, (java.awt.Paint) color4, stroke8, (java.awt.Paint) color9, stroke28, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range4, true, false);
        numberAxis1.resizeRange((-9.0d), (double) 'a');
        numberAxis1.setPositiveArrowVisible(false);
        boolean boolean13 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.SortOrder sortOrder3 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        java.awt.Paint paint4 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin(0.05d);
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis13.getTickLabelInsets();
        double double17 = rectangleInsets15.trimWidth((double) (-1));
        double double18 = rectangleInsets15.getRight();
        categoryAxis1.setLabelInsets(rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets15.createInsetRectangle(rectangle2D20, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.0d) + "'", double17 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.centerRange((double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation8, plotOrientation9);
        try {
            double double11 = numberAxis1.valueToJava2D((double) 100L, rectangle2D7, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13, stroke14 };
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray9, strokeArray15, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextStroke();
        try {
            java.awt.Shape shape19 = defaultDrawingSupplier17.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Image image13 = null;
        categoryPlot0.setBackgroundImage(image13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) (short) 1, 0, rectangle2D8, rectangleEdge9);
        boolean boolean12 = categoryAxis1.equals((java.lang.Object) (byte) 10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getRangeAxisEdge();
        try {
            java.util.List list18 = categoryAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        boolean boolean22 = categoryPlot10.isRangeZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = null;
        try {
            categoryPlot10.setInsets(rectangleInsets23, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.centerRange(1.0d);
        boolean boolean5 = seriesRenderingOrder0.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        double double5 = categoryAxis1.getLowerMargin();
        categoryAxis1.setFixedDimension((-1.0d));
        categoryAxis1.setFixedDimension(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean2 = unitType0.equals((java.lang.Object) 1.0E-8d);
        java.lang.String str3 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UnitType.RELATIVE" + "'", str3.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        try {
            categoryPlot0.mapDatasetToRangeAxis((int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot10.getRangeMarkers(4, layer20);
        categoryPlot10.mapDatasetToDomainAxis((int) (short) 100, (int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot10.getDataset((int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(categoryDataset26);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setFixedAutoRange(0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 6, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.String str3 = datasetRenderingOrder2.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.data.RangeType rangeType11 = null;
        try {
            numberAxis1.setRangeType(rangeType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass3 = color2.getClass();
        try {
            java.util.EventListener[] eventListenerArray4 = categoryMarker1.getListeners((java.lang.Class) wildcardClass3);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound(10.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        double double10 = categoryAxis9.getLowerMargin();
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Color color12 = color11.darker();
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        double double15 = categoryPlot14.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot14.getDataset((int) (byte) 1);
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot14.setRenderer(categoryItemRenderer20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis23.setNegativeArrowVisible(false);
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis23.setRange(range26, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double32 = numberAxis31.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double35 = numberAxis34.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis37.setNegativeArrowVisible(false);
        java.awt.Shape shape40 = numberAxis37.getDownArrow();
        double double41 = numberAxis37.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double44 = numberAxis43.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis46.setNegativeArrowVisible(false);
        java.awt.Paint paint49 = numberAxis46.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis23, numberAxis31, numberAxis34, numberAxis37, numberAxis43, numberAxis46 };
        categoryPlot14.setRangeAxes(valueAxisArray50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        double double54 = categoryPlot53.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset56 = categoryPlot53.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = categoryPlot53.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = categoryPlot53.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace61 = numberAxis1.reserveSpace(graphics2D7, (org.jfree.chart.plot.Plot) categoryPlot14, rectangle2D52, rectangleEdge59, axisSpace60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0E-8d + "'", double32 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-8d + "'", double35 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0E-8d + "'", double44 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset56);
        org.junit.Assert.assertNull(categoryAxis58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.lang.String str22 = numberAxis18.getLabelURL();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis24.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis24.getStandardTickUnits();
        numberAxis18.setStandardTickUnits(tickUnitSource27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        numberAxis18.setLabelPaint((java.awt.Paint) color29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        java.awt.Paint paint13 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.plot.Plot plot14 = categoryPlot6.getParent();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        double double3 = numberAxis1.getLowerBound();
        double double4 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        double double22 = categoryAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis21.getTickLabelInsets();
        java.awt.Paint paint25 = categoryAxis21.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font26 = categoryAxis21.getLabelFont();
        intervalMarker17.setLabelFont(font26);
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean31 = chartChangeEventType29.equals((java.lang.Object) color30);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) font26, jFreeChart28, chartChangeEventType29);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryItemRenderer12, jFreeChart14, chartChangeEventType29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(chartChangeEventType29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.plot.Plot plot14 = categoryPlot0.getRootPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot0.setRenderer(categoryItemRenderer15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        java.awt.Color color6 = color3.brighter();
        float[] floatArray9 = new float[] { (byte) 0, (byte) 100 };
        try {
            float[] floatArray10 = color3.getRGBColorComponents(floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        java.awt.Paint paint6 = intervalMarker2.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        try {
            intervalMarker2.setLabelAnchor(rectangleAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot6.getRangeAxisEdge();
        try {
            double double8 = numberAxis1.lengthToJava2D((double) '#', rectangle2D5, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot5.getDataset((int) (byte) 1);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot5.getRangeAxis(255);
        categoryPlot5.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16, true);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot5.getRowRenderingOrder();
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        double double22 = categoryPlot21.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot21.getDataset((int) (byte) 1);
        boolean boolean25 = categoryPlot21.isRangeCrosshairVisible();
        boolean boolean26 = categoryPlot21.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot21.getAxisOffset();
        categoryPlot5.setInsets(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str8 = categoryPlot7.getNoDataMessage();
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        intervalMarker11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Paint paint14 = intervalMarker11.getLabelPaint();
        boolean boolean15 = categoryPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11);
        boolean boolean16 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) 1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) -1, (float) 100, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = null;
        try {
            numberAxis1.setDownArrow(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        int int11 = categoryPlot0.getRangeAxisCount();
        try {
            categoryPlot0.setBackgroundImageAlpha((float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        java.awt.Color color12 = java.awt.Color.WHITE;
        java.awt.Color color13 = color12.darker();
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        float[] floatArray16 = new float[] { 1 };
        try {
            float[] floatArray17 = color8.getColorComponents(colorSpace14, floatArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-1L), (float) 100L, 10.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.trimWidth((double) (-1));
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets3.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.centerRange(1.0d);
        boolean boolean4 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass6 = color5.getClass();
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.lang.Class class9 = null;
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone11);
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass15 = color14.getClass();
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.lang.Class class18 = null;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone20);
        java.lang.Class class23 = null;
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date16, timeZone25);
        java.awt.Font font28 = null;
        try {
            categoryAxis1.setTickLabelFont((java.lang.Comparable) regularTimePeriod27, font28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getTickLabelInsets();
        double double9 = rectangleInsets7.calculateBottomInset((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot0.setDataset(categoryDataset7);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        double double11 = categoryAxis1.getCategoryMargin();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            categoryPlot0.drawOutline(graphics2D25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categoryAnchor23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        java.util.List list6 = categoryPlot0.getCategories();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        double double11 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        double double12 = categoryAxis11.getLowerMargin();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color8, stroke13, (java.awt.Paint) color17, stroke18, 0.0f);
        java.lang.Object obj21 = valueMarker20.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        double double2 = categoryPlot1.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset4 = categoryPlot1.getDataset((int) (byte) 1);
        boolean boolean5 = categoryPlot1.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot1.getRangeAxis(255);
        categoryPlot1.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint10 = categoryPlot1.getNoDataMessagePaint();
        boolean boolean11 = color0.equals((java.lang.Object) categoryPlot1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(4, 1, (int) (short) 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 0);
        int int3 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.trimWidth((double) (-1));
        double double7 = rectangleInsets3.calculateBottomInset((double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke4);
        xYPlot0.setDomainGridlineStroke(stroke4);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getDomainAxisForDataset(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 3 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        boolean boolean8 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        java.lang.String str12 = color10.toString();
        int int13 = color10.getBlue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=0,g=0,b=255]" + "'", str12.equals("java.awt.Color[r=0,g=0,b=255]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        java.lang.Object obj6 = intervalMarker2.clone();
        intervalMarker2.setStartValue(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        double double7 = categoryAxis6.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getTickLabelInsets();
        java.awt.Paint paint10 = categoryAxis6.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font11 = categoryAxis6.getLabelFont();
        double double12 = categoryAxis6.getLowerMargin();
        categoryAxis6.setCategoryMargin(0.05d);
        categoryAxis6.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        double double19 = categoryAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis18.getTickLabelInsets();
        double double22 = rectangleInsets20.trimWidth((double) (-1));
        double double23 = rectangleInsets20.getRight();
        categoryAxis6.setLabelInsets(rectangleInsets20);
        categoryAxis1.setTickLabelInsets(rectangleInsets20);
        java.lang.String str26 = rectangleInsets20.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-9.0d) + "'", double22 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str26.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass9 = color8.getClass();
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.Class class12 = null;
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone14);
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.lang.Class class21 = null;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone23);
        java.lang.Class class26 = null;
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date19, timeZone28);
        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color32 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass33 = color32.getClass();
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        java.lang.Class class36 = null;
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date31, timeZone38);
        try {
            java.util.EventListener[] eventListenerArray42 = intervalMarker2.getListeners((java.lang.Class) wildcardClass9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            xYPlot13.addAnnotation(xYAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-1.0f), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        java.awt.Color color3 = java.awt.Color.blue;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        double double6 = categoryAxis5.getLowerMargin();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        categoryAxis5.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        double double11 = categoryPlot10.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot10.getDataset((int) (byte) 1);
        categoryAxis5.setPlot((org.jfree.chart.plot.Plot) categoryPlot10);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getOutlineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, paint1, stroke2, (java.awt.Paint) color3, stroke16, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis14.setNegativeArrowVisible(false);
        boolean boolean17 = numberAxis14.isNegativeArrowVisible();
        java.lang.String str18 = numberAxis14.getLabelURL();
        int int19 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        java.lang.Object obj6 = intervalMarker2.clone();
        java.lang.String str7 = intervalMarker2.getLabel();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-65281) + "'", int2 == (-65281));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.trimHeight((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-4.0d) + "'", double5 == (-4.0d));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day1.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        java.text.NumberFormat numberFormat4 = null;
        numberAxis1.setNumberFormatOverride(numberFormat4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Shape shape16 = numberAxis13.getDownArrow();
        numberAxis13.setUpperMargin((double) 100.0f);
        double double19 = numberAxis13.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str24 = categoryPlot23.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryPlot23.setNoDataMessageFont(font26);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot23.addDomainMarker((int) 'a', categoryMarker30, layer31);
        java.util.Collection collection33 = xYPlot21.getRangeMarkers(3, layer31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot21.getRangeAxisEdge();
        try {
            double double35 = numberAxis1.lengthToJava2D((-4.0d), rectangle2D7, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot1.getFixedLegendItems();
        java.awt.Image image3 = null;
        categoryPlot1.setBackgroundImage(image3);
        categoryPlot1.clearAnnotations();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) categoryPlot1);
        int int7 = categoryPlot1.getRangeAxisCount();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart13);
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        chartChangeEvent14.setChart(jFreeChart15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes((double) 1L, (double) 100.0f, plotRenderingInfo4, point2D5);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot6.getIndexOf(categoryItemRenderer14);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        double double19 = categoryPlot18.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot18.getDataset((int) (byte) 1);
        boolean boolean22 = categoryPlot18.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot18.getRangeAxis(255);
        categoryPlot18.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot18.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str35 = categoryPlot34.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryPlot34.setNoDataMessageFont(font37);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot34.addDomainMarker((int) 'a', categoryMarker41, layer42);
        categoryPlot18.addDomainMarker(categoryMarker33, layer42);
        try {
            categoryPlot6.addRangeMarker((-16777216), marker17, layer42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(layer42);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) ' ', (double) (byte) 10, plotRenderingInfo7, point2D8);
        double double10 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        java.awt.Color color19 = java.awt.Color.WHITE;
        java.awt.Color color20 = color19.darker();
        categoryAxis17.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        double double23 = categoryPlot22.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot22.getDataset((int) (byte) 1);
        categoryAxis17.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot22.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        categoryPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle((double) 0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setNegativeArrowVisible(false);
        java.awt.Shape shape14 = numberAxis11.getDownArrow();
        numberAxis11.setUpperMargin((double) 100.0f);
        double double17 = numberAxis11.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer18);
        boolean boolean20 = xYPlot19.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot19.getRangeAxisEdge(11);
        try {
            double double23 = categoryAxis0.getCategoryMiddle((int) (byte) -1, (int) (short) 100, rectangle2D5, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Color color2 = color1.brighter();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        double double5 = categoryPlot4.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot4.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot4.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot4.getDataRange(valueAxis10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot4.setNoDataMessagePaint(paint12);
        java.awt.Color color14 = java.awt.Color.blue;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot17.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot17.getRangeAxis();
        java.awt.Stroke stroke20 = categoryPlot17.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 2.0d, (java.awt.Paint) color2, stroke3, paint16, stroke20, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        double double11 = categoryAxis1.getCategoryMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot13.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot13.getRangeAxis();
        java.awt.Stroke stroke16 = categoryPlot13.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot13.setRenderer(2, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot13.getOutlineStroke();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot22.getFixedLegendItems();
        java.awt.Image image24 = null;
        categoryPlot22.setBackgroundImage(image24);
        java.util.List list26 = categoryPlot22.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot22.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace29 = categoryAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot13, rectangle2D21, rectangleEdge27, axisSpace28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin(0.05d);
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        java.lang.String str12 = categoryAxis1.getLabel();
        categoryAxis1.setLabel("java.awt.Color[r=0,g=0,b=255]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        java.util.List list4 = categoryPlot2.getCategories();
        boolean boolean5 = categoryPlot2.isDomainZoomable();
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        int int4 = xYPlot0.indexOf(xYDataset3);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        java.awt.Paint paint19 = xYPlot13.getDomainCrosshairPaint();
        java.awt.Stroke stroke20 = null;
        try {
            xYPlot13.setRangeGridlineStroke(stroke20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot10.getRendererForDataset(categoryDataset17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            categoryPlot10.addAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryItemRenderer18);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        java.lang.String str2 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str2.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint5 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        boolean boolean11 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot7.getRangeAxis(255);
        categoryPlot7.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo17, point2D18, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str24 = categoryPlot23.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryPlot23.setNoDataMessageFont(font26);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot23.addDomainMarker((int) 'a', categoryMarker30, layer31);
        categoryPlot7.addDomainMarker(categoryMarker22, layer31);
        try {
            categoryPlot0.addDomainMarker(categoryMarker6, layer31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(layer31);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot5.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot5.getDomainAxisLocation(255);
        java.lang.String str10 = axisLocation9.toString();
        categoryPlot0.setDomainAxisLocation(axisLocation9, false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str10.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        boolean boolean13 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker12);
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass15 = color14.getClass();
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.lang.Class class18 = null;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        try {
            java.util.EventListener[] eventListenerArray24 = categoryMarker12.getListeners(class23);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Millisecond; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.calculateRightInset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setNegativeArrowVisible(false);
        java.awt.Shape shape14 = numberAxis11.getDownArrow();
        numberAxis11.setUpperMargin((double) 100.0f);
        double double17 = numberAxis11.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str22 = categoryPlot21.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryPlot21.setNoDataMessageFont(font24);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot21.addDomainMarker((int) 'a', categoryMarker28, layer29);
        java.util.Collection collection31 = xYPlot19.getRangeMarkers(3, layer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot19.getRangeAxisEdge();
        try {
            double double33 = numberAxis1.lengthToJava2D(0.0d, rectangle2D5, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray25 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer24 };
        categoryPlot23.setRenderers(categoryItemRendererArray25);
        categoryPlot23.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot23.setDataset(categoryDataset29);
        java.awt.Paint paint31 = categoryPlot23.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot23.getRendererForDataset(categoryDataset32);
        int int34 = categoryPlot23.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        double double37 = categoryAxis36.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener38 = null;
        categoryAxis36.addChangeListener(axisChangeListener38);
        categoryAxis36.setLabelAngle((double) 100);
        boolean boolean42 = categoryAxis36.isTickLabelsVisible();
        categoryAxis36.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint46 = categoryAxis36.getTickLabelPaint((java.lang.Comparable) 100);
        double double47 = categoryAxis36.getUpperMargin();
        double double48 = categoryAxis36.getLowerMargin();
        int int49 = categoryPlot23.getDomainAxisIndex(categoryAxis36);
        categoryPlot0.setDomainAxis(categoryAxis36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        double double28 = categoryPlot27.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot27.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot27.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.Range range34 = categoryPlot27.getDataRange(valueAxis33);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        java.awt.Color color37 = java.awt.Color.blue;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color37);
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color37);
        java.awt.color.ColorSpace colorSpace40 = color37.getColorSpace();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNull(categoryAxis32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace40);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint9 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot10.getRangeAxis();
        java.awt.Stroke stroke13 = categoryPlot10.getRangeGridlineStroke();
        categoryPlot10.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        intervalMarker18.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint21 = intervalMarker18.getLabelPaint();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = categoryPlot10.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker18, layer22, true);
        java.util.Collection collection25 = categoryPlot0.getDomainMarkers(layer22);
        categoryPlot0.clearRangeMarkers((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot5.getDataset((int) (byte) 1);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot5.getRangeAxis(255);
        categoryPlot5.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16, true);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot5.getRowRenderingOrder();
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot5.zoomDomainAxes(100.0d, plotRenderingInfo22, point2D23, true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis2.getTickLabelInsets();
        java.awt.Paint paint6 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font7 = categoryAxis2.getLabelFont();
        double double8 = categoryAxis2.getLowerMargin();
        categoryAxis2.setTickMarkOutsideLength((float) 100L);
        boolean boolean11 = lengthAdjustmentType0.equals((java.lang.Object) 100L);
        java.lang.String str12 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "EXPAND" + "'", str12.equals("EXPAND"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean13 = sortOrder11.equals((java.lang.Object) lengthAdjustmentType12);
        java.lang.String str14 = sortOrder11.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SortOrder.ASCENDING" + "'", str14.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin(0.05d);
        categoryAxis1.setLabelAngle((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        boolean boolean2 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str5 = categoryPlot4.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font7 = categoryAxis6.getLabelFont();
        categoryPlot4.setNoDataMessageFont(font7);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot4.addDomainMarker((int) 'a', categoryMarker11, layer12);
        java.lang.String str14 = layer12.toString();
        try {
            categoryPlot0.addRangeMarker(marker3, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNull(axisSpace3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        double double7 = categoryAxis6.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getTickLabelInsets();
        java.awt.Paint paint10 = categoryAxis6.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font11 = categoryAxis6.getLabelFont();
        double double12 = categoryAxis6.getLowerMargin();
        categoryAxis6.setCategoryMargin(0.05d);
        categoryAxis6.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        double double19 = categoryAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis18.getTickLabelInsets();
        double double22 = rectangleInsets20.trimWidth((double) (-1));
        double double23 = rectangleInsets20.getRight();
        categoryAxis6.setLabelInsets(rectangleInsets20);
        categoryAxis1.setTickLabelInsets(rectangleInsets20);
        double double27 = rectangleInsets20.calculateLeftOutset((double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-9.0d) + "'", double22 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis25.setNegativeArrowVisible(false);
        java.awt.Shape shape28 = numberAxis25.getDownArrow();
        numberAxis25.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = numberAxis25.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis33.setNegativeArrowVisible(false);
        org.jfree.data.Range range36 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis33.setRange(range36, true, false);
        numberAxis25.setRangeWithMargins(range36, false, true);
        numberAxis18.setRangeWithMargins(range36);
        java.awt.Shape shape44 = null;
        try {
            numberAxis18.setDownArrow(shape44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(markerAxisBand31);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot13.draw(graphics2D18, rectangle2D19, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        org.jfree.data.Range range19 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            xYPlot13.addAnnotation(xYAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        categoryPlot0.notifyListeners(plotChangeEvent6);
        categoryPlot0.setForegroundAlpha((float) (-16777216));
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getFirstMillisecond();
//        int int3 = day1.getMonth();
//        int int4 = day1.getYear();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.clearRangeAxes();
        try {
            categoryPlot0.setBackgroundImageAlpha(100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot0.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot0.setDomainAxis(6, categoryAxis11, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            categoryPlot0.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot0.getDomainAxis(3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(11, categoryItemRenderer14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        double double9 = categoryAxis8.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis8.getTickLabelInsets();
        double double12 = rectangleInsets10.calculateLeftOutset(0.0d);
        categoryPlot0.setAxisOffset(rectangleInsets10);
        org.jfree.chart.plot.Plot plot14 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNotNull(plot14);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.lang.Class class2 = null;
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date0, timeZone4);
//        long long7 = day6.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.lang.Object obj3 = null;
        boolean boolean4 = defaultDrawingSupplier0.equals(obj3);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        categoryPlot6.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Font font14 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        xYPlot13.clearRangeMarkers();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setDomainCrosshairStroke(stroke27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot13.setRenderer(xYItemRenderer29);
        boolean boolean31 = xYPlot13.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        java.awt.Color color22 = java.awt.Color.lightGray;
        intervalMarker10.setOutlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) color1);
        int int3 = color1.getAlpha();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.util.List list4 = categoryPlot0.getCategories();
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor10);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        xYPlot13.clearRangeMarkers();
        boolean boolean27 = xYPlot13.isDomainZeroBaselineVisible();
        xYPlot13.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        xYPlot13.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke26 = xYPlot13.getDomainCrosshairStroke();
        java.awt.Stroke stroke27 = null;
        try {
            xYPlot13.setDomainGridlineStroke(stroke27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13, stroke14 };
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray9, strokeArray15, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        boolean boolean21 = defaultDrawingSupplier17.equals((java.lang.Object) categoryAxis20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot25.getRangeAxisEdge();
        try {
            double double27 = categoryAxis20.getCategoryEnd(0, (-65281), rectangle2D24, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.lang.Class class2 = null;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date0, timeZone4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        double double5 = numberAxis1.getUpperBound();
        numberAxis1.resizeRange((double) (byte) 100, (double) (-16777216));
        try {
            numberAxis1.setRange((double) 3, (-16.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3.0) <= upper (-16.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.clearRangeAxes();
        try {
            categoryPlot0.mapDatasetToDomainAxis((int) (byte) -1, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        boolean boolean11 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot7.getRangeAxis(255);
        categoryPlot7.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis17.getTickLabelInsets();
        java.awt.Paint paint20 = categoryAxis17.getTickLabelPaint();
        categoryAxis17.setLowerMargin((-1.0d));
        java.util.List list23 = categoryPlot7.getCategoriesForAxis(categoryAxis17);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.util.SortOrder sortOrder26 = null;
        try {
            categoryPlot7.setRowRenderingOrder(sortOrder26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(255);
        categoryPlot0.setBackgroundAlpha((float) 100L);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(drawingSupplier14);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        double double3 = numberAxis1.getLabelAngle();
        double double4 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        double double7 = categoryAxis6.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getTickLabelInsets();
        java.awt.Paint paint10 = categoryAxis6.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font11 = categoryAxis6.getLabelFont();
        intervalMarker2.setLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean16 = chartChangeEventType14.equals((java.lang.Object) color15);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) font11, jFreeChart13, chartChangeEventType14);
        java.lang.Object obj18 = chartChangeEvent17.getSource();
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        chartChangeEvent17.setChart(jFreeChart19);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 4, (double) 11, (double) '4', (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        java.awt.Color color7 = java.awt.Color.WHITE;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color7);
        categoryAxis1.setTickMarkInsideLength((float) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        double double13 = categoryAxis12.getLowerMargin();
        java.awt.Paint paint15 = categoryAxis12.getTickLabelPaint((java.lang.Comparable) 'a');
        categoryAxis1.setTickMarkPaint(paint15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        xYPlot13.setRangeCrosshairValue(0.2d, true);
        java.lang.Object obj25 = xYPlot13.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor23);
        java.lang.String str25 = categoryAnchor23.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str25.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        double double7 = categoryAxis6.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getTickLabelInsets();
        categoryAxis6.setUpperMargin((-1.0d));
        java.awt.Font font11 = categoryAxis6.getTickLabelFont();
        numberAxis1.setLabelFont(font11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        int int6 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        double double12 = categoryPlot11.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot11.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            org.jfree.chart.axis.AxisState axisState19 = categoryAxis1.draw(graphics2D7, 10.0d, rectangle2D9, rectangle2D10, rectangleEdge17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        categoryPlot6.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot6.getRenderer();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot6 = numberAxis1.getPlot();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot9.getRangeAxisEdge((int) (short) 100);
        try {
            double double12 = numberAxis1.lengthToJava2D((double) (-1L), rectangle2D8, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) -1, (float) 1560409200000L, (-1.0f));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) datasetRenderingOrder2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        try {
            categoryPlot0.zoom((double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) ' ', (double) (byte) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        categoryPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot5.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot5.getDomainAxisLocation(255);
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        java.lang.Object obj13 = null;
        boolean boolean14 = categoryPlot0.equals(obj13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRange(false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int9 = color8.getAlpha();
        numberAxis1.setLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot11.getFixedLegendItems();
        java.awt.Image image13 = null;
        categoryPlot11.setBackgroundImage(image13);
        categoryPlot11.clearAnnotations();
        boolean boolean16 = numberAxis1.equals((java.lang.Object) categoryPlot11);
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getRangeAxisLocation((int) (short) 0);
        java.awt.Paint paint5 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke6 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.util.List list10 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str2.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double17 = numberAxis16.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis19.setNegativeArrowVisible(false);
        java.awt.Shape shape22 = numberAxis19.getDownArrow();
        numberAxis19.setUpperMargin((double) 100.0f);
        double double25 = numberAxis19.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation30);
        xYPlot27.setDomainAxisLocation(11, axisLocation29);
        java.awt.Paint paint33 = xYPlot27.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation34, plotOrientation35);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation37, plotOrientation38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation34, plotOrientation38);
        xYPlot27.setDomainAxisLocation(axisLocation34);
        categoryPlot0.setRangeAxisLocation((int) (short) 100, axisLocation34);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        double double5 = categoryAxis1.getLowerMargin();
        categoryAxis1.setFixedDimension((-1.0d));
        java.lang.Comparable comparable9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            double double14 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 100.0f, comparable9, categoryDataset10, (double) 1L, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        try {
            java.awt.Paint paint23 = xYPlot13.getQuadrantPaint((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        xYPlot13.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke26 = xYPlot13.getDomainCrosshairStroke();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot13.drawRangeTickBands(graphics2D27, rectangle2D28, list29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        categoryPlot0.notifyListeners(plotChangeEvent6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            boolean boolean11 = categoryPlot0.removeRangeMarker((int) (byte) -1, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(layer10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        double double29 = categoryAxis28.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        categoryAxis28.addChangeListener(axisChangeListener30);
        categoryAxis28.setLabelAngle((double) 100);
        java.awt.Color color34 = java.awt.Color.WHITE;
        categoryAxis28.setTickMarkPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getLowerMargin();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis37.setAxisLineStroke(stroke39);
        java.awt.Color color43 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color34, stroke39, (java.awt.Paint) color43, stroke44, 0.0f);
        xYPlot13.setDomainGridlineStroke(stroke44);
        xYPlot13.clearRangeMarkers();
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        try {
            xYPlot13.drawBackground(graphics2D49, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor23);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categoryAnchor23);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = null;
        intervalMarker6.setGradientPaintTransformer(gradientPaintTransformer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        double double11 = categoryAxis10.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        java.awt.Paint paint14 = categoryAxis10.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font15 = categoryAxis10.getLabelFont();
        intervalMarker6.setLabelFont(font15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker6.setLabelAnchor(rectangleAnchor17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str20 = categoryPlot19.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font22 = categoryAxis21.getLabelFont();
        categoryPlot19.setNoDataMessageFont(font22);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot19.addDomainMarker((int) 'a', categoryMarker26, layer27);
        boolean boolean29 = rectangleAnchor17.equals((java.lang.Object) categoryMarker26);
        categoryPlot0.addDomainMarker(categoryMarker26);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.JFreeChart jFreeChart23 = markerChangeEvent22.getChart();
        java.lang.String str24 = markerChangeEvent22.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(jFreeChart23);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        boolean boolean8 = categoryAxis2.isTickLabelsVisible();
        categoryAxis2.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint12 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) 100);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot15.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis22.setNegativeArrowVisible(false);
        java.awt.Shape shape25 = numberAxis22.getDownArrow();
        boolean boolean26 = numberAxis22.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot27 = numberAxis22.getPlot();
        int int28 = xYPlot15.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer29);
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge();
        java.util.List list7 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        java.awt.Color color6 = color3.brighter();
        int int7 = color6.getRGB();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        double double12 = categoryAxis1.getLowerMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint17 = categoryAxis14.getTickLabelPaint();
        int int18 = categoryAxis14.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        double double21 = categoryAxis20.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        categoryAxis20.addChangeListener(axisChangeListener22);
        categoryAxis20.setLabelAngle((double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis20.getTickLabelInsets();
        categoryAxis14.setTickLabelInsets(rectangleInsets26);
        categoryAxis1.setTickLabelInsets(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean13 = categoryPlot0.removeAnnotation(categoryAnnotation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot0.getRowRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis20.setNegativeArrowVisible(false);
        java.awt.Shape shape23 = numberAxis20.getDownArrow();
        numberAxis20.setUpperMargin((double) 100.0f);
        double double26 = numberAxis20.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str31 = categoryPlot30.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font33 = categoryAxis32.getLabelFont();
        categoryPlot30.setNoDataMessageFont(font33);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot30.addDomainMarker((int) 'a', categoryMarker37, layer38);
        java.util.Collection collection40 = xYPlot28.getRangeMarkers(3, layer38);
        java.util.Collection collection41 = categoryPlot0.getRangeMarkers(layer38);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNull(collection41);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double28 = numberAxis27.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis30.setNegativeArrowVisible(false);
        java.awt.Shape shape33 = numberAxis30.getDownArrow();
        numberAxis30.setUpperMargin((double) 100.0f);
        double double36 = numberAxis30.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis30, xYItemRenderer37);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str41 = categoryPlot40.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font43 = categoryAxis42.getLabelFont();
        categoryPlot40.setNoDataMessageFont(font43);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot40.addDomainMarker((int) 'a', categoryMarker47, layer48);
        java.util.Collection collection50 = xYPlot38.getRangeMarkers(3, layer48);
        xYPlot38.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot38.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 2.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo14, point2D15, false);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation20);
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation19, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int5 = color4.getAlpha();
        numberAxis1.setTickMarkPaint((java.awt.Paint) color4);
        java.lang.Object obj7 = null;
        boolean boolean8 = numberAxis1.equals(obj7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.trimWidth((double) (-1));
        double double7 = rectangleInsets3.calculateRightOutset(0.0d);
        double double9 = rectangleInsets3.calculateBottomInset((double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        boolean boolean5 = numberAxis1.isAutoRange();
        java.awt.Shape shape6 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) ' ', (double) (byte) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        double double12 = categoryPlot11.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot11.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot11.getDataRange(valueAxis17);
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        java.awt.Color color21 = java.awt.Color.blue;
        categoryPlot11.setNoDataMessagePaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot11.getIndexOf(categoryItemRenderer23);
        java.awt.Color color25 = java.awt.Color.darkGray;
        categoryPlot11.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        double double29 = categoryAxis28.getLowerMargin();
        java.awt.Color color30 = java.awt.Color.WHITE;
        java.awt.Color color31 = color30.darker();
        categoryAxis28.setTickMarkPaint((java.awt.Paint) color30);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        double double34 = categoryPlot33.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot33.getDataset((int) (byte) 1);
        categoryAxis28.setPlot((org.jfree.chart.plot.Plot) categoryPlot33);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot33.getRowRenderingOrder();
        categoryPlot11.setRowRenderingOrder(sortOrder38);
        categoryPlot0.setRowRenderingOrder(sortOrder38);
        java.util.List list41 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset36);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNull(list41);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        java.awt.Color color7 = java.awt.Color.GREEN;
        java.awt.Color color8 = java.awt.Color.getColor("UnitType.RELATIVE", color7);
        java.awt.Color color9 = color8.darker();
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        java.awt.Shape shape21 = numberAxis18.getDownArrow();
        numberAxis18.setUpperMargin((double) 100.0f);
        double double24 = numberAxis18.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer25);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str29 = categoryPlot28.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font31 = categoryAxis30.getLabelFont();
        categoryPlot28.setNoDataMessageFont(font31);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot28.addDomainMarker((int) 'a', categoryMarker35, layer36);
        java.util.Collection collection38 = xYPlot26.getRangeMarkers(3, layer36);
        xYPlot26.clearRangeMarkers();
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot26.setDomainCrosshairStroke(stroke40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        xYPlot26.setRenderer(xYItemRenderer42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot26.getDomainAxisLocation(2019);
        try {
            xYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setNegativeArrowVisible(false);
        java.awt.Shape shape14 = numberAxis11.getDownArrow();
        numberAxis11.setUpperMargin((double) 100.0f);
        double double17 = numberAxis11.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer18);
        boolean boolean20 = xYPlot19.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot19.getRangeAxisEdge(11);
        try {
            java.util.List list23 = categoryAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot10.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = null;
        categoryAxis24.setTickLabelFont((java.lang.Comparable) (-4.0d), font26);
        double double28 = categoryAxis24.getLowerMargin();
        categoryAxis24.setFixedDimension((-1.0d));
        boolean boolean31 = axisLocation22.equals((java.lang.Object) categoryAxis24);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double38 = numberAxis37.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis40.setNegativeArrowVisible(false);
        java.awt.Shape shape43 = numberAxis40.getDownArrow();
        numberAxis40.setUpperMargin((double) 100.0f);
        double double46 = numberAxis40.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis40, xYItemRenderer47);
        boolean boolean49 = xYPlot48.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot48.getRangeAxisEdge(11);
        try {
            double double52 = categoryAxis24.getCategoryStart(0, 500, rectangle2D34, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categoryAnchor23);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        double double4 = categoryAxis3.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis3.getTickLabelInsets();
        java.awt.Paint paint7 = categoryAxis3.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font8 = categoryAxis3.getLabelFont();
        double double9 = categoryAxis3.getLowerMargin();
        categoryAxis3.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot12.getFixedLegendItems();
        java.awt.Image image14 = null;
        categoryPlot12.setBackgroundImage(image14);
        java.util.List list16 = categoryPlot12.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot12.getDomainAxisEdge();
        boolean boolean18 = categoryAxis3.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        categoryPlot12.notifyListeners(plotChangeEvent19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot12.getRangeMarkers(4, layer22);
        categoryPlot12.mapDatasetToDomainAxis((int) (short) 100, (int) (byte) 10);
        boolean boolean27 = plotOrientation0.equals((java.lang.Object) categoryPlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = null;
        try {
            categoryPlot12.setInsets(rectangleInsets28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot0.axisChanged(axisChangeEvent9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer(categoryItemRenderer12, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        double double17 = categoryAxis16.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis16.getTickLabelInsets();
        double double20 = rectangleInsets18.trimWidth((double) (-1));
        double double21 = rectangleInsets18.getRight();
        java.lang.String str22 = rectangleInsets18.toString();
        categoryPlot0.setAxisOffset(rectangleInsets18);
        double double24 = rectangleInsets18.getTop();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-9.0d) + "'", double20 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str22.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        categoryPlot0.setForegroundAlpha(0.0f);
        int int10 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        double double12 = categoryPlot11.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot11.getDataset((int) (byte) 1);
        boolean boolean15 = categoryPlot11.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot11.getRangeAxis(255);
        categoryPlot11.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str28 = categoryPlot27.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font30 = categoryAxis29.getLabelFont();
        categoryPlot27.setNoDataMessageFont(font30);
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot27.addDomainMarker((int) 'a', categoryMarker34, layer35);
        categoryPlot11.addDomainMarker(categoryMarker26, layer35);
        categoryPlot0.addDomainMarker(categoryMarker26);
        java.awt.Paint paint39 = categoryMarker26.getOutlinePaint();
        categoryMarker26.setLabel("Layer.FOREGROUND");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7, true);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color2 = java.awt.Color.BLACK;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color2);
        int int4 = color2.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot5.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot5.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot5.getDataRange(valueAxis11);
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot5.setNoDataMessagePaint(paint13);
        java.awt.Color color15 = java.awt.Color.blue;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot5.getIndexOf(categoryItemRenderer17);
        java.awt.Color color19 = java.awt.Color.darkGray;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color19);
        java.util.List list21 = categoryPlot5.getAnnotations();
        boolean boolean22 = color2.equals((java.lang.Object) list21);
        int int23 = color2.getGreen();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        double double14 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis20.setNegativeArrowVisible(false);
        java.awt.Shape shape23 = numberAxis20.getDownArrow();
        numberAxis20.setUpperMargin((double) 100.0f);
        double double26 = numberAxis20.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str31 = categoryPlot30.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font33 = categoryAxis32.getLabelFont();
        categoryPlot30.setNoDataMessageFont(font33);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot30.addDomainMarker((int) 'a', categoryMarker37, layer38);
        java.util.Collection collection40 = xYPlot28.getRangeMarkers(3, layer38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot28.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        double double43 = categoryPlot42.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot42.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = categoryPlot42.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.data.Range range49 = categoryPlot42.getDataRange(valueAxis48);
        java.awt.Paint paint50 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot42.setNoDataMessagePaint(paint50);
        java.awt.Color color52 = java.awt.Color.blue;
        categoryPlot42.setNoDataMessagePaint((java.awt.Paint) color52);
        xYPlot28.setDomainTickBandPaint((java.awt.Paint) color52);
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertNull(categoryAxis47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(color52);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        boolean boolean13 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot6.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(sortOrder14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        boolean boolean11 = numberAxis7.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot12 = numberAxis7.getPlot();
        int int13 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Paint paint14 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot5.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot5.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot5.getDataRange(valueAxis11);
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot5.setNoDataMessagePaint(paint13);
        java.awt.Color color15 = java.awt.Color.blue;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot5.getIndexOf(categoryItemRenderer17);
        java.awt.Color color19 = java.awt.Color.darkGray;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color19);
        java.util.List list21 = categoryPlot5.getAnnotations();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis28.setNegativeArrowVisible(false);
        java.awt.Shape shape31 = numberAxis28.getDownArrow();
        numberAxis28.setUpperMargin((double) 100.0f);
        double double34 = numberAxis28.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer35);
        boolean boolean37 = xYPlot36.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot36.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace41 = numberAxis1.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) categoryPlot5, rectangle2D22, rectangleEdge39, axisSpace40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        xYPlot13.setBackgroundImageAlignment((int) (byte) 100);
        xYPlot13.setRangeCrosshairValue((double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        double double24 = categoryAxis23.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis23.getTickLabelInsets();
        java.awt.Paint paint27 = categoryAxis23.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font28 = categoryAxis23.getLabelFont();
        double double29 = categoryAxis23.getLowerMargin();
        categoryAxis23.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot32.getFixedLegendItems();
        java.awt.Image image34 = null;
        categoryPlot32.setBackgroundImage(image34);
        java.util.List list36 = categoryPlot32.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot32.getDomainAxisEdge();
        boolean boolean38 = categoryAxis23.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis40.setNegativeArrowVisible(false);
        categoryPlot32.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis40);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis40.setTickLabelPaint((java.awt.Paint) color44);
        boolean boolean46 = numberAxis40.isNegativeArrowVisible();
        boolean boolean47 = intervalMarker10.equals((java.lang.Object) numberAxis40);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double50 = numberAxis49.getUpperMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = numberAxis49.getMarkerBand();
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis49.setStandardTickUnits(tickUnitSource52);
        numberAxis40.setStandardTickUnits(tickUnitSource52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNull(list36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand51);
        org.junit.Assert.assertNotNull(tickUnitSource52);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRange(false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int9 = color8.getAlpha();
        numberAxis1.setLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot11.getFixedLegendItems();
        java.awt.Image image13 = null;
        categoryPlot11.setBackgroundImage(image13);
        categoryPlot11.clearAnnotations();
        boolean boolean16 = numberAxis1.equals((java.lang.Object) categoryPlot11);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        double double12 = categoryAxis11.getLowerMargin();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color8, stroke13, (java.awt.Paint) color17, stroke18, 0.0f);
        double double21 = valueMarker20.getValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        categoryPlot6.mapDatasetToDomainAxis((int) '4', 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        xYPlot13.setRangeZeroBaselineVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        double double31 = categoryAxis30.getLowerMargin();
        java.awt.Color color32 = java.awt.Color.WHITE;
        java.awt.Color color33 = color32.darker();
        categoryAxis30.setTickMarkPaint((java.awt.Paint) color32);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        double double36 = categoryPlot35.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot35.getDataset((int) (byte) 1);
        categoryAxis30.setPlot((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.util.SortOrder sortOrder40 = categoryPlot35.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot35.setRenderer(categoryItemRenderer41);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis44.setNegativeArrowVisible(false);
        org.jfree.data.Range range47 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis44.setRange(range47, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double53 = numberAxis52.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double56 = numberAxis55.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis58.setNegativeArrowVisible(false);
        java.awt.Shape shape61 = numberAxis58.getDownArrow();
        double double62 = numberAxis58.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double65 = numberAxis64.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis67.setNegativeArrowVisible(false);
        java.awt.Paint paint70 = numberAxis67.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray71 = new org.jfree.chart.axis.ValueAxis[] { numberAxis44, numberAxis52, numberAxis55, numberAxis58, numberAxis64, numberAxis67 };
        categoryPlot35.setRangeAxes(valueAxisArray71);
        xYPlot13.setDomainAxes(valueAxisArray71);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder40);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0E-8d + "'", double53 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0E-8d + "'", double56 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0E-8d + "'", double65 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(valueAxisArray71);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setCategoryMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        double double7 = categoryAxis6.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getTickLabelInsets();
        java.awt.Paint paint10 = categoryAxis6.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font11 = categoryAxis6.getLabelFont();
        intervalMarker2.setLabelFont(font11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker2.setLabelAnchor(rectangleAnchor13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        boolean boolean25 = rectangleAnchor13.equals((java.lang.Object) categoryMarker22);
        categoryMarker22.setDrawAsLine(true);
        boolean boolean28 = categoryMarker22.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str1.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        double double21 = categoryAxis20.getLowerMargin();
        java.awt.Color color22 = java.awt.Color.WHITE;
        java.awt.Color color23 = color22.darker();
        categoryAxis20.setTickMarkPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        categoryAxis20.setPlot((org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot25.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot25.getRangeAxisLocation();
        xYPlot13.setRangeAxisLocation(axisLocation31, true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        try {
            xYPlot13.setDomainAxisLocation(axisLocation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        xYPlot13.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke26 = xYPlot13.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = xYPlot27.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        java.awt.Color color33 = java.awt.Color.red;
        xYPlot27.setDomainGridlinePaint((java.awt.Paint) color33);
        xYPlot13.setBackgroundPaint((java.awt.Paint) color33);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.darker();
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot7.getRowRenderingOrder();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean14 = sortOrder12.equals((java.lang.Object) chartChangeEventType13);
        java.lang.String str15 = sortOrder12.toString();
        boolean boolean16 = categoryAnchor0.equals((java.lang.Object) str15);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "SortOrder.ASCENDING" + "'", str15.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 100, (-9.0d), plotRenderingInfo15, point2D16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        double double29 = categoryAxis28.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        categoryAxis28.addChangeListener(axisChangeListener30);
        categoryAxis28.setLabelAngle((double) 100);
        java.awt.Color color34 = java.awt.Color.WHITE;
        categoryAxis28.setTickMarkPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getLowerMargin();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis37.setAxisLineStroke(stroke39);
        java.awt.Color color43 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color34, stroke39, (java.awt.Paint) color43, stroke44, 0.0f);
        xYPlot13.setDomainGridlineStroke(stroke44);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        double double51 = categoryAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryAxis50.getTickLabelInsets();
        java.awt.Paint paint54 = categoryAxis50.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font55 = categoryAxis50.getLabelFont();
        double double56 = categoryAxis50.getLowerMargin();
        categoryAxis50.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot59.getFixedLegendItems();
        java.awt.Image image61 = null;
        categoryPlot59.setBackgroundImage(image61);
        java.util.List list63 = categoryPlot59.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot59.getDomainAxisEdge();
        boolean boolean65 = categoryAxis50.hasListener((java.util.EventListener) categoryPlot59);
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis67.setNegativeArrowVisible(false);
        categoryPlot59.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis67);
        java.lang.String str71 = numberAxis67.getLabelURL();
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis73.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource76 = numberAxis73.getStandardTickUnits();
        numberAxis67.setStandardTickUnits(tickUnitSource76);
        double double78 = numberAxis67.getAutoRangeMinimumSize();
        xYPlot13.setDomainAxis(5, (org.jfree.chart.axis.ValueAxis) numberAxis67, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection60);
        org.junit.Assert.assertNull(list63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(tickUnitSource76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0E-8d + "'", double78 == 1.0E-8d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot0.getFixedRangeAxisSpace();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stroke11, dataset12);
        org.jfree.data.general.Dataset dataset14 = datasetChangeEvent13.getDataset();
        categoryPlot0.datasetChanged(datasetChangeEvent13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(dataset14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot6.setDataset(categoryDataset13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        double double5 = categoryAxis4.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis4.getTickLabelInsets();
        java.awt.Paint paint8 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font9 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-1.0d), font9);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 10L, (float) ' ', (float) 11);
        org.junit.Assert.assertNotNull(color3);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.lang.String str2 = day1.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day1.next();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        java.util.List list6 = categoryPlot0.getCategories();
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation9, plotOrientation10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation9.getOpposite();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean14 = axisLocation12.equals((java.lang.Object) categoryAxis13);
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation12, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        boolean boolean11 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot7.getRangeAxis(255);
        categoryPlot7.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis17.getTickLabelInsets();
        java.awt.Paint paint20 = categoryAxis17.getTickLabelPaint();
        categoryAxis17.setLowerMargin((-1.0d));
        java.util.List list23 = categoryPlot7.getCategoriesForAxis(categoryAxis17);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        java.awt.Font font25 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        double double6 = numberAxis1.getLabelAngle();
        numberAxis1.setAutoRangeMinimumSize((double) 5, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.Marker marker7 = markerChangeEvent6.getMarker();
        java.awt.Stroke stroke8 = marker7.getOutlineStroke();
        java.awt.Paint paint9 = marker7.getLabelPaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(marker7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        java.util.List list16 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot0.getRangeAxisEdge(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.lang.Class class4 = null;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date2, timeZone6);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class10 = null;
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass15 = color14.getClass();
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.lang.Class class18 = null;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date11, timeZone20);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone20);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(tickUnitSource24);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot0.getIndexOf(categoryItemRenderer8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double13 = numberAxis12.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        java.awt.Shape shape18 = numberAxis15.getDownArrow();
        numberAxis15.setUpperMargin((double) 100.0f);
        double double21 = numberAxis15.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str26 = categoryPlot25.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font28 = categoryAxis27.getLabelFont();
        categoryPlot25.setNoDataMessageFont(font28);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot25.addDomainMarker((int) 'a', categoryMarker32, layer33);
        java.util.Collection collection35 = xYPlot23.getRangeMarkers(3, layer33);
        xYPlot23.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot23.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation37, true);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        intervalMarker8.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Paint paint11 = intervalMarker8.getLabelPaint();
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = categoryPlot0.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker8, layer12, true);
        java.util.List list15 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot0.getFixedRangeAxisSpace();
        try {
            categoryPlot0.zoom((double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot5.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxis();
        java.awt.Stroke stroke8 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = null;
        intervalMarker13.setGradientPaintTransformer(gradientPaintTransformer14);
        java.awt.Paint paint16 = intervalMarker13.getLabelPaint();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean19 = categoryPlot5.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker13, layer17, true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot20.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setDomainCrosshairStroke(stroke23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot20.getRendererForDataset(xYDataset25);
        java.awt.Stroke stroke27 = xYPlot20.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = xYPlot20.getDomainMarkers(4, layer29);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer29);
        xYPlot0.setRangeCrosshairValue((double) (byte) 0, false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range4, true, false);
        org.jfree.data.Range range8 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        double double13 = categoryAxis1.getLowerMargin();
        categoryAxis1.setAxisLineVisible(true);
        categoryAxis1.setLowerMargin((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        java.awt.Color color19 = java.awt.Color.WHITE;
        java.awt.Color color20 = color19.darker();
        categoryAxis17.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        double double23 = categoryPlot22.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot22.getDataset((int) (byte) 1);
        categoryAxis17.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot22.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertNotNull(sortOrder27);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setNegativeArrowVisible(false);
        java.awt.Paint paint15 = numberAxis12.getTickMarkPaint();
        org.jfree.data.Range range16 = numberAxis12.getRange();
        numberAxis1.setDefaultAutoRange(range16);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.centerRange((double) (byte) 0);
        numberAxis1.setVisible(true);
        java.awt.Paint paint8 = numberAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.lang.String str2 = day1.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day1.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray8 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer7 };
        categoryPlot6.setRenderers(categoryItemRendererArray8);
        categoryPlot6.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        categoryPlot6.drawBackgroundImage(graphics2D12, rectangle2D13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot6.getRendererForDataset(categoryDataset15);
        boolean boolean17 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray8);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color22 = java.awt.Color.BLACK;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color22);
        int int24 = color22.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Color color35 = java.awt.Color.blue;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot25.getIndexOf(categoryItemRenderer37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color39);
        java.util.List list41 = categoryPlot25.getAnnotations();
        boolean boolean42 = color22.equals((java.lang.Object) list41);
        xYPlot13.drawRangeTickBands(graphics2D18, rectangle2D19, list41);
        int int44 = xYPlot13.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot45.getFixedLegendItems();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        categoryPlot45.drawBackgroundImage(graphics2D47, rectangle2D48);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str51 = categoryAnchor50.toString();
        categoryPlot45.setDomainGridlinePosition(categoryAnchor50);
        xYPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot45);
        boolean boolean54 = xYPlot13.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double58 = numberAxis57.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis60.setNegativeArrowVisible(false);
        java.awt.Shape shape63 = numberAxis60.getDownArrow();
        numberAxis60.setUpperMargin((double) 100.0f);
        double double66 = numberAxis60.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) numberAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis60, xYItemRenderer67);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit69 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis60.setTickUnit(numberTickUnit69, true, true);
        xYPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis60);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(categoryAnchor50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "CategoryAnchor.END" + "'", str51.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit69);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((int) 'a', categoryMarker7, layer8);
        java.lang.Comparable comparable10 = categoryMarker7.getKey();
        boolean boolean11 = categoryMarker7.getDrawAsLine();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", comparable10.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot13.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRendererForDataset(xYDataset26);
        java.awt.Stroke stroke28 = xYPlot21.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot21.getDomainMarkers(4, layer30);
        java.util.Collection collection32 = xYPlot13.getDomainMarkers(layer30);
        xYPlot13.setRangeCrosshairValue((double) (-65281));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot1.getFixedLegendItems();
        java.awt.Image image3 = null;
        categoryPlot1.setBackgroundImage(image3);
        categoryPlot1.clearAnnotations();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.util.List list9 = categoryPlot1.getCategoriesForAxis(categoryAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        double double11 = categoryPlot10.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot10.getDataset((int) (byte) 1);
        boolean boolean14 = categoryPlot10.isRangeCrosshairVisible();
        java.awt.Paint paint15 = categoryPlot10.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot10.zoomRangeAxes((double) 1, (double) 1, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot10.getDomainGridlinePosition();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double28 = numberAxis27.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis30.setNegativeArrowVisible(false);
        java.awt.Shape shape33 = numberAxis30.getDownArrow();
        numberAxis30.setUpperMargin((double) 100.0f);
        double double36 = numberAxis30.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis30, xYItemRenderer37);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str41 = categoryPlot40.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font43 = categoryAxis42.getLabelFont();
        categoryPlot40.setNoDataMessageFont(font43);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot40.addDomainMarker((int) 'a', categoryMarker47, layer48);
        java.util.Collection collection50 = xYPlot38.getRangeMarkers(3, layer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot38.getRangeAxisEdge();
        try {
            double double52 = categoryAxis8.getCategoryJava2DCoordinate(categoryAnchor21, (int) (byte) 100, (int) (byte) 1, rectangle2D24, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        java.lang.Object obj6 = intervalMarker2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot7.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot7.getDataRange(valueAxis13);
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        java.awt.Color color17 = java.awt.Color.blue;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color17);
        intervalMarker2.setOutlinePaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        intervalMarker2.setLabelTextAnchor(textAnchor20);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        double double10 = categoryAxis9.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        categoryAxis9.addChangeListener(axisChangeListener11);
        categoryAxis9.setLabelAngle((double) 100);
        java.awt.Color color15 = java.awt.Color.WHITE;
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        double double19 = categoryAxis18.getLowerMargin();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis18.setAxisLineStroke(stroke20);
        java.awt.Color color24 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color15, stroke20, (java.awt.Paint) color24, stroke25, 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        double double30 = categoryAxis29.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryAxis29.getTickLabelInsets();
        double double33 = rectangleInsets31.calculateTopInset((double) 100);
        double double35 = rectangleInsets31.calculateLeftOutset((double) 100.0f);
        valueMarker27.setLabelOffset(rectangleInsets31);
        categoryAxis1.setLabelInsets(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.lang.Class class4 = null;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date2, timeZone6);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot10.getRangeMarkers(4, layer20);
        categoryPlot10.mapDatasetToDomainAxis((int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint25 = categoryPlot10.getOutlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot10.setRenderer(categoryItemRenderer26, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke15 = xYPlot13.getRangeGridlineStroke();
        int int16 = xYPlot13.getWeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getRangeAxisEdge((int) (short) 100);
        xYPlot26.clearDomainMarkers();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot32.getDataset((int) (byte) 1);
        boolean boolean36 = categoryPlot32.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot32.getRangeAxis(255);
        categoryPlot32.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryAxis42.getTickLabelInsets();
        java.awt.Paint paint45 = categoryAxis42.getTickLabelPaint();
        categoryAxis42.setLowerMargin((-1.0d));
        java.util.List list48 = categoryPlot32.getCategoriesForAxis(categoryAxis42);
        xYPlot26.drawRangeTickBands(graphics2D30, rectangle2D31, list48);
        xYPlot13.drawRangeTickBands(graphics2D24, rectangle2D25, list48);
        org.jfree.chart.axis.AxisLocation axisLocation52 = null;
        try {
            xYPlot13.setRangeAxisLocation(0, axisLocation52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        double double12 = categoryAxis11.getLowerMargin();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color8, stroke13, (java.awt.Paint) color17, stroke18, 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        double double23 = categoryAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis22.getTickLabelInsets();
        valueMarker20.setLabelOffset(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        java.awt.Paint paint19 = xYPlot13.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation24);
        xYPlot13.setDomainAxisLocation(axisLocation20);
        xYPlot13.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis5.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRange(range16, true, false);
        numberAxis5.setRangeWithMargins(range16, false, true);
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        xYPlot0.setDomainCrosshairValue((double) 0, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double33 = numberAxis32.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setNegativeArrowVisible(false);
        java.awt.Shape shape38 = numberAxis35.getDownArrow();
        numberAxis35.setUpperMargin((double) 100.0f);
        double double41 = numberAxis35.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer42);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str46 = categoryPlot45.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryPlot45.setNoDataMessageFont(font48);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot45.addDomainMarker((int) 'a', categoryMarker52, layer53);
        java.util.Collection collection55 = xYPlot43.getRangeMarkers(3, layer53);
        xYPlot43.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot59.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray62 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer61 };
        xYPlot59.setRenderers(xYItemRendererArray62);
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = xYPlot59.getRendererForDataset(xYDataset64);
        java.awt.geom.Point2D point2D66 = xYPlot59.getQuadrantOrigin();
        xYPlot43.zoomRangeAxes((double) 100L, plotRenderingInfo58, point2D66);
        xYPlot0.zoomRangeAxes(0.2d, plotRenderingInfo29, point2D66);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation69 = null;
        try {
            boolean boolean71 = xYPlot0.removeAnnotation(xYAnnotation69, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(xYItemRendererArray62);
        org.junit.Assert.assertNull(xYItemRenderer65);
        org.junit.Assert.assertNotNull(point2D66);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        try {
            numberAxis1.setRange((double) 12, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (12.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        java.lang.String str17 = categoryAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRange(false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int9 = color8.getAlpha();
        numberAxis1.setLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot11.getFixedLegendItems();
        java.awt.Image image13 = null;
        categoryPlot11.setBackgroundImage(image13);
        categoryPlot11.clearAnnotations();
        boolean boolean16 = numberAxis1.equals((java.lang.Object) categoryPlot11);
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        double double9 = categoryAxis8.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis8.getTickLabelInsets();
        double double12 = rectangleInsets10.calculateLeftOutset(0.0d);
        categoryPlot0.setAxisOffset(rectangleInsets10);
        double double15 = rectangleInsets10.calculateTopOutset((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets10.createOutsetRectangle(rectangle2D16, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        java.awt.Color color2 = java.awt.Color.red;
        boolean boolean3 = unitType0.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        intervalMarker5.setGradientPaintTransformer(gradientPaintTransformer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = intervalMarker5.getLabelOffset();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        intervalMarker5.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = intervalMarker5.getLabelAnchor();
        java.lang.String str12 = rectangleAnchor11.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 2019, (double) (short) -1, rectangleAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str12.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            xYPlot13.handleClick((-1), (int) 'a', plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke15 = xYPlot13.getRangeGridlineStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot13.setDomainGridlinePaint((java.awt.Paint) color16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Color color3 = java.awt.Color.getColor("UnitType.RELATIVE", color2);
        boolean boolean4 = lengthAdjustmentType0.equals((java.lang.Object) color3);
        float[] floatArray5 = null;
        float[] floatArray6 = color3.getRGBColorComponents(floatArray5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = categoryPlot10.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        intervalMarker21.setGradientPaintTransformer(gradientPaintTransformer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        double double26 = categoryAxis25.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryAxis25.getTickLabelInsets();
        java.awt.Paint paint29 = categoryAxis25.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font30 = categoryAxis25.getLabelFont();
        intervalMarker21.setLabelFont(font30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker21.setLabelAnchor(rectangleAnchor32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker21, layer34);
        java.awt.Paint paint36 = intervalMarker21.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
//        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
//        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
//        float float5 = intervalMarker2.getAlpha();
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) float5, jFreeChart6, chartChangeEventType7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        long long11 = day9.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
//        org.jfree.data.xy.XYDataset xYDataset13 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
//        double double16 = numberAxis15.getUpperMargin();
//        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
//        numberAxis18.setNegativeArrowVisible(false);
//        java.awt.Shape shape21 = numberAxis18.getDownArrow();
//        numberAxis18.setUpperMargin((double) 100.0f);
//        double double24 = numberAxis18.getFixedDimension();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
//        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer25);
//        xYPlot26.setRangeGridlinesVisible(false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot26.getRangeAxisEdge(11);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
//        java.awt.geom.Point2D point2D33 = null;
//        xYPlot26.zoomRangeAxes((double) 100.0f, plotRenderingInfo32, point2D33);
//        xYPlot26.setRangeCrosshairValue(0.2d, true);
//        boolean boolean38 = day9.equals((java.lang.Object) xYPlot26);
//        boolean boolean39 = chartChangeEventType7.equals((java.lang.Object) day9);
//        java.lang.String str40 = chartChangeEventType7.toString();
//        java.lang.String str41 = chartChangeEventType7.toString();
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
//        org.junit.Assert.assertNotNull(chartChangeEventType7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
//        org.junit.Assert.assertNotNull(shape21);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangleEdge30);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str40.equals("ChartChangeEventType.NEW_DATASET"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str41.equals("ChartChangeEventType.NEW_DATASET"));
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = numberAxis15.getStandardTickUnits();
        xYPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis15.setMarkerBand(markerAxisBand20);
        numberAxis15.setLowerMargin(0.0d);
        java.lang.Object obj24 = numberAxis15.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace12);
        categoryPlot0.mapDatasetToRangeAxis(1, 12);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        java.awt.Paint paint19 = xYPlot13.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation24);
        xYPlot13.setDomainAxisLocation(axisLocation20);
        java.lang.Object obj28 = xYPlot13.clone();
        boolean boolean29 = xYPlot13.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        categoryPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(100, valueAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot1.getFixedLegendItems();
        java.awt.Image image3 = null;
        categoryPlot1.setBackgroundImage(image3);
        categoryPlot1.clearAnnotations();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.util.List list9 = categoryPlot1.getCategoriesForAxis(categoryAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot1.getFixedDomainAxisSpace();
        boolean boolean11 = categoryPlot1.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot10.getRangeMarkers(4, layer20);
        categoryPlot10.mapDatasetToDomainAxis((int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint25 = categoryPlot10.getOutlinePaint();
        int int26 = categoryPlot10.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(sortOrder4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        java.awt.Color color7 = java.awt.Color.WHITE;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color7);
        categoryAxis1.setLabelToolTip("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.xy.XYDataset xYDataset4 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
//        double double7 = numberAxis6.getUpperMargin();
//        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
//        numberAxis9.setNegativeArrowVisible(false);
//        java.awt.Shape shape12 = numberAxis9.getDownArrow();
//        numberAxis9.setUpperMargin((double) 100.0f);
//        double double15 = numberAxis9.getFixedDimension();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
//        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer16);
//        xYPlot17.setRangeGridlinesVisible(false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(11);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
//        java.awt.geom.Point2D point2D24 = null;
//        xYPlot17.zoomRangeAxes((double) 100.0f, plotRenderingInfo23, point2D24);
//        xYPlot17.setRangeCrosshairValue(0.2d, true);
//        boolean boolean29 = day0.equals((java.lang.Object) xYPlot17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
//        org.junit.Assert.assertNotNull(shape12);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangleEdge21);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        double double7 = rectangleInsets6.getRight();
        double double9 = rectangleInsets6.calculateRightInset((double) 10L);
        double double11 = rectangleInsets6.calculateBottomOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke15 = xYPlot13.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = xYPlot13.getFixedLegendItems();
        java.awt.Paint paint17 = xYPlot13.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(legendItemCollection16);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        double double2 = categoryPlot1.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxisForDataset(0);
        boolean boolean5 = chartChangeEventType0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        long long5 = day4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str6 = categoryAnchor5.toString();
        categoryPlot0.setDomainGridlinePosition(categoryAnchor5);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CategoryAnchor.END" + "'", str6.equals("CategoryAnchor.END"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomRangeAxes((double) 0.0f, plotRenderingInfo12, point2D13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot6.getRendererForDataset(categoryDataset15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        intervalMarker8.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Paint paint11 = intervalMarker8.getLabelPaint();
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = categoryPlot0.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker8, layer12, true);
        org.jfree.chart.text.TextAnchor textAnchor15 = intervalMarker8.getLabelTextAnchor();
        intervalMarker8.setStartValue(100.0d);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        double double10 = categoryAxis9.getLowerMargin();
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Color color12 = color11.darker();
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color11);
        java.awt.Color color14 = color11.brighter();
        numberAxis1.setTickMarkPaint((java.awt.Paint) color14);
        java.awt.Shape shape16 = numberAxis1.getLeftArrow();
        java.awt.Stroke stroke17 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str1.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        double double29 = categoryAxis28.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        categoryAxis28.addChangeListener(axisChangeListener30);
        categoryAxis28.setLabelAngle((double) 100);
        java.awt.Color color34 = java.awt.Color.WHITE;
        categoryAxis28.setTickMarkPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        double double38 = categoryAxis37.getLowerMargin();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis37.setAxisLineStroke(stroke39);
        java.awt.Color color43 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color34, stroke39, (java.awt.Paint) color43, stroke44, 0.0f);
        xYPlot13.setDomainGridlineStroke(stroke44);
        xYPlot13.clearRangeMarkers();
        xYPlot13.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setNegativeArrowVisible(false);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis4.setRange(range7, true, false);
        numberAxis4.resizeRange((-9.0d), (double) 'a');
        java.lang.Object obj14 = null;
        boolean boolean15 = numberAxis4.equals(obj14);
        numberAxis4.setTickMarkInsideLength((float) 8);
        try {
            xYPlot0.setRangeAxis((-16777216), (org.jfree.chart.axis.ValueAxis) numberAxis4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot0.setDomainGridlinePaint(paint7);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        double double13 = categoryAxis12.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener14 = null;
        categoryAxis12.addChangeListener(axisChangeListener14);
        categoryAxis12.setLabelAngle((double) 100);
        java.awt.Color color18 = java.awt.Color.WHITE;
        categoryAxis12.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        double double22 = categoryAxis21.getLowerMargin();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis21.setAxisLineStroke(stroke23);
        java.awt.Color color27 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color18, stroke23, (java.awt.Paint) color27, stroke28, 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        double double33 = categoryAxis32.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis32.getTickLabelInsets();
        double double36 = rectangleInsets34.calculateTopInset((double) 100);
        double double38 = rectangleInsets34.calculateLeftOutset((double) 100.0f);
        valueMarker30.setLabelOffset(rectangleInsets34);
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean42 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) valueMarker30, layer40, false);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder46 = xYPlot45.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray48 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer47 };
        xYPlot45.setRenderers(xYItemRendererArray48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot45.getRendererForDataset(xYDataset50);
        java.awt.geom.Point2D point2D52 = xYPlot45.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        try {
            xYPlot0.draw(graphics2D43, rectangle2D44, point2D52, plotState53, plotRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder46);
        org.junit.Assert.assertNotNull(xYItemRendererArray48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(point2D52);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        java.awt.Paint paint3 = intervalMarker2.getPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot0.axisChanged(axisChangeEvent8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        java.awt.Paint paint19 = xYPlot13.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation24);
        xYPlot13.setDomainAxisLocation(axisLocation20);
        java.lang.Object obj28 = xYPlot13.clone();
        xYPlot13.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        numberAxis7.setUpperMargin((double) 100.0f);
        double double13 = numberAxis7.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer14);
        xYPlot15.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot15.getRangeAxisEdge(11);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis23.setNegativeArrowVisible(false);
        java.awt.Paint paint26 = numberAxis23.getTickMarkPaint();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint26, stroke27, (java.awt.Paint) color28, stroke29, (float) (byte) 1);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean34 = xYPlot15.removeDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker31, layer32, true);
        boolean boolean35 = seriesRenderingOrder0.equals((java.lang.Object) valueMarker31);
        java.lang.String str36 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str36.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        double double4 = numberAxis2.getLowerBound();
        boolean boolean5 = categoryAnchor0.equals((java.lang.Object) numberAxis2);
        numberAxis2.setAutoRange(true);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.Class class0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        double double5 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYPlot0.handleClick(5, 0, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 'a');
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot8.getFixedLegendItems();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        categoryPlot8.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str14 = categoryAnchor13.toString();
        categoryPlot8.setDomainGridlinePosition(categoryAnchor13);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        double double20 = categoryPlot19.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot19.getDataset((int) (byte) 1);
        boolean boolean23 = categoryPlot19.isRangeCrosshairVisible();
        boolean boolean24 = categoryPlot19.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot19.getDomainAxisEdge();
        try {
            double double26 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor13, 0, 0, rectangle2D18, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "CategoryAnchor.END" + "'", str14.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis5.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRange(range16, true, false);
        numberAxis5.setRangeWithMargins(range16, false, true);
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        xYPlot0.setDomainCrosshairValue((double) 0, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double33 = numberAxis32.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setNegativeArrowVisible(false);
        java.awt.Shape shape38 = numberAxis35.getDownArrow();
        numberAxis35.setUpperMargin((double) 100.0f);
        double double41 = numberAxis35.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer42);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str46 = categoryPlot45.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryPlot45.setNoDataMessageFont(font48);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot45.addDomainMarker((int) 'a', categoryMarker52, layer53);
        java.util.Collection collection55 = xYPlot43.getRangeMarkers(3, layer53);
        xYPlot43.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot59.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray62 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer61 };
        xYPlot59.setRenderers(xYItemRendererArray62);
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = xYPlot59.getRendererForDataset(xYDataset64);
        java.awt.geom.Point2D point2D66 = xYPlot59.getQuadrantOrigin();
        xYPlot43.zoomRangeAxes((double) 100L, plotRenderingInfo58, point2D66);
        xYPlot0.zoomRangeAxes(0.2d, plotRenderingInfo29, point2D66);
        xYPlot0.setRangeCrosshairValue((-1.0d), false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(xYItemRendererArray62);
        org.junit.Assert.assertNull(xYItemRenderer65);
        org.junit.Assert.assertNotNull(point2D66);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.darker();
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot7.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot7.setRenderer(categoryItemRenderer13);
        double double15 = categoryPlot7.getRangeCrosshairValue();
        boolean boolean16 = chartChangeEventType0.equals((java.lang.Object) categoryPlot7);
        int int17 = categoryPlot7.getDomainAxisCount();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.lang.Class<?> wildcardClass7 = categoryPlot0.getClass();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        double double28 = categoryPlot27.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot27.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot27.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.Range range34 = categoryPlot27.getDataRange(valueAxis33);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        java.awt.Color color37 = java.awt.Color.blue;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color37);
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot13.getDomainAxisEdge((int) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNull(categoryAxis32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        java.awt.Paint paint13 = categoryPlot6.getNoDataMessagePaint();
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        boolean boolean15 = categoryPlot6.isSubplot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 15, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        xYPlot13.clearRangeMarkers();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setDomainCrosshairStroke(stroke27);
        boolean boolean29 = xYPlot13.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        categoryPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(100, valueAxis5, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean11 = categoryPlot0.removeAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean13 = sortOrder11.equals((java.lang.Object) lengthAdjustmentType12);
        java.lang.String str14 = lengthAdjustmentType12.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        categoryAxis17.addChangeListener(axisChangeListener19);
        categoryAxis17.setLabelAngle((double) 100);
        java.awt.Color color23 = java.awt.Color.WHITE;
        categoryAxis17.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        double double27 = categoryAxis26.getLowerMargin();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis26.setAxisLineStroke(stroke28);
        java.awt.Color color32 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color23, stroke28, (java.awt.Paint) color32, stroke33, 0.0f);
        boolean boolean36 = lengthAdjustmentType12.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "NO_CHANGE" + "'", str14.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Class class0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        int int5 = day4.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin(0.05d);
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis13.getTickLabelInsets();
        double double17 = rectangleInsets15.trimWidth((double) (-1));
        double double18 = rectangleInsets15.getRight();
        categoryAxis1.setLabelInsets(rectangleInsets15);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets15.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(unitType20, (double) ' ', 0.0d, (double) (short) 10, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.0d) + "'", double17 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(unitType20);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        double double2 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        xYPlot13.clearRangeMarkers();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setDomainCrosshairStroke(stroke27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot13.setRenderer(xYItemRenderer29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis33.setNegativeArrowVisible(false);
        java.awt.Paint paint36 = numberAxis33.getTickMarkPaint();
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint36, stroke37, (java.awt.Paint) color38, stroke39, (float) (byte) 1);
        xYPlot13.setDomainCrosshairPaint(paint36);
        org.jfree.chart.axis.AxisSpace axisSpace43 = xYPlot13.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(axisSpace43);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis1.getStandardTickUnits();
        boolean boolean6 = numberAxis1.isAutoRange();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot7.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot7.getRangeAxisEdge();
        java.awt.Image image14 = categoryPlot7.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        double double22 = categoryAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis21.getTickLabelInsets();
        java.awt.Paint paint25 = categoryAxis21.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font26 = categoryAxis21.getLabelFont();
        intervalMarker17.setLabelFont(font26);
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        double double31 = categoryAxis30.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryAxis30.getTickLabelInsets();
        java.awt.Paint paint34 = categoryAxis30.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        double double36 = categoryAxis30.getLowerMargin();
        categoryAxis30.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot39.getFixedLegendItems();
        java.awt.Image image41 = null;
        categoryPlot39.setBackgroundImage(image41);
        java.util.List list43 = categoryPlot39.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot39.getDomainAxisEdge();
        boolean boolean45 = categoryAxis30.hasListener((java.util.EventListener) categoryPlot39);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis47.setNegativeArrowVisible(false);
        categoryPlot39.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis47);
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis47.setTickLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis47.isNegativeArrowVisible();
        boolean boolean54 = intervalMarker17.equals((java.lang.Object) numberAxis47);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis56.setNegativeArrowVisible(false);
        org.jfree.data.Range range59 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis56.setRange(range59, true, false);
        numberAxis47.setRangeWithMargins(range59, false, true);
        numberAxis1.setDefaultAutoRange(range59);
        numberAxis1.setRangeAboutValue(100.0d, (double) 4);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNull(list43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(8, (int) (byte) 10, 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color22 = java.awt.Color.BLACK;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color22);
        int int24 = color22.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Color color35 = java.awt.Color.blue;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot25.getIndexOf(categoryItemRenderer37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color39);
        java.util.List list41 = categoryPlot25.getAnnotations();
        boolean boolean42 = color22.equals((java.lang.Object) list41);
        xYPlot13.drawRangeTickBands(graphics2D18, rectangle2D19, list41);
        int int44 = xYPlot13.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot45.getFixedLegendItems();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        categoryPlot45.drawBackgroundImage(graphics2D47, rectangle2D48);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str51 = categoryAnchor50.toString();
        categoryPlot45.setDomainGridlinePosition(categoryAnchor50);
        xYPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot45);
        xYPlot13.setWeight(11);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation56 = null;
        try {
            boolean boolean57 = xYPlot13.removeAnnotation(xYAnnotation56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(categoryAnchor50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "CategoryAnchor.END" + "'", str51.equals("CategoryAnchor.END"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis5.setTickUnit(numberTickUnit14, true, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis5.setTickUnit(numberTickUnit18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(numberTickUnit18);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (byte) 0);
        double double4 = rectangleInsets0.calculateTopOutset((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-16.0d) + "'", double2 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.centerRange(1.0d);
        numberAxis1.setTickLabelsVisible(true);
        numberAxis1.setAutoRangeMinimumSize((double) 6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Paint paint24 = numberAxis21.getTickMarkPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint24, stroke25, (java.awt.Paint) color26, stroke27, (float) (byte) 1);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean32 = xYPlot13.removeDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker29, layer30, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        xYPlot13.rendererChanged(rendererChangeEvent33);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot5.getDataset((int) (byte) 1);
        boolean boolean9 = categoryPlot5.isRangeCrosshairVisible();
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot5.getAxisOffset();
        double double12 = rectangleInsets11.getRight();
        categoryPlot0.setAxisOffset(rectangleInsets11);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.handleClick(0, 0, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        double double4 = categoryAxis3.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        categoryAxis3.addChangeListener(axisChangeListener5);
        categoryAxis3.setLabelAngle((double) 100);
        java.awt.Color color9 = java.awt.Color.WHITE;
        categoryAxis3.setTickMarkPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        double double13 = categoryAxis12.getLowerMargin();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis12.setAxisLineStroke(stroke14);
        java.awt.Color color18 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color9, stroke14, (java.awt.Paint) color18, stroke19, 0.0f);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot22.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.data.general.Dataset dataset26 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stroke25, dataset26);
        xYPlot22.setRangeGridlineStroke(stroke25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-4.0d), (java.awt.Paint) color18, stroke25);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        xYPlot13.clearAnnotations();
        boolean boolean19 = xYPlot13.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        double double22 = categoryAxis21.getLowerMargin();
        java.awt.Color color23 = java.awt.Color.WHITE;
        java.awt.Color color24 = color23.darker();
        categoryAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        double double27 = categoryPlot26.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset29 = categoryPlot26.getDataset((int) (byte) 1);
        categoryAxis21.setPlot((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot26.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot26.getRangeAxisLocation();
        java.awt.Paint paint33 = categoryPlot26.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot26.getLegendItems();
        xYPlot13.setFixedLegendItems(legendItemCollection34);
        org.jfree.chart.JFreeChart jFreeChart36 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot13, jFreeChart36);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset29);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(legendItemCollection34);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setNegativeArrowVisible(false);
        java.awt.Paint paint5 = numberAxis2.getTickMarkPaint();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint5, stroke6, (java.awt.Paint) color7, stroke8, (float) (byte) 1);
        float float11 = valueMarker10.getAlpha();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str8 = plotOrientation7.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        double double11 = categoryAxis10.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        java.awt.Paint paint14 = categoryAxis10.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font15 = categoryAxis10.getLabelFont();
        double double16 = categoryAxis10.getLowerMargin();
        categoryAxis10.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot19.getFixedLegendItems();
        java.awt.Image image21 = null;
        categoryPlot19.setBackgroundImage(image21);
        java.util.List list23 = categoryPlot19.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot19.getDomainAxisEdge();
        boolean boolean25 = categoryAxis10.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        categoryPlot19.notifyListeners(plotChangeEvent26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot19.getRangeMarkers(4, layer29);
        categoryPlot19.mapDatasetToDomainAxis((int) (short) 100, (int) (byte) 10);
        boolean boolean34 = plotOrientation7.equals((java.lang.Object) categoryPlot19);
        categoryPlot0.setOrientation(plotOrientation7);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str8.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertNull(list23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.Marker marker7 = markerChangeEvent6.getMarker();
        java.awt.Stroke stroke8 = marker7.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis14.setNegativeArrowVisible(false);
        java.awt.Shape shape17 = numberAxis14.getDownArrow();
        numberAxis14.setUpperMargin((double) 100.0f);
        double double20 = numberAxis14.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer21);
        boolean boolean23 = xYPlot22.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke24 = xYPlot22.getRangeGridlineStroke();
        java.awt.Paint paint25 = xYPlot22.getRangeCrosshairPaint();
        marker7.setLabelPaint(paint25);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(marker7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        java.lang.String str2 = axisLocation0.toString();
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str2.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = intervalMarker2.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        double double13 = categoryAxis1.getLowerMargin();
        categoryAxis1.setAxisLineVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        boolean boolean18 = categoryAxis1.equals((java.lang.Object) defaultDrawingSupplier16);
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = intervalMarker2.getLabelAnchor();
        java.lang.String str9 = rectangleAnchor8.toString();
        java.lang.String str10 = rectangleAnchor8.toString();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str9.equals("RectangleAnchor.TOP_LEFT"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str10.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        xYPlot13.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer25 };
        xYPlot13.setRenderers(xYItemRendererArray26);
        xYPlot13.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(xYItemRendererArray26);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        xYPlot13.setRangeCrosshairLockedOnData(false);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        xYPlot13.drawAnnotations(graphics2D22, rectangle2D23, plotRenderingInfo24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D15 = xYPlot13.getQuadrantOrigin();
        java.util.List list16 = xYPlot13.getAnnotations();
        int int17 = xYPlot13.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot13.getDomainAxisLocation((int) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        double double5 = categoryAxis4.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis4.getTickLabelInsets();
        double double8 = rectangleInsets6.calculateTopInset((double) 100);
        categoryMarker1.setLabelOffset(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        intervalMarker3.setGradientPaintTransformer(gradientPaintTransformer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = intervalMarker3.getLabelOffset();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        intervalMarker3.setOutlinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = intervalMarker3.getLabelAnchor();
        java.lang.String str10 = rectangleAnchor9.toString();
        try {
            java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str10.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.centerRange((double) (byte) 0);
        numberAxis1.zoomRange((double) (byte) -1, (double) 2.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        double double7 = numberAxis1.getFixedDimension();
        boolean boolean8 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot8.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot8.getRangeAxis();
        java.awt.Stroke stroke11 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        intervalMarker16.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Paint paint19 = intervalMarker16.getLabelPaint();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot8.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker16, layer20, true);
        java.util.Collection collection23 = categoryPlot0.getRangeMarkers(layer20);
        java.awt.Paint paint24 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer26, true);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setNegativeArrowVisible(false);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis9.setRange(range12, true, false);
        numberAxis1.setRangeWithMargins(range12, false, true);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        double double22 = categoryPlot21.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot21.getDataset((int) (byte) 1);
        boolean boolean25 = categoryPlot21.isRangeCrosshairVisible();
        boolean boolean26 = categoryPlot21.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot21.getDomainAxisEdge();
        try {
            double double28 = numberAxis1.valueToJava2D((double) (byte) 100, rectangle2D20, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        java.util.Date date51 = dateAxis50.getMaximumDate();
        java.awt.Color color52 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass53 = color52.getClass();
        java.util.Date date54 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        java.lang.Class class56 = null;
        java.util.Date date57 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone58);
        java.awt.Color color61 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass62 = color61.getClass();
        java.util.Date date63 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        java.lang.Class class65 = null;
        java.util.Date date66 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date63, timeZone67);
        java.lang.Class class70 = null;
        java.util.Date date71 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date71, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date63, timeZone72);
        java.util.Date date75 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color76 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass77 = color76.getClass();
        java.util.Date date78 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date78);
        java.lang.Class class80 = null;
        java.util.Date date81 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date81, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date75, timeZone82);
        java.util.Date date86 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date86);
        try {
            dateAxis50.setRange(date75, date86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(date86);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        try {
            categoryPlot0.handleClick((int) (short) -1, 11, plotRenderingInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        try {
            categoryPlot6.setDataset((-65281), categoryDataset14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.JFreeChart jFreeChart7 = markerChangeEvent6.getChart();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(jFreeChart7);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureRangeAxes();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            categoryPlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13, stroke14 };
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray9, strokeArray15, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        boolean boolean21 = defaultDrawingSupplier17.equals((java.lang.Object) categoryAxis20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        categoryPlot25.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot25.getRangeAxisEdge((int) (byte) -1);
        try {
            double double37 = categoryAxis20.getCategoryMiddle((int) (byte) 1, (int) (short) -1, rectangle2D24, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color3 = java.awt.Color.BLACK;
        categoryAxis2.setTickLabelPaint((java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.getColor("AxisLocation.TOP_OR_LEFT", color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke4);
        xYPlot0.setDomainGridlineStroke(stroke4);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        double double9 = categoryPlot8.getAnchorValue();
        categoryPlot8.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot13.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot13.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot13.getDomainAxisLocation(255);
        categoryPlot8.setDomainAxisLocation((int) (byte) 100, axisLocation17);
        xYPlot0.setRangeAxisLocation((int) 'a', axisLocation17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            boolean boolean15 = categoryPlot0.removeAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            xYPlot0.handleClick((int) '4', 500, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.centerRange((double) (byte) 0);
        numberAxis1.setAutoRangeMinimumSize((double) 10.0f, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setUpperMargin((-1.0d));
        categoryAxis1.setLabelAngle((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str10 = categoryPlot9.getNoDataMessage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot9.getIndexOf(categoryItemRenderer11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        categoryPlot9.datasetChanged(datasetChangeEvent13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        boolean boolean22 = categoryPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        categoryPlot0.addDomainMarker(categoryMarker21);
        java.lang.String str24 = categoryMarker21.getLabel();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis10.setNegativeArrowVisible(false);
        java.awt.Shape shape13 = numberAxis10.getDownArrow();
        numberAxis10.setUpperMargin((double) 100.0f);
        double double16 = numberAxis10.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer17);
        boolean boolean19 = xYPlot18.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D20 = xYPlot18.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot0.draw(graphics2D3, rectangle2D4, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(point2D20);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        categoryPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomDomainAxes((double) 2, plotRenderingInfo14, point2D15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        double double6 = categoryAxis5.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis5.getTickLabelInsets();
        java.awt.Paint paint9 = categoryAxis5.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font10 = categoryAxis5.getLabelFont();
        double double11 = categoryAxis5.getLowerMargin();
        categoryAxis5.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot14.getFixedLegendItems();
        java.awt.Image image16 = null;
        categoryPlot14.setBackgroundImage(image16);
        java.util.List list18 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot14.getDomainAxisEdge();
        boolean boolean20 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis22.setNegativeArrowVisible(false);
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis22.setTickLabelPaint((java.awt.Paint) color26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis29.setNegativeArrowVisible(false);
        java.awt.Shape shape32 = numberAxis29.getDownArrow();
        numberAxis29.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = numberAxis29.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis37.setNegativeArrowVisible(false);
        org.jfree.data.Range range40 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis37.setRange(range40, true, false);
        numberAxis29.setRangeWithMargins(range40, false, true);
        numberAxis22.setRangeWithMargins(range40);
        double double48 = numberAxis22.getFixedAutoRange();
        int int49 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(markerAxisBand35);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.trimWidth((double) (-1));
        double double6 = rectangleInsets3.getRight();
        java.lang.String str7 = rectangleInsets3.toString();
        double double8 = rectangleInsets3.getBottom();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str7.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis2.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis2.getTickLabelPaint();
        categoryAxis2.setLowerMargin((-1.0d));
        boolean boolean8 = textAnchor0.equals((java.lang.Object) (-1.0d));
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color5);
        float[] floatArray13 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray14 = color5.getRGBComponents(floatArray13);
        int int15 = color5.getTransparency();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot7.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot7.getRangeAxis();
        java.awt.Stroke stroke10 = categoryPlot7.getRangeGridlineStroke();
        categoryPlot7.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = null;
        intervalMarker15.setGradientPaintTransformer(gradientPaintTransformer16);
        java.awt.Paint paint18 = intervalMarker15.getLabelPaint();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = categoryPlot7.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker15, layer19, true);
        org.jfree.chart.text.TextAnchor textAnchor22 = intervalMarker15.getLabelTextAnchor();
        boolean boolean23 = intervalMarker2.equals((java.lang.Object) textAnchor22);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(legendItemCollection8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Paint paint24 = numberAxis21.getTickMarkPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint24, stroke25, (java.awt.Paint) color26, stroke27, (float) (byte) 1);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean32 = xYPlot13.removeDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker29, layer30, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        double double35 = categoryAxis34.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryAxis34.getTickLabelInsets();
        double double38 = rectangleInsets36.trimWidth((double) (-1));
        double double39 = rectangleInsets36.getRight();
        valueMarker29.setLabelOffset(rectangleInsets36);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        double double42 = categoryPlot41.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot41.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot41.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.Range range48 = categoryPlot41.getDataRange(valueAxis47);
        java.awt.Paint paint49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot41.setNoDataMessagePaint(paint49);
        java.awt.Color color51 = java.awt.Color.blue;
        categoryPlot41.setNoDataMessagePaint((java.awt.Paint) color51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        int int54 = categoryPlot41.getIndexOf(categoryItemRenderer53);
        java.awt.Color color55 = java.awt.Color.darkGray;
        categoryPlot41.setNoDataMessagePaint((java.awt.Paint) color55);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("");
        double double59 = categoryAxis58.getLowerMargin();
        java.awt.Paint paint61 = categoryAxis58.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color62 = java.awt.Color.MAGENTA;
        categoryAxis58.setTickMarkPaint((java.awt.Paint) color62);
        float[] floatArray70 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray71 = color62.getRGBComponents(floatArray70);
        float[] floatArray72 = color55.getRGBComponents(floatArray70);
        valueMarker29.setPaint((java.awt.Paint) color55);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-9.0d) + "'", double38 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertNull(categoryAxis46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertNotNull(floatArray72);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRange(false);
        org.jfree.data.Range range8 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        categoryAxis13.addChangeListener(axisChangeListener15);
        categoryAxis13.setLabelAngle((double) 100);
        boolean boolean19 = categoryAxis13.isTickLabelsVisible();
        categoryAxis13.setTickMarkInsideLength((float) 10L);
        int int22 = categoryPlot0.getDomainAxisIndex(categoryAxis13);
        org.jfree.data.general.Dataset dataset23 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, dataset23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.configure();
        categoryAxis1.setLabel("ChartChangeEventType.NEW_DATASET");
        org.jfree.chart.plot.Plot plot16 = categoryAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(plot16);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.calculateTopInset((double) 100);
        double double7 = rectangleInsets3.calculateLeftOutset((double) 100.0f);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets3.getUnitType();
        double double10 = rectangleInsets3.calculateRightInset((double) 500);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.centerRange((double) (byte) 0);
        numberAxis1.setVisible(true);
        numberAxis1.centerRange((double) 8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        int int11 = categoryPlot0.getDatasetCount();
        categoryPlot0.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis5.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRange(range16, true, false);
        numberAxis5.setRangeWithMargins(range16, false, true);
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        xYPlot0.setDomainCrosshairValue((double) 0, false);
        double double28 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        try {
            xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo30, point2D31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        java.lang.Object obj5 = numberAxis1.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes((double) 4, (double) (short) -1, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape13 = defaultDrawingSupplier12.getNextShape();
        java.awt.Shape shape14 = defaultDrawingSupplier12.getNextShape();
        java.awt.Shape shape15 = defaultDrawingSupplier12.getNextShape();
        java.awt.Stroke stroke16 = defaultDrawingSupplier12.getNextStroke();
        java.awt.Stroke stroke17 = defaultDrawingSupplier12.getNextStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke17);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        boolean boolean27 = xYPlot13.isDomainZeroBaselineVisible();
        boolean boolean28 = xYPlot13.isRangeCrosshairLockedOnData();
        xYPlot13.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation((int) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot12.setRenderers(categoryItemRendererArray14);
        categoryPlot12.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot12.zoomRangeAxes((double) (-1.0f), plotRenderingInfo19, point2D20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke23 = xYPlot22.getRangeZeroBaselineStroke();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) xYPlot22, dataset24);
        categoryPlot12.datasetChanged(datasetChangeEvent25);
        categoryPlot0.datasetChanged(datasetChangeEvent25);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 'a');
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        java.lang.String str6 = categoryAxis1.getLabel();
        org.jfree.chart.plot.Plot plot7 = categoryAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(plot7);
    }
}

